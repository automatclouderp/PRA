# -*- coding: utf-8 -*-
# Copyright 2016 Openworx, LasLabs Inc.
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl.html).

{
    "name": "Professional theme v9",
    "summary": """
    Backend theme v9!
    
Professional them, for Professional business
""",
    "version": "1.0",
    "category": "Themes/Backend",
    'live_test_url':'http://automat.co.in',
    "website": "http://www.automat.co.in",
	"description": """
		Professional theme v9 community edition.
    """,
	'images':[
        'images/screen.png'
	],
    "author": "Anil Kumar R",
    "license": "LGPL-3",
    "installable": True,
    "depends": [
        'web',
    ],
    "data": [
        'views/assets.xml',
        'views/web.xml',
    ],
}

