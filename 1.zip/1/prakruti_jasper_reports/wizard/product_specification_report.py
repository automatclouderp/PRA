# -*- coding: utf-8 -*-
import pdb
from openerp.osv import osv,fields
from openerp.tools.translate import _
import time
from datetime import datetime,date
from dateutil.relativedelta import relativedelta


class product_specification_report(osv.osv_memory):
    _name = "report.product_specification_report"
    _description = "Product Specification Report"

    _columns = {
        'product_id': fields.many2one('product.template', 'Product', required=True),
        
        'report_type':fields.selection([('html','HTML'),
					  ('csv','CSV'),
					  ('xls','XLS'),
					  ('rtf','RTF'),
					  ('odt','ODT'),
					  ('ods','ODS'),
					  ('txt','Text'),
					  ('pdf','PDF')], 'Type', required=True)
        }


    def print_report(self, cr, uid, ids, data, context=None):
        for wiz_obj in self.read(cr, uid, ids):
            if 'form' not in data:
                data['form'] = {}
                data['form']['product_id'] = wiz_obj['product_id']
                report_name = 'jasper_product_specification_report'
                report_type = wiz_obj['report_type']
            return {
                'type': 'ir.actions.report.xml',
                'report_name': report_name,
                'report_type': report_type,
                'datas': data,
                }

    #def print_report(self, cr, uid, ids, context=None):

        #data = self.read(cr, uid, ids,)[-1]
        #report = {
            #'type' : 'ir.actions.report.xml',
            #'datas': {
                #'model':'product.template',
                #'id': context.get('active_ids') and context.get('active_ids')[0] or False,
                #'ids': context.get('active_ids') and context.get('active_ids') or [],
                #'report_type': data['report_type'],
                #'form': data,
                #},
            #'report_name': 'jasper_product_specification_report',
            #'nodestroy': True
            #}
        #return report
    
product_specification_report()
