from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import time
from datetime import datetime
from operator import itemgetter

import openerp
from openerp import SUPERUSER_ID
from openerp import tools
from openerp.addons.base.res.res_partner import format_address
from openerp.osv import fields, osv, orm
from openerp.tools.translate import _
from openerp.tools import email_re, email_split
import re
import openerp.addons.decimal_precision as dp
from openerp import netsvc
import pdb

class material_receipt_report(osv.osv_memory):
    _name = "report.material_receipt_report"
    _description = "Material Receipt Report"
    
    def get_product_ids(self, cr, uid, context=None):
        cr.execute('''  select cast(id as character varying)as id,name from product_template ''') 
        return cr.fetchall()

    _columns = {
        'product_ids': fields.selection(get_product_ids, string='Product Name', required=True),
        'report_type':fields.selection([('html','HTML'),
					  ('csv','CSV'),
					  ('xls','XLS'),
					  ('rtf','RTF'),
					  ('odt','ODT'),
					  ('ods','ODS'),
					  ('txt','Text'),
					  ('pdf','PDF')], 'Type', required=True)
        }

    def start_report(self, cr, uid, ids, data, context=None):
        for wiz_obj in self.read(cr, uid, ids):
            if 'form' not in data:

                data['form'] = {}
                data['form']['product_ids'] = wiz_obj['product_ids']

                report_name = 'jasper_material_receipt_report'
                report_type = wiz_obj['report_type']

                return {
                    'type': 'ir.actions.report.xml',
                    'report_name': report_name,
                    'report_type': report_type,
                    'datas': data
                    }
            
    _defaults = {
        'report_type': lambda *a: 'pdf', 
        }
    
material_receipt_report()
