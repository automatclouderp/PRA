# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import sale
import sale_analytic
import sales_team
import res_partner
import wizard
import report
import res_config
