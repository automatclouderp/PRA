# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
import test_sale_to_invoice
import test_sale_order
from . import test_product_id_change
