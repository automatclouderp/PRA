# -*- coding: utf-8 -*-

import time
from datetime import datetime
from openerp import tools
from openerp.osv import osv, fields
from functools import partial
from datetime import timedelta as td

from openerp.report import report_sxw
from dateutil.relativedelta import relativedelta
from openerp import SUPERUSER_ID

class report_prakruti_vendor_wise_list(report_sxw.rml_parse):    
    def get_prakruti_vendor_wise_list(self, data):
        form = data['form']
        self.cr.execute('''SELECT order_date,vendor,product,uom,quantity,unit_price,subtotal,freight_total_value FROM vendor_wise_statement_report(CAST(%s as character varying),CAST(%s as character varying))
''',((form['vendor_id']),(form['product_id']),))
        res = self.cr.dictfetchall()
        print res,'Report ---------1'
        return res
    
    def get_flag(self, data):
        res = {}
        res['flag'] = data['form']['is_detail']
        print res,'Report ---------15'
        return res
    
    def __init__(self, cr, uid, name, context):      
        super(report_prakruti_vendor_wise_list, self).__init__(cr, uid, name, context=context)
        self.context = context
        self.localcontext.update({
            'time': time,
            'set_prakruti_vendor_wise_list': self.get_prakruti_vendor_wise_list,
            'get_flag': self.get_flag
        })

   
class wrapped_report_sp(osv.AbstractModel):
    _name = 'report.prakruti_qweb_reports.report_vendor_wise_list'
    _inherit = 'report.abstract_report'
    _template = 'prakruti_qweb_reports.report_vendor_wise_list'
    _wrapped_report_class = report_prakruti_vendor_wise_list