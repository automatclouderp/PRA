# -*- coding: utf-8 -*-
import time
from datetime import datetime
from openerp import tools
from openerp.osv import osv, fields
from functools import partial
from datetime import timedelta as td
from openerp.report import report_sxw
from dateutil.relativedelta import relativedelta
from openerp import SUPERUSER_ID

class report_prakruti_pending_purchase_order(report_sxw.rml_parse):    
    def get_prakruti_pending_purchase_order(self, data):
        form = data['form']
        self.cr.execute("SELECT prakruti_purchase_order.order_date,res_partner.name as vendor,product_product.name_template,prakruti_purchase_line.quantity,sum(prakruti_purchase_line.quantity) as quantity,prakruti_purchase_order.po_no,product_uom.name as uom,sum(prakruti_purchase_line.quantity) as quantity,prakruti_purchase_line.remarks FROM prakruti_purchase_order INNER JOIN prakruti_purchase_line ON prakruti_purchase_order.id = prakruti_purchase_line.purchase_line_id INNER JOIN product_product ON product_product.id = prakruti_purchase_line.product_id INNER JOIN product_uom ON product_uom.id = prakruti_purchase_line.uom_id INNER JOIN res_partner ON res_partner.id = prakruti_purchase_order.vendor_id  WHERE prakruti_purchase_order.order_date BETWEEN %s AND %s AND prakruti_purchase_order.state = 'order' GROUP BY prakruti_purchase_order.order_date,prakruti_purchase_order.po_no,res_partner.name,product_product.name_template,product_uom.name,prakruti_purchase_line.remarks,prakruti_purchase_line.quantity ORDER BY prakruti_purchase_order.po_no",((form['from_date']),(form['to_date']),))
        res = self.cr.dictfetchall()
        print res,'Report ---------1'
        return res
    
    def get_flag(self, data):
        res = {}
        res['flag'] = data['form']['is_detail']
        print res,'Report ---------2'
        return res
    
    def __init__(self, cr, uid, name, context):      
        super(report_prakruti_pending_purchase_order, self).__init__(cr, uid, name, context=context)
        self.context = context
        self.localcontext.update({
            'time': time,
            'set_prakruti_pending_purchase_order': self.get_prakruti_pending_purchase_order,
            'get_flag': self.get_flag
        })

   
class wrapped_report_sp(osv.AbstractModel):
    _name = 'report.prakruti_qweb_reports.report_pending_purchase_order'
    _inherit = 'report.abstract_report'
    _template = 'prakruti_qweb_reports.report_pending_purchase_order'
    _wrapped_report_class = report_prakruti_pending_purchase_order