# -*- coding: utf-8 -*-
import time
from datetime import datetime
from openerp import tools
from openerp.osv import osv, fields
from functools import partial
from datetime import timedelta as td

from openerp.report import report_sxw
from dateutil.relativedelta import relativedelta
from openerp import SUPERUSER_ID

class report_prakruti_logistics_po_tracking(report_sxw.rml_parse):
    
    def get_prakruti_logistics_po_tracking(self, data):
        form = data['form']
        self.cr.execute('''SELECT order_date as date,po_no,expected_date as tracking_date,order_date,tracking_number,actual_date,expected_date,status,* from   prakruti_logistics_po_tracking WHERE order_date BETWEEN %s AND %s AND vendor_id=%s''',((form['from_date']),(form['to_date']),(form['vendor_id'][0]),))
        res = self.cr.dictfetchall()
        print res,'Product Date Wise Stock - Report ---------1'
        return res
    
    def get_flag(self, data):
        res = {}
        res['flag'] = data['form']['is_detail']
        print res,'Get Product Date Wise Stock - Report ---------2'
        return res
    
    def __init__(self, cr, uid, name, context):      
        super(report_prakruti_logistics_po_tracking, self).__init__(cr, uid, name, context=context)
        self.context = context
        self.localcontext.update({
            'time': time,
            'set_prakruti_logistics_po_tracking': self.get_prakruti_logistics_po_tracking,
            'get_flag': self.get_flag
        })

   
class wrapped_report_sp(osv.AbstractModel):
    _name = 'report.prakruti_qweb_reports.report_logistics_po_tracking'
    _inherit = 'report.abstract_report'
    _template = 'prakruti_qweb_reports.report_logistics_po_tracking'
    _wrapped_report_class = report_prakruti_logistics_po_tracking