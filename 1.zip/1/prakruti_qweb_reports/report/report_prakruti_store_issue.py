# -*- coding: utf-8 -*-
import time
from datetime import datetime
from openerp import tools
from openerp.osv import osv, fields
from functools import partial
from datetime import timedelta as td

from openerp.report import report_sxw
from dateutil.relativedelta import relativedelta
from openerp import SUPERUSER_ID

class report_prakruti_store_issue(report_sxw.rml_parse):
    
    def get_prakruti_store_issue(self, data):
        form = data['form']
        self.cr.execute("SELECT issue_date,issue_no,approved_quantity,issued_quantity,name,name_template FROM store_issue_summary_report(%s,%s)",((form['from_date']),(form['to_date']),))
        res = self.cr.dictfetchall()
        print res,'Store Issue Summary - Report ---------1'
        return res
    
    def get_flag(self, data):
        res = {}
        res['flag'] = data['form']['is_detail']
        print res,'Get Store Issue Summary - Report ---------15'
        return res
    
    def __init__(self, cr, uid, name, context):      
        super(report_prakruti_store_issue, self).__init__(cr, uid, name, context=context)
        self.context = context
        self.localcontext.update({
            'time': time,
            'set_prakruti_store_issue': self.get_prakruti_store_issue,
            'get_flag': self.get_flag
        })

   
class wrapped_report_sp(osv.AbstractModel):
    _name = 'report.prakruti_qweb_reports.report_store_issue'
    _inherit = 'report.abstract_report'
    _template = 'prakruti_qweb_reports.report_store_issue'
    _wrapped_report_class = report_prakruti_store_issue  