# -*- coding: utf-8 -*-
import time
from datetime import datetime
from openerp import tools
from openerp.osv import osv, fields
from functools import partial
from datetime import timedelta as td

from openerp.report import report_sxw
from dateutil.relativedelta import relativedelta
from openerp import SUPERUSER_ID

class report_prakruti_logistics_invoice_tracking(report_sxw.rml_parse):
    
    def get_prakruti_logistics_invoice_tracking(self, data):
        form = data['form']
        self.cr.execute('''SELECT prakruti_logistics_invoice_tracking.order_date as date,prakruti_sales_order.order_no,prakruti_logistics_invoice_tracking.expected_date as tracking_date,prakruti_logistics_invoice_tracking.order_date,prakruti_logistics_invoice_tracking.tracking_number,prakruti_logistics_invoice_tracking.actual_date,prakruti_logistics_invoice_tracking.expected_date,prakruti_logistics_invoice_tracking.status FROM prakruti_logistics_invoice_tracking INNER JOIN prakruti_sales_order ON prakruti_logistics_invoice_tracking.order_no = prakruti_sales_order.id WHERE prakruti_logistics_invoice_tracking.order_date BETWEEN %s AND %s AND prakruti_logistics_invoice_tracking.customer_id=%s''',((form['from_date']),(form['to_date']),(form['customer_id'][0]),))
        res = self.cr.dictfetchall()
        print res,'Invoice Tracking- Report ---------1'
        return res
    
    def get_flag(self, data):
        res = {}
        res['flag'] = data['form']['is_detail']
        print res,'Get Invoice Tracking- Report ---------2'
        return res
    
    def __init__(self, cr, uid, name, context):      
        super(report_prakruti_logistics_invoice_tracking, self).__init__(cr, uid, name, context=context)
        self.context = context
        self.localcontext.update({
            'time': time,
            'set_prakruti_logistics_invoice_tracking': self.get_prakruti_logistics_invoice_tracking,
            'get_flag': self.get_flag
        })

   
class wrapped_report_sp(osv.AbstractModel):
    _name = 'report.prakruti_qweb_reports.report_logistics_invoice_tracking'
    _inherit = 'report.abstract_report'
    _template = 'prakruti_qweb_reports.report_logistics_invoice_tracking'
    _wrapped_report_class = report_prakruti_logistics_invoice_tracking