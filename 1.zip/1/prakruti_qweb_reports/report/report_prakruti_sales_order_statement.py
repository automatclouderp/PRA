# -*- coding: utf-8 -*-
import time
from datetime import datetime
from openerp import tools
from openerp.osv import osv, fields
from functools import partial
from datetime import timedelta as td
from openerp.report import report_sxw
from dateutil.relativedelta import relativedelta
from openerp import SUPERUSER_ID

class report_prakruti_sales_order_statement(report_sxw.rml_parse):
    
    def get_prakruti_sales_order_statement(self, data):
        form = data['form']
        self.cr.execute('''SELECT order_date,name_template,quantity,name,unit_price,amount FROM sales_order_statement_report(%s,CAST(%s as character varying),%s,%s)''',((form['customer_id'][0]),(form['product_id']),(form['from_date']),(form['to_date']),))
        res = self.cr.dictfetchall()
        print res,'Sales Statement Report ---------1'
        return res
    
    def get_flag(self, data):
        res = {}
        res['flag'] = data['form']['is_detail']
        print res,'Get Sales Statement Report ---------15'
        return res
    
    def __init__(self, cr, uid, name, context):      
        super(report_prakruti_sales_order_statement, self).__init__(cr, uid, name, context=context)
        self.context = context
        self.localcontext.update({
            'time': time,
            'set_prakruti_sales_order_statement': self.get_prakruti_sales_order_statement,
            'get_flag': self.get_flag
        })

   
class wrapped_report_sp(osv.AbstractModel):
    _name = 'report.prakruti_qweb_reports.report_sales_order_statement'
    _inherit = 'report.abstract_report'
    _template = 'prakruti_qweb_reports.report_sales_order_statement'
    _wrapped_report_class = report_prakruti_sales_order_statement  