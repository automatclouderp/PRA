# -*- coding: utf-8 -*-
import time
from datetime import datetime
from openerp import tools
from openerp.osv import osv, fields
from functools import partial
from datetime import timedelta as td

from openerp.report import report_sxw
from dateutil.relativedelta import relativedelta
from openerp import SUPERUSER_ID

class report_prakruti_product_date_wise(report_sxw.rml_parse):
    
    def get_date_wise_stock_data(self, data):
        form = data['form']
        self.cr.execute('''SELECT date_order,opening_stock,receive_qty,dispatch_qty,closing_stock FROM
datewise_product_stock_summary_report(%s,%s,%s) ''',((form['product_id']),(form['from_date']),(form['to_date']),))
        
        res = self.cr.dictfetchall()
        print res,'Product Date Wise Stock - Report ---------1'
        return res
    
    def get_flag(self, data):
        res = {}
        res['flag'] = data['form']['is_detail']
        print res,'Get Product Date Wise Stock - Report ---------15'
        return res
    
    def __init__(self, cr, uid, name, context):      
        super(report_prakruti_product_date_wise, self).__init__(cr, uid, name, context=context)
        self.context = context
        self.localcontext.update({
            'time': time,
            'set_product_date_wise_data': self.get_date_wise_stock_data,
            'get_flag': self.get_flag
        })

   
class wrapped_report_sp(osv.AbstractModel):
    _name = 'report.prakruti_qweb_reports.report_product_date_wise'
    _inherit = 'report.abstract_report'
    _template = 'prakruti_qweb_reports.report_product_date_wise'
    _wrapped_report_class = report_prakruti_product_date_wise