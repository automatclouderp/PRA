# -*- coding: utf-8 -*-
import time
from datetime import datetime
from openerp import tools
from openerp.osv import osv, fields
from functools import partial
from datetime import timedelta as td
from openerp.report import report_sxw
from dateutil.relativedelta import relativedelta
from openerp import SUPERUSER_ID

class report_prakruti_dispatch(report_sxw.rml_parse):    
    def get_prakruti_dispatch(self, data):
        form = data['form']
        self.cr.execute('''SELECT dispatch_date,dispatch_no,order_no,name_template,name,accepted_qty,batch_no FROM monthly_dispatch_statement_report(CAST(%s as character varying),CAST(%s as character varying),%s,%s)''',((form['customer_id']),(form['product_id']),(form['from_date']),(form['to_date']),))
        res = self.cr.dictfetchall()
        print res,'Monthly Dispatch Summary Report - Report ---------1'
        return res
    
    def get_flag(self, data):
        res = {}
        res['flag'] = data['form']['is_detail']
        print res,'Get Monthly Dispatch Summary Report - Report ---------2'
        return res
    
    def __init__(self, cr, uid, name, context):      
        super(report_prakruti_dispatch, self).__init__(cr, uid, name, context=context)
        self.context = context
        self.localcontext.update({
            'time': time,
            'set_prakruti_dispatch': self.get_prakruti_dispatch,
            'get_flag': self.get_flag
        })

   
class wrapped_report_sp(osv.AbstractModel):
    _name = 'report.prakruti_qweb_reports.report_dispatch'
    _inherit = 'report.abstract_report'
    _template = 'prakruti_qweb_reports.report_dispatch'
    _wrapped_report_class = report_prakruti_dispatch  