# -*- coding: utf-8 -*-
#
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#

import time
from datetime import datetime
from openerp import tools
from openerp.osv import osv, fields
from functools import partial
from datetime import timedelta as td

from openerp.report import report_sxw
from dateutil.relativedelta import relativedelta
from openerp import SUPERUSER_ID

class report_prakruti_product_current_stock(report_sxw.rml_parse):
    
    def get_current_stock_data(self, data):
        form = data['form']
        self.cr.execute('''SELECT id,name,coalesce(qty_aval,0) as qty_aval,uom,code FROM 
    (
	SELECT 
	uom, product_id as id, qty_in, 
	qty_out, qty_in - qty_out as qty_aval,name,code FROM 
    ( 
	    SELECT uom,product_id,name, sum(qty_out) as qty_out, sum(qty_in) as qty_in,code FROM 
	    ( 
		SELECT 
		product_uom.name as uom,stock_move.product_id, 
		product_product.name_template as name, picking_id,
		case when move_dest_id > 0 then stock_move.product_qty else 0 end as qty_out, 
		case when move_dest_id > 0 then 0 else stock_move.product_qty end as qty_in,product_template.code 
	    FROM product_uom INNER JOIN product_template ON product_uom.id = product_template.uom_id INNER JOIN product_product ON product_product.product_tmpl_id = product_template.id LEFT JOIN stock_move ON stock_move.product_id = product_product.id 
	    WHERE 
	    location_dest_id = 12  AND stock_move.state = 'done' AND
		
		product_template.active='t' AND
              (
	     CASE WHEN CAST(%s as character varying ) = '9999999'  THEN
		 CAST(%s as character varying) = CAST(%s  as character varying) ELSE
		 CAST(product_product.id as character varying) =CAST(%s as character varying) END

              )AND
              (
	     CASE WHEN CAST(%s as character varying ) = '8888888'  THEN
		 CAST(%s as character varying) = CAST(%s  as character varying) ELSE
		 CAST(product_template.group_ref as character varying) =CAST(%s as character varying) END
              )
	       

	    ) as a group by product_id, name, uom,code 
    ) as aa 
    ) AS b 
    ORDER BY id ''',((form['product_id']),(form['product_id']),(form['product_id']),(form['product_id']),(form['category_id']),(form['category_id']),(form['category_id']),(form['category_id']),))
        res = self.cr.dictfetchall()
        print res,'Product Current Stock - Report ---------1'
        return res
    
    def get_flag(self, data):
        res = {}
        res['flag'] = data['form']['is_detail']
        print res,'Get Product Current Stock - Report ---------15'
        return res
    
    def __init__(self, cr, uid, name, context):      
        super(report_prakruti_product_current_stock, self).__init__(cr, uid, name, context=context)
        self.context = context
        self.localcontext.update({
            'time': time,
            'set_current_stock_data': self.get_current_stock_data,
            'get_flag': self.get_flag
        })

   
class wrapped_report_sp(osv.AbstractModel):
    _name = 'report.prakruti_qweb_reports.report_product_current_stock'
    _inherit = 'report.abstract_report'
    _template = 'prakruti_qweb_reports.report_product_current_stock'
    _wrapped_report_class = report_prakruti_product_current_stock
