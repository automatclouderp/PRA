# -*- coding: utf-8 -*-

import time
from datetime import datetime
from openerp import tools
from openerp.osv import osv, fields
from functools import partial
from datetime import timedelta as td

from openerp.report import report_sxw
from dateutil.relativedelta import relativedelta
from openerp import SUPERUSER_ID

class report_prakruti_store_inward(report_sxw.rml_parse):    
    def get_prakruti_store_inward(self, data):
        form = data['form']
        self.cr.execute("SELECT grn_date,grn_no,requested_qty,order_qty,received_qty FROM store_inward_report(%s,%s)", ((form['from_date']),(form['to_date']),))
        res = self.cr.dictfetchall()
        print res,'Report ---------1'
        return res
    
    def get_flag(self, data):
        res = {}
        res['flag'] = data['form']['is_detail']
        print res,'Report ---------2'
        return res
    
    def __init__(self, cr, uid, name, context):      
        super(report_prakruti_store_inward, self).__init__(cr, uid, name, context=context)
        self.context = context
        self.localcontext.update({
            'time': time,
            'set_prakruti_store_inward': self.get_prakruti_store_inward,
            'get_flag': self.get_flag
        })

   
class wrapped_report_sp(osv.AbstractModel):
    _name = 'report.prakruti_qweb_reports.report_store_inward'
    _inherit = 'report.abstract_report'
    _template = 'prakruti_qweb_reports.report_store_inward'
    _wrapped_report_class = report_prakruti_store_inward