# -*- coding: utf-8 -*-
from openerp.osv import osv, fields
import time
import datetime
from datetime import datetime, date


class product_current_stock_report(osv.osv_memory):
    _name = 'product.current_stock_report'
    _description = 'Prakruti Current Stock Report'
    
    def get_products(self, cr, uid, context=None):
        cr.execute('''select cast('9999999' as character varying)as id,cast('ALL PRODUCTS' as character varying)as name 
        union all select cast(id as character varying)as id,name_template as name from product_product  order by name asc ''')
        return cr.fetchall()
    
    def get_product_group(self, cr, uid, context=None):
        cr.execute(''' select cast('8888888' as character varying)as id,cast('ALL CATEGORY' as character varying)as name 
        union all select cast(id as character varying)as id,group_name as name from product_group  order by name asc''')
        return cr.fetchall()
    
    _columns = {
        'category_id' : fields.selection(get_product_group, string='Category'),
        'product_id': fields.selection(get_products, string='Product', required=True),
        'is_detail': fields.boolean('Show Details of Each Day'),
        }
    
    _defaults = {
        'landscape': True,
        'product_id':'9999999',
        'category_id':'8888888'
        }


    def print_report(self, cr, uid, ids, context=None):
        """
         To get the date and print the report
         @param self: The object pointer.
         @param cr: A database cursor
         @param uid: ID of the user currently logged in
         @param context: A standard dictionary
         @return : retrun report
        """
        if context is None:
            context = {}
        datas = {'ids': context.get('active_ids', [])}
        print 'datasdatasdatasdatasdatasdatasdatas-----------3333',datas
        res = self.read(cr, uid, ids, ['product_id','category_id','is_detail'], context=context)
        print 'resresresresresresresresresres-----------44444',res
        res = res and res[0] or {}
        datas['form'] = res
        if res.get('id', False):
            datas['ids'] = [res['id']]
            print 'resresresresresresresresresres-----------44444',res
        return self.pool['report'].get_action(cr, uid, [],'prakruti_qweb_reports.report_product_current_stock', data=datas, context=context)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
