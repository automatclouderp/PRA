# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp.osv import osv, fields
import time
import datetime
from datetime import datetime, date


class logistics_invoice_tracking_report(osv.osv_memory):
    _name = 'logistics_invoice_tracking.report'
    _description = 'PO Logistics Tracking Report'


    def _get_from_date(self, cr, uid, context=None):
        dt = fields.date.context_today(self, cr, uid)
        return dt
      
    def _get_to_date(self, cr, uid, context=None):
        dt = fields.date.context_today(self, cr, uid)
        return dt + " 00:00:00"

    _columns = {
        #'grn_id' : fields.many2one('prakruti.grn_inspection_details', "GRN NO", required=True),
        'customer_id': fields.many2one('res.partner',string= "Customer"),
        'from_date': fields.date('From Date', required=True),
        'to_date': fields.date('To Date', required=True),
        'is_detail': fields.boolean('Show Details of Each Day'),
    }
    _defaults = {
        'from_date': _get_from_date,
        'to_date': _get_to_date,
        'landscape': True,
    }

    def _validate_date(self, cr, uid, ids, context=None):
        obj = self.browse(cr, uid, ids[0], context=context)
        start_date = obj.from_date
        end_date = obj.to_date

        if(start_date > end_date):
            return False
        return True

    _constraints = [
        (_validate_date, 'Please enter valid date', ['from_date'])
        ]

    def print_report(self, cr, uid, ids, context=None):
        """
         To get the date and print the report
         @param self: The object pointer.
         @param cr: A database cursor
         @param uid: ID of the user currently logged in
         @param context: A standard dictionary
         @return : retrun report
        """
        if context is None:
            context = {}
        datas = {'ids': context.get('active_ids', [])}
        print 'datasdatasdatasdatasdatasdatasdatas-----------3333',datas
        res = self.read(cr, uid, ids, ['from_date', 'to_date','customer_id','is_detail'], context=context)
        print 'resresresresresresresresresres-----------44444',res
        res = res and res[0] or {}
        datas['form'] = res
        if res.get('id', False):
            datas['ids'] = [res['id']]
            print 'resresresresresresresresresres-----------44444',res
	
        return self.pool['report'].get_action(cr, uid, [], 'prakruti_qweb_reports.report_logistics_invoice_tracking', data=datas, context=context)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
