# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Prakruti Qweb Reports',
    'version': '1.0',
    'category': 'Manufacturing',
    'sequence': 20,
    'summary': 'Prakruti Qweb Reports',
    'description': """
    Prakruti Qweb Reports
===================================

    """,
    'depends': ['prakruti','product'],
    'data': [
            'security/prakruti_qweb_reports.xml',
            'security/ir.model.access.csv',
            'views/report_product_current_stock.xml',
            'views/report_product_date_wise.xml',
            'views/report_logistics_po_tracking.xml',
            'views/report_logistics_invoice_tracking.xml',
            'views/report_dispatch.xml',
            'views/report_store_issue.xml',
            'views/report_sales_order.xml',
            'views/report_vendor_wise_list.xml',
            'views/report_pending_purchase_order.xml',
            'views/report_store_inward.xml',
            'views/report_sales_order_statement.xml',
            
            'wizard/prakruti_sales_order_statement.xml',
            'wizard/product_current_stock_report_view.xml',
            'wizard/product_date_wise_report.xml',
            'wizard/prakruti_logistics_po_tracking.xml',
            'wizard/prakruti_logistics_invoice_tracking.xml',
            'wizard/prakruti_dispatch.xml',
            'wizard/prakruti_store_issue.xml',
            'wizard/prakruti_sales_order.xml',
            'wizard/prakruti_vendor_wise.xml',
            'wizard/prakruti_pending_purchase_order.xml',
            'wizard/prakruti_store_inward.xml',
            
            'prakruti_product_report_menu.xml'
    ],
    'qweb': [ ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
