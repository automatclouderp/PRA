# -*- coding: utf-8 -*-

from openerp import models, fields, api
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp.exceptions import ValidationError
import re
import logging

class PrakrutiStoreApproveRequest(models.Model):
    _name = 'prakruti.store_approve_request'
    _table = "prakruti_store_approve_request"
    _description = 'Prakruti store approve request Information'
    _order='id desc'
    _rec_name = "request_no"
    
    purchase_type= fields.Selection([('extraction','Extraction'),('formulation','Formulation')],'Purchase Type',required=True)
    request_date = fields.Date('Request Date', readonly=True, default=fields.Date.today)
    approved_date = fields.Date('Approved Date', required=True, default=fields.Date.today)    
    dept_id = fields.Many2one('manage.department_sorting','Department', readonly=True)
    company_id = fields.Many2one('res.company',string="Company", readonly=True)
    request_no = fields.Char(string = "Request No", readonly=True)    
    requested_by= fields.Many2one('res.users',string="Requested By",readonly=True)    
    approved_by= fields.Many2one('res.users',string="Approved By",required=True)
    store_incharge = fields.Many2one('res.users','Store Incharge',readonly=True)
    plant_incharge = fields.Many2one('res.users',string="Plant Incharge", readonly=True)
    date = fields.Date('Date', default=fields.Date.today, readonly=True) 
    production_incharge = fields.Many2one('res.users',string="Production Incharge", readonly=True)
    doc_no = fields.Char(' Doc No', readonly=True)
    rev_no = fields.Char(' Rev No',readonly=True)    
    state =fields.Selection([
		('request', 'Request'),
                ('approve','Approve'),
                ('issue','Issue')],default= 'approve', string= 'Status')    
    grid_id = fields.One2many('prakruti.store_approve_request_item', 'main_id',string='Grid') 
    extraction_bom_id = fields.Integer(' Extraction BOM Common id')
    syrup_bom_id = fields.Integer(' Syrup BOM Common id')
    tablet_bom_id = fields.Integer('Tablet BOM Common id')
    batch_no= fields.Many2one('prakruti.batch_master',string= 'Batch No')
    store_location_id= fields.Many2one('stock.location','Store Location')
    syrup_packing_bom_id = fields.Integer(' Syrup Packing BOM Common id')
    tablet_packing_bom_id = fields.Integer(' Tablet Packing BOM Common id')  
    product_id = fields.Many2one('product.product', related='grid_id.product_id', string='Product Name')
    
    @api.one
    @api.constrains('approved_date')
    def _check_approved_date(self):
        if self.approved_date < fields.Date.today():
            raise ValidationError(
                "Approved Date Can\'t Take Back Date !!!")
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['request','approve','issue']:
                raise UserError(_('Can\'t be Deleted'))
        return super(PrakrutiStoreApproveRequest, self).unlink()  
    
    @api.model
    def _default_company(self):
        return self.env['res.company']._company_default_get('res.partner') 
    
    _defaults = {
        'purchase_type':'extraction',
        'requested_by': lambda s, cr, uid, c:uid,
        'store_incharge': lambda s, cr, uid, c:uid,
        'plant_incharge': lambda s, cr, uid, c:uid,
        'production_incharge': lambda s, cr, uid, c:uid,
        'doc_no':'PO-STR-F-004',
        'company_id':_default_company,
        'approved_by': lambda s, cr, uid, c:uid,
        }
    
    @api.one
    @api.multi
    def action_to_issue(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}  
            template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Store Approve Request')],context=context)[0]
            email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
            store_issue = self.pool.get('prakruti.store_issue').create(cr,uid, {
                'request_date':temp.request_date,
                'request_no':temp.request_no,
                'dept_id':temp.dept_id.id,
                'company_id':temp.company_id.id,
                'store_incharge':temp.store_incharge.id,
                'plant_incharge':temp.plant_incharge.id,
                'doc_no':temp.doc_no,
                'date':temp.date,
                'production_incharge':temp.production_incharge.id,
                'extraction_bom_id':temp.extraction_bom_id,
                'syrup_bom_id':temp.syrup_bom_id,
                'tablet_bom_id':temp.tablet_bom_id,
                'batch_no':temp.batch_no.id,
                'store_location_id':temp.store_location_id.id,
                'syrup_packing_bom_id':temp.syrup_packing_bom_id,                
                'tablet_packing_bom_id':temp.tablet_packing_bom_id
                 })
            for item in temp.grid_id:
                if item.approved_quantity > item.requested_quantity:
                    raise UserError(_('Oops...! Approved Qty Cannot Be Greater Than Requested Qty '))
                else:
                    grid_values = self.pool.get('prakruti.store_issue_item').create(cr,uid, {
                        'style_flag':item.style_flag,
                        'packing_flag':item.packing_flag,
                        'product_id':item.product_id.id,
                        'uom_id':item.uom_id.id,
                        'description':item.description,
                        'requested_quantity':item.requested_quantity,
                        'approved_quantity':item.approved_quantity,
                        'remarks':item.remarks,
                        'store_qty':item.store_qty,
                        'grid_common_id_bom':item.grid_common_id,
                        'grn_no': item.grn_no.id,
                        'ar_no': item.ar_no.id,
                        'extra_readonly_flag':item.extra_readonly_flag,
                        'extra_issued_packing':item.extra_issued_packing,
                        'main_id':store_issue
                    })
                
                cr.execute("UPDATE  prakruti_store_approve_request SET state = 'issue' WHERE prakruti_store_approve_request.id = cast(%s as integer)",
                                   ((temp.id),))
                                   
        return {}



class PrakrutiStoreApproveRequestItem(models.Model):
    _name = 'prakruti.store_approve_request_item'
    _table = "prakruti_store_approve_request_item"
    _description = 'Prakruti store approve request Item Information'
        
    product_id = fields.Many2one('product.product', string='Product Name',readonly=True)
    uom_id = fields.Many2one('product.uom',string="UOM", readonly=True)
    description = fields.Text(string = "Description", readonly=True)
    batch_no = fields.Char(string = "Batch No", readonly=True)
    requested_quantity = fields.Float(string = "Req.Quantity", readonly=True,digits=(6,3))
    approved_quantity = fields.Float(string = "Approved Quantity",digits=(6,3))
    remarks = fields.Text(string="Remarks", readonly=True)
    store_qty = fields.Float(string="Store Qty", readonly=True,digits=(6,3))
    main_id = fields.Many2one('prakruti.store_approve_request',string="Main class ID",required=True, ondelete='cascade')    
    grid_common_id = fields.Integer('Grid common id')
    grn_no = fields.Many2one('prakruti.grn_inspection_details',string='GRN No.')
    ar_no = fields.Many2one('prakruti.specification.ar.no',string='AR No.')    
    style_flag = fields.Integer(string= 'Style',default=0)
    packing_flag = fields.Integer(string= 'Packing',default=0)
    extra_readonly_flag = fields.Integer(string= 'Extra Flag',default=0)
    extra_issued_packing = fields.Float(string= 'Extra Packing',default=0,digits=(6,3))
    
    @api.one
    @api.constrains('approved_quantity')
    def _check_approved_quantity(self):
        if self.approved_quantity < 0 :
            raise ValidationError(
                "Approved Qty. Can't be Negative or Zero !!!")
    
