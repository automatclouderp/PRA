# -*- coding: utf-8 -*-
from openerp import models, fields, api,_
from openerp.tools import amount_to_text
from openerp.tools.amount_to_text import amount_to_text_in 
from openerp.tools.amount_to_text import amount_to_text_in_without_word_rupees 
import openerp
from datetime import date, datetime
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from datetime import timedelta
from openerp.osv import osv,fields
from openerp import models, fields, api, _
from openerp.tools.translate import _
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
from lxml import etree
import cgi
import logging
import lxml.html
import lxml.html.clean as clean
import openerp.pooler as pooler
import random
import re
import socket
import threading
import time
from openerp.tools import image_resize_image_big

class PrakrutiQualityQA(models.Model):
    _name =  'prakruti.quality_check_qa'
    _table = 'prakruti_quality_check_qa'
    _description = 'Dispatched item Quality QA'
    _order="id desc"
    _rec_name= "dispatch_no"
    
    qc_check_line = fields.One2many('prakruti.quality_check_line_qa','qc_check_line_id')    
    checked_by = fields.Many2one('res.users',string = 'Checked By')
    qc_date = fields.Date('QA Date', default=fields.Date.today)
    dispatch_no = fields.Char('Dispatch No', readonly=True)
    dispatch_date = fields.Date('Dispatch Date', readonly=True)
    order_no = fields.Many2one('prakruti.sales_order', string='Order No',readonly=True)
    order_date = fields.Date('Order Date', readonly=True)
    dispatch_to = fields.Many2one('res.partner', string='Dispatch To', readonly=True)
    customer_id = fields.Many2one('res.partner',string="Customer")
    state =fields.Selection([
		('draft','Draft'),
		('sent_to_dispatch','Sent to Dispatch'),
		('validate','Validated'),
		('qa_ha','QA HA'),
		('qa_done','Done'),
		],default= 'draft', string= 'Status', readonly=True)
    store_incharge = fields.Many2one('res.users', string="Store Incharge")
    quality_incharge = fields.Many2one('res.users', string="Quality Incharge")    
    remarks = fields.Text(string="Remarks")
    dispatch_id =fields.Many2one('res.users','Dispatch By') 
    requested_id =fields.Many2one('res.users','Requested By')
    quotation_id =fields.Many2one('res.users','Quotation By')
    order_id =fields.Many2one('res.users','Order By')
    reference_no= fields.Char(string='Ref No')  
    product_id = fields.Many2one('product.product', related='qc_check_line.product_id', string='Product Name') 
    flag_rejected_count = fields.Integer('Flag', default=1)  
    
    _defaults = {
        'checked_by': lambda s, cr, uid, c:uid,
        'store_incharge': lambda s, cr, uid, c:uid,
        'quality_incharge': lambda s, cr, uid, c:uid
        } 
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['draft','done']:
                raise UserError(_('Can\'t Delete...'))
        return super(PrakrutiQualityQA, self).unlink()
    
    @api.one
    @api.multi 
    def validate(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        count_value= 0
        accept_value = 0
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            cr.execute(''' SELECT count(id) as status_marked FROM prakruti_quality_check_line_qa WHERE (status = 'accepted' OR status = 'rejected') AND qc_check_line_id = %s''',((temp.id),))
            for no_of_line in cr.dictfetchall():
                status_marked = int(no_of_line['status_marked'])
            if status_marked == len(temp.qc_check_line):
                cr.execute("UPDATE prakruti_quality_check_qa SET state = 'validate' WHERE id=%s",((temp.id),))
                cr.execute("SELECT count(id) as count_value FROM prakruti_quality_check_line_qa WHERE status = 'rejected' AND qc_check_line_id = %s",((temp.id),))
                for item in cr.dictfetchall():
                    count_value=int(item['count_value'])
                    print '------------------------1111111111111111111111111111-------------------',count_value
                    if count_value >= accept_value:
                        cr.execute("update prakruti_quality_check_qa set flag_rejected_count =2 where id=%s",((temp.id),))
                cr.execute("SELECT count(id) as accept_value FROM prakruti_quality_check_line_qa WHERE status = 'accepted' AND qc_check_line_id = %s",((temp.id),))
                for item in cr.dictfetchall():
                    accept_value=int(item['accept_value'])    
                    print '--------------------------------00000000000000000000000000000000-------------------------------------------',accept_value
                    if count_value == accept_value:
                        print '------------------------------updateeeeeeeeeeeeee---------------------------------------------',accept_value
                        cr.execute("update prakruti_quality_check_qa set flag_rejected_count =2 where id=%s",((temp.id),))
                    elif count_value == 0:
                        print '------------------------------count_value---------------------------------------------',count_value
                        cr.execute("update prakruti_quality_check_qa set flag_rejected_count =4 where id=%s",((temp.id),))
                        cr.execute("update prakruti_dispatch set flag_rejected_count =4 where dispatch_no=%s",((temp.dispatch_no),))
            else:
                raise UserError(_('Please Enter Accepted Qty\nPlease Check Status'))
        return {}
    
    @api.one
    @api.multi 
    def update_to_dispatch(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            if temp.quality_incharge and temp.checked_by:
                cr.execute("update prakruti_dispatch set state ='qa_done' where dispatch_no=%s",((temp.dispatch_no),))
                cr.execute("update prakruti_dispatch set dispatch_flag =1 where dispatch_no=%s",((temp.dispatch_no),))
                cr.execute("UPDATE prakruti_dispatch_line AS b SET accepted_qty =a.accepted_qty,rejected_qty=a.rejected_qty,specification_id=a.specification_id,state = a.state,status = a.status,dispatched_qty = a.accepted_qty FROM(SELECT qc_check_line_id,dispatch_line_grid_id,product_id,accepted_qty,specification_id,rejected_qty,state,status,scheduled_qty FROM prakruti_quality_check_line_qa WHERE qc_check_line_id= %s ) AS a WHERE a.dispatch_line_grid_id = b.id AND a.product_id = b.product_id",((temp.id),))
                cr.execute("UPDATE prakruti_quality_check_qa SET state = 'qa_done' WHERE prakruti_quality_check_qa.dispatch_no = %s", ((temp.dispatch_no),))
                for line in temp.qc_check_line:
                    if line.scheduled_qty == line.accepted_qty:
                        cr.execute("update prakruti_dispatch set state ='qa_done' where dispatch_no=%s",((temp.dispatch_no),))
            else:
                raise UserError(_('Please Select the Quality Incharge and Checked By Person'))
        return {}
    
    @api.one
    @api.multi 
    def quality_to_ha(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            if temp.quality_incharge and temp.checked_by:
                cr.execute("UPDATE prakruti_quality_check_qa SET state ='qa_ha' WHERE id=%s",((temp.id),))
                quality_ha = self.pool.get('prakruti.quality_check_qa_ha').create(cr,uid, {
                        'qc_date':temp.qc_date,
                        'dispatch_no':temp.dispatch_no,
                        'dispatch_date':temp.dispatch_date,
                        'checked_by':temp.checked_by.id,
                        'order_no':temp.order_no.id,
                        'order_date':temp.order_date,
                        'dispatch_to':temp.dispatch_to.id,
                        'store_incharge':temp.store_incharge.id,
                        'quality_incharge':temp.quality_incharge.id,
                        'requested_id':temp.requested_id.id,
                        'order_id':temp.order_id.id,
                        'quotation_id':temp.quotation_id.id,
                        'dispatch_id':temp.dispatch_id.id,
                        'reference_no':temp.reference_no
                        })
                for item in temp.qc_check_line:
                    grid_values = self.pool.get('prakruti.quality_check_line_qa_ha').create(cr,uid, {
                        'product_id': item.product_id.id,
                        'uom_id': item.uom_id.id,
                        'specification_id':item.specification_id.id,
                        'batch_no':item.batch_no.id,
                        'description': item.description,
                        'ordered_qty': item.ordered_qty,
                        'dispatched_qty': item.dispatched_qty,
                        'accepted_qty':item.accepted_qty,
                        'rejected_qty':item.rejected_qty,      
                        'status': item.status,     
                        'test_result': item.test_result,
                        'remarks':item.remarks,
                        'scheduled_qty':item.scheduled_qty,
                        'dispatch_line_grid_id':item.dispatch_line_grid_id,
                        'qc_check_line_id': quality_ha
                        })
            else:
                raise UserError(_('Please Select the Quality Incharge and Checked By Person'))
            cr.execute("UPDATE prakruti_quality_check_qa SET flag_rejected_count =3 WHERE id=%s",((temp.id),))
        return {}
    
    
    
class PrakrutiQualityControlLineQa(models.Model):
    _name = 'prakruti.quality_check_line_qa'
    _table = 'prakruti_quality_check_line_qa'
    
    qc_check_line_id = fields.Many2one('prakruti.quality_check_qa', ondelete='cascade')    
    product_id = fields.Many2one('product.product',string='Product Name')
    uom_id = fields.Many2one('product.uom',string='UOM')
    description = fields.Text(string='Description')
    specification_id = fields.Many2one('product.specification.main', string = "Specification")
    #ar_no = fields.Many2one('prakruti.specification.ar.no', string = "AR No.")
    ordered_qty = fields.Float('Ordered Qty',digits=(6,3))
    dispatched_qty = fields.Float('Dispatched Qty',digits=(6,3))
    remarks = fields.Text(string="Remarks")
    status = fields.Selection([
		('accepted', 'Accepted'),
		#('par_reject', 'Par. Rejected'),
                #('accept_under_deviation','Accepted Under Deviation'),
		('rejected','Rejected')
		],default= 'rejected', string= 'Status')
    state =fields.Selection([
		('draft','Draft'),
		('done','Done')
		],default= 'draft', string= 'State', readonly=True)
    test_result = fields.Text('Test Result')
    accepted_qty = fields.Float(string= 'Accept. Qty.',digits=(6,3))
    rejected_qty = fields.Float(string= 'Reject. Qty.', store=True , compute='_compute_rejected_qty',digits=(6,3))
    scheduled_qty = fields.Float(string= 'Sch. Qty.',digits=(6,3))    
    dispatch_line_grid_id = fields.Integer(string= 'Dispatch Line QA Grid ID')
    batch_no= fields.Many2one('prakruti.batch_master',string= 'Batch No')
    #batch_no= fields.Text(string= 'Batch No')
    
    
    @api.one
    @api.constrains('rejected_qty')
    def _check_rejected_qty(self):
        if self.rejected_qty < 0:
            raise ValidationError(
                "Rejected Qty. !!! Can't be Negative") 
    
    @api.depends('dispatched_qty','accepted_qty')
    def _compute_rejected_qty(self):
        print 'automatautomat-----------------1'
        for order in self:
            print 'automatautomat-----------------2'
            rejected_qty = 0.0            
            order.update({                
                'rejected_qty': order.dispatched_qty - order.accepted_qty 
            })
            
    @api.onchange('status')
    def onchange_status(self):
        if self.status == 'accepted':
            self.accepted_qty = self.dispatched_qty
            self.test_result = 'TESTED OK'
        elif self.status == 'rejected':
            self.rejected_qty = self.dispatched_qty
            self.accepted_qty = 0.0
            self.test_result = 'TESTED OK'
        #elif self.status == 'par_reject':
            #self.accepted_qty = self.dispatched_qty
            #self.rejected_qty = 0.0
            #self.test_result = 'PARTIAL'
        #elif self.status == 'accept_under_deviation':
            #self.accepted_qty = self.dispatched_qty
            #self.rejected_qty = 0.0
            #self.test_result = 'Accept Under Deviation'
        else:
            self.accepted_qty = 0.0
            self.rejected_qty = 0.0
            self.test_result = 'NO SELECTION'