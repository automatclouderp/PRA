# -*- coding: utf-8 -*-

from openerp import models, fields, api
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp.exceptions import ValidationError
import re
import logging
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re

class PrakrutiStoreIssue(models.Model):
    _name = 'prakruti.store_issue'
    _table = "prakruti_store_issue"
    _description = 'Prakruti Store Issue Information'
    _rec_name = "issue_no"
    _order = 'id desc'
    
    purchase_type= fields.Selection([('extraction','Extraction'),('formulation','Formulation')],'Purchase Type',required=True)
    request_date = fields.Date('Request Date', readonly=True, default=fields.Date.today)
    approved_date = fields.Date('Approved Date',readonly=True, default=fields.Date.today)
    issue_date = fields.Date('Issue Date', required=True, default=fields.Date.today)
    dept_id = fields.Many2one('manage.department_sorting','Department',readonly=True)
    company_id = fields.Many2one('res.company',string="Company" ,readonly=True)
    request_no = fields.Char(string = "Request No", readonly=True)
    issue_no = fields.Char(string = "Issue No",readonly= True,help= "Its a Issue Number.",)
    requested_by= fields.Many2one('res.users',string="Requested By",required=True)
    status= fields.Selection([('waiting','Waiting'),('issue','Issued')],string= 'Status',default='waiting')
    approved_by= fields.Many2one('res.users',string="Approved By",readonly=True)
    issued_by= fields.Many2one('res.users',string="Issued By",required=True)
    store_incharge = fields.Many2one('res.users','Store Incharge',readonly=True)
    plant_incharge = fields.Many2one('res.users',string="Plant Incharge",required=True)
    date = fields.Date('Date', required=True, default=fields.Date.today) 
    production_incharge = fields.Many2one('res.users',string="Production Incharge", required= True)
    doc_no = fields.Char(' Doc No', required=True)
    rev_no = fields.Char(' Rev No')
    store_issue_no = fields.Char(string = "Issue No",compute='_get_auto')
    auto_no = fields.Integer('Auto')
    req_no_control_id = fields.Integer('Auto Generating id',default= 0)
    grid_id = fields.One2many('prakruti.store_issue_item', 'main_id',string='Grid')
    remarks = fields.Text(' Remarks ')
    extraction_bom_id = fields.Integer(' Extraction BOM Common id')
    syrup_bom_id = fields.Integer(' Syrup BOM Common id')
    tablet_bom_id = fields.Integer('Tablet BOM Common id')
    batch_no= fields.Many2one('prakruti.batch_master',string= 'Batch No')
    store_location_id= fields.Many2one('stock.location','Store Location')    
    syrup_packing_bom_id = fields.Integer(' Syrup Packing BOM Common id')
    tablet_packing_bom_id = fields.Integer(' Tablet Packing BOM Common id')
    coming_from = fields.Char(string = "Coming From",default='Internal',readonly=True)
    subplant_id= fields.Many2one('prakruti.sub_plant', string="Product",readonly=True)  
    product_id = fields.Many2one('product.product', related='grid_id.product_id', string='Product Name')
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['request','approve','issue']:
                raise UserError(_('Can\'t be  Deleted'))
        return super(PrakrutiStoreIssue, self).unlink()
    
    @api.one
    @api.constrains('issue_date')
    def _check_issue_date(self):
        if self.issue_date < fields.Date.today():
            raise ValidationError(
                "Issue Date Can\'t Take Back Date !!!") 
    
    @api.one
    @api.multi
    def _get_auto(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids   
        for temp in self:
            print 'lathalathalathalathalathalathalatha1'
            cr.execute('''select cast(extract (month from issue_date) as integer) as month ,cast(extract (year from issue_date) as integer) as year ,id from prakruti_store_issue where id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
            if month_value<=3:
                year_value=year_value-1
            else:                
                year_value=year_value
            next_year=year_value+1
            dispay_year=str(next_year)[-2:]
            display_present_year=str(year_value)[-2:]
            cr.execute('''select autogenerate_store_issue(%s)''', ((temp.id),)  ) 
            result = cr.dictfetchall()
            parent_invoice_id = 0
            for value in result: parent_invoice_id = value['autogenerate_store_issue'];
            auto_gen = int(parent_invoice_id)
            print 'lathalathalathalathalathalathalatha1',auto_gen
            if len(str(auto_gen)) < 2:
                auto_gen = '000'+ str(auto_gen)
            elif len(str(auto_gen)) < 3:
                auto_gen = '00' + str(auto_gen)
            elif len(str(auto_gen)) == 3:
                auto_gen = '0'+str(auto_gen)
            else:
                auto_gen = str(auto_gen)
            for record in self :
                x[record.id] = 'ST\\'+'ISSU\\'+'FG\\'+str(auto_gen) +'/'+str(display_present_year)+'-'+str(dispay_year)
                print 'lathalathalathalathalathalathalatha1',x[record.id]
            cr.execute('''update prakruti_store_issue set issue_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
        return x
    
    @api.one
    @api.multi
    def UpdateIssueStock(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}  
           
            cr.execute('''SELECT extra_issued_packing,issued_quantity,extra_issued_qty FROM prakruti_store_issue_item WHERE main_id= %s ''', ((temp.id),))
            for line in cr.dictfetchall():
                issued_quantity = line['issued_quantity']
                extra_issued_qty = line['extra_issued_qty']
                extra_issued_packing = line['extra_issued_packing']
            if issued_quantity:
                cr.execute("UPDATE prakruti_bill_of_material as b SET state = 'issued_quant' ,material_issued_by= a.issued_by FROM (SELECT issued_by,extraction_bom_id FROM prakruti_store_issue INNER JOIN prakruti_bill_of_material ON prakruti_store_issue.extraction_bom_id =prakruti_bill_of_material.id WHERE prakruti_store_issue.id =CAST(%s as INTEGER) ) as a WHERE b.id = a.extraction_bom_id",((temp.id),)) 
                #cr.execute('''UPDATE prakruti_bill_of_material SET state = 'issued_quant' WHERE prakruti_bill_of_material.id =CAST(%s as INTEGER)''', ((temp.extraction_bom_id),))                
                cr.execute('''UPDATE prakruti_bill_of_material_line as b SET extra_flag = 1,issued_qty = a.issued_quantity , grn_no= a.grn_no , ar_no = a.ar_no FROM (SELECT issued_quantity,prakruti_store_issue_item.grn_no, ar_no,extraction_bom_id, grid_common_id_bom FROM prakruti_store_issue_item INNER JOIN prakruti_store_issue ON prakruti_store_issue.id =prakruti_store_issue_item.main_id 
                WHERE prakruti_store_issue.id =CAST(%s as INTEGER) ) as a WHERE b.main_id = a.extraction_bom_id AND b.id =a.grid_common_id_bom''', ((temp.id),))                
                cr.execute('''UPDATE prakruti_syrup as b SET state = 'issued_quant' ,material_issued_by= a.issued_by FROM (SELECT issued_by,syrup_bom_id FROM prakruti_store_issue INNER JOIN prakruti_syrup ON prakruti_store_issue.syrup_bom_id =prakruti_syrup.id WHERE prakruti_store_issue.id =CAST(%s as INTEGER)) as a WHERE b.id = a.syrup_bom_id''', ((temp.id),))              
                cr.execute('''UPDATE prakruti_syrup_line as b SET extra_flag = 1,issued_weight = a.issued_quantity ,grn_no= a.grn_no,ar_no = a.ar_no FROM ( SELECT issued_quantity, prakruti_store_issue_item.grn_no, ar_no,syrup_bom_id ,grid_common_id_bom FROM prakruti_store_issue_item INNER JOIN prakruti_store_issue ON prakruti_store_issue.id =prakruti_store_issue_item.main_id 
                WHERE prakruti_store_issue.id =CAST(%s as INTEGER) ) as a WHERE b.main_id = a.syrup_bom_id AND b.id =a.grid_common_id_bom''', ((temp.id),))                
                cr.execute('''UPDATE prakruti_tablet as b SET state = 'issued_quant' ,material_issued_by= a.issued_by FROM (SELECT issued_by,tablet_bom_id FROM prakruti_store_issue INNER JOIN prakruti_tablet ON prakruti_store_issue.tablet_bom_id =prakruti_tablet.id WHERE prakruti_store_issue.id =CAST(%s as INTEGER)) as a WHERE b.id = a.tablet_bom_id''', ((temp.id),))            
                cr.execute('''UPDATE prakruti_tablet_line as b SET extra_flag = 1,issued_weight = a.issued_quantity,grn_no= a.grn_no,ar_no = a.ar_no FROM ( SELECT issued_quantity,prakruti_store_issue_item.grn_no, ar_no, tablet_bom_id ,grid_common_id_bom FROM prakruti_store_issue_item INNER JOIN prakruti_store_issue ON prakruti_store_issue.id =prakruti_store_issue_item.main_id WHERE prakruti_store_issue.id =CAST(%s as INTEGER) ) as a WHERE b.main_id = a.tablet_bom_id AND b.id =a.grid_common_id_bom''', ((temp.id),))                
                ##########Packing Qty for Syrup and Tablet #######                
                cr.execute('''UPDATE prakruti_syrup as b SET state = 'issued_pack' ,material_issued_by= a.issued_by FROM (SELECT issued_by,syrup_packing_bom_id FROM prakruti_store_issue INNER JOIN prakruti_syrup ON prakruti_store_issue.syrup_packing_bom_id =prakruti_syrup.id WHERE prakruti_store_issue.id =CAST(%s as INTEGER) ) as a WHERE b.id = a.syrup_packing_bom_id''', ((temp.id),))                 
                cr.execute('''UPDATE prakruti_syrup_line_packing as b SET extra_flag = 1,issued_weight = a.issued_quantity,grn_no= a.grn_no,ar_no = a.ar_no FROM ( SELECT issued_quantity,prakruti_store_issue_item.grn_no, ar_no, syrup_packing_bom_id ,grid_common_id_bom FROM prakruti_store_issue_item INNER JOIN prakruti_store_issue ON prakruti_store_issue.id =prakruti_store_issue_item.main_id WHERE prakruti_store_issue.id =CAST(%s as INTEGER) ) as a WHERE b.packing_id = a.syrup_packing_bom_id AND b.id =a.grid_common_id_bom''', ((temp.id),))                
                cr.execute('''UPDATE prakruti_tablet as b SET state = 'issued_pack' ,material_issued_by= a.issued_by FROM (SELECT issued_by,tablet_packing_bom_id FROM prakruti_store_issue INNER JOIN prakruti_tablet ON prakruti_store_issue.tablet_packing_bom_id =prakruti_tablet.id WHERE prakruti_store_issue.id =CAST(%s as INTEGER) ) as a WHERE b.id = a.tablet_packing_bom_id''', ((temp.id),))                 
                cr.execute('''UPDATE prakruti_tablet_line_packing as b SET extra_flag = 1,issued_weight = a.issued_quantity,grn_no= a.grn_no,ar_no = a.ar_no FROM ( SELECT issued_quantity,prakruti_store_issue_item.grn_no, ar_no, tablet_packing_bom_id ,grid_common_id_bom FROM prakruti_store_issue_item INNER JOIN prakruti_store_issue ON prakruti_store_issue.id =prakruti_store_issue_item.main_id WHERE prakruti_store_issue.id =CAST(%s as INTEGER) ) as a WHERE b.packing_id = a.tablet_packing_bom_id AND b.id =a.grid_common_id_bom''', ((temp.id),))                
                cr.execute('''SELECT updateissuestock(%s)''', ((temp.id),))                
            elif extra_issued_qty:
                cr.execute('''UPDATE prakruti_bill_of_material_line as b SET extra_issued_qty = a.extra_issued_qty,grn_no= a.grn_no,ar_no = a.ar_no FROM (SELECT extra_issued_qty,prakruti_store_issue_item.grn_no, ar_no, extraction_bom_id,grid_common_id_bom FROM prakruti_store_issue_item INNER JOIN prakruti_store_issue ON prakruti_store_issue.id =prakruti_store_issue_item.main_id WHERE prakruti_store_issue.id =CAST(%s as INTEGER) ) as a WHERE b.main_id = a.extraction_bom_id AND b.id =a.grid_common_id_bom''', ((temp.id),))                
                cr.execute('''UPDATE prakruti_syrup_line as b SET extra_issued_qty = a.extra_issued_qty,grn_no= a.grn_no,ar_no = a.ar_no FROM (SELECT extra_issued_qty,prakruti_store_issue_item.grn_no, ar_no, syrup_bom_id,grid_common_id_bom FROM prakruti_store_issue_item INNER JOIN prakruti_store_issue ON prakruti_store_issue.id =prakruti_store_issue_item.main_id WHERE prakruti_store_issue.id =CAST(%s as INTEGER) ) as a WHERE b.main_id = a.syrup_bom_id AND b.id =a.grid_common_id_bom''', ((temp.id),))                
                cr.execute('''UPDATE prakruti_tablet_line as b SET extra_issued_qty = a.extra_issued_qty,grn_no= a.grn_no,ar_no = a.ar_no FROM (SELECT extra_issued_qty,prakruti_store_issue_item.grn_no, ar_no, tablet_bom_id,grid_common_id_bom FROM prakruti_store_issue_item INNER JOIN prakruti_store_issue ON prakruti_store_issue.id =prakruti_store_issue_item.main_id WHERE prakruti_store_issue.id =CAST(%s as INTEGER) ) as a WHERE b.main_id = a.tablet_bom_id AND b.id =a.grid_common_id_bom''', ((temp.id),))                
                ##########Extra Packing Qty for Syrup and Tablet #######                 
                cr.execute('''UPDATE prakruti_syrup_line_packing as b SET extra_issued_qty = a.extra_issued_qty,grn_no= a.grn_no,ar_no = a.ar_no FROM ( SELECT extra_issued_qty,prakruti_store_issue_item.grn_no, ar_no, syrup_packing_bom_id ,grid_common_id_bom FROM prakruti_store_issue_item INNER JOIN prakruti_store_issue ON prakruti_store_issue.id =prakruti_store_issue_item.main_id WHERE prakruti_store_issue.id =CAST(%s as INTEGER) ) as a WHERE b.packing_id = a.syrup_packing_bom_id AND b.id =a.grid_common_id_bom''', ((temp.id),))                
                cr.execute('''UPDATE prakruti_tablet_line_packing as b SET extra_issued_qty = a.extra_issued_qty,grn_no= a.grn_no,ar_no = a.ar_no FROM ( SELECT extra_issued_qty,prakruti_store_issue_item.grn_no, ar_no, tablet_packing_bom_id ,grid_common_id_bom FROM prakruti_store_issue_item INNER JOIN prakruti_store_issue ON prakruti_store_issue.id =prakruti_store_issue_item.main_id WHERE prakruti_store_issue.id =CAST(%s as INTEGER) ) as a WHERE b.packing_id = a.tablet_packing_bom_id AND b.id =a.grid_common_id_bom''', ((temp.id),))
                cr.execute('''SELECT updateextra_issued(%s)''', ((temp.id),)) 
            elif extra_issued_packing:
                ##########Extra Packing Qty for Syrup and Tablet #######                 
                cr.execute('''UPDATE prakruti_syrup_line_packing as b SET extra_issued_packing = a.extra_issued_packing,grn_no= a.grn_no,ar_no = a.ar_no FROM ( SELECT extra_issued_packing,prakruti_store_issue_item.grn_no, ar_no, syrup_packing_bom_id ,grid_common_id_bom FROM prakruti_store_issue_item INNER JOIN prakruti_store_issue ON prakruti_store_issue.id =prakruti_store_issue_item.main_id WHERE prakruti_store_issue.id =CAST(%s as INTEGER) ) as a WHERE b.packing_id = a.syrup_packing_bom_id AND b.id =a.grid_common_id_bom''', ((temp.id),))                
                cr.execute('''UPDATE prakruti_tablet_line_packing as b SET extra_issued_packing = a.extra_issued_packing,grn_no= a.grn_no,ar_no = a.ar_no FROM ( SELECT extra_issued_packing,prakruti_store_issue_item.grn_no, ar_no, tablet_packing_bom_id ,grid_common_id_bom FROM prakruti_store_issue_item INNER JOIN prakruti_store_issue ON prakruti_store_issue.id =prakruti_store_issue_item.main_id WHERE prakruti_store_issue.id =CAST(%s as INTEGER) ) as a WHERE b.packing_id = a.tablet_packing_bom_id AND b.id =a.grid_common_id_bom''', ((temp.id),))   
                cr.execute('''SELECT updateextrapacking_issued(%s)''', ((temp.id),))
            else:
                raise UserError(_('Please Enter qty'))
            cr.execute("UPDATE prakruti_store_issue SET status = 'issue' WHERE prakruti_store_issue.id = (%s)", ((temp.id),))
            template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Store Issue')],context=context)[0]
            email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
        return {}
    
    
    @api.model
    def _default_company(self):
        return self.env['res.company']._company_default_get('res.partner') 
    
    _defaults = {
        'purchase_type':'extraction',
        'request_no':'New',
        'issue_no':'New',
        'requested_by': lambda s, cr, uid, c:uid, #Current login user will display automatically
        'store_incharge': lambda s, cr, uid, c:uid,
        'plant_incharge': lambda s, cr, uid, c:uid,
        'production_incharge': lambda s, cr, uid, c:uid,
        'doc_no':'PO-STR-F-004',
        'company_id':_default_company,
        'approved_by': lambda s, cr, uid, c:uid,
        'issued_by': lambda s, cr, uid, c:uid,
        }



class PrakrutiStoreIssueItem(models.Model):
    _name = 'prakruti.store_issue_item'
    _table = "prakruti_store_issue_item"
    _description = 'Prakruti Store Issue Item Product Line'
        
    product_id = fields.Many2one('product.product', string='Product Name',readonly=True)
    uom_id = fields.Many2one('product.uom',string="UOM",readonly=True)
    description = fields.Text(string = "Description",readonly=True)
    batch_no = fields.Char(string = "Batch No",readonly=True)
    approved_quantity = fields.Float(string = "Approved Quantity",readonly=True,digits=(6,3))
    issued_quantity = fields.Float(string = "Issue Quantity",compute= '_compute_packing_qty',store=True,digits=(6,3))
    remarks = fields.Text(string="Remarks",readonly=True)    
    packing_style = fields.Float(string= 'Packing Style',digits=(6,3))
    packing_per_qty = fields.Float(string= 'Packing Per Qty',digits=(6,3))
    store_qty = fields.Float('Available Stock',digits=(6,3))
    main_id = fields.Many2one('prakruti.store_issue',string="Main class ID", ondelete='cascade')
    grid_common_id_bom = fields.Integer('Grid common id')
    grn_no = fields.Many2one('prakruti.grn_inspection_details',string='GRN No.')
    ar_no = fields.Many2one('prakruti.specification.ar.no',string='AR No.')
    extra_issued_qty =fields.Float(string='Extra Qty',digits=(6,3))    
    style_flag = fields.Integer(string= 'Style',default=0)
    packing_flag = fields.Integer(string= 'Packing',default=0)
    extra_readonly_flag = fields.Integer(string= 'Extra Flag',default=0)
    extra_issued_packing =fields.Float(string='(+)Extra Packing',default=0,digits=(6,3))    
    
    @api.depends('packing_style', 'packing_per_qty','extra_issued_packing')
    def _compute_packing_qty(self):
        print 'automat-----------------1'
        for order in self:
            print 'automat-----------------2'
            issued_quantity = 0.0            
            order.update({                
                'issued_quantity': (order.packing_style * order.packing_per_qty) + order.extra_issued_packing
            })
    
    def _check_issued_qty(self, cr, uid, ids):
         lines = self.browse(cr, uid, ids)
         for line in lines:
             if line.issued_quantity > line.approved_quantity:
                 return False
         return True
     
    _constraints = [
            (_check_issued_qty, 'Issued Qty cannot be more than Approved Qty !', ['issued_quantity'])
    ]