# -*- coding: utf-8 -*-
from openerp import models, fields, api
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
import re
import logging

class PrakrutiProductionPlanning(models.Model):
    _name = 'prakruti.production_planning'
    _table = 'prakruti_production_planning'
    _description = 'Production Planning'
    _order= "id desc"
    _rec_name= 'product_id' 
    
    slip_no= fields.Char(string='Slip No.',readonly=1)
    planning_line = fields.One2many('prakruti.production_planning_line','planning_id',string = 'Planning Line')
    product_id = fields.Many2one('product.product',string= 'Product Name',readonly=1)
    standard_batch_id = fields.Many2one('prakruti.standard_product',string = 'Batch Size')
    output_yield_qty = fields.Float(string= 'Output Yield Qty',digits=(6,3))
    standard_yield_qty= fields.Float(related= 'standard_batch_id.standard_output_yield',string= "Standard Yield Qty",digits=(6,3),store=1,readonly=1)
    raw_material_id = fields.Many2one('product.product', related='planning_line.product_id', string='Raw Material')
    flag_display_count = fields.Integer(string='Display Product',default=0)
    flag_delete_count = fields.Integer(string='Delete Product',default=0)
    all_send_to_request = fields.Integer(string='All Send To Request',default=0,readonly=1)
    request_id = fields.Many2one('res.users',string= 'Requested By',readonly=1)
    ps_line_grid_id = fields.Integer('Production Slip Line Grid ID')   
    status = fields.Selection([('planning','Planning'),('done','Done')],default='planning',string= 'Status')
    
    availble_stock_qty = fields.Float(string= 'Availble Stock',digits=(6,3),readonly=1)
    
    
    _defaults = {
        'request_id': lambda s, cr, uid, c:uid
        }
    
    @api.one
    @api.multi
    def action_list_products(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute("SELECT prakruti_standard_product_line.product_id,prakruti_standard_product_line.uom_id,prakruti_standard_product_line.description,prakruti_standard_product_line.standard_value FROM prakruti_standard_product_line INNER JOIN prakruti_standard_product ON prakruti_standard_product.id=prakruti_standard_product_line.standard_line_id INNER JOIN prakruti_production_planning ON prakruti_production_planning.standard_batch_id = prakruti_standard_product.id WHERE prakruti_production_planning.id = CAST(%s as integer)",((temp.id),))
            for item in cr.dictfetchall():
                print 'CURRENT DATABASE CURSOR',cr
                print 'CURRENT USER ID',uid
                print 'CURRENT IDS',ids
                product_id=item['product_id']
                uom_id=item['uom_id']
                description =item['description']
                standard_value=item['standard_value']
                product_line = self.pool.get('prakruti.production_planning_line').create(cr,uid, {
                    'product_id':product_id,
                    'uom_id':uom_id,
                    'description':description,
                    'standard_value':standard_value,
                    'planning_id':temp.id,
                        })
            cr.execute("UPDATE  prakruti_production_planning SET flag_display_count = 1,flag_delete_count = 0 WHERE id = %s",((temp.id),))
        return {}
    
            
    @api.one
    @api.multi
    def action_delete_products(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute("DELETE FROM prakruti_production_planning_line WHERE planning_id = %s", ((temp.id),))
            cr.execute("UPDATE  prakruti_production_planning SET flag_delete_count = 1,flag_display_count = 0 WHERE id = %s",((temp.id),))
        return {}
    
    @api.one
    @api.multi
    def check_stock(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr.execute("UPDATE prakruti_production_planning_line SET store_qty= qty_aval FROM ( SELECT product_id,(sum(qty_in) - sum(qty_out)) as qty_aval,id FROM ( SELECT stock_move.product_id, case when move_dest_id > 0 then product_qty else 0 end as qty_out, case when move_dest_id > 0 then 0 else product_qty end as qty_in,planning_id,prakruti_production_planning_line.id FROM product_template INNER JOIN product_product  ON product_product.product_tmpl_id = product_template.id INNER JOIN stock_move ON stock_move.product_id = product_product.id INNER JOIN prakruti_production_planning_line ON prakruti_production_planning_line.product_id = stock_move.product_id WHERE prakruti_production_planning_line.planning_id = %s and location_dest_id = 12  AND stock_move.state = 'done')as a GROUP BY product_id,id) as b WHERE b.id = prakruti_production_planning_line.id",((temp.id),))
            cr.execute("UPDATE prakruti_production_planning_line SET virtual_qty=virtual_quantity FROM ( SELECT product_id,id,(sum(virtual_qty)) as virtual_quantity FROM ( SELECT stock_move.product_id,stock_move.virtual_qty,planning_id,prakruti_production_planning_line.id FROM product_template INNER JOIN product_product  ON product_product.product_tmpl_id = product_template.id INNER JOIN stock_move ON stock_move.product_id = product_product.id INNER JOIN prakruti_production_planning_line ON prakruti_production_planning_line.product_id = stock_move.product_id WHERE prakruti_production_planning_line.planning_id = %s AND location_dest_id = 12  AND stock_move.state = 'virtual_entry' OR stock_move.state = 'done')AS a GROUP BY product_id,id) as b WHERE b.id = prakruti_production_planning_line.id",((temp.id),))
            cr.execute("UPDATE prakruti_production_planning SET availble_stock_qty = qty_aval FROM ( SELECT product_id,(sum(qty_in) - sum(qty_out)) as qty_aval,id FROM ( SELECT stock_move.product_id,case when move_dest_id > 0 then product_qty else 0 end as qty_out, case when move_dest_id > 0 then 0 else product_qty end as qty_in,prakruti_production_planning.id FROM prakruti_production_planning INNER JOIN product_product ON product_product.id = prakruti_production_planning.product_id INNER JOIN product_template  ON product_product.product_tmpl_id = product_template.id INNER JOIN stock_move ON stock_move.product_id = product_product.id WHERE prakruti_production_planning.id = %s AND location_dest_id = 12  AND stock_move.state = 'done')as a GROUP BY product_id,id) as b WHERE b.id = prakruti_production_planning.id",((temp.id),))
        return {}
        
        
    @api.one
    @api.multi 
    def raise_purchase_requisition(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr.execute("SELECT count(id) as requisition_flag_status FROM prakruti_production_planning_line WHERE planning_id = %s AND requisition_status = 'True' AND requisition_flag = 0",((temp.id),))
            for line in cr.dictfetchall():
                requisition_flag_status = line['requisition_flag_status']
            if requisition_flag_status >= 1:
                purchase_requisition = self.pool.get('prakruti.purchase_requisition').create(cr,uid, {
                    'purchase_manager':temp.request_id.id,
                    'plant_manager':temp.request_id.id,
                    'stores_incharge':temp.request_id.id,
                    'to_name':temp.request_id.id,
                    'remarks':'Requisition Raised Against this Slip Number ' + temp.slip_no + ' For Production'
                    })
                cr.execute("SELECT prakruti_production_planning.slip_no,prakruti_production_planning_line.product_id,description,uom_id,virtual_qty,prakruti_production_planning.standard_yield_qty,prakruti_production_planning.output_yield_qty,prakruti_production_planning_line.standard_value FROM prakruti_production_planning_line INNER JOIN prakruti_production_planning ON prakruti_production_planning_line.planning_id = prakruti_production_planning.id WHERE planning_id = %s AND requisition_status = 'True' AND requisition_flag = 0",((temp.id),))
                for line in cr.dictfetchall():
                    product_id = line['product_id']
                    description = line['description']
                    uom_id = line['uom_id']
                    output_yield_qty = line['output_yield_qty']
                    standard_yield_qty = line['standard_yield_qty']
                    standard_value = line['standard_value']
                    virtual_qty = line['virtual_qty']
                    remarks = line['slip_no']
                    grid_values = self.pool.get('prakruti.purchase_requisition_line').create(cr,uid,{
                        'product_id':product_id,
                        'description':description,
                        'uom_id':uom_id,
                        'quantity_req':(output_yield_qty * standard_value)/standard_yield_qty - virtual_qty,
                        'remarks':remarks,
                        'order_id':purchase_requisition
                        })
                cr.execute("UPDATE prakruti_production_planning_line SET requisition_flag = 1 WHERE requisition_status = 'True' AND planning_id = %s",((temp.id),))
                cr.execute("SELECT count(id) as flag_line FROM prakruti_production_planning_line WHERE planning_id = %s AND requisition_flag = 1",((temp.id),))
                for line in cr.dictfetchall():
                    flag_line = line['flag_line']
                cr.execute("SELECT count(id) as total_line FROM prakruti_production_planning_line WHERE planning_id = %s",((temp.id),))
                for line in cr.dictfetchall():
                    total_line = line['total_line']
                if total_line == flag_line:
                    cr.execute("UPDATE prakruti_production_planning SET all_send_to_request = 1 WHERE id = %s",((temp.id),))
            else:
                raise UserError(_('No Any Product to send for Requisition'))
        return {}
    
    
    @api.one
    @api.multi 
    def update_production_slip(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        virtual_quantity = 0.0
        for temp in self:
            for line in temp.planning_line:
                cr.execute("SELECT prakruti_production_planning.output_yield_qty,prakruti_production_planning.standard_yield_qty,prakruti_production_planning_line.standard_value FROM public.prakruti_production_planning, public.prakruti_production_planning_line WHERE prakruti_production_planning.id = prakruti_production_planning_line.planning_id AND prakruti_production_planning_line.product_id = CAST(%s AS INTEGER) AND prakruti_production_planning.id = CAST(%s AS INTEGER)", ((line.product_id.id),(temp.id),))
                for item in cr.dictfetchall():
                    output_yield_qty = item['output_yield_qty']
                    standard_value = item['standard_value']
                    standard_yield_qty = item['standard_yield_qty']
                cr.execute("SELECT product_id,name,id,(sum(virtual_qty)) as virtual_quantity FROM ( SELECT stock_move.product_id,product_template.name,stock_move.virtual_qty,planning_id,prakruti_production_planning_line.id FROM product_template INNER JOIN product_product  ON product_product.product_tmpl_id = product_template.id INNER JOIN stock_move ON stock_move.product_id = product_product.id INNER JOIN prakruti_production_planning_line ON prakruti_production_planning_line.product_id = stock_move.product_id WHERE prakruti_production_planning_line.planning_id = %s AND location_dest_id = 12  AND (stock_move.state = 'virtual_entry' OR stock_move.state = 'done'))AS a GROUP BY product_id,id,name",((temp.id),))
                for item in cr.dictfetchall():
                    virtual_quantity = item['virtual_quantity']
                print '-------------------------------PRODUCT ID----------------------------------------------',line.product_id.id
                print '-------------------------------PRODUCT NAME----------------------------------------------',line.product_id.name_template
                print '-------------------------------ACTUAL QTY----------------------------------------------',((output_yield_qty * standard_value)/standard_yield_qty)
                print '-------------------------------VIRTUAL QTY----------------------------------------------',virtual_quantity
                if ((output_yield_qty * standard_value)/standard_yield_qty) > virtual_quantity:
                    raise UserError(_('Your Actual Qty is %s for the Product [ %s ] and the Stock Availability is %s') %(((output_yield_qty * standard_value)/standard_yield_qty),line.product_id.name_template,virtual_quantity))
            cr.execute("UPDATE prakruti_production_slip_line AS b SET planning_done = 'True' FROM(SELECT ps_line_grid_id,product_id FROM prakruti_production_planning WHERE id= %s ) AS a WHERE a.ps_line_grid_id = b.id AND a.product_id = b.product_id",((temp.id),))
            cr.execute("UPDATE prakruti_production_planning SET status = 'done' WHERE id = %s",((temp.id),))
            cr.execute('''SELECT update_planning(%s)''',((temp.id),))
        return True

class PrakrutiProductionPlanningLine(models.Model):
    _name= 'prakruti.production_planning_line'
    _table = 'prakruti_production_planning_line'
    _description = 'Production Planning Line'
    _order= "id desc"
    
    planning_id = fields.Many2one('prakruti.production_planning',string= 'Planning ID',readonly=1)
    product_id = fields.Many2one('product.product',string= 'Ingredient Name',readonly=1,required=1)
    description = fields.Text(string= 'Description',readonly=1)
    uom_id= fields.Many2one('product.uom', string="UOM",readonly=1)
    standard_value=fields.Float(string='Standard Qty',digits=(6,3),default=0,readonly=1)
    actual_qty=fields.Float(string='Actual Qty',digits=(6,3),compute= '_compute_actual_qty')
    virtual_qty = fields.Float(string="Available Qty",digits=(6,3),default=0,readonly=1)
    store_qty = fields.Float(string="Store Qty",digits=(6,3),readonly=1,default=0)
    requisition_qty = fields.Float(string="Requisition Qty",digits=(6,3),compute= '_calculate_requisition_qty')
    standard_yield_qty= fields.Float(related='planning_id.standard_yield_qty',string="Standard Yield Qty")
    output_yield_qty= fields.Float(related='planning_id.output_yield_qty',string="Output Yield Qty")
    remarks = fields.Text(string= 'Remarks')
    requisition_status = fields.Boolean(string= 'Requisition ChecK',default=1)
    requisition_flag = fields.Integer(string= 'Requisition Flag',default=0,readonly=1)
    
    def onchange_product(self, cr, uid, ids, product_id, context=None):
        line3 = 0.0
        qty_aval = 0.0
        cr.execute("""SELECT qty_aval FROM (SELECT uom, product_id, name, qty_in, qty_out, qty_in - qty_out as qty_aval FROM ( SELECT uom,product_id, name, sum(qty_out) as qty_out, sum(qty_in) as qty_in FROM ( SELECT product_uom.name as uom,stock_move.product_id, product_product.name_template as name, picking_id, case when move_dest_id > 0 then product_qty else 0 end as qty_out, case when move_dest_id > 0 then 0 else product_qty end as qty_in FROM product_uom INNER JOIN product_template ON product_uom.id = product_template.uom_id INNER JOIN product_product ON product_product.product_tmpl_id = product_template.id INNER JOIN stock_move ON stock_move.product_id = product_product.id WHERE location_dest_id = 12  AND stock_move.state = 'done' AND product_product.id = CAST(%s as integer)) as a group by product_id, name, uom ) as a ) AS b ORDER BY product_id""", ((product_id),))
        for line in cr.dictfetchall():
            line3 = line['qty_aval']
        print 'AVAILABLE STOCK',line3
        return {'value' :{
                          'store_qty': line3 or 0.0
                          }}
    
    @api.depends('standard_yield_qty','output_yield_qty','standard_value')
    def _compute_actual_qty(self):
        for order in self:
            actual_qty = single_value = standard_value = standard_yield_qty = output_yield_qty = 0.0
            single_value = (order.output_yield_qty * order.standard_value)/order.standard_yield_qty
            order.update({
                'actual_qty': single_value
                })
    
    @api.depends('store_qty','actual_qty')
    def _calculate_requisition_qty(self):
        for order in self:
            store_qty = actual_qty = 0.0
            if order.actual_qty <= order.virtual_qty:
                order.update({
                    'requisition_qty': 0
                    })
            else:
                order.update({
                    'requisition_qty': order.actual_qty - order.virtual_qty
                    })