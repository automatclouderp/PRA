# -*- coding: utf-8 -*-
import openerp
from datetime import date, datetime
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from datetime import timedelta
from openerp.osv import osv,fields
from openerp import models, fields, api, _
from openerp.tools.translate import _
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
from lxml import etree
import cgi
import logging
import lxml.html
import lxml.html.clean as clean
import openerp.pooler as pooler
import random
import re
import socket
import threading
import time
from openerp.tools import image_resize_image_big

class prakruti_logistics_po_tracking(models.Model):
    _name= "prakruti.logistics_po_tracking"
    _table= "prakruti_logistics_po_tracking"
    _order= "id desc"
    _rec_name= "tracking_number"
    
    po_no = fields.Char(string='Order No', readonly=True)
    order_date= fields.Date(string= "Order Date")
    vendor_id= fields.Many2one('res.partner',string= "Vendor Name")
    tracking_number= fields.Char(string= "Tracking Number")
    expected_date= fields.Date(string= "Expected Delivery Date")
    tracking_date=fields.Date(string= "Tracking Date")
    actual_date= fields.Date(string= "Actual Delivery Date")
    status= fields.Selection([('open','Open'),('in_transit','In-Transit'),('deliver','Delivered')],string= "Status",default='open')
    flag_count_display_product = fields.Integer(default=0)
    qa_no = fields.Char(string='Analysis No')
    pr_no = fields.Char(string='Requisition No')
    qo_no = fields.Char(string='Quotation No')
    req_no =fields.Char(string='Request No')
    vendor_reference = fields.Char(string='Vendor/Supplier Reference')
    payment = fields.Char(string='Mode/Terms of Payments')
    destination = fields.Char(string='Destination')
    other_reference = fields.Char(string='Other Reference')
    maintanence_manager = fields.Many2one('res.users',string="Maintanence Manager")
    purchase_manager = fields.Many2one('res.users',string="Purchase Manager")
    stores_incharge = fields.Many2one('res.users',string="Stores Incharge")
    terms_of_delivery = fields.Text(string='Terms of Delivery')
    state = fields.Selection([
		('requisition', 'Requisition'),
		('request','Request'),
		('quotation','Quotation'),
                ('analysis','Quotation Analysis'),
                ('reject','Rejected'),
                ('order','Order'),
                ('confirm','Order Confirm')], string="Status")
    remarks=fields.Text('Remarks')
    request_date = fields.Date(string = "Requisition Date")
    amount_untaxed= fields.Float(string='Untaxed Amount',digits=(6,3))
    additional_charges = fields.Float(string='Additional Charges')
    frieght_charges_applied = fields.Selection([('yes','Yes'),('no','No')])
    frieght_charges = fields.Float(string="Frieght Charges",digits=(6,3))
    dispatch_through = fields.Char(string='Dispatch Through')
    packing_charges = fields.Float(string='Packing & Forwarding',digits=(6,3))
    total_discount = fields.Float(string="Total Discount",digits=(6,3))
    total_tax = fields.Float(string="Total Tax",digits=(6,3))
    grand_total= fields.Float(string='Grand Total',digits=(6,3))
    excise_id = fields.Many2one('account.other.tax', string='Excise Duty', domain=['|', ('active', '=', False), ('active', '=', True)])
    excise_duty = fields.Float(related='excise_id.per_amount',string= 'Excise Duty(%)',store=True,digits=(6,3))
    total_excise_duty = fields.Float(string= 'Total Excise Duty',digits=(6,3))
    order_line = fields.One2many('prakruti.purchase_line_in_logistics','logistics_line_id',string='Purchase Order Line of Logistics')
    purchase_type = fields.Many2one('product.group',string= 'Purchase Type')
    company_address = fields.Many2one('res.company',string='Company Address')
    vehicle_no = fields.Char(string="Vehicle No.")
    transport_name=fields.Char(string="Name of the Transporter")
    any_adv_payment =fields.Selection([
                    ('no', 'No'),
                    ('yes','Yes')
                    ], string= 'Any Advance Payment')
    advance_payment_type =fields.Selection([
                    ('cash', 'CASH'),
                    ('cheque','CHEQUE'),
                    ('demand_draft','DEMAND DRAFT')
                    ], string= 'Done By')
    cash_amount = fields.Float(string="Amount",digits=(6,3))
    cash_remarks = fields.Text(string="Remarks")    
    cheque_amount = fields.Float(string="Amount",digits=(6,3))
    cheque_no = fields.Integer(string="Cheque No.")
    cheque_remarks = fields.Text(string="Remarks")    
    draft_amount = fields.Float(string="Amount",digits=(6,3))
    draft_no = fields.Integer(string="Draft No.")
    draft_remarks = fields.Text(string="Remarks") 
    product_id = fields.Many2one('product.product', related='order_line.product_id', string='Product Name')
    
    vendor_accepted_delivery_date = fields.Date(string= 'Vendor Accepted Delivery Date')
    invoice_no_check = fields.Boolean(string= 'Invoice Copy')
    dc_no_inward_check = fields.Selection([('applicable','Applicable'),('not_applicable','Not Applicable')],default='applicable',string= 'Delivery Challan')
    mod_vat_copy_collected_check = fields.Selection([('applicable','Applicable'),('not_applicable','Not Applicable')],default='applicable',string= 'Does MOD VAT Copy Collected')
    po_no_check = fields.Selection([('applicable','Applicable'),('not_applicable','Not Applicable')],default='applicable',string= 'Purchase Order No')
    does_lr_copy_received_check = fields.Selection([('applicable','Applicable'),('not_applicable','Not Applicable')],default='applicable',string= 'Does LR Copy Received')
    
    _sql_constraints = [
    ('unique_tracking_no', 'unique(tracking_number)','Tracking number must be unique !')
    ]
    
    @api.onchange('any_adv_payment')
    def onchange_any_adv_payment(self):
        if self.any_adv_payment == 'no':
            self.advance_payment_type = None
    
    @api.onchange('advance_payment_type')
    def onchange_advance_payment_type(self):
        if self.advance_payment_type == 'cash':
            self.cheque_amount = 0
            self.cheque_no = 0
            self.cheque_remarks = ''
            self.draft_amount = 0
            self.draft_no = 0
            self.draft_remarks = ''
        if self.advance_payment_type == 'cheque':
            self.cash_amount = 0
            self.cash_remarks = ''
            self.draft_amount = 0
            self.draft_no = 0
            self.draft_remarks = ''
        if self.advance_payment_type == 'demand_draft':
            self.cash_amount = 0
            self.cash_remarks = ''
            self.cheque_amount = 0
            self.cheque_no = 0
            self.cheque_remarks = ''
        else:
            self.cash_amount = 0
            self.cash_remarks = ''
            self.cheque_amount = 0
            self.cheque_no = 0
            self.cheque_remarks = ''
            self.draft_amount = 0
            self.draft_no = 0
            self.draft_remarks = ''
            
            
            
    @api.multi
    def unlink(self):
        for order in self:
            if order.status in ['open','deliver','in_transit']:
                raise UserError(_('Can\'t Delete'))
        return super(prakruti_logistics_po_tracking, self).unlink()
    @api.one
    @api.multi 
    def order_in_transit(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {} 
            if temp.tracking_number and temp.vehicle_no and temp.transport_name:
                if temp.expected_date:
                    if temp.expected_date >= temp.order_date:
                        template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Logistics PO Tracking')],context=context)[0]
                        email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True) 
                        cr.execute('''UPDATE prakruti_logistics_po_tracking SET status = 'in_transit' where prakruti_logistics_po_tracking.id = %s  ''', ((temp.id),)) 
                        cr.execute('''UPDATE prakruti_purchase_requisition SET state = 'in_transit' where prakruti_purchase_requisition.requisition_no = %s  ''', ((temp.pr_no),))
                    else:
                        raise UserError(_('Oops...! Your Expected delivery date should not be less than Order date'))
                else:
                    raise UserError(_('Oops...! Please Enter Expected delivery date'))
            else:
                raise UserError(_('Oops...! Please Enter\nTracking Number\nVehicle Number\nTransporter Name'))
        return True
    
    @api.one
    @api.multi 
    def confirm_to_gate_pass(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            if temp.actual_date:
                if temp.actual_date >= temp.order_date:
                    template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Logistics PO Tracking GRN')],context=context)[0]
                    email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
                    to_gate_pass= self.pool.get('prakruti.gate_pass').create(cr,uid, {
                        'cash_amount':temp.cash_amount,
                        'cash_remarks':temp.cash_remarks,
                        'cheque_amount':temp.cheque_amount,
                        'cheque_no':temp.cheque_no,
                        'cheque_remarks':temp.cheque_remarks,
                        'draft_amount':temp.draft_amount,
                        'draft_no':temp.draft_no,
                        'draft_remarks':temp.draft_remarks,
                        'advance_payment_type':temp.advance_payment_type,
                        'any_adv_payment':temp.any_adv_payment,
                        'po_no':temp.po_no,
                        'qa_no':temp.qa_no,
                        'pr_no':temp.pr_no,
                        'qo_no':temp.qo_no,
                        'req_no':temp.req_no,
                        'vendor_reference':temp.vendor_reference,
                        'payment':temp.payment,
                        'destination':temp.destination,
                        'other_reference':temp.other_reference,
                        'maintanence_manager':temp.maintanence_manager.id,
                        'purchase_manager':temp.purchase_manager.id,
                        'stores_incharge':temp.stores_incharge.id,
                        'terms_of_delivery':temp.terms_of_delivery,
                        'vendor_id': temp.vendor_id.id,
                        'state':'draft',
                        'remarks':temp.remarks,
                        'request_date':temp.request_date,
                        'order_date':temp.order_date,                        
                        'amount_untaxed':temp.amount_untaxed,
                        'additional_charges':temp.additional_charges,
                        'grand_total':temp.grand_total,
                        'frieght_charges_applied':temp.frieght_charges_applied,
                        'frieght_charges':temp.frieght_charges,
                        'packing_charges':temp.packing_charges,
                        'total_discount':temp.total_discount,
                        'total_tax':temp.total_tax,
                        'dispatch_through':temp.dispatch_through,
                        'excise_id':temp.excise_id.id,
                        'excise_duty':temp.excise_duty,
                        'total_excise_duty':temp.total_excise_duty,
                        'purchase_type':temp.purchase_type.id,
                        #Gate Pass Entry
                        'customer_id':temp.company_address.id,
                        'vehicle_no':temp.vehicle_no,
                        'transport_name':temp.transport_name,
                        'coming_from':'purchase',
                        'document_type':'inward',    
                        'invoice_no_check':temp.invoice_no_check,
                        'dc_no_inward_check':temp.dc_no_inward_check,
                        'mod_vat_copy_collected_check':temp.mod_vat_copy_collected_check,
                        'po_no_check':temp.po_no_check,
                        'does_lr_copy_received_check':temp.does_lr_copy_received_check,
                            })
                    for item in temp.order_line:
                        gate_pass_grid_item= self.pool.get('prakruti.gate_pass_line').create(cr,uid, {
                            'product_id': item.product_id.id,
                            'description': item.description,
                            'actual_quantity': item.quantity,
                            'accepted_qty': item.quantity,
                            'quantity': item.quantity,
                            'uom_id': item.uom_id.id,
                            'scheduled_date': item.scheduled_date,                   
                            'unit_price': item.unit_price,
                            'discount': item.discount,
                            'tax_price': item.tax_price,
                            'tax_id': item.tax_id.id,
                            'subtotal': item.subtotal,
                            'remarks':item.remarks,
                            'no_of_packings': item.no_of_packings,
                            'pack_per_qty': item.pack_per_qty,
                            'extra_packing':item.extra_packing,
                            'purchase_line_common_id':item.purchase_line_common_id,
                            'main_id':to_gate_pass
                                })
                    cr.execute('''UPDATE prakruti_logistics_po_tracking SET status = 'deliver' WHERE prakruti_logistics_po_tracking.id = %s  ''', ((temp.id),))
                    cr.execute('''UPDATE prakruti_purchase_requisition SET state = 'deliver' where prakruti_purchase_requisition.requisition_no = %s  ''', ((temp.pr_no),))
                else:
                    raise UserError(_('Oops...! Delivery Date should not be less than order date'))
            else:
                raise UserError(_('Oops...! Please Enter Delivery Date'))
        return {}

class PrakrutiPurchaseLineInLogistics(models.Model):
    
    _name = 'prakruti.purchase_line_in_logistics'
    _table = 'prakruti_purchase_line_in_logistics'
    
    logistics_line_id = fields.Many2one('prakruti.logistics_po_tracking', ondelete='cascade')        
    product_id = fields.Many2one('product.product',string='Product Name')    
    description = fields.Text(string='Description')
    uom_id = fields.Many2one('product.uom',string='UOM')
    scheduled_date =fields.Datetime(string='Due On')
    unit_price = fields.Float(string='Unit price',digits=(6,3))
    discount = fields.Float(string='Discount(%)',digits=(6,3))
    tax_type = fields.Selection([('cst','CST'),('tin','TIN'),('tax','Tax'),('vat','VAT')], string="Tax", default= 'tax')
    tax_id = fields.Many2one('account.other.tax', string='Taxes', domain=['|', ('active', '=', False), ('active', '=', True)])
    tax_price = fields.Float(related='tax_id.per_amount',string='Taxes', store=True,digits=(6,3)) 
    subtotal= fields.Float(string='Sub Total',digits=(6,3))
    remarks=fields.Text('Remarks')
    status = fields.Selection([
		('open', 'Open'),
		('close','Close')],default= 'open', string= 'Status') 
    purchase_line_common_id = fields.Integer(string="Purchase Line ID")
    quantity = fields.Float(string='Quantity',digits=(6,3))    
    no_of_packings= fields.Float(string= "No. of Packings",digits=(6,3))
    pack_per_qty= fields.Float(string= "Packing Per. Qty.",digits=(6,3))
    extra_packing= fields.Float(string= "(+)Extra Packing",default=0,digits=(6,3))
    
    @api.onchange('no_of_packings','pack_per_qty','extra_packing')
    def _compute_total_quantity(self):
        for order in self:
            quantity = 0.0
            order.update({
                    'quantity': ((order.no_of_packings * order.pack_per_qty) + order.extra_packing)
                    })
    
    
