# -*- coding: utf-8 -*-
from . import prakruti_material_rejected_store