# -*- coding: utf-8 -*-

from openerp import models, fields, api
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
import re
import logging



class PrakrutiDebitNote(models.Model):
    _name='prakruti.debit.note'
    _table='prakruti_debit_note'
    _order='id desc'
    _rec_name='debit_note_no'
    
    debit_note_no = fields.Char(string= 'Debit Note No.',readonly=1,default='New')
    debit_date = fields.Date(string= 'Date', default=fields.Date.today)
    purchase_return_id = fields.Many2one('prakruti.purchase_invoice',string = 'Select Invoice')
    vendor_id = fields.Many2one('res.partner',string = 'Vendor Name')
    dispatch_to = fields.Many2one('res.partner',string='Vendor Address')
    notes = fields.Text(string= 'Notes')
    order_line = fields.One2many('prakruti.debit.note.line','line_id',string='Order Line')
    subtotal = fields.Float(string='Subtotal',compute='_compute_subtotal',store=True,digits=(6,3))
    note_no = fields.Char(compute= '_get_auto')
    auto_no = fields.Integer('Auto')
    req_no_control_id = fields.Integer('Auto Generating id',default= 0)
    flag_count_accept = fields.Integer('Accepted Line is There',default= 1)
    ha_flag=fields.Integer('To HA',default= 0)
    po_no= fields.Char(string= "Order No.")
    order_date = fields.Date(string='Order Date')
    mrn_flag=fields.Integer('To MRN',default= 0)
    #SELECT THE PURCHASE RETURN NUMBER DATED 20170408    
    return_id = fields.Many2one('prakruti.purchase_return',string='Return No.')
    flag_display_product= fields.Integer(string='Product List Shown',default=0)
    flag_delete_product= fields.Integer(string='Product List Deleted',default=0)
    purchase_manager = fields.Many2one('res.users',string="Purchase Manager") 
    stores_incharge = fields.Many2one('res.users','Stores Incharge')
    
    def onchange_return_id(self, cr, uid, ids, return_id, context=None):
        process_type = self.pool.get('prakruti.purchase_return').browse(cr, uid, return_id, context=context)
        result = {
            'vendor_id': process_type.vendor_id,
            'dispatch_to':process_type.vendor_id,
            'po_no':process_type.po_no,
            'order_date':process_type.order_date
                }
        return {'value': result}
    
    @api.one
    @api.multi
    def action_list_products(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute('''SELECT product_id,uom_id,return_qty,unit_price FROM prakruti_purchase_return INNER JOIN prakruti_purchase_return_line ON prakruti_purchase_return.id=prakruti_purchase_return_line.return_line_id WHERE prakruti_purchase_return_line.return_line_id =CAST(%s as integer)''',((temp.return_id.id),))
            for item in cr.dictfetchall():
                product_id=item['product_id']
                uom_id=item['uom_id']
                return_qty=item['return_qty']
                unit_price =item['unit_price']
                grid_down = self.pool.get('prakruti.debit.note.line').create(cr,uid, {
                    'product_id':product_id,
                    'uom_id':uom_id,
                    'return_qty':return_qty,
                    'unit_price':unit_price,
                    'line_id':temp.id,
                        })
            cr.execute("UPDATE  prakruti_debit_note SET flag_display_product = 1 WHERE prakruti_debit_note.id = cast(%s as integer)",((temp.id),))
            cr.execute("UPDATE  prakruti_debit_note SET flag_delete_product = 0 WHERE prakruti_debit_note.id = cast(%s as integer)",((temp.id),))
            return {}
   
    @api.one
    @api.multi
    def action_delete_products(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute('''DELETE FROM prakruti_debit_note_line WHERE prakruti_debit_note_line.line_id = (%s)''', ((temp.id),))
            cr.execute("UPDATE  prakruti_debit_note SET flag_display_product = 0 WHERE prakruti_debit_note.id = cast(%s as integer)",((temp.id),))
            cr.execute("UPDATE  prakruti_debit_note SET flag_delete_product = 1 WHERE prakruti_debit_note.id = cast(%s as integer)",((temp.id),))
        return {}
    
    @api.multi
    def unlink(self):
        raise UserError(_('Can\'t Delete'))
        return super(PrakrutiDebitNote, self).unlink()
    
    @api.depends('order_line.return_qty','order_line.unit_price')
    def _compute_subtotal(self):
        for order in self:
            subtotal  = total_amount=0.0
            for line in order.order_line:
                total_amount += line.return_qty * line.unit_price
                order.update({
                    'subtotal': total_amount
                    })
    
    @api.one
    @api.multi
    def _get_auto(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        for temp in self:
            cr.execute('''select cast(extract (month from debit_date) as integer) as month ,cast(extract (year from debit_date) as integer) as year ,id from prakruti_debit_note where id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
                if month_value<=3:
                    year_value=year_value-1
                else:
                    year_value=year_value
                next_year=year_value+1
                dispay_year=str(next_year)[-2:]
                display_present_year=str(year_value)[-2:]                        
                cr.execute('''select autogenerate_debit_note(%s)''', ((temp.id),)  ) 
                result = cr.dictfetchall()
                parent_invoice_id = 0
                for value in result: parent_invoice_id = value['autogenerate_debit_note'];
                auto_gen = int(parent_invoice_id)
                if len(str(auto_gen)) < 2:
                    auto_gen = '000'+ str(auto_gen)
                elif len(str(auto_gen)) < 3:
                    auto_gen = '00' + str(auto_gen)
                elif len(str(auto_gen)) == 3:
                    auto_gen = '0'+str(auto_gen)
                else:
                    auto_gen = str(auto_gen)
                for record in self :
                    x[record.id] = 'DN\\'+str(auto_gen) +'\\'+str(display_present_year)+'-'+str(dispay_year)
                cr.execute('''update prakruti_debit_note set debit_note_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
            return x
   
    @api.one
    @api.multi
    def to_ha(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {} 
            template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Debit Note')],context=context)[0]
            email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
            to_dn_ha = self.pool.get('prakruti.debit.note.ha').create(cr,uid, {
                'debit_note_no':temp.debit_note_no,
                'debit_date':temp.debit_date,
                'return_id':temp.return_id.id,
                'vendor_id':temp.vendor_id.id,
                'dispatch_to':temp.dispatch_to.id,
                'notes':temp.notes,
                'subtotal':temp.subtotal
                 })
            for item in temp.order_line:
                grid_values = self.pool.get('prakruti.debit.note.ha.line').create(cr,uid, {
                    'product_id':item.product_id.id,
                    'uom_id':item.uom_id.id,
                    'return_qty':item.return_qty,
                    'unit_price':item.unit_price,
                    'total':item.total,
                    'line_id':to_dn_ha
                    })
            cr.execute("UPDATE prakruti_debit_note SET ha_flag = 1 WHERE prakruti_debit_note.id = cast(%s as integer)",((temp.id),))
        return {}
    
class PrakrutiDebitNoteLine(models.Model):
    _name = 'prakruti.debit.note.line'
    _table = "prakruti_debit_note_line"
    
    line_id = fields.Many2one('prakruti.debit.note')
    
    product_id = fields.Many2one('product.product',string= 'Product Name')
    uom_id = fields.Many2one('product.uom',string= 'Units')
    return_qty = fields.Float(string= 'Qty.',digits=(6,3))
    unit_price = fields.Float(string= 'Amount',digits=(6,3))
    total = fields.Float(string= 'Total',compute='_compute_price_total',store=True,digits=(6,3))
   
   
    @api.depends('return_qty', 'unit_price')
    def _compute_price_total(self):
        for order in self:
            total = 0.0            
            order.update({                
                'total': order.return_qty * order.unit_price 
            })