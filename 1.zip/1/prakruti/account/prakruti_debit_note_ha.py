# -*- coding: utf-8 -*-
from openerp import models, fields, api
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
import re
import logging

class PrakrutiDebitNoteHa(models.Model):
    _name='prakruti.debit.note.ha'
    _table='prakruti_debit_note_ha'
    _order='id desc'
    _rec_name='debit_note_no'
    
    debit_note_no = fields.Char(string= 'Debit Note No.',readonly=1)
    debit_date = fields.Date(string= 'Date', default=fields.Date.today)
    purchase_return_id = fields.Many2one('prakruti.purchase_invoice',string = 'Select Invoice')
    vendor_id = fields.Many2one('res.partner',string = 'Vendor Name')
    dispatch_to = fields.Many2one('res.partner',string='Vendor Address')
    notes = fields.Text(string= 'Notes')
    order_line = fields.One2many('prakruti.debit.note.ha.line','line_id',string='Order Line')
    subtotal = fields.Float(string='Subtotal',compute='_compute_subtotal',store=True,digits=(6,3))
    #SELECT THE PURCHASE RETURN NUMBER DATED 20170408    
    return_id = fields.Many2one('prakruti.purchase_return',string='Return No.')
    
    @api.depends('order_line.return_qty','order_line.unit_price')
    def _compute_subtotal(self):
        for order in self:
            subtotal  = total_amount=0.0
            for line in order.order_line:
                total_amount += line.return_qty * line.unit_price
                order.update({
                    'subtotal': total_amount
                    })
    @api.multi
    def unlink(self):
        raise UserError(_('Can\'t Delete '))
        return super(PrakrutiDebitNoteHa, self).unlink()
    
class PrakrutiDebitNoteHaLine(models.Model):
    _name = 'prakruti.debit.note.ha.line'
    _table = "prakruti_debit_note_ha_line"
    
    line_id = fields.Many2one('prakruti.debit.note.ha')    
    product_id = fields.Many2one('product.product',string= 'Product Name')
    uom_id = fields.Many2one('product.uom',string= 'Units')
    return_qty = fields.Float(string= 'Qty.',digits=(6,3))
    unit_price = fields.Float(string= 'Amount',digits=(6,3))
    total = fields.Float(string= 'Total',compute='_compute_price_total',store=True,digits=(6,3))
   
   
    @api.depends('return_qty', 'unit_price')
    def _compute_price_total(self):
        for order in self:
            total = 0.0            
            order.update({                
                'total': order.return_qty * order.unit_price 
            })