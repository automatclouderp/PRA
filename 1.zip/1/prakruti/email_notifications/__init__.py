# -*- encoding: utf-8 -*-

import prakruti_po_tracking_notifications
import prakruti_invoice_tracking_notifications