# -*- coding: utf-8 -*-

from openerp import models, fields, api
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
import re
import logging


#########################################################################################################


class PrakrutiShiftMaster(models.Model):
    _name = 'prakruti.shift_master'
    _table = 'prakruti_shift_master'
    _description = 'Prakruti Shift Master '
    _order= "id desc"
    _rec_name="name"
    
    #effective_date= fields.Date('Effective Date', default=fields.Date.today,required="True")
    name= fields.Char('Name',required="True")
    shift_starttime =fields.Datetime(string='Start Time ',required="True")
    shift_endtime =fields.Datetime(string='End Time',required="True")
    
    _sql_constraints = [
        ('name_code', 'unique (name)', ' This entry is already entered. Please check and retry!'),
        ]
    
    #def _check_effective_date(self, cr, uid, ids,effective_date,context=None):
        
        #for current_id in self.browse(cr, uid, ids, context={}):
            #cr.execute(''' select count(id) As count from prakruti_shift_master where effective_date=%s''', ( (current_id.effective_date)))
            #for effective_date in cr.dictfetchall():
                #effective_date = effective_date['count']
                #if effective_date > 3:
                    #return False
                #else:
                    #return True
                   
    #_constraints = [
	    #( _check_effective_date, ' Effective Date is already entered 3 times' , ['effective_date'] )	
	#]
   
    def onchange_check_name(self, cr, uid, ids, name, context=None):
        if name == False:
            return {
                'value': {
                    'name': False
                }
            }

        if re.match("^[ A-Za-z0-9]*$", name) != None:
            ''' to strip left and right spaces '''
            name = name.strip()
            name = name.upper()

            return {
                'value': {
                    'name': name
                }
            }

        else:
            warning_shown = {
                'title': _("Alert"),
                'message': _('Enter only numbers and alphabets'),
            }
            return {'value': {
                'name': False
            }, 'warning': warning_shown}