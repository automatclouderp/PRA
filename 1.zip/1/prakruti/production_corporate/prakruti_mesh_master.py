# -*- coding: utf-8 -*-

from openerp import models, fields, api
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
import re
import logging


#########################################################################################################


class PrakrutiMeshMaster(models.Model):
    _name = 'prakruti.mesh_master'
    _table = 'prakruti_mesh_master'
    _description = 'Prakruti Mesh Master'
    _order= "id desc"
    _rec_name="mesh_size"
    
  
    subplant_id= fields.Many2one('prakruti.sub_plant', string="Sub Plant",required="True")
    mesh_size= fields.Float(string='Mesh Size',required="True",digits=(6,3))
    
       
    _sql_constraints = [
        ('uniq_mesh_size','unique(subplant_id,mesh_size)','This entry is already entered. Please check and retry!')
        ]
   