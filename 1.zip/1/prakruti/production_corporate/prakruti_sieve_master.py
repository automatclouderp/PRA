# -*- coding: utf-8 -*-

from openerp import models, fields, api
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
import re
import logging


#########################################################################################################


class PrakrutiSieveMaster(models.Model):
    _name = 'prakruti.sieve_master'
    _table = 'prakruti_sieve_master'
    _description = 'Prakruti Sieve Master'
    _order= "id desc"
    _rec_name="sieve"
    
    
    subplant_id= fields.Many2one('prakruti.sub_plant', string="Sub Plant",required="True")
    sieve= fields.Float(string='Sieve' ,required="True",digits=(6,3))
    
       
    _sql_constraints = [
        ('uniq_sub_sieve','unique(subplant_id,sieve)','This entry is already entered. Please check and retry!')
        ]
    
   