# -*- coding: utf-8 -*-

from openerp import models, fields, api
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
import re
import logging
from openerp.exceptions import ValidationError
from datetime import timedelta
from openerp.tools import email_re, email_split



#########################################################################################################


class PrakrutiBatchMaster(models.Model):
    _name = 'prakruti.batch_master'
    _table = 'prakruti_batch_master'
    _description = 'Prakruti Batch Master '
    _order= "id desc"
    _rec_name="batch_no"
    
    
    drying_chart=fields.Selection([('yes','Yes'),('no','No')],default='yes',string="Drying Chart")
    
    pulverisation=fields.Selection([('yes','Yes'),('no','No')],default='yes',string="Pulverisation")
    extraction_new=fields.Selection([('yes','Yes'),('no','No')],default='yes',string="Extraction")
    precipitation=fields.Selection([('yes','Yes'),('no','No')],default='yes',string="Precipitation")
    bleaching=fields.Selection([('yes','Yes'),('no','No')],default='yes',string="Bleaching")
    
    concentration=fields.Selection([('yes','Yes'),('no','No')],default='yes',string="Concentartion")
    evaporation=fields.Selection([('yes','Yes'),('no','No')],default='yes',string="Evaporation")
    stirring=fields.Selection([('yes','Yes'),('no','No')],default='yes',string="Stirring")
    spent_stripping=fields.Selection([('yes','Yes'),('no','No')],default='yes',string="Spent Stripping")
    spent_cooling_unloading=fields.Selection([('yes','Yes'),('no','No')],default='yes',string="Spent Cooling & Unloading")
    maturation_crystalization=fields.Selection([('yes','Yes'),('no','No')],default='yes',string="Maturation & Crystalization")
    water_striiping_chart=fields.Selection([('yes','Yes'),('no','No')],default='yes',string="Water Strriping Chart")
    charcolisation_chart=fields.Selection([('yes','Yes'),('no','No')],default='yes',string="Charcolisation Chart")
    spray_drying_chart=fields.Selection([('yes','Yes'),('no','No')],default='yes',string="Spray Drying Chart")
    magnetic_particle_seperation=fields.Selection([('yes','Yes'),('no','No')],default='yes',string="Magnetic Particle Seperation")
    heat_sterilization=fields.Selection([('yes','Yes'),('no','No')],default='yes',string="Heat Sterilization")
    
    
    ############Process involved in syrup ##############
    other_ingredient_addition = fields.Selection([('yes','Yes'),('no','No')],default='yes',string="Other Ingredient Addition")
    #pulverisation=fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Pulverisation")
    extract_solution = fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Extract Solution")
    soak_raw_material =fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Soak Raw Material")
    #extraction_new=fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Extraction")
    api_addition=fields.Selection([('yes','Yes'),('no','No')],default='yes', string="API Addition")
    
    autoclave = fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Autoclave")
    addition_preservative = fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Addition of Preservative")
    preparation_syrup = fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Syrup Preparation")
    
    ph_control_buffer = fields.Selection([('yes','Yes'),('no','No')],default='yes', string="pH control buffer action ")
    solvent_name= fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Solvent Name")
    filling =  fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Filling")
    coding =  fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Coding")
    
    ###########process names in common with syrup and tablet production#################
    packing =  fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Packing")
    #equipment_down_time =  fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Equipment Down Time")
    #remarks  =  fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Remarks")
    #breakdown  =  fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Breakdown")
    
    #####  FIELDS IN COMMON WITH EXTRACTION AND TABLET  #########
    coating = fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Coating")
    sieving=fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Sieving")
    blending=fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Blending")
    milling=fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Milling")
    
    #####  FIELDS IN COMMON WITH EXTRACTION AND SYRUP  #########
    filtration = fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Filtration")
    ############################################################################################################################
    
    preparation_of_binder= fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Preparation of Binder")
    granulation = fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Granulation")
    semi_drying = fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Semi Drying")
    final_drying = fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Final Drying")
    compression = fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Compression")
    tablet_coating = fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Tablet Coating Preparation")
    inspection =fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Inspection Details")
    metal_inspection=fields.Selection([('yes','Yes'),('no','No')],default='yes', string="Metal Inspection")
    plant_type=fields.Selection([('extraction','Extraction'),('syrup','Syrup'),('tablet','Tablet')],string='Plant Type', default='extraction')
   
    subplant_id= fields.Many2one('prakruti.sub_plant', string="Sub Plant",required="True")    
    batch_name=fields.Char(string='Batch Name',required="True")
    batch_no=fields.Char(string='Batch No',required="True" )
    batch_allocation_date=fields.Datetime(string='Batch Allocation Date', default=fields.Date.today)
    batch_end_date=fields.Datetime(string='Batch End Date')
    batch_capacity=fields.Float(string='Batch Capacity',required="True",digits=(6,3))
    batch_allocated_by = fields.Selection([('free', 'Free'),('extraction', 'Extraction'),('syrup','Syrup'),('tablet','Tablet')],string='Batch Allocated By',default='free')
    is_batch_closed = fields.Selection([('open', 'Open'),('close', 'Closed')],string='Batch Status',default='open')
    batch_allocated_flag = fields.Integer('Is Allocated',default=0,readonly=True)
    email_template=fields.Char(compute='send_mail',store=True)
    insert_flag = fields.Integer(string= 'Field Insert',default=0,readonly=1)
    insert_into_bom = fields.Char(string='Inserted Or Not',compute='_on_save')
    bmr_no = fields.Char(string = 'BMR No')    
    
    @api.one
    @api.multi
    def _on_save(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        for temp in self:
            if temp.insert_flag == 0:
                if temp.plant_type == 'extraction':
                    insert_into_bom = self.pool.get('prakruti.bill_of_material').create(cr,uid,{
                        'subplant_id':temp.subplant_id.id,
                        'batch_id':temp.id,
                        'actual_batch_size':temp.batch_capacity
                        })
                elif temp.plant_type == 'syrup':
                    insert_into_syrup_bom = self.pool.get('prakruti.syrup').create(cr,uid,{
                        'subplant_id':temp.subplant_id.id,
                        'batch_no':temp.id,
                        'actual_batch_size':temp.batch_capacity
                        })
                elif temp.plant_type == 'tablet':
                    insert_into_tablet_bom = self.pool.get('prakruti.tablet').create(cr,uid,{
                        'subplant_id':temp.subplant_id.id,
                        'batch_no':temp.id,
                        'actual_batch_size':temp.batch_capacity
                        })
            cr.execute('''update prakruti_batch_master set insert_flag =1 where id=%s ''', ((temp.id),))
        return {}
    
    _sql_constraints = [
        ('name_uniq', 'unique (batch_no)', 'Batch No Should be Unique!'),
    ]    
    
    @api.one
    @api.constrains('batch_allocation_date')
    def _check_batch_allocation_date(self):
        if self.batch_allocation_date < fields.Date.today():
            raise ValidationError(
                "Batch Allocation Date can't be less than current date!")  
    @api.one
    @api.constrains('batch_end_date')
    def _check_batch_end_date(self):
        if self.batch_end_date < fields.Date.today():
            raise ValidationError(
                "Batch End Date can't be less than current date!")
   
    def name_get(self, cr, uid, ids, context=None):
        if context is None:
                context = {}
        res = []
        for record in self.browse(cr, uid, ids, context=context):
            name = record.batch_no
            code = record.batch_allocated_by                    
            name_code = "%s : %s" % (name,code)
            res.append((record.id, name_code))
        return res
    
    
    def send_mail(self, cr, uid, ids, context=None):
        for temp in self.browse(cr, uid, ids, context={}):
            template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Manage Batch')],context=context)[0]
            email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
            print 'template_idtemplate_idtemplate_idtemplate_id',template_id
        return True
    
    
    def onchange_check_batch_name(self, cr, uid, ids, batch_name, context=None):
        if batch_name == False:
            return {
                'value': {
                    'batch_name': False
                }
            }

        if re.match("^[ A-Za-z0-9]", batch_name) != None:
            ''' to strip left and right spaces '''
            batch_name = batch_name.strip()
            batch_name = batch_name.upper()

            return {
                'value': {
                    'batch_name': batch_name
                }
            }

        else:
            warning_shown = {
                'title': _("Alert"),
                'message': _('Enter only numbers and alphabets'),
            }
            return {'value': {
                'batch_name': False
            }, 'warning': warning_shown}
        
        
    def onchange_check_batch_no(self, cr, uid, ids, batch_no, context=None):
        if batch_no == False:
            return {
                'value': {
                    'batch_no': False
                }
            }

        if re.match("^[ A-Za-z0-9]", batch_no) != None:
            ''' to strip left and right spaces '''
            batch_no = batch_no.strip()
            batch_no = batch_no.upper()

            return {
                'value': {
                    'batch_no': batch_no
                }
            }

        else:
            warning_shown = {
                'title': _("Alert"),
                'message': _('Enter only numbers and alphabets'),
            }
            return {'value': {
                'batch_no': False
            }, 'warning': warning_shown}
        
        
       
    def onchange_subplant_id(self, cr, uid, ids, subplant_id, context=None):
        cr.execute('SELECT  metal_inspection,inspection,tablet_coating,compression,final_drying,semi_drying,granulation,preparation_of_binder,filtration,milling,blending,sieving,coating,packing,coding,filling,solvent_name,ph_control_buffer,preparation_syrup,addition_preservative,autoclave,api_addition,soak_raw_material,extract_solution,other_ingredient_addition,heat_sterilization,magnetic_particle_seperation,spray_drying_chart,water_striiping_chart,charcolisation_chart,maturation_crystalization,spent_cooling_unloading,spent_stripping,stirring,evaporation,concentration,bleaching,precipitation,extraction_new,pulverisation,drying_chart,plant_type FROM prakruti_sub_plant WHERE prakruti_sub_plant.id=cast(%s as integer)', ((subplant_id),))
        for values in cr.dictfetchall():
            metal_inspection = values['metal_inspection']
            inspection = values['inspection']
            tablet_coating= values['tablet_coating']
            compression= values['compression']
            final_drying= values['final_drying']
            semi_drying= values['semi_drying']
            granulation= values['granulation']
            preparation_of_binder= values['preparation_of_binder']
            filtration= values['filtration']
            milling= values['milling']
            blending= values['blending']
            sieving= values['sieving']
            coating= values['coating']
            packing= values['packing']
            coding= values['coding']
            filling= values['filling']
            solvent_name= values['solvent_name']
            ph_control_buffer= values['ph_control_buffer']
            preparation_syrup= values['preparation_syrup']
            addition_preservative= values['addition_preservative']
            autoclave= values['autoclave']
            api_addition= values['api_addition']
            soak_raw_material= values['soak_raw_material']
            other_ingredient_addition= values['other_ingredient_addition']
            heat_sterilization= values['heat_sterilization']
            magnetic_particle_seperation= values['magnetic_particle_seperation']
            spray_drying_chart= values['spray_drying_chart']
            water_striiping_chart= values['water_striiping_chart']
            charcolisation_chart= values['charcolisation_chart']
            maturation_crystalization= values['maturation_crystalization']
            spent_cooling_unloading= values['spent_cooling_unloading']
            spent_stripping= values['spent_stripping']
            stirring= values['stirring']
            evaporation= values['evaporation']
            concentration= values['concentration']
            bleaching= values['bleaching']
            precipitation= values['precipitation']
            extraction_new= values['extraction_new']
            pulverisation= values['pulverisation']
            drying_chart= values['drying_chart'] 
            plant_type= values['plant_type']          
            return {'value' :{
                'metal_inspection': metal_inspection,
                'inspection':inspection,
                'tablet_coating': tablet_coating,
                'compression': compression,
                'final_drying': final_drying,
                'semi_drying': semi_drying,
                'granulation': granulation,
                'preparation_of_binder': preparation_of_binder,
                'filtration': filtration,
                'milling': milling,
                'blending': blending,
                'sieving': sieving,
                'coating': coating,
                'packing': packing,
                'coding': coding,
                'filling': filling,
                'solvent_name': solvent_name,
                'ph_control_buffer': ph_control_buffer,
                'preparation_syrup': preparation_syrup,
                'addition_preservative': addition_preservative,
                'autoclave': autoclave,
                'api_addition': api_addition,
                'soak_raw_material': soak_raw_material,
                'other_ingredient_addition': other_ingredient_addition,
                'heat_sterilization': heat_sterilization,
                'magnetic_particle_seperation': magnetic_particle_seperation,
                'spray_drying_chart': spray_drying_chart,
                'water_striiping_chart': water_striiping_chart,
                'charcolisation_chart': charcolisation_chart,
                'maturation_crystalization': maturation_crystalization,
                'spent_cooling_unloading': spent_cooling_unloading,
                'spent_stripping': spent_stripping,
                'stirring': stirring,
                'evaporation': evaporation,
                'concentration': concentration,
                'bleaching': bleaching,
                'precipitation': precipitation,
                'extraction_new': extraction_new,
                'pulverisation': pulverisation,
                'drying_chart': drying_chart,
                'plant_type': plant_type
                }}