# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import mail_mail
import purchase
import partner
import stock
import report
import stock
import company
import res_config
import invoice
