# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2009 Tiny SPRL (<http://tiny.be>). All Rights Reserved
#    $Id$
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from openerp.osv import fields, osv
import openerp.tools.sql as sql




class prakruti_gm_report(osv.osv):
    _name = "prakruti.gm.report"
    _description = "General Manager Dashboard"
    _auto = False
    
    _columns = {
         'pending_purchase_approval': fields.integer('Purchase Waiting For Approval',readonly=True),
         'pending_production_slip': fields.integer('Pending Production Slip',readonly=True),
         'pending_store_approval': fields.integer('Pending Store Request Approval',readonly=True),
         'pending_dispatch_qc_ha': fields.integer('Dispatch QC HA Pending ',readonly=True),
         'pending_qc_ha': fields.integer('Quality Control HA Pending',readonly=True),
         'pending_sales_grn_qc_ha': fields.integer('Sales GRN QC HA Pending',readonly=True),
         'pending_ptn_qc_ha': fields.integer('PTN QC HA Pending',readonly=True),
         }
    
    def init(self, cr):
        sql.drop_view_if_exists(cr, 'prakruti_gm_report')
        cr.execute("""
          CREATE or REPLACE view prakruti_gm_report AS 
          (
          
         SELECT  pending_purchase_approval.id as id,
            pending_purchase_approval,
            pending_production_slip,
            pending_store_approval,
            pending_dispatch_qc_ha,
            pending_qc_ha,
            pending_sales_grn_qc_ha,
            pending_ptn_qc_ha 

            FROM
          (
         
	  SELECT 
            count(id) as pending_purchase_approval,
            CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id
         FROM 
             prakruti_purchase_requisition_approve
         WHERE
             prakruti_purchase_requisition_approve.state='approve'
     
          ) AS pending_purchase_approval LEFT JOIN
          (
         SELECT 
            count(id) as pending_production_slip,
            CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
         FROM 
             prakruti_production_slip
         WHERE
             prakruti_production_slip.state='slip_request'

          ) as pending_production_slip
          ON pending_purchase_approval.id = pending_production_slip.id
             
         LEFT JOIN
          (

         SELECT 
           count(id) as pending_store_approval,
           CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
         FROM 
             prakruti_store_approve_request
         WHERE
             prakruti_store_approve_request.state='approve'
            ) as pending_store_approval
          ON pending_purchase_approval.id = pending_store_approval.id
       LEFT JOIN
          (


          SELECT 
           count(id) as pending_dispatch_qc_ha,
           CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
         FROM 
             prakruti_quality_check_ha
         WHERE
             prakruti_quality_check_ha.state='draft'

 ) as pending_dispatch_qc_ha
          ON pending_purchase_approval.id = pending_dispatch_qc_ha.id
       LEFT JOIN
          (


          SELECT 
            count(id) as pending_qc_ha,
           CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
         FROM 
             prakruti_quality_control_ha
         WHERE
             prakruti_quality_control_ha.state='qc_ha'

         ) as pending_qc_ha
          ON pending_purchase_approval.id = pending_qc_ha.id
       LEFT JOIN
          (

         SELECT 
           count(id)  pending_sales_grn_qc_ha,
           CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
         FROM 
             prakruti_sales_return_grn_qc_ha
         WHERE
             prakruti_sales_return_grn_qc_ha.state='qc_check'

 ) as pending_sales_grn_qc_ha
          ON pending_purchase_approval.id = pending_sales_grn_qc_ha.id
       LEFT JOIN
          (

         SELECT 
          count(id) pending_ptn_qc_ha,
          CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
         FROM 
             prakruti_production_transfer_note_ha
         WHERE
             prakruti_production_transfer_note_ha.state='ha_check'
             
         ) as pending_ptn_qc_ha
          ON pending_purchase_approval.id = pending_ptn_qc_ha.id
             
	  )
          """)
        
prakruti_gm_report()




class prakruti_store_report(osv.osv):
    _name = "prakruti.store.report"
    _description = "Store Dashboard"
    _auto = False
    
    _columns = {
         'no_of_request': fields.integer('Store Request',readonly=True),
         'pending_store_approval': fields.integer('Pending Store Request Approval',readonly=True),
         'pending_store_issue': fields.integer('Pending Store Issue',readonly=True)
         }
    
    def init(self, cr):
        sql.drop_view_if_exists(cr, 'prakruti_store_report')
        cr.execute("""
          CREATE or REPLACE view prakruti_store_report AS 
          (
          
         SELECT  no_of_request.id as id,
            no_of_request,
            pending_store_approval,
            pending_store_issue

            FROM
          (
         
	  SELECT 
            count(id) as no_of_request,
            CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id
         FROM 
             prakruti_store_request
         WHERE
             prakruti_store_request.state='request'
     
          ) AS no_of_request LEFT JOIN
          (
         SELECT 
            count(id) as pending_store_approval,
            CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
         FROM 
             prakruti_store_approve_request
         WHERE
             prakruti_store_approve_request.state='approve'

          ) as pending_store_approval
          ON no_of_request.id = pending_store_approval.id
             
         LEFT JOIN
          (

         SELECT 
           count(id) as pending_store_issue,
           CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
         FROM 
             prakruti_store_issue
         WHERE
             prakruti_store_issue.status='waiting'
            ) as pending_store_issue
          ON no_of_request.id = pending_store_issue.id
      
             
	  )
          """)
        
prakruti_store_report()



class prakruti_purchase_report(osv.osv):
    _name = "prakruti.purchase.report"
    _description = "Purchase Dashboard"
    _auto = False
    
    _columns = {
         'no_of_requistion': fields.integer('Purchase Requistion Raised',readonly=True),
         'pending_purchase_approval': fields.integer('Waiting For Approval',readonly=True),
         'pending_purchase_analaysis': fields.integer('Waiting For Analaysis',readonly=True),
         'pending_purchase_quatation': fields.integer('Waiting For Quatation',readonly=True),
         'pending_purchase_quatation_analaysis': fields.integer('Waiting For Quatation Analaysis',readonly=True),
         'confirmed_purchase_order': fields.integer('Purchase Order Confirmed',readonly=True),
         'meterial_received': fields.integer('Meterial Received',readonly=True)
         }
    
    def init(self, cr):
        sql.drop_view_if_exists(cr, 'prakruti_purchase_report')
        cr.execute("""
          CREATE or REPLACE view prakruti_purchase_report AS 
          (
          SELECT  no_of_requistion.id as id,
            no_of_requistion,
            pending_purchase_approval,
            pending_purchase_analaysis,
            pending_purchase_quatation,
            pending_purchase_quatation_analaysis,
            confirmed_purchase_order,
            meterial_received
            FROM
          (
                SELECT 
                    count(id) as no_of_requistion,
		    CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id
		 FROM 
		     prakruti_purchase_requisition
		 WHERE
		     prakruti_purchase_requisition.state='requisition'
          ) AS no_of_requistion 
          LEFT JOIN
          (
		 SELECT 
		    count(id) as pending_purchase_approval,
		    CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
		 FROM 
		     prakruti_purchase_requisition_approve
		 WHERE
		     prakruti_purchase_requisition_approve.state='approve'

          ) as pending_purchase_approval
          ON no_of_requistion.id = pending_purchase_approval.id
             
         LEFT JOIN
          (
           SELECT 
		   count(id) as pending_purchase_analaysis,
		   CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
		 FROM 
		     prakruti_purchase_requistion_analysis
		 WHERE
		     prakruti_purchase_requistion_analysis.state='requisition_analysis'
           ) as pending_purchase_analaysis
          ON no_of_requistion.id = pending_purchase_analaysis.id
          LEFT JOIN
          (
                SELECT 
                   count(id) as pending_purchase_quatation,
		   CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
		 FROM 
		     prakruti_purchase_order_quotation
		 WHERE
		     prakruti_purchase_order_quotation.state='quotation'
            ) as pending_purchase_quatation
          ON no_of_requistion.id = pending_purchase_quatation.id

           LEFT JOIN
          (
               SELECT 
		   count(id) as pending_purchase_quatation_analaysis,
		   CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
		 FROM 
		     prakruti_purchase_order_quotation_analysis
		 WHERE
		     prakruti_purchase_order_quotation_analysis.state='analysis'
            ) as pending_purchase_quatation_analaysis
          ON no_of_requistion.id = pending_purchase_quatation_analaysis.id

           LEFT JOIN
          (
                SELECT 
		   count(id) as confirmed_purchase_order,
		   CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
		 FROM 
		     prakruti_purchase_order
		 WHERE
		     prakruti_purchase_order.state='confirm'
            ) as confirmed_purchase_order
          ON no_of_requistion.id = confirmed_purchase_order.id
           LEFT JOIN
          (
                SELECT 
		   count(id) as meterial_received,
		   CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
		 FROM 
		     prakruti_grn_inspection_details
		 WHERE
		     prakruti_grn_inspection_details.state='done'
            ) as meterial_received
          ON no_of_requistion.id = meterial_received.id
	  )
          """)
        
prakruti_purchase_report()




class prakruti_sales_report(osv.osv):
    _name = "prakruti.sales.report"
    _description = "Sales Dashboard"
    _auto = False
    
    _columns = {
         'no_of_sales_request': fields.integer('Sales Inquiry Raised',readonly=True),
         'no_of_sales_quatation': fields.integer('Sales Quatation',readonly=True),
         'no_of_sales_confirmed': fields.integer('Sales Order Confirmed'),
         'pending_production_slip': fields.integer('Pending Production Slip',readonly=True),
         'no_of_sales_dispatched': fields.integer('Dispatched',readonly=True)
         }
    
    def init(self, cr):
        sql.drop_view_if_exists(cr, 'prakruti_sales_report')
        cr.execute("""
          CREATE or REPLACE view prakruti_sales_report AS 
          (
          SELECT  no_of_sales_request.id as id,
            no_of_sales_request,
            no_of_sales_quatation,
            no_of_sales_confirmed,
            pending_production_slip,
            no_of_sales_dispatched
            FROM
          (
		  SELECT 
		    count(id) as no_of_sales_request,
		    CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id
		 FROM 
		     prakruti_sales_inquiry
		 WHERE
		     prakruti_sales_inquiry.state='inquiry'
          ) AS no_of_sales_request LEFT JOIN
          (
		 SELECT 
		    count(id) as no_of_sales_quatation,
		    CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
		 FROM 
		     prakruti_sales_quotation
		 WHERE
		     prakruti_sales_quotation.state='quotation'
          ) as no_of_sales_quatation
          ON no_of_sales_request.id = no_of_sales_quatation.id
             
         LEFT JOIN
          (
		 SELECT 
		   count(id) as no_of_sales_confirmed,
		   CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
		 FROM 
		     prakruti_sales_order
		 WHERE
		     prakruti_sales_order.state='confirm'
            ) as no_of_sales_confirmed
          ON no_of_sales_request.id = no_of_sales_confirmed.id
          LEFT JOIN
          (
		 SELECT 
		   count(id) as pending_production_slip,
		   CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
		 FROM 
		     prakruti_production_slip
		 WHERE
		     prakruti_production_slip.state='slip_request'
            ) as pending_production_slip
          ON no_of_sales_request.id = pending_production_slip.id
          LEFT JOIN
          (
              SELECT 
		   count(id) as no_of_sales_dispatched,
		   CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
		 FROM 
		     prakruti_dispatch
		 WHERE
		     prakruti_dispatch.state='done'
            ) as no_of_sales_dispatched
          ON no_of_sales_request.id = no_of_sales_dispatched.id
	  )
          """)
        
prakruti_sales_report()




class prakruti_quality_report(osv.osv):
    _name = "prakruti.quality.report"
    _description = "Quality Dashboard"
    _auto = False
    
    _columns = {
         'pending_dispatch_qc': fields.integer('Pending Dispatch Quality Control',readonly=True),
         'pending_qc': fields.integer('Pending Quality Control',readonly=True),
         'pending_sales_grn_qc': fields.integer('Pending Sales GRN Quality Control',readonly=True),
         'pending_ptn_qc': fields.integer('Pending PTN Quality Control',readonly=True)
         }
    
    def init(self, cr):
        sql.drop_view_if_exists(cr, 'prakruti_quality_report')
        cr.execute("""
          CREATE or REPLACE view prakruti_quality_report AS 
          (
          SELECT  pending_dispatch_qc.id as id,
            pending_dispatch_qc,
            pending_qc,
            pending_sales_grn_qc,
            pending_ptn_qc
            FROM
          (
		  SELECT 
		    count(id) as pending_dispatch_qc,
		    CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id
		 FROM 
		     prakruti_quality_check
		 WHERE
		     prakruti_quality_check.state='draft'
          ) AS pending_dispatch_qc LEFT JOIN
          (
		 SELECT 
		    count(id) as pending_qc,
		    CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
		 FROM 
		     prakruti_quality_control
		 WHERE
		     prakruti_quality_control.state='qc'
          ) as pending_qc
          ON pending_dispatch_qc.id = pending_qc.id
             
         LEFT JOIN
          (
		 SELECT 
		   count(id) as pending_sales_grn_qc,
		   CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
		 FROM 
		     prakruti_sales_return_grn_qc
		 WHERE
		     prakruti_sales_return_grn_qc.state='qc_check'
            ) as pending_sales_grn_qc
          ON pending_dispatch_qc.id = pending_sales_grn_qc.id
          LEFT JOIN
          (
		 SELECT 
		   count(id) as pending_ptn_qc,
		   CAST(EXTRACT(year from now()) as text) || CAST(EXTRACT(month from now()) as text) as id 
		 FROM 
		     prakruti_production_transfer_note_qc
		 WHERE
		     prakruti_production_transfer_note_qc.state='qc_check'
            ) as pending_ptn_qc
          ON pending_dispatch_qc.id = pending_ptn_qc.id
	  )
          """)
        
prakruti_quality_report()







