# -*- coding: utf-8 -*-
from openerp.osv import osv,fields
from openerp.tools.translate import _
import time
from datetime import datetime
import sys, os, urllib2, urlparse
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
import cgi
import lxml.html
import lxml.html.clean as clean
from lxml import etree
import cgi
import logging
import lxml.html
import lxml.html.clean as clean
import openerp.pooler as pooler
import random
import re
import socket
import threading
import time

_logger = logging.getLogger(__name__)


class purchase_quatation_email_report(osv.osv_memory):
    _name = "report.purchase_quatation_email_report"
    
    _description = "Purchase Quatation" 

    def send_mail_quotation(self, cr, uid, ids, cron_mode=True, context=None):        
        ids = 24
        email_obj  = self.pool.get('email.template')
        template_id=email_obj.search(cr, uid, [('name', '=', 'Purchase Quatation')], context=context)[0]
        
        cr.execute('''SELECT COALESCE(count(id),0) As quatation_id  FROM prakruti_purchase_order_quotation  ''')
        for record_count in cr.dictfetchall():
            record_count = record_count['quatation_id']
            
            if record_count != 0:                
                yesterday = date.today() - timedelta(1)
                YesDay = yesterday.strftime('%d-%m-%Y')
                yester_day = str(YesDay)
                
                body = '''Dear Purchase Incharge, <br/><br/>''' +'''
                    Prakruti ERP application did not get the Quatation data for the date of  ''' + yester_day +'''. Prakruti ERP application generates automatic report at
                    10:30 AM every day. Please complete the data entry before 10:30 AM
                    so that Prakruti ERP application takes correct data for reporting.
                    Missing data for today's report have been notified to Purchase Incharge / Management.
                    Make sure this doesn't happen in the future. <br/><br/> Regards <br/> Prakruti ERP application admin'''
                    
                sub =  'Purchase Quatation'
                
                email_obj.write(cr, uid, template_id, {'subject': sub})
                email_obj.write(cr, uid, template_id, {'body_html': body})
                                
                email_obj.send_mail(cr, uid, template_id, ids, force_send=True)
    
purchase_quatation_email_report()
