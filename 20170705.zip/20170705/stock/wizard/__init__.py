# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import stock_move
import stock_return_picking
import stock_change_product_qty
import make_procurement_product
import orderpoint_procurement
import stock_immediate_transfer
import stock_backorder_confirmation