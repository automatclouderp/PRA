CREATE OR REPLACE FUNCTION public.update_planning_stock(integer)
  RETURNS integer AS
$BODY$

BEGIN

UPDATE prakruti_production_planning_line set store_qty = final.quantity  FROM(SELECT store_qty.product_id,quantity,id FROM(SELECT location_id,product_id,SUM(quantity) as quantity from ((SELECT stock_move.id AS id,stock_move.id AS move_id,dest_location.id AS location_id,dest_location.company_id AS company_id,
                    stock_move.product_id AS product_id,
                    product_template.categ_id AS product_categ_id,
                    quant.qty AS quantity,
                    stock_move.date AS date,
                    quant.cost as price_unit_on_quant,
                    stock_move.origin AS source
                    ,a.name as name

                FROM
                    stock_move
                JOIN
                    stock_quant_move_rel on stock_quant_move_rel.move_id = stock_move.id
                JOIN
                    stock_quant as quant on stock_quant_move_rel.quant_id = quant.id
                JOIN
                   stock_location dest_location ON stock_move.location_dest_id = dest_location.id
                JOIN
                    stock_location source_location ON stock_move.location_id = source_location.id
                JOIN
                    product_product ON product_product.id = stock_move.product_id
                JOIN
                    product_template ON product_template.id = product_product.product_tmpl_id
                 join stock_location as a on a.id=  dest_location.id
                WHERE quant.qty>0 AND stock_move.state = 'done' AND dest_location.usage in ('internal', 'transit')
                AND ((source_location.company_id is null and dest_location.company_id is not null) or
                (source_location.company_id is not null and dest_location.company_id is null)
                or source_location.company_id != dest_location.company_id
                 or source_location.company_id=dest_location.company_id)

                ) UNION ALL
                (SELECT
                    (-1) * stock_move.id AS id,
                    stock_move.id AS move_id,
                    source_location.id AS location_id,
                    source_location.company_id AS company_id,
                    stock_move.product_id AS product_id,
                    product_template.categ_id AS product_categ_id,
                    - quant.qty AS quanquantitytity,
                    stock_move.date AS date,
                    quant.cost as price_unit_on_quant,
                    stock_move.origin AS source
                   , a.name as name
                FROM
                    stock_move
                JOIN
                    stock_quant_move_rel on stock_quant_move_rel.move_id = stock_move.id
                JOIN
                    stock_quant as quant on stock_quant_move_rel.quant_id = quant.id
                JOIN
                    stock_location source_location ON stock_move.location_id = source_location.id
                JOIN
                    stock_location dest_location ON stock_move.location_dest_id = dest_location.id
                JOIN
                    product_product ON product_product.id = stock_move.product_id
                JOIN
                    product_template ON product_template.id = product_product.product_tmpl_id
                  join stock_location as a on a.id=  dest_location.id
                WHERE quant.qty>0 AND stock_move.state = 'done' AND source_location.usage in ('internal', 'transit')
                AND ((source_location.company_id is null and dest_location.company_id is not null) or
                (source_location.company_id is not null and dest_location.company_id is null)
                or source_location.company_id != dest_location.company_id
                 or source_location.company_id=dest_location.company_id)

                ))
                AS foo
                GROUP BY location_id,product_id
                ) as store_qty 
                LEFT JOIN
                (
                 SELECT product_id,id FROM prakruti_production_planning_line where
                  planning_id =$1
                ) as pppl ON
                    pppl.product_id = store_qty.product_id
               ) as final 
                 WHERE 
                 final.id = prakruti_production_planning_line.id AND 
                 final.product_id =prakruti_production_planning_line.product_id AND planning_id =$1 ;


UPDATE prakruti_production_planning_line set virtual_qty = final.quantity  FROM(SELECT store_qty.product_id,quantity,id FROM(SELECT location_id,product_id,SUM(quantity) as quantity from ((SELECT stock_move.id AS id,stock_move.id AS move_id,dest_location.id AS location_id,dest_location.company_id AS company_id,
                    stock_move.product_id AS product_id,
                    product_template.categ_id AS product_categ_id,
                    quant.virtual_qty AS quantity,
                    stock_move.date AS date,
                    quant.cost as price_unit_on_quant,
                    stock_move.origin AS source
                    ,a.name as name
                FROM
                    stock_move
                JOIN
                    stock_quant_move_rel on stock_quant_move_rel.move_id = stock_move.id
                JOIN
                    stock_quant as quant on stock_quant_move_rel.quant_id = quant.id
                JOIN
                   stock_location dest_location ON stock_move.location_dest_id = dest_location.id
                JOIN
                    stock_location source_location ON stock_move.location_id = source_location.id
                JOIN
                    product_product ON product_product.id = stock_move.product_id
                JOIN
                    product_template ON product_template.id = product_product.product_tmpl_id
                 join stock_location as a on a.id=  dest_location.id
                WHERE quant.virtual_qty>0 AND stock_move.state = 'done' OR stock_move.state = 'virtual_entry' AND dest_location.usage in ('internal', 'transit')
                AND ((source_location.company_id is null and dest_location.company_id is not null) or
                (source_location.company_id is not null and dest_location.company_id is null)
                or source_location.company_id != dest_location.company_id
                 or source_location.company_id=dest_location.company_id)

                ) UNION ALL
                (SELECT
                    (-1) * stock_move.id AS id,
                    stock_move.id AS move_id,
                    source_location.id AS location_id,
                    source_location.company_id AS company_id,
                    stock_move.product_id AS product_id,
                    product_template.categ_id AS product_categ_id,
                    - quant.virtual_qty AS quanquantitytity,
                    stock_move.date AS date,
                    quant.cost as price_unit_on_quant,
                    stock_move.origin AS source
                   , a.name as name
                FROM
                    stock_move
                JOIN
                    stock_quant_move_rel on stock_quant_move_rel.move_id = stock_move.id
                JOIN
                    stock_quant as quant on stock_quant_move_rel.quant_id = quant.id
                JOIN
                    stock_location source_location ON stock_move.location_id = source_location.id
                JOIN
                    stock_location dest_location ON stock_move.location_dest_id = dest_location.id
                JOIN
                    product_product ON product_product.id = stock_move.product_id
                JOIN
                    product_template ON product_template.id = product_product.product_tmpl_id
                  join stock_location as a on a.id=  dest_location.id
                WHERE quant.virtual_qty>0 AND stock_move.state = 'done' OR stock_move.state = 'virtual_entry' AND source_location.usage in ('internal', 'transit')
                AND ((source_location.company_id is null and dest_location.company_id is not null) or
                (source_location.company_id is not null and dest_location.company_id is null)
                or source_location.company_id != dest_location.company_id
                 or source_location.company_id=dest_location.company_id)

                ))
                AS foo
                GROUP BY location_id,product_id
                ) as store_qty 
                LEFT JOIN
                (
                 SELECT product_id,id FROM prakruti_production_planning_line where
                  planning_id =$1
                ) as pppl ON
                    pppl.product_id = store_qty.product_id
               ) as final 
                 WHERE 
                 final.id = prakruti_production_planning_line.id AND 
                 final.product_id =prakruti_production_planning_line.product_id AND planning_id =$1;


RETURN 0;



  END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION public.update_planning_stock(integer)
  OWNER TO odoo;