-- Function: public.updatedispatchstock(integer)

-- DROP FUNCTION public.updatedispatchstock(integer);

CREATE OR REPLACE FUNCTION public.updatedispatchstock(integer)
  RETURNS integer AS
$BODY$
DECLARE qty   integer;
BEGIN

qty = 0;

INSERT INTO procurement_group(
                            create_uid,
                            create_date,
                            name,
                            move_type,
                            write_date,
                            write_uid
                            )                                    
SELECT  create_uid,
        create_date,
        order_no,
        move_type,
        write_date,
        write_uid
FROM(SELECT
        prakruti_dispatch.create_uid,
        prakruti_dispatch.create_date,
        prakruti_dispatch.order_no,
        CAST('direct' as character varying) as move_type,
        prakruti_dispatch.write_date,        
        prakruti_dispatch.write_uid
    FROM 
        prakruti_dispatch 
    INNER JOIN
        prakruti_dispatch_line 
    ON 
        prakruti_dispatch.id = prakruti_dispatch_line.main_id 
    WHERE
        prakruti_dispatch.id = $1 AND send_status = 'dispatch'
        
        ) AS A ;

INSERT INTO stock_move(
                    origin,
                    create_date,
                    product_uom,
                    price_unit,
                    product_uom_qty,
                    company_id,
                    date,
                    product_qty,
                    location_id,
                    priority,
                    picking_type_id,
                    sequence,
                    state,
                    date_expected,
                    name,
                    warehouse_id,
                    partially_available,
                    propagate,
                    procure_method,
                    write_uid,
                    product_id,
                    location_dest_id,           
                    prakruti_sale_id
                    ) 
SELECT  origin,
        create_date,
        uom_id,
        price_unit,
        - product_uom_qty,    
        company_id,
        write_date,
        - quantity,        
        location_id,
        priority,
        picking_type_id,
        sequence,
        state,
        write_date,
        order_no,
        warehouse_id,
        partially_available,
        propagate,
        procure_method,
        write_uid,
        product_id,
        location_dest_id,
        id   
FROM ( SELECT
        prakruti_dispatch.order_no as origin,
        prakruti_dispatch.create_date,
        prakruti_dispatch_line.uom_id,
        CAST(1 as integer) as price_unit,
        -- prakruti_dispatch_line.accepted_qty as product_uom_qty,
        CAST(coalesce(prakruti_dispatch_line.accepted_qty, '0') AS integer )as product_uom_qty,
        prakruti_dispatch.company_id,
        prakruti_dispatch.write_date as date,
        prakruti_dispatch_line.accepted_qty as quantity,
        CAST(12 as integer) as location_id,
        CAST(1 as integer) as priority,
        CAST(1 as integer) as picking_type_id,
        CAST(10 as integer) as sequence,
        CAST('done' as character varying) as state,
        prakruti_dispatch_line.write_date,
        prakruti_dispatch.order_no,
        CAST(1 as integer) as warehouse_id,        
        CAST('f' as boolean) as partially_available,        
        CAST('t' as boolean) as propagate,
        CAST('make_to_stock' as character varying) as  procure_method,
        prakruti_dispatch.write_uid,        
        prakruti_dispatch_line.product_id,
        CAST(12 as integer) as location_dest_id,
        prakruti_dispatch.id    
    FROM 
        public.prakruti_dispatch 
    INNER JOIN
        public.prakruti_dispatch_line 
    ON 
        prakruti_dispatch.id = prakruti_dispatch_line.main_id 
    WHERE
        prakruti_dispatch.id = $1 AND send_status = 'dispatch'
        
        ) AS B;
        
INSERT INTO stock_quant(
        create_date,
        write_uid,
        cost,
        location_id,
        company_id,
        write_date,
        qty,
        product_id,
        in_date        
        )        
SELECT  
        create_date,
        write_uid,
        cost,
        location_dest_id,
        company_id,
        write_date,        
        - product_uom_qty,
        product_id,
        in_date       
    FROM(SELECT
        prakruti_dispatch.create_date,
        prakruti_dispatch.write_uid,
        CAST(1 as integer) as cost,        
        CAST(12 as integer) as location_dest_id,        
        prakruti_dispatch.company_id, 
        prakruti_dispatch.write_date,        
        -- prakruti_dispatch_line.accepted_qty as product_uom_qty,
        CAST(coalesce(prakruti_dispatch_line.accepted_qty, '0') AS integer )as product_uom_qty,        
        prakruti_dispatch_line.product_id,
        prakruti_dispatch.write_date as in_date       
    FROM 
        public.prakruti_dispatch 
    INNER JOIN
        public.prakruti_dispatch_line 
    ON 
        prakruti_dispatch.id = prakruti_dispatch_line.main_id 
    WHERE
        prakruti_dispatch.id = $1 AND send_status = 'dispatch'
        
        ) AS C ;
        
INSERT INTO stock_picking( 
        origin,
        date_done,
        write_uid,
        launch_pack_operations,
        partner_id,
        priority,
        picking_type_id,
        location_id,
        move_type,
        company_id,
        state,
        name,
        min_date,        
        printed,
        write_date,
        date,
        recompute_pack_op,
        location_dest_id,
        max_date        
        )
SELECT 
        order_no,
        date_done,
        write_uid,
        launch_pack_operations,
        partner_id,
        priority,
        picking_id,
        location_id,        
        move_type,
        company_id,
        state,
        name,
        min_date,
        printed,
        write_date,
        date,
        recompute_pack_op,
        location_dest_id,
        max_date
        
FROM(SELECT
        prakruti_dispatch.order_no, 
        prakruti_dispatch.write_date as date_done,
        prakruti_dispatch.write_uid,
        CAST('f' as boolean) as launch_pack_operations,
        prakruti_dispatch.dispatch_to as partner_id,
        CAST(1 as integer) as priority,
        CAST(1 as integer) as picking_id,
        CAST(12 as integer) as location_id,
        CAST('direct' as character varying) as move_type,
        prakruti_dispatch.company_id,
        CAST('done' as character varying) as state,
        CAST('IN' || order_no as character varying) as name,
        prakruti_dispatch.create_date as min_date,
        CAST('f' as boolean) as printed,
        prakruti_dispatch_line.write_date,
        prakruti_dispatch_line.write_date as date,
        CAST('f' as boolean) as recompute_pack_op,
        CAST(12 as integer) as location_dest_id,
        prakruti_dispatch_line.write_date as max_date
    FROM 
        public.prakruti_dispatch 
    INNER JOIN
        public.prakruti_dispatch_line 
    ON 
        prakruti_dispatch.id = prakruti_dispatch_line.main_id 
    WHERE
        prakruti_dispatch.id = $1 AND send_status = 'dispatch'

        ) AS D ;


RETURN qty;
                                
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION public.updatedispatchstock(integer)
  OWNER TO odoo;