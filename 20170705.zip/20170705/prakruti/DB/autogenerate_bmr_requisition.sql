-- Function: public.autogenerate_bmr_requisition(integer)

-- DROP FUNCTION public.autogenerate_bmr_requisition(integer);

CREATE OR REPLACE FUNCTION public.autogenerate_bmr_requisition(integer)
  RETURNS integer AS
$BODY$
DECLARE serial_number text;
DECLARE id_product text;
DECLARE id_plant integer;
DECLARE s_id integer;
DECLARE plant_id_inward integer;
DECLARE year_added integer;
        month_added integer;
        serial_disable_id1 integer;

BEGIN

s_id=0;

  
-- year_added = Year from entry date.
SELECT  CAST(EXTRACT(YEAR FROM start_date) as integer) into year_added FROM prakruti_bmr_requisition WHERE id =$1;
SELECT  CAST(EXTRACT(MONTH FROM start_date) as integer) into month_added FROM prakruti_bmr_requisition WHERE id =$1;

SELECT CASE WHEN month_added > 3 THEN year_added ELSE (year_added -1 ) END into year_added ;
select req_no_control_id into serial_disable_id1 from prakruti_bmr_requisition where prakruti_bmr_requisition.id =$1;


-- serial_disable_id1 is 0 for the first time only.
if(serial_disable_id1=0)

THEN

        SELECT  MAX(coalesce(a.auto_no,0)+1) into s_id
        FROM  prakruti_bmr_requisition as a
        WHERE start_date between cast(year_added||'-04-'||'01' as date) and cast(year_added+1||'-03-'||'31' as date) ;


        if length(cast(s_id as text)) < 2 then s_id = '00'|| cast(s_id as text);
        ELSIF length(cast(s_id as text)) < 3 then s_id = '0' || cast(s_id as text);
	    
        else
	s_id = cast(s_id as text);
	end if;
        update prakruti_bmr_requisition set req_no_control_id = 1,auto_no = s_id where
                        prakruti_bmr_requisition.id = $1 ;

ELSE

       

        SELECT  a.auto_no into s_id
        FROM  prakruti_bmr_requisition as a
        WHERE    a.id =$1;


         if length(cast(s_id as text)) < 2 then s_id = '00'|| cast(s_id as text);
        ELSIF length(cast(s_id as text)) < 3 then s_id = '0' || cast(s_id as text);
	    
        else
	s_id = cast(s_id as text);
	end if;
        
        update prakruti_bmr_requisition set auto_no = s_id where
                        prakruti_bmr_requisition.id = $1 ;


END IF;
RETURN s_id;



  END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION public.autogenerate_bmr_requisition(integer)
  OWNER TO odoo;