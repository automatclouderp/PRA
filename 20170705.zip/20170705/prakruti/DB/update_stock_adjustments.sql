CREATE OR REPLACE FUNCTION public.update_stock_adjustments(integer)
  RETURNS integer AS
$BODY$
DECLARE qty   integer;
BEGIN

qty = 0;

INSERT INTO procurement_group(name,move_type,partner_id,write_date,write_uid
                                    ) 
                                   SELECT 
                                   po_name,
                                   'direct' as move_type,vendor_id,in_date,write_uid
                                  FROM(
                            SELECT
                            CAST(12 as integer) as unit_price,
                            CAST(12 as integer) as location_dest_id,
                            CAST(1 as integer) as company_address, 
                            prakruti_stock_adjustments.write_date as create_date,
                            (prakruti_stock_adjustments_line.real_qty - prakruti_stock_adjustments_line.stock_qty) as product_uom_qty,
                            prakruti_stock_adjustments_line.product_id,
                            prakruti_stock_adjustments.write_date as in_date,
                            prakruti_stock_adjustments_line.description as po_name,
                            CAST(1 as integer) as vendor_id,
                            prakruti_stock_adjustments.write_uid
                            

                            FROM 
                            public.prakruti_stock_adjustments INNER JOIN
                            public.prakruti_stock_adjustments_line ON 
                            prakruti_stock_adjustments.id = prakruti_stock_adjustments_line.adjustment_id 
                            WHERE
                            prakruti_stock_adjustments.id = $1
                            ) AS B;

                            
INSERT INTO stock_move(
                            product_uom,
                            product_uom_qty,
                            virtual_qty,
                            company_id,
                            date,
                            product_qty,
                            location_id,
                            priority,
                            sequence,
                            state,
                            date_expected,
                            name,
                            partially_available,
                            propagate,
                            procure_method,
                            product_id,
                            location_dest_id,
                            prakruti_purchase_id,
                            origin,
                            create_date,
                            picking_type_id,
                            price_unit,
                            warehouse_id,
                            write_uid)

SELECT 
                            uom_id,
                            product_uom_qty,
                            virtual_qty,
                            company_address,
                            write_date,
                            accepted_qty,
                            location_id,
                            priority,
                            sequence,
                            state,
                            scheduled_date,
                            description,
                            partially_available,
                            propagate,
                            procure_method,
                            product_id,
                            location_dest_id,
                            id,
                            origin,
                            create_date,
                            picking_type_id,
                            unit_price,
                            warehouse_id,
                            write_uid 
FROM(
    SELECT
                            prakruti_stock_adjustments_line.uom_id, 
                            (prakruti_stock_adjustments_line.real_qty - prakruti_stock_adjustments_line.stock_qty) as product_uom_qty,
                            (prakruti_stock_adjustments_line.real_qty - prakruti_stock_adjustments_line.stock_qty) as virtual_qty,
                            CAST(1 as integer) as company_address,
                            prakruti_stock_adjustments.write_date,
                            (prakruti_stock_adjustments_line.real_qty - prakruti_stock_adjustments_line.stock_qty) as accepted_qty,
                            CAST(12 as integer) as location_id,
                            CAST(1 as integer) as priority,
                            CAST(10 as integer) as sequence,
                            CAST('done' as character varying) as state,
                            prakruti_stock_adjustments.write_date as scheduled_date,
                            CAST(prakruti_stock_adjustments_line.description as character varying) as description,
                            CAST('f' as boolean) as partially_available,
                            CAST('t' as boolean) as propagate,
                            CAST('make_to_stock' as character varying) as  procure_method,
                            prakruti_stock_adjustments_line.product_id,
                            CAST(12 as integer) as location_dest_id,
                            prakruti_stock_adjustments_line.id,
                            prakruti_stock_adjustments_line.description as origin,
                            prakruti_stock_adjustments.write_date as create_date,                            
                            CAST(1 as integer) as picking_type_id,
                            CAST(1 as integer) as unit_price,
                            CAST(1 as integer) as warehouse_id,
                            prakruti_stock_adjustments.write_uid
                            
                            
                            FROM 
                            prakruti_stock_adjustments INNER JOIN
                            prakruti_stock_adjustments_line ON 
                            prakruti_stock_adjustments.id = prakruti_stock_adjustments_line.adjustment_id 
                            WHERE
                            prakruti_stock_adjustments.id = $1
                            
                            ) AS C;
                            
                            
INSERT INTO stock_quant(cost,location_id,company_id,write_date,qty,product_id,in_date,write_uid
                                    ) 
                                    
                                   SELECT 
                                   unit_price,
                                   location_dest_id,
                                   company_address,create_date,product_uom_qty,product_id,in_date,write_uid
                                  FROM(
                            SELECT
                            CAST(12 as integer) as unit_price,
                            CAST(12 as integer) as location_dest_id,
                            CAST(1 as integer) as company_address, 
                            prakruti_stock_adjustments.write_date as create_date,
                            (prakruti_stock_adjustments_line.real_qty - prakruti_stock_adjustments_line.stock_qty) as product_uom_qty,
                            prakruti_stock_adjustments_line.product_id,
                            prakruti_stock_adjustments.write_date as in_date,
                            prakruti_stock_adjustments.write_uid
                            

                            FROM 
                            public.prakruti_stock_adjustments INNER JOIN
                            public.prakruti_stock_adjustments_line ON 
                            prakruti_stock_adjustments.id = prakruti_stock_adjustments_line.adjustment_id 
                            WHERE
                            prakruti_stock_adjustments.id = $1
                            
                            ) AS D;


                        
INSERT INTO stock_picking( 
origin,date_done,write_uid,launch_pack_operations,partner_id,priority,
picking_type_id,location_id,move_type,company_id,name,min_date,printed,write_date,date,recompute_pack_op,
location_dest_id,max_date,
--group_id,
state
) 
                                    
                                   SELECT 
                                   origin,
                                   write_date,
                                   write_uid,
                                   CAST('f' as boolean) as launch_pack_operations,
                                   picking_partner_id,
                                   priority,
                                   picking_id,
                                   location_dest_id,
                                   'direct' as move_type,
                                   company_address,
                                   CAST('IN' || origin as character varying) as name,
                                   scheduled_date,
                                   CAST('f' as boolean) as printed,
                                   write_date,
                                   write_date,
                                   CAST('f' as boolean) as recompute_pack_op,
                                   location_dest_id,
                                   write_date,
                                  -- 1 as group_id,
                                   'done' as state
                                  FROM(
                            SELECT
                            prakruti_stock_adjustments_line.uom_id, 
                            (prakruti_stock_adjustments_line.real_qty - prakruti_stock_adjustments_line.stock_qty) as product_uom_qty,
                            CAST(1 as integer) as company_address,  
                            prakruti_stock_adjustments.write_date,
                            (prakruti_stock_adjustments_line.real_qty - prakruti_stock_adjustments_line.stock_qty) as accepted_qty,
                            CAST(12 as integer) as location_id,
                            CAST(1 as integer) as priority,
                            CAST(10 as integer) as sequence,
                            CAST('done' as character varying) as state,
                            prakruti_stock_adjustments.write_date as scheduled_date,
                            CAST(prakruti_stock_adjustments_line.description as character varying) as description,
                            CAST('f' as boolean) as partially_available,
                            CAST('t' as boolean) as propagate,
                            CAST('make_to_stock' as character varying) as  procure_method,
                            prakruti_stock_adjustments_line.product_id,
                            CAST(12 as integer) as location_dest_id,
                            prakruti_stock_adjustments.id,
                            CAST(prakruti_stock_adjustments_line.description as character varying) as origin,
                            CAST(1 as integer) as picking_partner_id,
                            prakruti_stock_adjustments.write_date as create_date,
                            CAST(1 as integer) as picking_type_id,
                            CAST(12 as integer) as unit_price,
                            CAST(1 as integer) as picking_id,
                            CAST(1 as integer) as warehouse_id,
                            prakruti_stock_adjustments.write_uid
                            

                            FROM 
                            public.prakruti_stock_adjustments INNER JOIN
                            public.prakruti_stock_adjustments_line ON 
                            prakruti_stock_adjustments.id = prakruti_stock_adjustments_line.adjustment_id 
                            WHERE
                            prakruti_stock_adjustments.id = $1
                            
                            ) AS E ;

RETURN qty;
                                
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION public.update_stock_adjustments(integer)
  OWNER TO odoo;