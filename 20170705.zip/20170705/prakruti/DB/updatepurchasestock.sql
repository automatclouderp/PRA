-- Function: public.updatepurchasestock(integer)

-- DROP FUNCTION public.updatepurchasestock(integer);

CREATE OR REPLACE FUNCTION public.updatepurchasestock(integer)
  RETURNS integer AS
$BODY$
DECLARE qty   integer;
BEGIN

qty = 0;

INSERT INTO procurement_group(name,move_type,partner_id,write_date,write_uid
                                    ) 
                                   SELECT 
                                   po_name,
                                   'direct' as move_type,vendor_id,in_date,write_uid
                                  FROM(
                            SELECT
                            prakruti_grn_inspection_details_line.unit_price,
                            CAST(12 as integer) as location_dest_id,
                            prakruti_grn_inspection_details.company_address, 
                            prakruti_grn_inspection_details.write_date as create_date,
                            prakruti_grn_inspection_details_line.accepted_qty as product_uom_qty,
                            prakruti_grn_inspection_details_line.product_id,
                            prakruti_grn_inspection_details.write_date as in_date,
                            prakruti_grn_inspection_details.po_no as po_name,
                            prakruti_grn_inspection_details.vendor_id as vendor_id,
                            prakruti_grn_inspection_details.write_uid
                            

                            FROM 
                            public.prakruti_grn_inspection_details INNER JOIN
                            public.prakruti_grn_inspection_details_line ON 
                            prakruti_grn_inspection_details.id = prakruti_grn_inspection_details_line.inspection_line_id 
                            WHERE
                            prakruti_grn_inspection_details.id = $1
                            ) AS B;

                            
INSERT INTO stock_move(
                            product_uom,
                            product_uom_qty,
                            virtual_qty,
                            company_id,
                            date,
                            product_qty,
                            location_id,
                            priority,
                            sequence,
                            state,
                            date_expected,
                            name,
                            partially_available,
                            propagate,
                            procure_method,
                            product_id,
                            location_dest_id,
                            prakruti_purchase_id,
                            origin,
                            create_date,
                            picking_type_id,
                            price_unit,
                            warehouse_id,
                            write_uid)

SELECT 
                            uom_id,
                            product_uom_qty,
                            virtual_qty,
                            company_address,
                            write_date,
                            accepted_qty,
                            location_id,
                            priority,
                            sequence,
                            state,
                            scheduled_date,
                            description,
                            partially_available,
                            propagate,
                            procure_method,
                            product_id,
                            location_dest_id,
                            id,
                            origin,
                            create_date,
                            picking_type_id,
                            unit_price,
                            warehouse_id,
                            write_uid 
FROM(
    SELECT
                            prakruti_grn_inspection_details_line.uom_id, 
                            prakruti_grn_inspection_details_line.accepted_qty as product_uom_qty,
                            prakruti_grn_inspection_details_line.accepted_qty as virtual_qty,
                            prakruti_grn_inspection_details.company_address, 
                            prakruti_grn_inspection_details.write_date,
                            prakruti_grn_inspection_details_line.accepted_qty,
                            CAST(12 as integer) as location_id,
                            CAST(1 as integer) as priority,
                            CAST(10 as integer) as sequence,
                            CAST('done' as character varying) as state,
                            prakruti_grn_inspection_details_line.scheduled_date,
                            CAST(prakruti_grn_inspection_details_line.description as character varying) as description,
                            CAST('f' as boolean) as partially_available,
                            CAST('t' as boolean) as propagate,
                            CAST('make_to_stock' as character varying) as  procure_method,
                            prakruti_grn_inspection_details_line.product_id,
                            CAST(12 as integer) as location_dest_id,
                            prakruti_grn_inspection_details_line.id,
                            prakruti_grn_inspection_details.po_no as origin,
                            prakruti_grn_inspection_details.write_date as create_date,                            
                            CAST(1 as integer) as picking_type_id,
                            prakruti_grn_inspection_details_line.unit_price,
                            CAST(1 as integer) as warehouse_id,
                            prakruti_grn_inspection_details.write_uid
                            
                            
                            FROM 
                            prakruti_grn_inspection_details INNER JOIN
                            prakruti_grn_inspection_details_line ON 
                            prakruti_grn_inspection_details.id = prakruti_grn_inspection_details_line.inspection_line_id 
                            WHERE
                            prakruti_grn_inspection_details.id = $1
                            
                            ) AS C;
INSERT INTO stock_move( product_uom,
                        product_uom_qty,
                        virtual_qty,
                        company_id,
                        date,
                        product_qty,
                        location_id,
                        priority,
                        sequence,
                        state,
                        date_expected,
                        name,
                        partially_available,
                        propagate,
                        procure_method,
                        product_id,
                        location_dest_id,
                        prakruti_purchase_id,
                        origin,
                        create_date,
                        picking_type_id,
                        price_unit,
                        warehouse_id,
                        write_uid
                        ) 
                                    
SELECT                  uom_id,
                        product_uom_qty,
                        virtual_qty,
                        company_address,
                        write_date,
                        quantity,
                        location_id,
                        priority,
                        sequence,
                        state,
                        scheduled_date,
                        description,
                        partially_available,
                        propagate,
                        procure_method,
                        product_id,
                        location_dest_id,
                        id,
                        origin,
                        create_date,
                        picking_type_id,
                        unit_price,
                        warehouse_id,
                        write_uid
                        
                FROM(
                
                SELECT  pgindl.uom_id,
                        pml.qty*pgindl.packing_style as product_uom_qty,
                        pml.qty*pgindl.packing_style as virtual_qty,
                        grn.company_address, 
                        grn.write_date,
                        pml.qty*pgindl.packing_style as quantity,
                        CAST(12 as integer) as location_id,
                        CAST(1 as integer) as priority,
                        CAST(10 as integer) as sequence,
                        CAST('done' as character varying) as state,
                        pgindl.scheduled_date,
                        CAST(pgindl.description as character varying) as description,
                        CAST('f' as boolean) as partially_available,
                        CAST('t' as boolean) as propagate,
                        CAST('make_to_stock' as character varying) as  procure_method,                        
                        packing_name as product_id,
                        CAST(12 as integer) as location_dest_id,
                        pgindl.id,
                        grn.po_no as origin,
                        grn.write_date as create_date,
                        CAST(1 as integer) as picking_type_id,
                        pgindl.unit_price,
                        CAST(1 as integer) as warehouse_id,
                        grn.write_uid

                FROM    packing_material_line as pml
                INNER JOIN 
                        product_template as pt ON 
                        pml.packing_id = pt.id
                INNER JOIN 
			product_product as pp ON
			pt.id = pp.product_tmpl_id                                  
                INNER JOIN
                        prakruti_grn_inspection_details_line as pgindl ON
                        pgindl.product_id = pp.id
                INNER JOIN 
                        prakruti_grn_inspection_details as grn ON
                        grn.id = pgindl.inspection_line_id
                WHERE 
                        grn.id = $1 )AS P;
                            
                            
INSERT INTO stock_quant(cost,location_id,company_id,write_date,qty,product_id,in_date,write_uid
                                    ) 
                                    
                                   SELECT 
                                   unit_price,
                                   location_dest_id,
                                   company_address,create_date,product_uom_qty,product_id,in_date,write_uid
                                  FROM(
                            SELECT
                            prakruti_grn_inspection_details_line.unit_price,
                            CAST(12 as integer) as location_dest_id,
                            prakruti_grn_inspection_details.company_address, 
                            prakruti_grn_inspection_details.write_date as create_date,
                            prakruti_grn_inspection_details_line.accepted_qty as product_uom_qty,
                            prakruti_grn_inspection_details_line.product_id,
                            prakruti_grn_inspection_details.write_date as in_date,
                            prakruti_grn_inspection_details.write_uid
                            

                            FROM 
                            public.prakruti_grn_inspection_details INNER JOIN
                            public.prakruti_grn_inspection_details_line ON 
                            prakruti_grn_inspection_details.id = prakruti_grn_inspection_details_line.inspection_line_id 
                            WHERE
                            prakruti_grn_inspection_details.id = $1
                            
                            ) AS D;

INSERT INTO stock_quant(cost,
                        location_id,
                        company_id,
                        write_date,
                        qty,
                        product_id,
                        in_date,
                        write_uid
                        )                                     
                        SELECT 
                            unit_price,
                            location_dest_id,
                            company_address,
                            create_date,
                            qaty,
                            product_id,
                            in_date,
                            write_uid
                        FROM(
                            SELECT
                            pgindl.unit_price,
                            CAST(12 as integer) as location_dest_id,
                            grn.company_address, 
                            grn.write_date as create_date,
                            pml.qty*pgindl.packing_style as qaty,
                            pml.packing_name as product_id,
                            grn.write_date as in_date,
                            grn.write_uid                            

                        FROM    packing_material_line as pml
                INNER JOIN 
                        product_template as pt ON 
                        pml.packing_id = pt.id
                INNER JOIN 
			product_product as pp ON
			pt.id = pp.product_tmpl_id                                  
                INNER JOIN
                        prakruti_grn_inspection_details_line as pgindl ON
                        pgindl.product_id = pp.id
                INNER JOIN 
                        prakruti_grn_inspection_details as grn ON
                        grn.id = pgindl.inspection_line_id
                WHERE 
                                grn.id = $1 )AS C;
                        
INSERT INTO stock_picking( 
origin,date_done,write_uid,launch_pack_operations,partner_id,priority,
picking_type_id,location_id,move_type,company_id,name,min_date,printed,write_date,date,recompute_pack_op,
location_dest_id,max_date,
--group_id,
state
) 
                                    
                                   SELECT 
                                   origin,
                                   write_date,
                                   write_uid,
                                   CAST('f' as boolean) as launch_pack_operations,
                                   picking_partner_id,
                                   priority,
                                   picking_id,
                                   location_dest_id,
                                   'direct' as move_type,
                                   company_address,
                                   CAST('IN' || origin as character varying) as name,
                                   scheduled_date,
                                   CAST('f' as boolean) as printed,
                                   write_date,
                                   write_date,
                                   CAST('f' as boolean) as recompute_pack_op,
                                   location_dest_id,
                                   write_date,
                                  -- 1 as group_id,
                                   'done' as state
                                  FROM(
                            SELECT
                            prakruti_grn_inspection_details_line.uom_id, 
                            prakruti_grn_inspection_details_line.quantity as product_uom_qty,
                            prakruti_grn_inspection_details.company_address, 
                            prakruti_grn_inspection_details.write_date,
                            prakruti_grn_inspection_details_line.accepted_qty,
                            CAST(12 as integer) as location_id,
                            CAST(1 as integer) as priority,
                            CAST(10 as integer) as sequence,
                            CAST('done' as character varying) as state,
                            prakruti_grn_inspection_details_line.scheduled_date,
                            CAST(prakruti_grn_inspection_details_line.description as character varying) as description,
                           -- CAST(4 as integer) as inventory_id,
                            CAST('f' as boolean) as partially_available,
                            CAST('t' as boolean) as propagate,
                            CAST('make_to_stock' as character varying) as  procure_method,
                            prakruti_grn_inspection_details_line.product_id,
                            CAST(12 as integer) as location_dest_id,
                            prakruti_grn_inspection_details.id,
                            prakruti_grn_inspection_details.po_no as origin,
                            
                            prakruti_grn_inspection_details.vendor_id as picking_partner_id,
                            prakruti_grn_inspection_details.write_date as create_date,
                            CAST(1 as integer) as picking_type_id,
                            prakruti_grn_inspection_details_line.unit_price,
                            CAST(1 as integer) as picking_id,
                            CAST(1 as integer) as warehouse_id,
                            prakruti_grn_inspection_details.write_uid
                            

                            FROM 
                            public.prakruti_grn_inspection_details INNER JOIN
                            public.prakruti_grn_inspection_details_line ON 
                            prakruti_grn_inspection_details.id = prakruti_grn_inspection_details_line.inspection_line_id 
                            WHERE
                            prakruti_grn_inspection_details.id = $1
                            
                            ) AS E ;

RETURN qty;
                                
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION public.updatepurchasestock(integer)
  OWNER TO odoo;