-- Function: public.update_purchase_order_gst_calculation(integer)

-- DROP FUNCTION public.update_purchase_order_gst_calculation(integer);

CREATE OR REPLACE FUNCTION public.update_purchase_order_gst_calculation(integer)
  RETURNS integer AS
$BODY$
DECLARE qty   integer;
BEGIN

qty = 0;

--GRID CALCULATION
--compute= '_compute_price_total'
--compute= '_compute_line_discount'
--compute='_compute_taxable_value' 
--compute= '_compute_taxable_value_after_adding_others'
--compute= '_compute_cgst_value'
--compute= '_compute_igst_value'
--compute= '_compute_sgst_value'
--compute= '_compute_subtotal'

--PARENT CALCULATION
--compute='_total_no_of_product'
--compute= '_compute_taxed_amount'


--compute= '_compute_total_igst'
--compute= '_compute_total_sgst'
--compute= '_compute_total_cgst'
--compute= '_compute_total_gst' 
--compute= '_compute_grand_total'


--TOTAL AMOUNT FOR THE GRID

UPDATE 
    prakruti_purchase_line 
SET  
    total= quantity * unit_price
WHERE
    prakruti_purchase_line.purchase_line_id = $1 AND prakruti_purchase_line.status = 'open';


--TOTAL DISCOUNT FOR THE GRID

UPDATE 
    prakruti_purchase_line 
SET  
    discount_value= total * (discount_rate/100)
WHERE
    prakruti_purchase_line.purchase_line_id = $1 AND prakruti_purchase_line.status = 'open';


--TAXABLE VALUE FOR THE GRID

UPDATE 
    prakruti_purchase_line 
SET  
    taxable_value= total - (total*(discount_rate/100)) 
WHERE
    prakruti_purchase_line.purchase_line_id = $1 AND prakruti_purchase_line.status = 'open';
        
--TOTAL NO OF PRODUCTS

UPDATE 
    prakruti_purchase_order AS b 
SET 
    no_of_product =a.no_of_product
FROM(SELECT 
        SUM(prakruti_purchase_line.quantity) AS no_of_product,
        prakruti_purchase_order.id
    FROM 
        prakruti_purchase_line JOIN
        prakruti_purchase_order ON
        prakruti_purchase_order.id = prakruti_purchase_line.purchase_line_id
    WHERE 
        prakruti_purchase_line.purchase_line_id= $1 AND prakruti_purchase_order.id = $1 AND prakruti_purchase_line.status = 'open' 
    GROUP BY 
        prakruti_purchase_order.id
        ) AS a 
WHERE 
    a.id = b.id;
    
--TAXABLE VALUE AFTER CHARGES FOR THE GRID

UPDATE 
    prakruti_purchase_line 
SET  
    taxable_value_after_adding_other = a.taxable_value + a.other_charges
FROM(SELECT 
        prakruti_purchase_line.taxable_value AS taxable_value,
        ((coalesce(prakruti_purchase_order.packing_charges,0) + coalesce(prakruti_purchase_order.frieght_charges,0) + coalesce(prakruti_purchase_order.additional_charges,0) + coalesce( prakruti_purchase_order.insurance_charges,0))/ prakruti_purchase_order.no_of_product) AS other_charges,
        prakruti_purchase_line.id
    FROM 
        prakruti_purchase_line JOIN
        prakruti_purchase_order ON
        prakruti_purchase_order.id = prakruti_purchase_line.purchase_line_id
    WHERE 
        prakruti_purchase_line.purchase_line_id= $1 AND prakruti_purchase_order.id = $1 AND prakruti_purchase_line.status = 'open'
        ) AS a 
WHERE 
    a.id = prakruti_purchase_line.id;
    
    
--CGST AMOUNT FOR THE GRID

UPDATE 
    prakruti_purchase_line 
SET  
    cgst_value = (a.taxable_value + a.other_charges) * a.cgst_rate/100
FROM(SELECT 
        prakruti_purchase_line.taxable_value AS taxable_value,
        ((coalesce(prakruti_purchase_order.packing_charges,0) + coalesce(prakruti_purchase_order.frieght_charges,0) + coalesce(prakruti_purchase_order.additional_charges,0) + coalesce( prakruti_purchase_order.insurance_charges,0))/ prakruti_purchase_order.no_of_product) AS other_charges,
        prakruti_purchase_line.cgst_rate AS cgst_rate,
        prakruti_purchase_line.id
    FROM 
        prakruti_purchase_line JOIN
        prakruti_purchase_order ON
        prakruti_purchase_order.id = prakruti_purchase_line.purchase_line_id
    WHERE 
        prakruti_purchase_line.purchase_line_id= $1 AND prakruti_purchase_order.id = $1 AND prakruti_purchase_line.status = 'open'
        ) AS a 
WHERE 
    a.id = prakruti_purchase_line.id;
    
    
--SGST AMOUNT FOR THE GRID

UPDATE 
    prakruti_purchase_line 
SET  
    sgst_value = (a.taxable_value + a.other_charges) * a.sgst_rate/100
FROM(SELECT 
        prakruti_purchase_line.taxable_value AS taxable_value,
        ((coalesce(prakruti_purchase_order.packing_charges,0) + coalesce(prakruti_purchase_order.frieght_charges,0) + coalesce(prakruti_purchase_order.additional_charges,0) + coalesce( prakruti_purchase_order.insurance_charges,0))/ prakruti_purchase_order.no_of_product) AS other_charges,
        prakruti_purchase_line.sgst_rate AS sgst_rate,
        prakruti_purchase_line.id
    FROM 
        prakruti_purchase_line JOIN
        prakruti_purchase_order ON
        prakruti_purchase_order.id = prakruti_purchase_line.purchase_line_id
    WHERE 
        prakruti_purchase_line.purchase_line_id= $1 AND prakruti_purchase_order.id = $1 AND prakruti_purchase_line.status = 'open'
        ) AS a 
WHERE 
    a.id = prakruti_purchase_line.id;
    
    
--IGST AMOUNT FOR THE GRID

UPDATE 
    prakruti_purchase_line 
SET  
    igst_value = (a.taxable_value + a.other_charges) * a.igst_rate/100
FROM(SELECT 
        prakruti_purchase_line.taxable_value AS taxable_value,
        ((coalesce(prakruti_purchase_order.packing_charges,0) + coalesce(prakruti_purchase_order.frieght_charges,0) + coalesce(prakruti_purchase_order.additional_charges,0) + coalesce( prakruti_purchase_order.insurance_charges,0))/ prakruti_purchase_order.no_of_product) AS other_charges,
        prakruti_purchase_line.igst_rate AS igst_rate,
        prakruti_purchase_line.id
    FROM 
        prakruti_purchase_line JOIN
        prakruti_purchase_order ON
        prakruti_purchase_order.id = prakruti_purchase_line.purchase_line_id
    WHERE 
        prakruti_purchase_line.purchase_line_id= $1 AND prakruti_purchase_order.id = $1 AND prakruti_purchase_line.status = 'open'
        ) AS a 
WHERE 
    a.id = prakruti_purchase_line.id;


--SUBTOTAL FOR THE GRID

UPDATE 
    prakruti_purchase_line 
SET  
    subtotal= taxable_value_after_adding_other + cgst_value + sgst_value + igst_value
WHERE
    prakruti_purchase_line.purchase_line_id = $1 AND prakruti_purchase_line.status = 'open';
    
    
    

--TOTAL AMOUNT BEFORE TAX

UPDATE prakruti_purchase_order SET 
                                amount_taxed = b.total_quantity
    FROM(

    SELECT
        sum(prakruti_purchase_line.taxable_value_after_adding_other) as total_quantity,
        prakruti_purchase_order.id
    FROM
        prakruti_purchase_line INNER JOIN
        prakruti_purchase_order ON
        prakruti_purchase_line.purchase_line_id = prakruti_purchase_order.id
     WHERE
        prakruti_purchase_order.id = $1 and prakruti_purchase_line.purchase_line_id = $1 AND prakruti_purchase_line.status = 'open'
        GROUP BY 
        prakruti_purchase_order.id
        
    )as b     
        WHERE 
             prakruti_purchase_order.id = b.id;
    
    
    

--TOTAL CGST

UPDATE prakruti_purchase_order SET 
                                total_cgst = b.total_quantity
    FROM(

    SELECT
        sum(prakruti_purchase_line.cgst_value) as total_quantity,
        prakruti_purchase_order.id
    FROM
        prakruti_purchase_line INNER JOIN
        prakruti_purchase_order ON
        prakruti_purchase_line.purchase_line_id = prakruti_purchase_order.id
     WHERE
        prakruti_purchase_order.id = $1 and prakruti_purchase_line.purchase_line_id = $1 AND prakruti_purchase_line.status = 'open'
        GROUP BY 
        prakruti_purchase_order.id
        
    )as b     
        WHERE 
             prakruti_purchase_order.id = b.id;
    
    
    

--TOTAL SGST

UPDATE prakruti_purchase_order SET 
                                total_sgst = b.total_quantity
    FROM(

    SELECT
        sum(prakruti_purchase_line.sgst_value) as total_quantity,
        prakruti_purchase_order.id
    FROM
        prakruti_purchase_line INNER JOIN
        prakruti_purchase_order ON
        prakruti_purchase_line.purchase_line_id = prakruti_purchase_order.id
     WHERE
        prakruti_purchase_order.id = $1 and prakruti_purchase_line.purchase_line_id = $1 AND prakruti_purchase_line.status = 'open'
        GROUP BY 
        prakruti_purchase_order.id
        
    )as b     
        WHERE 
             prakruti_purchase_order.id = b.id;
    
    
    

--TOTAL SGST

UPDATE prakruti_purchase_order SET 
                                total_igst = b.total_quantity
    FROM(

    SELECT
        sum(prakruti_purchase_line.igst_value) as total_quantity,
        prakruti_purchase_order.id
    FROM
        prakruti_purchase_line INNER JOIN
        prakruti_purchase_order ON
        prakruti_purchase_line.purchase_line_id = prakruti_purchase_order.id
     WHERE
        prakruti_purchase_order.id = $1 and prakruti_purchase_line.purchase_line_id = $1 AND prakruti_purchase_line.status = 'open'
        GROUP BY 
        prakruti_purchase_order.id
        
    )as b     
        WHERE 
             prakruti_purchase_order.id = b.id;
             
             
             
-- TOTAL GST AMOUNT

UPDATE
        prakruti_purchase_order
SET
        total_gst = total_cgst + total_sgst + total_igst
WHERE
        prakruti_purchase_order.id = $1;
    
    
    

--TOTAL AFTER TAX

UPDATE prakruti_purchase_order SET 
                                grand_total = b.total_quantity
    FROM(

    SELECT
        sum(prakruti_purchase_line.subtotal) as total_quantity,
        prakruti_purchase_order.id
    FROM
        prakruti_purchase_line INNER JOIN
        prakruti_purchase_order ON
        prakruti_purchase_line.purchase_line_id = prakruti_purchase_order.id
     WHERE
        prakruti_purchase_order.id = $1 and prakruti_purchase_line.purchase_line_id = $1 AND prakruti_purchase_line.status = 'open'
        GROUP BY 
        prakruti_purchase_order.id
        
    )as b     
        WHERE 
             prakruti_purchase_order.id = b.id;
    
    
    

--GRAND TOTAL AFTER TAX

UPDATE prakruti_purchase_order SET  grand_total_after_payments = (gt - cash - cheque - draft) FROM
                                (
                                SELECT 
                                        COALESCE(prakruti_purchase_order.grand_total,0) AS gt,
                                        COALESCE(prakruti_purchase_order.cash_amount,0) AS cash,
                                        COALESCE(prakruti_purchase_order.cheque_amount,0) AS cheque,
                                        COALESCE(prakruti_purchase_order.draft_amount,0) AS draft,
                                        prakruti_purchase_order.id
                                FROM
                                        prakruti_purchase_order
                                WHERE
                                        prakruti_purchase_order.id = $1)AS b WHERE prakruti_purchase_order.id = b.id;

RETURN qty;
                                
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION public.update_purchase_order_gst_calculation(integer)
  OWNER TO odoo;