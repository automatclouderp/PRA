-- Function: public.update_purchase_invoice_gst_calculation(integer)

-- DROP FUNCTION public.update_purchase_invoice_gst_calculation(integer);

CREATE OR REPLACE FUNCTION public.update_purchase_invoice_gst_calculation(integer)
  RETURNS integer AS
$BODY$
DECLARE qty   integer;
BEGIN

qty = 0;


--TOTAL AMOUNT FOR THE GRID

UPDATE 
    prakruti_purchase_invoice_line 
SET  
    total= quantity * unit_price
WHERE
    prakruti_purchase_invoice_line.invoice_line_id = $1 ;


--TOTAL DISCOUNT FOR THE GRID

UPDATE 
    prakruti_purchase_invoice_line 
SET  
    discount_value= total * (discount_rate/100)
WHERE
    prakruti_purchase_invoice_line.invoice_line_id = $1 ;


--TAXABLE VALUE FOR THE GRID

UPDATE 
    prakruti_purchase_invoice_line 
SET  
    taxable_value= total - (total*(discount_rate/100)) 
WHERE
    prakruti_purchase_invoice_line.invoice_line_id = $1 ;
        
--TOTAL NO OF PRODUCTS

UPDATE 
    prakruti_purchase_invoice AS b 
SET 
    no_of_product =a.no_of_product
FROM(SELECT 
        SUM(prakruti_purchase_invoice_line.quantity) AS no_of_product,
        prakruti_purchase_invoice.id
    FROM 
        prakruti_purchase_invoice_line JOIN
        prakruti_purchase_invoice ON
        prakruti_purchase_invoice.id = prakruti_purchase_invoice_line.invoice_line_id
    WHERE 
        prakruti_purchase_invoice_line.invoice_line_id= $1 AND prakruti_purchase_invoice.id = $1  
    GROUP BY 
        prakruti_purchase_invoice.id
        ) AS a 
WHERE 
    a.id = b.id;
    
--TAXABLE VALUE AFTER CHARGES FOR THE GRID

UPDATE 
    prakruti_purchase_invoice_line 
SET  
    taxable_value_after_adding_other = a.taxable_value + other_charges
FROM(SELECT 
        prakruti_purchase_invoice_line.taxable_value AS taxable_value,
        ((prakruti_purchase_invoice.packing_charges + prakruti_purchase_invoice.frieght_charges + prakruti_purchase_invoice.additional_charges + prakruti_purchase_invoice.insurance_charges)/ prakruti_purchase_invoice.no_of_product) AS other_charges,
        prakruti_purchase_invoice_line.id
    FROM 
        prakruti_purchase_invoice_line JOIN
        prakruti_purchase_invoice ON
        prakruti_purchase_invoice.id = prakruti_purchase_invoice_line.invoice_line_id
    WHERE 
        prakruti_purchase_invoice_line.invoice_line_id= $1 AND prakruti_purchase_invoice.id = $1 
        ) AS a 
WHERE 
    a.id = prakruti_purchase_invoice_line.id;
    
    
--CGST AMOUNT FOR THE GRID

UPDATE 
    prakruti_purchase_invoice_line 
SET  
    cgst_value = (a.taxable_value + other_charges) * a.cgst_rate/100
FROM(SELECT 
        prakruti_purchase_invoice_line.taxable_value AS taxable_value,
        ((prakruti_purchase_invoice.packing_charges + prakruti_purchase_invoice.frieght_charges + prakruti_purchase_invoice.additional_charges + prakruti_purchase_invoice.insurance_charges)/ prakruti_purchase_invoice.no_of_product) AS other_charges,
        prakruti_purchase_invoice_line.cgst_rate AS cgst_rate,
        prakruti_purchase_invoice_line.id
    FROM 
        prakruti_purchase_invoice_line JOIN
        prakruti_purchase_invoice ON
        prakruti_purchase_invoice.id = prakruti_purchase_invoice_line.invoice_line_id
    WHERE 
        prakruti_purchase_invoice_line.invoice_line_id= $1 AND prakruti_purchase_invoice.id = $1 
        ) AS a 
WHERE 
    a.id = prakruti_purchase_invoice_line.id;
    
    
--SGST AMOUNT FOR THE GRID

UPDATE 
    prakruti_purchase_invoice_line 
SET  
    sgst_value = (a.taxable_value + other_charges) * a.sgst_rate/100
FROM(SELECT 
        prakruti_purchase_invoice_line.taxable_value AS taxable_value,
        ((prakruti_purchase_invoice.packing_charges + prakruti_purchase_invoice.frieght_charges + prakruti_purchase_invoice.additional_charges + prakruti_purchase_invoice.insurance_charges)/ prakruti_purchase_invoice.no_of_product) AS other_charges,
        prakruti_purchase_invoice_line.sgst_rate AS sgst_rate,
        prakruti_purchase_invoice_line.id
    FROM 
        prakruti_purchase_invoice_line JOIN
        prakruti_purchase_invoice ON
        prakruti_purchase_invoice.id = prakruti_purchase_invoice_line.invoice_line_id
    WHERE 
        prakruti_purchase_invoice_line.invoice_line_id= $1 AND prakruti_purchase_invoice.id = $1 
        ) AS a 
WHERE 
    a.id = prakruti_purchase_invoice_line.id;
    
    
--IGST AMOUNT FOR THE GRID

UPDATE 
    prakruti_purchase_invoice_line 
SET  
    igst_value = (a.taxable_value + other_charges) * a.igst_rate/100
FROM(SELECT 
        prakruti_purchase_invoice_line.taxable_value AS taxable_value,
        ((prakruti_purchase_invoice.packing_charges + prakruti_purchase_invoice.frieght_charges + prakruti_purchase_invoice.additional_charges + prakruti_purchase_invoice.insurance_charges)/ prakruti_purchase_invoice.no_of_product) AS other_charges,
        prakruti_purchase_invoice_line.igst_rate AS igst_rate,
        prakruti_purchase_invoice_line.id
    FROM 
        prakruti_purchase_invoice_line JOIN
        prakruti_purchase_invoice ON
        prakruti_purchase_invoice.id = prakruti_purchase_invoice_line.invoice_line_id
    WHERE 
        prakruti_purchase_invoice_line.invoice_line_id= $1 AND prakruti_purchase_invoice.id = $1 
        ) AS a 
WHERE 
    a.id = prakruti_purchase_invoice_line.id;


--SUBTOTAL FOR THE GRID

UPDATE 
    prakruti_purchase_invoice_line 
SET  
    subtotal= taxable_value_after_adding_other + cgst_value + sgst_value + igst_value
WHERE
    prakruti_purchase_invoice_line.invoice_line_id = $1 ;
    
    
    

--TOTAL AMOUNT BEFORE TAX

UPDATE prakruti_purchase_invoice SET 
                                amount_taxed = b.total_quantity
    FROM(

    SELECT
        sum(prakruti_purchase_invoice_line.taxable_value_after_adding_other) as total_quantity,
        prakruti_purchase_invoice.id
    FROM
        prakruti_purchase_invoice_line INNER JOIN
        prakruti_purchase_invoice ON
        prakruti_purchase_invoice_line.invoice_line_id = prakruti_purchase_invoice.id
     WHERE
        prakruti_purchase_invoice.id = $1 and prakruti_purchase_invoice_line.invoice_line_id = $1 
        GROUP BY 
        prakruti_purchase_invoice.id
        
    )as b     
        WHERE 
             prakruti_purchase_invoice.id = b.id;
    
    
    

--TOTAL CGST

UPDATE prakruti_purchase_invoice SET 
                                total_cgst = b.total_quantity
    FROM(

    SELECT
        sum(prakruti_purchase_invoice_line.cgst_value) as total_quantity,
        prakruti_purchase_invoice.id
    FROM
        prakruti_purchase_invoice_line INNER JOIN
        prakruti_purchase_invoice ON
        prakruti_purchase_invoice_line.invoice_line_id = prakruti_purchase_invoice.id
     WHERE
        prakruti_purchase_invoice.id = $1 and prakruti_purchase_invoice_line.invoice_line_id = $1 
        GROUP BY 
        prakruti_purchase_invoice.id
        
    )as b     
        WHERE 
             prakruti_purchase_invoice.id = b.id;
    
    
    

--TOTAL SGST

UPDATE prakruti_purchase_invoice SET 
                                total_sgst = b.total_quantity
    FROM(

    SELECT
        sum(prakruti_purchase_invoice_line.sgst_value) as total_quantity,
        prakruti_purchase_invoice.id
    FROM
        prakruti_purchase_invoice_line INNER JOIN
        prakruti_purchase_invoice ON
        prakruti_purchase_invoice_line.invoice_line_id = prakruti_purchase_invoice.id
     WHERE
        prakruti_purchase_invoice.id = $1 and prakruti_purchase_invoice_line.invoice_line_id = $1 
        GROUP BY 
        prakruti_purchase_invoice.id
        
    )as b     
        WHERE 
             prakruti_purchase_invoice.id = b.id;
    
    
    

--TOTAL SGST

UPDATE prakruti_purchase_invoice SET 
                                total_igst = b.total_quantity
    FROM(

    SELECT
        sum(prakruti_purchase_invoice_line.igst_value) as total_quantity,
        prakruti_purchase_invoice.id
    FROM
        prakruti_purchase_invoice_line INNER JOIN
        prakruti_purchase_invoice ON
        prakruti_purchase_invoice_line.invoice_line_id = prakruti_purchase_invoice.id
     WHERE
        prakruti_purchase_invoice.id = $1 and prakruti_purchase_invoice_line.invoice_line_id = $1 
        GROUP BY 
        prakruti_purchase_invoice.id
        
    )as b     
        WHERE 
             prakruti_purchase_invoice.id = b.id;
             
             
             
-- TOTAL GST AMOUNT

UPDATE
        prakruti_purchase_invoice
SET
        total_gst = total_cgst + total_sgst + total_igst
WHERE
        prakruti_purchase_invoice.id = $1;
    
    
    

--GRAND TOTAL AFTER TAX

UPDATE prakruti_purchase_invoice SET 
                                grand_total = b.total_quantity
    FROM(

    SELECT
        sum(prakruti_purchase_invoice_line.subtotal) as total_quantity,
        prakruti_purchase_invoice.id
    FROM
        prakruti_purchase_invoice_line INNER JOIN
        prakruti_purchase_invoice ON
        prakruti_purchase_invoice_line.invoice_line_id = prakruti_purchase_invoice.id
     WHERE
        prakruti_purchase_invoice.id = $1 and prakruti_purchase_invoice_line.invoice_line_id = $1 
        GROUP BY 
        prakruti_purchase_invoice.id
        
    )as b     
        WHERE 
             prakruti_purchase_invoice.id = b.id;
             
--GRAND TOTAL AFTER TAX

UPDATE prakruti_purchase_invoice SET  grand_total_after_payments = (gt - cash - cheque - draft) FROM
                                (
                                SELECT 
                                        COALESCE(prakruti_purchase_invoice.grand_total,0) AS gt,
                                        COALESCE(prakruti_purchase_invoice.cash_amount,0) AS cash,
                                        COALESCE(prakruti_purchase_invoice.cheque_amount,0) AS cheque,
                                        COALESCE(prakruti_purchase_invoice.draft_amount,0) AS draft,
                                        prakruti_purchase_invoice.id
                                FROM
                                        prakruti_purchase_invoice
                                WHERE
                                        prakruti_purchase_invoice.id = $1)AS b WHERE prakruti_purchase_invoice.id = b.id;

RETURN qty;
                                
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION public.update_purchase_invoice_gst_calculation(integer)
  OWNER TO odoo;
