-- Function: public.update_sales_order_gst_calculation(integer)

-- DROP FUNCTION public.update_sales_order_gst_calculation(integer);

CREATE OR REPLACE FUNCTION public.update_sales_order_gst_calculation(integer)
  RETURNS integer AS
$BODY$
DECLARE qty   integer;
BEGIN

qty = 0;


--TOTAL AMOUNT FOR THE GRID

UPDATE 
    prakruti_sales_order_item 
SET  
    amount= total_scheduled_qty * unit_price
WHERE
    prakruti_sales_order_item.main_id = $1;


--TAXABLE VALUE FOR THE GRID

UPDATE 
    prakruti_sales_order_item 
SET  
    taxable_value= amount - (amount*(discount/100)) 
WHERE
    prakruti_sales_order_item.main_id = $1;
    
--ADDITIONAL CHARGES

UPDATE
        prakruti_sales_order
SET
        all_additional_charges = freight_charges + loading_and_packing_charges + insurance_charges + other_charges
WHERE
        prakruti_sales_order.id = $1;
        
--TOTAL NO OF PRODUCTS

UPDATE 
    prakruti_sales_order AS b 
SET 
    total_no_of_products =a.total_no_of_products
FROM(SELECT 
        SUM(prakruti_sales_order_item.total_scheduled_qty) AS total_no_of_products,
        prakruti_sales_order.id
    FROM 
        prakruti_sales_order_item JOIN
        prakruti_sales_order ON
        prakruti_sales_order.id = prakruti_sales_order_item.main_id
    WHERE 
        prakruti_sales_order_item.main_id= $1 AND prakruti_sales_order.id = $1 
    GROUP BY 
        prakruti_sales_order.id
        ) AS a 
WHERE 
    a.id = b.id;
        
-- PROPORTIONATE AMOUNT TO PRODUCTS

UPDATE
        prakruti_sales_order
SET
        proportionate_amount_to_products = all_additional_charges/total_no_of_products
WHERE
        prakruti_sales_order.id = $1;

    
    
-- TAXABLE AMOUNT WITH CHARGES

UPDATE prakruti_sales_order_item SET 
                                taxable_value_with_charges = b.total_quantity
    FROM(

    SELECT
        (sum(prakruti_sales_order_item.taxable_value) + sum(prakruti_sales_order.proportionate_amount_to_products)) as total_quantity,
        prakruti_sales_order_item.id
    FROM
        prakruti_sales_order_item INNER JOIN
        prakruti_sales_order ON
        prakruti_sales_order_item.main_id = prakruti_sales_order.id
     WHERE
        prakruti_sales_order.id = $1 and prakruti_sales_order_item.main_id = $1
        GROUP BY 
        prakruti_sales_order_item.id
        
    )as b     
        WHERE 
             prakruti_sales_order_item.id = b.id;

   
    
-- CGST VALUE FOR THE GRID

UPDATE 
    prakruti_sales_order_item
    SET
        cgst_amount = taxable_value_with_charges * (cgst_value/100)
    WHERE
        main_id=$1;
    
    
-- SGST VALUE FOR THE GRID

UPDATE 
    prakruti_sales_order_item
    SET
        sgst_amount = taxable_value_with_charges * (sgst_value/100)
    WHERE
        main_id=$1;
    
    
-- IGST VALUE FOR THE GRID

UPDATE 
    prakruti_sales_order_item
    SET
        igst_amount = taxable_value_with_charges * (igst_value/100)
    WHERE
        main_id=$1;
    
    
-- GST VALUE FOR THE GRID

UPDATE 
    prakruti_sales_order_item
    SET
        gst_rate = cgst_value + sgst_value + igst_value
    WHERE
        main_id=$1;
        
        
-- TOTAL VALUE FOR THE GRID

UPDATE 
    prakruti_sales_order_item
    SET
        total = taxable_value_with_charges + cgst_amount + sgst_amount + igst_amount
    WHERE
        main_id=$1;
    
    
    

--TOTAL AMOUNT BEFORE TAX

UPDATE prakruti_sales_order SET 
                                total_amount_before_tax = b.total_quantity
    FROM(

    SELECT
        sum(prakruti_sales_order_item.taxable_value_with_charges) as total_quantity,
        prakruti_sales_order.id
    FROM
        prakruti_sales_order_item INNER JOIN
        prakruti_sales_order ON
        prakruti_sales_order_item.main_id = prakruti_sales_order.id
     WHERE
        prakruti_sales_order.id = $1 and prakruti_sales_order_item.main_id = $1
        GROUP BY 
        prakruti_sales_order.id
        
    )as b     
        WHERE 
             prakruti_sales_order.id = b.id;
    
    
    

--TOTAL CGST

UPDATE prakruti_sales_order SET 
                                total_cgst_amount = b.total_quantity
    FROM(

    SELECT
        sum(prakruti_sales_order_item.cgst_amount) as total_quantity,
        prakruti_sales_order.id
    FROM
        prakruti_sales_order_item INNER JOIN
        prakruti_sales_order ON
        prakruti_sales_order_item.main_id = prakruti_sales_order.id
     WHERE
        prakruti_sales_order.id = $1 and prakruti_sales_order_item.main_id = $1
        GROUP BY 
        prakruti_sales_order.id
        
    )as b     
        WHERE 
             prakruti_sales_order.id = b.id;
    
    
    

--TOTAL SGST

UPDATE prakruti_sales_order SET 
                                total_sgst_amount = b.total_quantity
    FROM(

    SELECT
        sum(prakruti_sales_order_item.sgst_amount) as total_quantity,
        prakruti_sales_order.id
    FROM
        prakruti_sales_order_item INNER JOIN
        prakruti_sales_order ON
        prakruti_sales_order_item.main_id = prakruti_sales_order.id
     WHERE
        prakruti_sales_order.id = $1 and prakruti_sales_order_item.main_id = $1
        GROUP BY 
        prakruti_sales_order.id
        
    )as b     
        WHERE 
             prakruti_sales_order.id = b.id;
    
    
    

--TOTAL IGST

UPDATE prakruti_sales_order SET 
                                total_igst_amount = b.total_quantity
    FROM(

    SELECT
        sum(prakruti_sales_order_item.igst_amount) as total_quantity,
        prakruti_sales_order.id
    FROM
        prakruti_sales_order_item INNER JOIN
        prakruti_sales_order ON
        prakruti_sales_order_item.main_id = prakruti_sales_order.id
     WHERE
        prakruti_sales_order.id = $1 and prakruti_sales_order_item.main_id = $1
        GROUP BY 
        prakruti_sales_order.id
        
    )as b     
        WHERE 
             prakruti_sales_order.id = b.id;
             
             
             
-- TOTAL GST AMOUNT

UPDATE
        prakruti_sales_order
SET
        total_gst_amount = total_cgst_amount + total_sgst_amount + total_igst_amount
WHERE
        prakruti_sales_order.id = $1;
    
    
    

--GRAND TOTAL AFTER TAX

UPDATE prakruti_sales_order SET 
                                total_amount_after_tax = b.total_quantity
    FROM(

    SELECT
        sum(prakruti_sales_order_item.total) as total_quantity,
        prakruti_sales_order.id
    FROM
        prakruti_sales_order_item INNER JOIN
        prakruti_sales_order ON
        prakruti_sales_order_item.main_id = prakruti_sales_order.id
     WHERE
        prakruti_sales_order.id = $1 and prakruti_sales_order_item.main_id = $1
        GROUP BY 
        prakruti_sales_order.id
        
    )as b     
        WHERE 
             prakruti_sales_order.id = b.id;
             
--GRAND TOTAL AFTER TAX

UPDATE prakruti_sales_order SET  grand_total = (taat - cash - cheque - draft) FROM
                                (
                                SELECT 
                                        COALESCE(prakruti_sales_order.total_amount_after_tax,0) AS taat,
                                        COALESCE(prakruti_sales_order.cash_amount,0) AS cash,
                                        COALESCE(prakruti_sales_order.cheque_amount,0) AS cheque,
                                        COALESCE(prakruti_sales_order.draft_amount,0) AS draft,
                                        prakruti_sales_order.id
                                FROM
                                        prakruti_sales_order
                                WHERE
                                        prakruti_sales_order.id = $1)AS b WHERE prakruti_sales_order.id = b.id;

RETURN qty;
                                
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION public.update_sales_order_gst_calculation(integer)
  OWNER TO odoo;
