# -*- coding: utf-8 -*-

from openerp import models, fields, api
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
import re
import logging


#########################################################################################################


class PrakrutiStandardProduct(models.Model):
    _name = 'prakruti.standard_product'
    _table = 'prakruti_standard_product'
    _description = 'Prakruti Standard Product '
    _order= "id desc"
    _rec_name="standard_batch_size"
    
    _sql_constraints = [('subplant_with_standard_batch_size', 'unique(subplant_id,standard_batch_size)','Subplant and Batch Size must be Unique !')]  
   
    subplant_id= fields.Many2one('prakruti.sub_plant', string="Sub Plant",required=True)
    standard_batch_size= fields.Float(string="Standard Batch Size",required=True,digits=(6,3))
    standard_output_yield= fields.Float(string="Standard Output Yield",required=True,digits=(6,3))
    duplicate_flag = fields.Char(string= 'Duplicate Flag',default=0,readonly=True)
    is_duplicate = fields.Boolean(string= 'Is a Duplicate',default=False,readonly=True) 
    
    subplant_line= fields.One2many('prakruti.standard_product_line','standard_line_id',string="Standard Line")
    
    @api.one
    @api.multi
    def duplicate_standard_bom(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            d_request = self.pool.get('prakruti.standard_product').create(cr,uid, {
                'subplant_id':temp.subplant_id.id,
                'standard_batch_size':0,
                'standard_output_yield':temp.standard_output_yield,
                'is_duplicate':'True',
                'duplicate_flag': 1
                })
            for item in temp.subplant_line:
                grid_values = self.pool.get('prakruti.standard_product_line').create(cr,uid, {
                    'product_id': item.product_id.id,
                    'description': item.description,
                    'uom_id': item.uom_id.id,
                    'standard_value': item.standard_value,
                    'standard_line_id': d_request
                    })
        return {}
    
    @api.one
    @api.multi
    def check_stock(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
                cr.execute("UPDATE prakruti_standard_product_line SET store_qty= qty_aval FROM ( SELECT product_id,(sum(qty_in) - sum(qty_out)) as qty_aval,id FROM ( SELECT stock_move.product_id, case when move_dest_id > 0 then product_qty else 0 end as qty_out, case when move_dest_id > 0 then 0 else product_qty end as qty_in,standard_line_id,prakruti_standard_product_line.id FROM product_template INNER JOIN product_product  ON product_product.product_tmpl_id = product_template.id INNER JOIN stock_move ON stock_move.product_id = product_product.id INNER JOIN prakruti_standard_product_line ON prakruti_standard_product_line.product_id = stock_move.product_id    WHERE prakruti_standard_product_line.standard_line_id = %s and location_dest_id = 12  AND stock_move.state = 'done')as a GROUP BY product_id,id) as b WHERE b.id = prakruti_standard_product_line.id",((temp.id),))
        return {}

class PrakrutiStandardProductLine(models.Model):
    _name= 'prakruti.standard_product_line'
    _table = 'prakruti_standard_product_line'
    _order= "id desc"
    
    standard_line_id = fields.Many2one('prakruti.standard_product', string="Line ID",readonly=True)
    
    product_id= fields.Many2one('product.product', string="Name",required=True)
    description = fields.Text(string= 'Description',required=True)
    uom_id= fields.Many2one('product.uom', string="UOM",required=True)
    standard_value=fields.Float(string='Standard Qty',required=True,digits=(6,3))
    store_qty = fields.Float(string= 'Store Qty',digits=(6,3))
    
    def onchange_product_id(self, cr, uid, ids, product_id, context=None):
        line1 = 0
        line2 = ''
        line3 = 0
        cr.execute('SELECT product_uom.id AS uom_id, product_uom.name AS uom_name, product_template.name AS description FROM product_uom INNER JOIN product_template ON product_uom.id=product_template.uom_id INNER JOIN product_product ON product_template.id=product_product.product_tmpl_id  WHERE product_product.id = cast(%s as integer)', ((product_id),))
        for line in cr.dictfetchall():
            line1 = line['uom_id']
            line2 = line['description']
        return {'value' :{
                'uom_id':line1,
                'description':line2
                          }}
    
    
    
    def onchange_product_id(self, cr, uid, ids, product_id, context=None):
        qty_aval = 0.0
        line1 = 0
        line2 = ''
        line3 = 0
        cr.execute('SELECT product_uom.id AS uom_id, product_uom.name AS uom_name, product_template.name AS description,product_template.group_ref AS group_ref FROM product_uom INNER JOIN product_template ON product_uom.id=product_template.uom_id INNER JOIN product_product ON product_template.id=product_product.product_tmpl_id WHERE product_product.id = cast(%s as integer)', ((product_id),))
        for line in cr.dictfetchall():
            line1 = line['uom_id']
            line2 = line['description']
        cr.execute('''SELECT qty_aval FROM (SELECT uom, product_id, name, qty_in, qty_out, qty_in - qty_out as qty_aval FROM ( SELECT uom,product_id, name, sum(qty_out) as qty_out, sum(qty_in) as qty_in FROM ( SELECT product_uom.name as uom,stock_move.product_id, product_product.name_template as name, picking_id, case when move_dest_id > 0 then product_qty else 0 end as qty_out, case when move_dest_id > 0 then 0 else product_qty end as qty_in FROM product_uom INNER JOIN product_template ON product_uom.id = product_template.uom_id INNER JOIN product_product ON product_product.product_tmpl_id = product_template.id INNER JOIN stock_move ON stock_move.product_id = product_product.id WHERE location_dest_id = 12  AND stock_move.state = 'done' AND product_product.id = CAST(%s as integer)) as a group by product_id, name, uom ) as a ) AS b ORDER BY product_id''', ((product_id),))
        for line in cr.dictfetchall():
            line3 = line['qty_aval']
        print 'PRODUCT NAME',line2
        print 'UOM ID',line1
        print 'AVAILABLE STOCK',line3
        return {'value' :{'uom_id':line1,
                          'description':line2,
                          'store_qty': line3 or 0.0,
                          }}