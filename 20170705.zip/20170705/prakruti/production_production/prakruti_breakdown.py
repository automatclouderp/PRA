# -*- coding: utf-8 -*-

from openerp import models, fields, api
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
import re
import logging


#########################################################################################################


class PrakrutiBreakdown(models.Model):
    _name = 'prakruti.breakdown'
    _table = 'prakruti_breakdown'
    _description = 'Prakruti Breakdown  '
    _order= "id desc"
    _rec_name="plant"
    
  
    plant=fields.Many2one('prakruti.sub_plant',string='Sub Plant',required="True")
    machine_plant=fields.Many2one('prakruti.manage_machine',string='Machine Plant',required="True")
    date=fields.Date(string='Date', default=fields.Date.today)
    breakdown_item=fields.Many2one('prakruti.breakdown_item',string='Break Down Item',required="True")
    breakdown_hours=fields.Char(string='Break Down Hours',required="True")
    remarks=fields.Text(string='Remarks')
    
    
    _sql_constraints = [
        ('breakdown_uniq', 'unique (date,plant)',
         'This entry is already entered. Please check and retry!')
        ]