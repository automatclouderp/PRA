# -*- coding: utf-8 -*-

from openerp import models, fields, api
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp.exceptions import ValidationError
import re
import logging


#########################################################################################################


class PrakrutiProductionTransferNote(models.Model):
    _name = 'prakruti.production_transfer_note'
    _table = 'prakruti_production_transfer_note'
    _order= "id desc"
    _rec_name="ptn_no" 
    
    @api.multi
    def unlink(self):
        for order in self:
            raise UserError(_('Can\'t Delete'))
        return super(PrakrutiProductionTransferNote, self).unlink() 
    
    @api.one
    @api.constrains('date')
    def _check_date(self):
        if self.date <  fields.Date.today():
            raise ValidationError(
                "Can\'t Select Back Date") 
    
    @api.one
    @api.multi
    def _get_auto(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids   
        for temp in self:
            cr.execute('''select cast(extract (month from date) as integer) as month ,cast(extract (year from date) as integer) as year ,id from prakruti_production_transfer_note where id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
            if month_value<=3:
                year_value=year_value-1
            else:                
                year_value=year_value
            next_year=year_value+1
            dispay_year=str(next_year)[-2:]
            display_present_year=str(year_value)[-2:]
            cr.execute('''select autogenerate_prakruti_production_transfer_note(%s)''', ((temp.id),)  ) 
            result = cr.dictfetchall()
            parent_invoice_id = 0
            for value in result: parent_invoice_id = value['autogenerate_prakruti_production_transfer_note'];
            auto_gen = int(parent_invoice_id)
            if len(str(auto_gen)) < 2:
                auto_gen = '000'+ str(auto_gen)
            elif len(str(auto_gen)) < 3:
                auto_gen = '00' + str(auto_gen)
            elif len(str(auto_gen)) == 3:
                auto_gen = '0'+str(auto_gen)
            else:
                auto_gen = str(auto_gen)
            for record in self :
                x[record.id] = 'PTN\\'+str(auto_gen) +'/'+str(display_present_year)+'-'+str(dispay_year)
            cr.execute('''update prakruti_production_transfer_note set ptn_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
        return x
        
    @api.one
    @api.multi
    def action_to_inward(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {} 
            cr.execute("SELECT count(id) as no_of_line FROM prakruti_production_transfer_note_line WHERE main_id = %s",((temp.id),))
            for line in cr.dictfetchall():
                no_of_line = line['no_of_line']            
            cr.execute("SELECT count(distinct(product_id)) as no_of_product_line FROM prakruti_production_transfer_note_line WHERE main_id = %s",((temp.id),))
            for line in cr.dictfetchall():
                no_of_product_line = line['no_of_product_line']
            if no_of_line == no_of_product_line and no_of_line:
                production_inward = self.pool.get('prakruti.production_inward').create(cr,uid, {
                    'qc_ptn_no':temp.qc_ptn_no,
                    'inward_no':temp.ptn_no,
                    'batch_no':temp.batch_no.id,
                    'date':temp.date,
                    'dept_from':temp.dept_from.id,
                    'prepared_by':temp.prepared_by.id,
                    'store_incharge':temp.store_incharge.id,
                    'approved_by':temp.approved_by.id,
                    'bmr_no':temp.bmr_no
                    })
                for item in temp.grid_id:
                    grid_values = self.pool.get('prakruti.production_inward_line').create(cr,uid, {
                        'product_id': item.product_id.id,
                        'uom_id': item.uom_id.id,
                        'description':item.description,
                        'specification_id':item.specification_id.id,
                        'packing_style':item.packing_style,
                        'packing_qty':item.packing_qty,
                        'total_output_qty':item.total_output_qty,
                        'accepted_qty':item.accepted_qty,
                        'rejected_qty':item.rejected_qty,
                        'test_result':item.test_result,    
                        'qc_status': item.qc_status,
                        'remarks':item.remarks,
                        'main_id':production_inward
                    })
            else:
                raise UserError(_('Can\'t Proceed, Since Product line is having Duplicate Entries else Please Enter Some Products'))
            cr.execute("UPDATE  prakruti_production_transfer_note SET state = 'inward' WHERE prakruti_production_transfer_note.id = cast(%s as integer)",((temp.id),))
            #cr.execute("UPDATE prakruti_batch_master AS b SET is_batch_closed = 'close' FROM(SELECT batch_no FROM prakruti_production_transfer_note WHERE id= %s) AS a WHERE a.batch_no = b.id",((temp.id),))
        return {}
    
    def onchange_batch_no(self, cr, uid, ids, batch_no, context=None):
        process_type = self.pool.get('prakruti.batch_master').browse(cr, uid, batch_no, context=context)
        result = {
            'batch_allocated_by': process_type.batch_allocated_by,
            'bmr_no': process_type.bmr_no
            }
        return {'value': result}
    
    def create(self, cr, uid, vals, context=None):
        onchangeResult = self.onchange_batch_no(cr, uid, [], vals['batch_no'])
        if onchangeResult.get('value') or onchangeResult['value'].get('batch_allocated_by','bmr_no'):
            vals['batch_allocated_by'] = onchangeResult['value']['batch_allocated_by']
            vals['bmr_no'] = onchangeResult['value']['bmr_no']
        return super(PrakrutiProductionTransferNote, self).create(cr, uid, vals, context=context)
    
    def write(self, cr, uid, ids, vals, context=None):
        op=super(PrakrutiProductionTransferNote, self).write(cr, uid, ids, vals, context=context)
        for record in self.browse(cr, uid, ids, context=context):
            store_type=record.batch_no.id
        onchangeResult = self.onchange_batch_no(cr, uid, ids, store_type)
        if onchangeResult.get('value') or onchangeResult['value'].get('batch_allocated_by','bmr_no'):
            vals['batch_allocated_by'] = onchangeResult['value']['batch_allocated_by']
            vals['bmr_no'] = onchangeResult['value']['bmr_no']
        return super(PrakrutiProductionTransferNote, self).write(cr, uid, ids, vals, context=context)
    
    batch_allocated_by = fields.Selection([('extraction', 'Extraction'),('syrup','Syrup'),('tablet','Tablet')],string='Batch Allocated By')
    batch_no = fields.Many2one('prakruti.batch_master',string='Batch No', required=True)
    ptn_no = fields.Char(string='PTN No',default='New',readonly=True)
    date=fields.Date(string='Date', default=fields.Date.today,required=True)
    dept_from = fields.Many2one('manage.department_sorting','From Department', required=True)
    dept_to = fields.Many2one('manage.department_sorting','To Department', required=True)
    doc_no = fields.Char(' Doc No')
    rev_no = fields.Char(' Rev No')
    prepared_by= fields.Many2one('res.users',string="Prepared By",required=True)
    store_incharge= fields.Many2one('res.users',string="Store Incharge",required=True)
    approved_by= fields.Many2one('res.users',string="Approved By",required=True)
    grid_id = fields.One2many('prakruti.production_transfer_note_line', 'main_id',string='Grid')
    ref_if_any = fields.Char('Ref If Any')
    remarks = fields.Char('Remarks')
    state =fields.Selection([
        ('ptn', 'PTN'),
        ('inward','Inward'),
        ('destruction','Destruction')

        ],default= 'ptn', string= 'Status')
    pt_no = fields.Char('PTN No', compute='_get_auto')
    auto_no = fields.Integer('Auto')
    req_no_control_id = fields.Integer('Auto Generating id',default= 0)
    
    
    extraction_display_flag = fields.Integer(string="Extraction Displayed",default=0)
    extraction_delete_flag = fields.Integer(string="Extraction Deleted",default=0)
    
    syrup_display_flag = fields.Integer(string="Syrup Displayed",default=0)
    syrup_delete_flag = fields.Integer(string="Syrup Deleted",default=0)
    
    tablet_display_flag = fields.Integer(string="Tablet Displayed",default=0)
    tablet_delete_flag = fields.Integer(string="Tablet Deleted",default=0)
    
    qc_ptn_no = fields.Char(string='QC PTN No')   
    bmr_no = fields.Char(string = 'BMR No')    
    
    @api.one
    @api.multi
    def action_list_products_for_extraction(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute('''INSERT INTO prakruti_production_transfer_note_line (product_id,uom_id,description,total_output_qty,main_id)
SELECT product_id,uom_id,description,total_output_qty,main_id FROM
(
SELECT prakruti_sub_plant.subplant_id AS product_id,product_uom.id AS uom_id,product_template.name AS description,prakruti_production.total_output_yeild AS total_output_qty
             FROM prakruti_sub_plant INNER JOIN prakruti_production ON
              prakruti_sub_plant.id = prakruti_production.subplant_id  INNER JOIN
              product_product ON
              prakruti_sub_plant.subplant_id = product_product.id INNER JOIN
              product_template ON
              product_template.id = product_product.product_tmpl_id INNER JOIN
              product_uom ON
              product_uom.id=product_template.uom_id
              WHERE prakruti_production.batch_id =%s 
   ) AS a CROSS JOIN
   (
   SELECT id AS main_id FROM prakruti_production_transfer_note WHERE prakruti_production_transfer_note.id = %s
   ) AS b''', ((temp.batch_no.id),(temp.id),))
            cr.execute("UPDATE prakruti_production_transfer_note SET extraction_display_flag = 1,extraction_delete_flag = 0,syrup_display_flag = 0,syrup_delete_flag = 0,tablet_display_flag = 0,tablet_delete_flag = 0 WHERE prakruti_production_transfer_note.id = %s",((temp.id),))
        return {}
    
    @api.one
    @api.multi
    def action_delete_products_for_extraction(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute("DELETE FROM prakruti_production_transfer_note_line WHERE main_id = %s",((temp.id),))
            cr.execute("UPDATE prakruti_production_transfer_note SET extraction_display_flag = 0,extraction_delete_flag = 1,syrup_display_flag = 0,syrup_delete_flag = 0,tablet_display_flag = 0,tablet_delete_flag = 0 WHERE prakruti_production_transfer_note.id = %s",((temp.id),))
        return {}
    
    @api.one
    @api.multi
    def action_delete_products_for_syrup(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute("DELETE FROM prakruti_production_transfer_note_line WHERE main_id = %s",((temp.id),))
            cr.execute("UPDATE prakruti_production_transfer_note SET syrup_display_flag = 0,syrup_delete_flag = 1,extraction_display_flag = 0,extraction_delete_flag = 0,tablet_display_flag = 0,tablet_delete_flag = 0 WHERE prakruti_production_transfer_note.id = %s",((temp.id),))
        return {}
    
    @api.one
    @api.multi
    def action_delete_products_for_tablet(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute("DELETE FROM prakruti_production_transfer_note_line WHERE main_id = %s",((temp.id),))
            cr.execute("UPDATE prakruti_production_transfer_note SET tablet_display_flag = 0,tablet_delete_flag = 1,syrup_display_flag = 0,syrup_delete_flag = 0,extraction_display_flag = 0,extraction_delete_flag = 0 WHERE prakruti_production_transfer_note.id = %s",((temp.id),))
        return {}
    
    @api.one
    @api.multi
    def action_list_products_for_tablet(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute('''INSERT INTO prakruti_production_transfer_note_line (product_id,uom_id,description,total_output_qty,main_id)
SELECT product_id,uom_id,description,total_output_qty,main_id FROM
(
SELECT prakruti_sub_plant.subplant_id as product_id,product_uom.id AS uom_id,product_template.name AS description,prakruti_tablet_production.total_output_yeild AS total_output_qty
             FROM prakruti_sub_plant INNER JOIN prakruti_tablet_production ON
              prakruti_sub_plant.id = prakruti_tablet_production.subplant_id  INNER JOIN
              product_product ON
              prakruti_sub_plant.subplant_id = product_product.id INNER JOIN
              product_template ON
              product_template.id = product_product.product_tmpl_id INNER JOIN
              product_uom ON
              product_uom.id=product_template.uom_id
              WHERE prakruti_tablet_production.batch_id =%s 
   ) as a CROSS JOIN
   (
   SELECT id as main_id FROM prakruti_production_transfer_note WHERE prakruti_production_transfer_note.id = %s
   ) as b''', ((temp.batch_no.id),(temp.id),))
            cr.execute("UPDATE prakruti_production_transfer_note SET tablet_display_flag = 1,tablet_delete_flag = 0,syrup_display_flag = 0,syrup_delete_flag = 0,extraction_display_flag = 0,extraction_delete_flag = 0 WHERE prakruti_production_transfer_note.id = %s",((temp.id),))
        return {}
    
    @api.one
    @api.multi
    def action_list_products_for_syrup(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute('''INSERT INTO prakruti_production_transfer_note_line (product_id,uom_id,description,total_output_qty,main_id)
SELECT product_id,uom_id,description,total_output_qty,main_id FROM
(
SELECT prakruti_sub_plant.subplant_id as product_id,product_uom.id AS uom_id,product_template.name AS description,prakruti_syrup_production.total_output_yeild AS total_output_qty
             FROM prakruti_sub_plant INNER JOIN prakruti_syrup_production ON
              prakruti_sub_plant.id = prakruti_syrup_production.subplant_id  INNER JOIN
              product_product ON
              prakruti_sub_plant.subplant_id = product_product.id INNER JOIN
              product_template ON
              product_template.id = product_product.product_tmpl_id INNER JOIN
              product_uom ON
              product_uom.id=product_template.uom_id
              WHERE prakruti_syrup_production.batch_id =%s 
   ) as a CROSS JOIN
   (
   SELECT id as main_id FROM prakruti_production_transfer_note WHERE prakruti_production_transfer_note.id = %s
   ) as b''', ((temp.batch_no.id),(temp.id),))
            cr.execute("UPDATE prakruti_production_transfer_note SET syrup_display_flag = 1,syrup_delete_flag = 0,tablet_display_flag = 0,tablet_delete_flag = 0,extraction_display_flag = 0,extraction_delete_flag = 0 WHERE prakruti_production_transfer_note.id = %s",((temp.id),))
        return {}
    
    
class PrakrutiPTNLine(models.Model):
    _name = 'prakruti.production_transfer_note_line'
    _table = "prakruti_production_transfer_note_line"
    _description = 'Prakruti Production Transfer Note Grid '

    
    product_id = fields.Many2one('product.product', string="Product Name", readonly=True)
    uom_id = fields.Many2one('product.uom',string="UOM", readonly=True)
    description = fields.Text(string="Description", readonly=True)
    specification_id = fields.Many2one('product.specification.main', string = "Specification", readonly=True)
    packing_style=fields.Float(string='Packing Style',digits=(6,3))
    packing_qty=fields.Float(string='Packing Qty',digits=(6,3))
    total_output_qty=fields.Float(string='Total Output Qty',digits=(6,3))
    accepted_qty = fields.Float(string = "Accepted.Qty",digits=(6,3))
    rejected_qty = fields.Float(string = "Reject Qty" ,digits=(6,3))
    test_result=fields.Char(string='Test Result')
    qc_status=fields.Selection([('approved','Approved'),('rejected','Rejected')],string='QC status')
    remarks=fields.Char(string='Remarks')
    main_id = fields.Many2one('prakruti.production_transfer_note',string="Grid", ondelete='cascade') 
    #ar_id = fields.Many2one('prakruti.specification.ar.no', string = "AR No.")  


    