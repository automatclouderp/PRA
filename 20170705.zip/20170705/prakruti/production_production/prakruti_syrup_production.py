# -*- coding: utf-8 -*-
from openerp.exceptions import ValidationError
import openerp
from datetime import date, datetime
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from datetime import timedelta
from openerp.osv import osv,fields
from openerp import models, fields, api, _
from openerp.tools.translate import _
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
from lxml import etree
import cgi
import logging
import lxml.html
import lxml.html.clean as clean
import openerp.pooler as pooler
import random
import re
import socket
import threading
import time
from openerp.tools import image_resize_image_big
from openerp.tools import amount_to_text
from openerp.tools.amount_to_text import amount_to_text_in 
from openerp.tools.amount_to_text import amount_to_text_in_without_word_rupees 

######################################################################################

class PrakrutiSyrupProduction(models.Model):
    _name='prakruti.syrup_production'
    _table ='prakruti_syrup_production'
    _description='Screen that defines complete syrup production'
    _order= 'id desc'
    _rec_name= 'subplant_id'
    
    
    batch_allocation_date=fields.Datetime(string='Batch Allocation Date', default=fields.Date.today)
    batch_end_date=fields.Datetime(string='Batch End Date')
    subplant_id = fields.Many2one('prakruti.sub_plant', string='Sub Plant', required=True)
    batch_id = fields.Many2one('prakruti.batch_master',string='Batch No',required=True)
    batch_size= fields.Float(string='Batch Size', required=True,digits=(6,3))
    standard_time=fields.Datetime(string='Standard Time')
    date= fields.Date(string = 'Date', default= fields.Date.today, required=True)    
    created_by =fields.Many2one('res.users','Created By')
    pulverization_production_syrup_id = fields.One2many('prakruti.production_syrup_pulverization','pulverization_id',string='Pulverization Grid')
    extract_solution_syrup_id= fields.One2many('prakruti.syrup_extract_solution','extract_solution_id',string='Extract Solution Grid') 
    soak_raw_material_syrup_id=fields.One2many('prakruti.soak_raw_material','soak_raw_material_id',string='Soak Raw Material Grid') 
    extraction_syrup_id=fields.One2many('prakruti.syrup_extraction','syrup_extraction_id',string='Extraction Grid') 
    filtration_syrup_id=fields.One2many('prakruti.syrup_filtration','syrup_filtration_id',string='Filtration Grid')
    autoclave_syrup_id=fields.One2many('prakruti.syrup_autoclave','syrup_autoclave_id',string='Autoclave Grid')
    addition_preservative_syrup_id=fields.One2many('prakruti.addition_preservative','addition_preservative_id',string='Addition Preservative Grid')
    syrup_preparation_id=fields.One2many('prakruti.preparation_syrup','preparation_syrup_id',string='Preparartion Syrup Grid')
    other_ingredient_addition_syrup_id=fields.One2many('prakruti.other_ingredient_addition','other_ingredient_addition_id',string='Other Ingredient Addition Grid')
    ph_control_buffer_action_syrup_id=fields.One2many('prakruti.ph_control_buffer_action','ph_control_buffer_action_id',string='Ph Control Buffer Action')
    solvent_name_syrup_id=fields.One2many('prakruti.solvent_name','solvent_name_id',string='Solvent Name')
    filling_syrup_id=fields.One2many('prakruti.filling','filling_id',string='Filling')
    coding_syrup_id=fields.One2many('prakruti.coding','coding_id',string='Coding')
    packing_syrup_id=fields.One2many('prakruti.packing','packing_id',string='Packing')
    breakdown_production_id = fields.One2many('prakruti.production_breakdown_syrup','breakdown_grid_id',string='Break Down Grid')
    pulverisation=fields.Selection([('yes','Yes'),('no','No')], string="Pulverisation", default='yes',required="True")
    extract_solution = fields.Selection([('yes','Yes'),('no','No')], string="Extract Solution", default='yes',required="True")
    soak_raw_material =fields.Selection([('yes','Yes'),('no','No')], string="Soak Raw Material", default='yes',required="True")
    extraction_new=fields.Selection([('yes','Yes'),('no','No')], string="Extraction", default='yes',required="True")    
    autoclave = fields.Selection([('yes','Yes'),('no','No')], string="Autoclave", default='yes',required="True")
    addition_preservative = fields.Selection([('yes','Yes'),('no','No')], string="Addition of Preservative", default='yes',required="True")
    preparation_syrup = fields.Selection([('yes','Yes'),('no','No')], string="Syrup Preparation", default='yes',required="True")    
    ph_control_buffer = fields.Selection([('yes','Yes'),('no','No')], string="pH control buffer action ", default='yes',required="True")
    solvent_name= fields.Selection([('yes','Yes'),('no','No')], string="Solvent Name", default='yes',required="True")
    filling =  fields.Selection([('yes','Yes'),('no','No')], string="Filling", default='yes',required="True")
    coding =  fields.Selection([('yes','Yes'),('no','No')], string="Coding", default='yes',required="True")
    ###########process names in common with syrup and tablet production#################
    packing =  fields.Selection([('yes','Yes'),('no','No')], string="Packing", default='yes',required="True")
    other_ingredient_addition = fields.Selection([('yes','Yes'),('no','No')], string="Other Ingredient Addition",default='yes',required="True")
    filtration = fields.Selection([('yes','Yes'),('no','No')], string="Filtration", default='yes',required="True")
    remarks = fields.Text(string='Remarks')
    production_name = fields.Selection([('syrup','Syrup')],string='Production Type',default='syrup')
    status = fields.Selection([('batch_alloted','Batch Alloted')],string="Status",readonly="True")
    total_weight_before = fields.Float(string='Total Weight Before',compute= '_compute_total_weight_before',store=True,digits=(6,3))
    total_weight_after = fields.Float(string='Total  Weight After',compute= '_compute_total_weight_after',store=True,digits=(6,3))
    total_volume_before_pe = fields.Float(string='Total Volume Before',compute= '_compute_total_volume_before_pe',store=True,digits=(6,3))
    total_volume_after_pe = fields.Float(string='Total  Volume After',compute= '_compute_total_volume_after_pe',store=True,digits=(6,3))
    total_weight_before_ex = fields.Float(string='Total Weight Before',compute= '_compute_total_weight_before_ex',store=True,digits=(6,3))
    total_volume_before_ps = fields.Float(string='Total Volume Before',compute= '_compute_total_volume_before_ps',store=True,digits=(6,3))
    total_volume_after_ps = fields.Float(string='Total  Volume After',compute= '_compute_total_volume_after_ps',store=True,digits=(6,3))
    total_volume_before_vu = fields.Float(string='Total Volume Before',compute= '_compute_total_volume_before_vu',store=True,digits=(6,3))
    total_volume_after_vu = fields.Float(string='Total  Volume After',compute= '_compute_total_volume_after_vu',store=True,digits=(6,3)) 
    total_output_yeild = fields.Float(string='Total Output Yield')
    bmr_no = fields.Char(string = 'BMR No')
    
    @api.depends('pulverization_production_syrup_id.weight_before')
    def _compute_total_weight_before(self):
        for order in self:
            weight_before = 0.0
            for line in order.pulverization_production_syrup_id:
                weight_before += line.weight_before 
                order.update({
                        'total_weight_before': weight_before
                        })
    
    @api.depends('pulverization_production_syrup_id.weight_after')
    def _compute_total_weight_after(self):
        for order in self:
            weight_after = 0.0
            for line in order.pulverization_production_syrup_id:
                weight_after += line.weight_after 
                order.update({
                        'total_weight_after': weight_after
                        })
    
    @api.depends('extract_solution_syrup_id.volume_before')
    def _compute_total_volume_before_pe(self):
        for order in self:
            volume_before_pe = 0.0
            for line in order.extract_solution_syrup_id:
                volume_before_pe += line.volume_before 
                order.update({
                        'total_volume_before_pe': volume_before_pe
                        })
    
    @api.depends('extract_solution_syrup_id.volume_after')
    def _compute_total_volume_after_pe(self):
        for order in self:
            volume_after_pe = 0.0
            for line in order.extract_solution_syrup_id:
                volume_after_pe += line.volume_after 
                order.update({
                        'total_volume_after_pe': volume_after_pe
                        })
    
    
    @api.depends('extract_solution_syrup_id.volume_before')
    def _compute_total_volume_before_pe(self):
        for order in self:
            volume_before_pe = 0.0
            for line in order.extract_solution_syrup_id:
                volume_before_pe += line.volume_before 
                order.update({
                        'total_volume_before_pe': volume_before_pe
                        })
    
    @api.depends('extraction_syrup_id.weight_before')
    def _compute_total_weight_before_ex(self):
        for order in self:
            weight_before_ex = 0.0
            for line in order.extraction_syrup_id:
                weight_before_ex += line.weight_before 
                order.update({
                        'total_weight_before_ex': weight_before_ex
                        })
    
    
    @api.depends('syrup_preparation_id.volume_before')
    def _compute_total_volume_before_ps(self):
        for order in self:
            volume_before_ps = 0.0
            for line in order.syrup_preparation_id:
                volume_before_ps += line.volume_before 
                order.update({
                        'total_volume_before_ps': volume_before_ps
                        })
    
    
    @api.depends('syrup_preparation_id.volume_after')
    def _compute_total_volume_after_ps(self):
        for order in self:
            volume_after_ps = 0.0
            for line in order.syrup_preparation_id:
                volume_after_ps += line.volume_after 
                order.update({
                        'total_volume_after_ps': volume_after_ps
                        })
    
    @api.depends('solvent_name_syrup_id.volume_before')
    def _compute_total_volume_before_vu(self):
        for order in self:
            volume_before_vu = 0.0
            for line in order.solvent_name_syrup_id:
                volume_before_vu += line.volume_before 
                order.update({
                        'total_volume_before_vu': volume_before_vu
                        })
    
    
    @api.depends('solvent_name_syrup_id.volume_after')
    def _compute_total_volume_after_vu(self):
        for order in self:
            volume_after_vu = 0.0
            for line in order.solvent_name_syrup_id:
                volume_after_vu += line.volume_after 
                order.update({
                        'total_volume_after_vu': volume_after_vu
                        })
    
    _defaults={
        'created_by': lambda s, cr, uid, c:uid  
        }
    
        
    def onchange_batch_id(self, cr, uid, ids, batch_id, context=None):
        process_type = self.pool.get('prakruti.batch_master').browse(cr, uid, batch_id, context=context)
        result = {
            'batch_size': process_type.batch_capacity,
            'batch_allocation_date': process_type.batch_allocation_date,
            'batch_end_date': process_type.batch_end_date,
            'pulverisation': process_type.pulverisation,
            'extraction_new': process_type.extraction_new,
            'extract_solution':process_type.extract_solution,
            'soak_raw_material':process_type.soak_raw_material,
            'filtration':process_type.filtration,
            'autoclave':process_type.autoclave,
            'addition_preservative':process_type.addition_preservative,
            'preparation_syrup':process_type.preparation_syrup,
            'ph_control_buffer':process_type.ph_control_buffer,
            'solvent_name':process_type.solvent_name,
            'filling':process_type.filling,
            'coding':process_type.coding,
            'packing':process_type.packing,
            'other_ingredient_addition':process_type.other_ingredient_addition,
            'bmr_no': process_type.bmr_no
            }
        return {'value': result}
 
    @api.one
    @api.multi
    def allocate_batch_no(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}   
            cr.execute("UPDATE prakruti_batch_master AS b SET batch_allocated_by = 'syrup',batch_allocated_flag = 1 FROM(SELECT batch_id FROM prakruti_syrup_production WHERE  id= %s ) AS a WHERE a.batch_id = b.id",((temp.id),))
            cr.execute("UPDATE prakruti_syrup_production SET status = 'batch_alloted' WHERE id = %s",((temp.id),))
        return {}
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.status in ['batch_alloted']:
                raise UserError(_('Can\'t Delete, Since the Batch is Alloted'))
        return super(PrakrutiSyrupProduction, self).unlink()   
    
    
    #_sql_constraints = [        
        #('production_uniq_with_batch_date','unique(batch_id,date)', 'This production Batch is already Entered for this Date. Please check and retry !'),       
        #('production_uniq_with_batch_subplant_date','unique(subplant_id,batch_id,date)', 'This batch is already in Use. Please check and retry !'),   
        #('production_uniq_with_batch_subplant','unique(subplant_id,batch_id)', 'This Subplant is already allocated to this Batch. Please check and retry !')
        #]    
    
class PrakrutiProductionSyrupPulverization(models.Model):
    _name ='prakruti.production_syrup_pulverization'
    _table = 'prakruti_production_syrup_pulverization'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    std_time = fields.Char( string='Standard Time')    
    machine_id=fields.Many2one('prakruti.machine',string='Equipment')
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    weight_before=fields.Float(string='Weight Before',digits=(6,3))
    weight_after=fields.Float(string='Weight After',digits=(6,3))
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')
    pulverization_id = fields.Many2one('prakruti.syrup_production') 
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
    #def _check_weight_before(self, cr, uid, ids):
        #lines = self.browse(cr, uid, ids)
        #for line in lines:
            #if line.weight_before <= 0:
                #return False
            #return True
        
    #def _check_weight_after(self, cr, uid, ids):
        #lines = self.browse(cr, uid, ids)
        #for line in lines:
            #if line.weight_after <= 0:
                #return False
            #return True
     
    #_constraints = [
       #(_check_weight_before, 'Weight before cannot be negative or zero !', ['weight_before']),
       #(_check_weight_after, 'Weight after cannot be negative or zero !', ['weight_after']),
        #]
     
    
class PrakrutiSyrupExtractSolution(models.Model):
    _name ='prakruti.syrup_extract_solution'
    _table = 'prakruti_syrup_extract_solution'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    std_time = fields.Char( string='Standard Time')
    name_of_extract = fields.Char( string='Name Of Extract')
    name_of_solvent = fields.Char( string='Name Of Solvent 1')
    solvent_name = fields.Char( string='Name Of Solvent 2')
    machine_id=fields.Many2one('prakruti.machine',string='Equipment')
    qty_of_extract_charged=fields.Float(string='Qty of Extract Charged',digits=(6,3))
    qty_of_solvent_charged=fields.Float(string='Qty of Solvent Charged 1',digits=(6,3))
    qty_of_solvent=fields.Float(string='Qty of Solvent Charged 2',digits=(6,3))
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    volume_before=fields.Float(string='Volume Before',digits=(6,3))
    volume_after=fields.Float(string='Volume After',digits=(6,3))
    temp_pressure_ph=fields.Float(string='Temp/Pressure/PH/RH',digits=(6,3))
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')     
    extract_solution_id = fields.Many2one('prakruti.syrup_production')
        
    #@api.one
    #@api.constrains('volume_before')
    #def _check_volume_before(self):
        #if self.volume_before < 0:
            #raise ValidationError(
                #"Volume Before can't be Negative !")  
        
    #@api.one
    #@api.constrains('volume_after')
    #def _check_volume_after(self):
        #if self.volume_after < 0:
            #raise ValidationError(
                #"Volume After can't be Negative !")  
        
    #@api.one
    #@api.constrains('qty_of_solvent_charged')
    #def _check_qty_of_solvent_charged(self):
        #if self.qty_of_solvent_charged <= 0:
            #raise ValidationError(
                #"Qty of Solvent Charged 1 can't be Negative !")  
        
    #@api.one
    #@api.constrains('qty_of_solvent')
    #def _check_qty_of_solvent(self):
        #if self.qty_of_solvent <= 0:
            #raise ValidationError(
                #"Qty of Solvent Charged 2 can't be Negative !")  
    
    #def _check_extract_charged(self, cr, uid, ids):
        #lines = self.browse(cr, uid, ids)
        #for line in lines:
            #if line.qty_of_extract_charged <= 0:
                #return False
            #return True
     
    #_constraints = [
       #(_check_extract_charged, 'Extract Charged cannot be negative or zero !', ['qty_of_extract_charged']),
        #]
    
class PrakrutiSoakRawMaterial(models.Model):
    _name ='prakruti.soak_raw_material'
    _table = 'prakruti_soak_raw_material'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    std_time = fields.Char( string='Standard Time')
    name_of_solvent = fields.Char( string='Name Of Solvent 1')
    solvent_name = fields.Char( string='Name Of Solvent 2')
    machine_id=fields.Many2one('prakruti.machine',string='Equipment')
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    qty_charged=fields.Float(string='Qty  Charged',digits=(6,3))
    solvent_charged=fields.Float(string='Solvent Charged 1',digits=(6,3))
    charged_solvent=fields.Float(string='Solvent Charged 2',digits=(6,3))
    temp_pressure_ph=fields.Float(string='Temp/Pressure/PH/RH',digits=(6,3))
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks') 
    soak_raw_material_id = fields.Many2one('prakruti.syrup_production')
        
    #@api.one
    #@api.constrains('solvent_charged')
    #def _check_solvent_charged(self):
        #if self.solvent_charged <= 0:
            #raise ValidationError(
                #"Solvent Charged 1 can't be Negative or 0!")  
        
    #@api.one
    #@api.constrains('charged_solvent')
    #def _check_charged_solvent(self):
        #if self.charged_solvent <= 0:
            #raise ValidationError(
                #"Solvent Charged 2 can't be Negative or 0!")  
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
    #def _check_qty_charged(self, cr, uid, ids):
        #lines = self.browse(cr, uid, ids)
        #for line in lines:
            #if line.qty_charged <= 0:
                #return False
            #return True
     
    #_constraints = [
       #(_check_qty_charged, 'Qty Charged cannot be negative or zero !', ['qty_charged']),
        #]
     
    
class PrakrutiSyrupExtraction(models.Model):
    _name ='prakruti.syrup_extraction'
    _table = 'prakruti_syrup_extraction'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    std_time = fields.Char( string='Standard Time')
    machine_id=fields.Many2one('prakruti.machine',string='Equipment')
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    weight_before=fields.Float(string='Weight Before',digits=(6,3))
    solvent_charged=fields.Float(string='Solvent Charged',digits=(6,3))
    temp_pressure_ph=fields.Float(string='Temp/Pressure/PH/RH',digits=(6,3))
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')
    syrup_extraction_id=fields.Many2one('prakruti.syrup_production')  
        
    #@api.one
    #@api.constrains('solvent_charged')
    #def _check_solvent_charged(self):
        #if self.solvent_charged < 0:
            #raise ValidationError(
                #"Solvent Charged can't be Negative !")  
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
    #def _check_weight_before(self, cr, uid, ids):
        #lines = self.browse(cr, uid, ids)
        #for line in lines:
            #if line.weight_before <= 0:
                #return False
            #return True
        
    #_constraints = [
       #(_check_weight_before, 'Weight cannot be negative or zero !', ['weight_before'])
        #]
     
     
    
class PrakrutiSyrupFiltration(models.Model):
    _name ='prakruti.syrup_filtration'
    _table = 'prakruti_syrup_filtration'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    std_time = fields.Char( string='Standard Time')
    machine_id=fields.Many2one('prakruti.machine',string='Equipment')
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    volume_collected=fields.Float(string='Volume Collected',digits=(6,3))
    temp_pressure_ph=fields.Float(string='Temp/Pressure/PH/RH',digits=(6,3))
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')
    syrup_filtration_id=fields.Many2one('prakruti.syrup_production') 
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")

class PrakrutiSyrupAutoclave(models.Model):
    _name ='prakruti.syrup_autoclave'
    _table = 'prakruti_syrup_autoclave'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    std_time = fields.Char( string='Standard Time')
    machine_id=fields.Many2one('prakruti.machine',string='Equipment')
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    temp_pressure_ph=fields.Float(string='Temp/Pressure/PH/RH',digits=(6,3))
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks') 
    syrup_autoclave_id=fields.Many2one('prakruti.syrup_production') 
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
class PrakrutiAdditionPreservative(models.Model):
    _name ='prakruti.addition_preservative'
    _table = 'prakruti_addition_preservative'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True") 
    std_time = fields.Char( string='Standard Time')
    machine_id=fields.Many2one('prakruti.machine',string='Equipment')
    quantity=fields.Char( string='Quantity')
    name_of_preservative=fields.Char( string='Name of Preservative')
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    temp_pressure_ph=fields.Float(string='Temp/Pressure/PH/RH',digits=(6,3))
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks') 
    addition_preservative_id=fields.Many2one('prakruti.syrup_production')
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
    #def _check_quantity(self, cr, uid, ids):
        #lines = self.browse(cr, uid, ids)
        #for line in lines:
            #if line.quantity <= 0:
                #return False
            #return True
     
    #_constraints = [
       #(_check_quantity, 'Extract Charged cannot be negative or zero !', ['quantity']),
        #]
     
     

class PrakrutiPreparationSyrup(models.Model):
    _name ='prakruti.preparation_syrup'
    _table = 'prakruti_preparation_syrup'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    std_time = fields.Char( string='Standard Time')
    machine_id=fields.Many2one('prakruti.machine',string='Equipment')
    quantity_of_sugar=fields.Char( string='Qty of Sugar')
    volume_before=fields.Float(string='Volume Before',digits=(6,3))
    volume_after=fields.Float(string='Volume After',digits=(6,3))
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    temp_pressure_ph=fields.Float(string='Temp/Pressure/PH/RH',digits=(6,3))
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks') 
    preparation_syrup_id=fields.Many2one('prakruti.syrup_production')
        
    #@api.one
    #@api.constrains('volume_after')
    #def _check_volume_after(self):
        #if self.volume_after <= 0:
            #raise ValidationError(
                #"Volume After can't be Negative or 0 !")  
        
    #@api.one
    #@api.constrains('volume_before')
    #def _check_volume_before(self):
        #if self.volume_before < 0:
            #raise ValidationError(
                #"Volume Before can't be Negative or 0!")  
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
    #def _check_quantity_of_sugar(self, cr, uid, ids):
        #lines = self.browse(cr, uid, ids)
        #for line in lines:
            #if line.quantity_of_sugar <= 0:
                #return False
            #return True
     
    #_constraints = [
       #(_check_quantity_of_sugar, 'Please enter Qty of Sugar Required !', ['quantity_of_sugar']),
        #]
     
     

class PrakrutiOtherIngredientAddition(models.Model):
    _name ='prakruti.other_ingredient_addition'
    _table = 'prakruti_other_ingredient_addition'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    std_time = fields.Char( string='Standard Time')
    machine_id=fields.Many2one('prakruti.machine',string='Equipment')
    ingredient_name=fields.Many2one('product.product', string='Ingredient Name')
    quantity=fields.Char( string='Quantity')
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    temp_pressure_ph=fields.Float(string='Temp/Pressure/PH/RH',digits=(6,3))
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks') 
    other_ingredient_addition_id=fields.Many2one('prakruti.syrup_production')
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
    #def _check_quantity(self, cr, uid, ids):
        #lines = self.browse(cr, uid, ids)
        #for line in lines:
            #if line.quantity <= 0:
                #return False
            #return True
     
    #_constraints = [
       #(_check_quantity, 'Extract Charged cannot be negative or zero !', ['quantity']),
        #]
     
     

class PrakrutiPhControlBufferAction(models.Model):
    _name ='prakruti.ph_control_buffer_action'
    _table = 'prakruti_ph_control_buffer_action'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    std_time = fields.Char( string='Standard Time')
    machine_id=fields.Many2one('prakruti.machine',string='Equipment')
    ingredient_name=fields.Many2one('product.product', string='Ingredient Name')
    quantity=fields.Char( string='Quantity')
    ph_before=fields.Float(string='PH Before',digits=(6,3))
    ph_after=fields.Float(string='PH After',digits=(6,3))
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')
    ph_control_buffer_action_id=fields.Many2one('prakruti.syrup_production') 
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
    #def _check_quantity(self, cr, uid, ids):
        #lines = self.browse(cr, uid, ids)
        #for line in lines:
            #if line.quantity <= 0:
                #return False
            #return True
     
    #_constraints = [
       #(_check_quantity, 'Extract Charged cannot be negative or zero !', ['quantity']),
        #]
     
     
    
class PrakrutiSolventName(models.Model):
    _name ='prakruti.solvent_name'
    _table = 'prakruti_solvent_name'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    std_time = fields.Char( string='Standard Time')
    name_of_solvent = fields.Char( string='Name Of Solvent')
    machine_id=fields.Many2one('prakruti.machine',string='Equipment')
    volume_added=fields.Char( string='Volume Added')
    volume_before=fields.Float(string='Volume Before',digits=(6,3))
    volume_after=fields.Float(string='Volume After',digits=(6,3))
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')
    solvent_name_id=fields.Many2one('prakruti.syrup_production') 
        
    #@api.one
    #@api.constrains('volume_added')
    #def _check_volume_added(self):
        #if self.volume_added <= 0:
            #raise ValidationError(
                #"Volume Added can't be Negative or 0 !")  
        
    #@api.one
    #@api.constrains('volume_before')
    #def _check_volume_before(self):
        #if self.volume_before <= 0:
            #raise ValidationError(
                #"Volume Before can't be Negative or 0 !")  
        
    #@api.one
    #@api.constrains('volume_after')
    #def _check_volume_after(self):
        #if self.volume_after <= 0:
            #raise ValidationError(
                #"Volume After can't be Negative or 0 !")  
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
class PrakrutiFilling(models.Model):
    _name ='prakruti.filling'
    _table = 'prakruti_filling'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    std_time = fields.Char( string='Standard Time')    
    machine_id=fields.Many2one('prakruti.machine',string='Equipment')
    no_of_bottles_filled=fields.Char( string='No of Bottles Filled')
    no_of_bottles_rejected=fields.Float(string='No of Bottles Rejected',digits=(6,3))
    total_bottles_accepted=fields.Float(string='Total Bottles Accepted',digits=(6,3))
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')
    filling_id=fields.Many2one('prakruti.syrup_production')
        
    #@api.one
    #@api.constrains('no_of_bottles_filled')
    #def _check_no_of_bottles_filled(self):
        #if self.no_of_bottles_filled < 0:
            #raise ValidationError(
                #"No of Bottles Filled can't be Negative  !")  
        
    #@api.one
    #@api.constrains('no_of_bottles_rejected')
    #def _check_no_of_bottles_rejected(self):
        #if self.no_of_bottles_rejected < 0:
            #raise ValidationError(
                #"No of Bottles Rejected can't be Negative !")  
        
    #@api.one
    #@api.constrains('total_bottles_accepted')
    #def _check_total_bottles_accepted(self):
        #if self.total_bottles_accepted < 0:
            #raise ValidationError(
                #"Total Bottles Accepted can't be Negative  !")   
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")

class PrakrutiCoding(models.Model):
    _name ='prakruti.coding'
    _table = 'prakruti_coding'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    std_time = fields.Char( string='Standard Time')
    machine_id=fields.Many2one('prakruti.machine',string='Equipment')
    no_of_units_code=fields.Char( string='No of Units Code')
    no_of_units_rejected=fields.Float(string='No of Units Rejected',digits=(6,3))
    total_units_accepted=fields.Float(string='Total Units Accepted',digits=(6,3))
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')
    coding_id=fields.Many2one('prakruti.syrup_production') 
        
    #@api.one
    #@api.constrains('no_of_units_rejected')
    #def _check_no_of_units_rejected(self):
        #if self.no_of_units_rejected < 0:
            #raise ValidationError(
                #"No of Units Rejected can't be Negative  !")  
        
    #@api.one
    #@api.constrains('total_units_accepted')
    #def _check_total_units_accepted(self):
        #if self.total_units_accepted < 0:
            #raise ValidationError(
                #"Total Units Accepted can't be Negative  !")  
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
class PrakrutiPacking(models.Model):
    _name ='prakruti.packing'
    _table = 'prakruti_packing'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    std_time = fields.Char( string='Standard Time')
    packing_style=fields.Text( string='Packing Style')
    no_of_packing=fields.Float( string='No of Packing',digits=(6,3))
    machine_id=fields.Many2one('prakruti.machine',string='Equipment')
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')
    packing_id=fields.Many2one('prakruti.syrup_production')
     
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    #def _check_no_of_packing(self, cr, uid, ids):
        #lines = self.browse(cr, uid, ids)
        #for line in lines:
            #if line.no_of_packing <= 0:
                #return False
            #return True
     
    #_constraints = [
       #(_check_no_of_packing, 'No of Packing cannot be negative or zero !', ['no_of_packing']),
        #]
    
    
class PrakrutiProductionBreakdownSyrup(models.Model):
    _name = 'prakruti.production_breakdown_syrup'
    _table = 'prakruti_production_breakdown_syrup'
    _description = 'Prakruti Production Breakdown Syrup  '
    _order= "id desc"
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    machine_id=fields.Many2one('prakruti.machine',string='Machine')
    date=fields.Date(string='Date', default=fields.Date.today)
    breakdown_id=fields.Many2one('prakruti.breakdown_item',string='Break Down Item')
    running_hours=fields.Char(string='Running Hours')
    breakdown_hours=fields.Char(string='Break Down Hours')
    remarks=fields.Text(string='Remarks')
    checked_by = fields.Char(string='Checked By')
    breakdown_grid_id = fields.Many2one('prakruti.syrup_production')