# -*- coding: utf-8 -*-

from openerp import models, fields, api
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
import re
import logging


#########################################################################################################


class PrakrutiProductionInward(models.Model):
    _name = 'prakruti.production_inward'
    _table = 'prakruti_production_inward'
    _description = 'Prakruti ProductionInward QC '
    _order= "id desc"
    _rec_name="inward_no"
    
    @api.multi
    def unlink(self):
        for order in self:
            raise UserError(_('Can\'t Delete'))
        return super(PrakrutiProductionInward, self).unlink()
    
    @api.one
    @api.multi
    def action_to_qc(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {} 
            production_qc = self.pool.get('prakruti.production_transfer_note_qc').create(cr,uid, {
                'ptn_no':temp.inward_no,
                'batch_no':temp.batch_no.id,
                })
            for item in temp.grid_id:
                grid_values = self.pool.get('prakruti.production_transfer_note_qc_line').create(cr,uid, {
                    'product_id': item.product_id.id,
                    'uom_id': item.uom_id.id,
                    'description': item.description,
                    'specification_id': item.specification_id.id,
                    'remarks':item.remarks,
                    'mrg_quantity':item.total_output_qty,
                    'common_inward_line_id':item.id,
                    'main_id':production_qc
                 })
            cr.execute("UPDATE  prakruti_production_inward SET state = 'qc_check' WHERE prakruti_production_inward.id = cast(%s as integer)",((temp.id),))
        return {}            
            
    inward_no = fields.Char(string='PTN/Inward No')
    date=fields.Date(string='PTN/Inward Date')
    batch_no = fields.Many2one('prakruti.batch_master',string='Batch No')
    dept_from = fields.Many2one('manage.department_sorting','From Department')
    prepared_by= fields.Many2one('res.users',string="Prepared By")
    store_incharge= fields.Many2one('res.users',string="Store Incharge")
    approved_by= fields.Many2one('res.users',string="Approved By")
    grid_id = fields.One2many('prakruti.production_inward_line', 'main_id',string='Grid ID') 
    remarks = fields.Text(string='Remarks')  
    state = fields.Selection([
                            ('ptn', 'PTN'),
                            ('inward','Inward'),
                            ('qc_check','QC Check'),
                            ('qc_check_done','QC Check Done'),
                            ('approved','Approved'),
                            ('rejected','Rejected'),
                            ('done','Done'),
                             ],default= 'inward', string= 'Status')
    bmr_no = fields.Char(string = 'BMR No')    
    
    @api.one
    @api.multi 
    def inward_to_stock(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {} 
            cr.execute("SELECT count(id) as accept_count FROM prakruti_production_inward_line WHERE accepted_qty > 0 AND main_id = %s",((temp.id),))
            for line in cr.dictfetchall():
                accept_count=int(line['accept_count'])
            if accept_count:
                cr.execute("SELECT updateinwardstock(%s)", ((temp.id),))
                cr.execute("UPDATE prakruti_production_inward SET state = 'approved' WHERE prakruti_production_inward.id = cast(%s as integer)", ((temp.id),))
            else:
                cr.execute("SELECT count(id) as reject_count FROM prakruti_production_inward_line WHERE qc_status = 'rejected' and rejected_qty > 0 AND main_id = %s",((temp.id),))
                for line in cr.dictfetchall():
                    reject_count=int(line['reject_count'])
                if reject_count >= 1:
                    material_rejection = self.pool.get('prakruti.material_rejected_store').create(cr,uid,{
                        'grn_no':temp.inward_no,
                        'order_date':temp.date,
                        'grn_date':temp.date,
                        'remarks':temp.remarks,
                        'state':'draft',
                        'coming_from':'production',
                        'batch_id':temp.batch_no.id,
                        'bmr_no':temp.bmr_no
                            })
                    for item in temp.grid_id:
                        grid_values = self.pool.get('prakruti.rejected_material_store_line').create(cr,uid, {
                            'product_id':item.product_id.id,
                            'uom_id':item.uom_id.id,
                            'description':item.description,
                            'quantity':item.rejected_qty,
                            'remarks':item.remarks,
                            'qc_check_line_id':material_rejection
                            })
                cr.execute("UPDATE prakruti_production_inward SET state = 'rejected' WHERE prakruti_production_inward.id = cast(%s as integer)", ((temp.id),))
        return{}
    
class PrakrutiProductionInwardLine(models.Model):
    _name = 'prakruti.production_inward_line'
    _table = "prakruti_production_inward_line"
    _description = 'Prakruti Production Inward Grid'

    product_id = fields.Many2one('product.product', string="Product", required=True)
    uom_id = fields.Many2one('product.uom',string="UOM",required=True)
    description = fields.Text(string="Description")
    packing_style=fields.Float(string='Packing Style',digits=(6,3))
    accepted_qty = fields.Float(string = "Accepted.Qty",digits=(6,3))
    rejected_qty = fields.Float(string = "Rejected.Qty",digits=(6,3))
    packing_qty=fields.Float(string='Packing Qty',digits=(6,3))
    total_output_qty=fields.Float(string='Total Output Qty',digits=(6,3))
    remarks=fields.Char(string='Remarks')
    specification_id = fields.Many2one('product.specification.main', string = "Specification")
    qc_status=fields.Selection([('approved','Approved'),('rejected','Rejected')],string=' QC Status',default= 'rejected')
    state = fields.Selection([
                            ('ptn', 'PTN'),
                            ('inward','Inward'),
                            ('qc_check','QC Check'),
                            ('from_qc','From QC')
                             ],default= 'inward', string= 'Status')    
    main_id = fields.Many2one('prakruti.production_inward',string="Grid", ondelete='cascade')   


    