# -*- coding: utf-8 -*-
from openerp.exceptions import ValidationError
import openerp
from datetime import date, datetime
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from datetime import timedelta
from openerp.osv import osv,fields
from openerp import models, fields, api, _
from openerp.tools.translate import _
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
from lxml import etree
import cgi
import logging
import lxml.html
import lxml.html.clean as clean
import openerp.pooler as pooler
import random
import re
import socket
import threading
import time
from openerp.tools import image_resize_image_big
from openerp.tools import amount_to_text
from openerp.tools.amount_to_text import amount_to_text_in 
from openerp.tools.amount_to_text import amount_to_text_in_without_word_rupees 
######################################################################################


class PrakrutiTabletProduction(models.Model):
    _name='prakruti.tablet_production'
    _table ='prakruti_tablet_production'
    _description='Screen that defines complete production'
    _order= 'id desc'
    _rec_name= 'subplant_id'
    
    batch_allocation_date=fields.Datetime(string='Batch Allocation Date', default=fields.Date.today)
    batch_end_date=fields.Datetime(string='Batch End Date')
    subplant_id = fields.Many2one('prakruti.sub_plant', string='Sub Plant', required=True)
    batch_id = fields.Many2one('prakruti.batch_master',string='Batch No',required=True)
    batch_size= fields.Float(string='Batch Size', required=True,digits=(6,3))
    date= fields.Date(string = 'Date', default= fields.Date.today, required=True)
    created_by =fields.Many2one('res.users','Created By')
    tablet_sieving_id = fields.One2many('prakruti.tablet_production_sieving','sieving_id',string='Sieving Grid')
    tablet_binder_id = fields.One2many('prakruti.tablet_production_binder','binder_id',string='Binder Grid')
    tablet_granulation_id = fields.One2many('prakruti.tablet_production_granulation','granulation_id',string='Granulation Grid')
    tablet_semi_drying_id = fields.One2many('prakruti.tablet_production_semi_drying','semi_drying_id',string='Semi Drying Grid')
    tablet_final_drying_id = fields.One2many('prakruti.tablet_production_final_drying','final_drying_id',string='Final Drying Grid')
    tablet_milling_id = fields.One2many('prakruti.tablet_production_milling','milling_id',string='Milling Grid')
    tablet_api_addition_id = fields.One2many('prakruti.tablet_production_api_addition','api_addition_id',string='Addition Grid')
    tablet_blending_id = fields.One2many('prakruti.tablet_production_blending','blending_id',string='Blending Grid')
    tablet_compression_id = fields.One2many('prakruti.tablet_production_compression','compression_id',string='Compression Grid')
    tablet_coating_preparation_id = fields.One2many('prakruti.tablet_production_coating_preparation','coating_preparation_id',string='Coating Preparation Grid')
    tablet_coating_id = fields.One2many('prakruti.tablet_production_coating','coating_id',string='Coating Grid')
    total_input_qty = fields.Float(string='Total Input Qty',digits=(6,3))#i
    total_output_qty = fields.Float(string='Total Output Qty',digits=(6,3))#i
    tablet_inspection_id = fields.One2many('prakruti.tablet_production_tablet_inspection','inspection_id',string='Inspection Grid')
    tablet_metal_inspection_id = fields.One2many('prakruti.tablet_production_metal_detection','metal_detection_id',string='Metal Detection Grid')
    tablet_packing_id = fields.One2many('prakruti.tablet_production_packing','packing_id',string='Packing Grid')
    breakdown_production_id = fields.One2many('prakruti.production_tablet_breakdown','breakdown_grid_id',string='Break Down Grid')
    sieving=fields.Selection([('yes','Yes'),('no','No')], string="Sieving", default='yes',required="True")
    preparation_of_binder= fields.Selection([('yes','Yes'),('no','No')], string="Preparation of Binder", default='yes',required="True")
    granulation = fields.Selection([('yes','Yes'),('no','No')], string="Granulation", default='yes',required="True")
    semi_drying = fields.Selection([('yes','Yes'),('no','No')], string="Semi Drying", default='yes',required="True")
    final_drying = fields.Selection([('yes','Yes'),('no','No')], string="Final Drying", default='yes',required="True")
    milling=fields.Selection([('yes','Yes'),('no','No')], string="Milling", default='yes',required="True")
    api_addition=fields.Selection([('yes','Yes'),('no','No')], string="API Addition", default='yes',required="True")
    blending=fields.Selection([('yes','Yes'),('no','No')], string="Blending", default='yes',required="True")
    compression = fields.Selection([('yes','Yes'),('no','No')], string="Compression\Capsule Filling", default='yes',required="True")
    tablet_coating = fields.Selection([('yes','Yes'),('no','No')], string="Tablet Coating Preparation", default='yes',required="True")
    coating = fields.Selection([('yes','Yes'),('no','No')], string="Coating", default='yes',required="True")
    inspection =fields.Selection([('yes','Yes'),('no','No')], string="Inspection Details", default='yes',required="True")
    metal_inspection=fields.Selection([('yes','Yes'),('no','No')], string="Metal Inspection", default='yes',required="True")
    packing =  fields.Selection([('yes','Yes'),('no','No')], string="Packing", default='yes',required="True")
    remarks = fields.Text(string='Remarks')
    production_name = fields.Selection([('tablet','Tablet')],string='Production Type',default='tablet')    
    status = fields.Selection([('batch_alloted','Batch Alloted')],string="Status",readonly="True")
    total_weight_before_si = fields.Float(string='Total Weight Before',compute= '_compute_total_weight_before_si',store=True,digits=(6,3))#i
    total_weight_after_si = fields.Float(string='Total  Weight After',compute= '_compute_total_weight_after_si',store=True,digits=(6,3))#i
    total_weight_before_mi = fields.Float(string='Total Weight Before',compute= '_compute_total_weight_before_mi',store=True,digits=(6,3))#i
    total_weight_after_mi = fields.Float(string='Total  Weight After',compute= '_compute_total_weight_after_mi',store=True,digits=(6,3))#i
    total_input_qty_pc = fields.Float(string='Total Input Qty',compute= '_compute_total_input_qty_pc',store=True,digits=(6,3))#i
    total_output_qty_pc = fields.Float(string='Total Output Qty',compute= '_compute_total_output_qty_pc',store=True,digits=(6,3))#i
    total_time_c = fields.Datetime(string='Total Time')
    total_input_qty_c = fields.Float(string='Total Input Qty',compute= '_compute_total_input_qty_c',store=True,digits=(6,3))#i
    total_output_qty_c = fields.Float(string='Total Output Qty',compute= '_compute_total_output_qty_c',store=True,digits=(6,3))#i 
    total_output_yeild = fields.Float(string='Total Output Yield')
    bmr_no = fields.Char(string = 'BMR No')
    
    _defaults={
        'created_by': lambda s, cr, uid, c:uid  
        }
    
    @api.depends('tablet_sieving_id.weight_before')
    def _compute_total_weight_before_si(self):
        for order in self:
            weight_before_si = 0.0
            for line in order.tablet_sieving_id:
                weight_before_si += line.weight_before 
                order.update({
                        'total_weight_before_si': weight_before_si
                        })
    
    @api.depends('tablet_sieving_id.weight_after')
    def _compute_total_weight_after_si(self):
        for order in self:
            weight_after_si = 0.0
            for line in order.tablet_sieving_id:
                weight_after_si += line.weight_after 
                order.update({
                        'total_weight_after_si': weight_after_si
                        })
    
    @api.depends('tablet_milling_id.weight_before')
    def _compute_total_weight_before_mi(self):
        for order in self:
            weight_before_mi = 0.0
            for line in order.tablet_milling_id:
                weight_before_mi += line.weight_before 
                order.update({
                        'total_weight_before_mi': weight_before_mi
                        })
    
    @api.depends('tablet_milling_id.weight_after')
    def _compute_total_weight_after_mi(self):
        for order in self:
            weight_after_mi = 0.0
            for line in order.tablet_milling_id:
                weight_after_mi += line.weight_after 
                order.update({
                        'total_weight_after_mi': weight_after_mi
                        })
    
    
    @api.depends('tablet_coating_preparation_id.input_qty')
    def _compute_total_input_qty_pc(self):
        for order in self:
            input_qty_pc = 0.0
            for line in order.tablet_coating_preparation_id:
                input_qty_pc += line.input_qty 
                order.update({
                        'total_input_qty_pc': input_qty_pc
                        })
    
    @api.depends('tablet_coating_preparation_id.output_qty')
    def _compute_total_output_qty_pc(self):
        for order in self:
            output_qty_pc = 0.0
            for line in order.tablet_coating_preparation_id:
                output_qty_pc += line.output_qty 
                order.update({
                        'total_output_qty_pc': output_qty_pc
                        })
    
    @api.depends('tablet_coating_id.input_qty')
    def _compute_total_input_qty_c(self):
        for order in self:
            input_qty_c = 0.0
            for line in order.tablet_coating_id:
                input_qty_c += line.input_qty 
                order.update({
                        'total_input_qty_c': input_qty_c
                        })
    
    @api.depends('tablet_coating_id.output_qty')
    def _compute_total_output_qty_c(self):
        for order in self:
            output_qty_c = 0.0
            for line in order.tablet_coating_id:
                output_qty_c += line.output_qty 
                order.update({
                        'total_output_qty_c': output_qty_c
                        })
    
    def onchange_batch_id(self, cr, uid, ids, batch_id, context=None):
        process_type = self.pool.get('prakruti.batch_master').browse(cr, uid, batch_id, context=context)
        result = {
            'batch_size': process_type.batch_capacity,
            'batch_allocation_date': process_type.batch_allocation_date,
            'batch_end_date': process_type.batch_end_date,
            'sieving': process_type.sieving,
            'preparation_of_binder': process_type.preparation_of_binder,
            'granulation':process_type.granulation,
            'semi_drying':process_type.semi_drying,
            'final_drying':process_type.final_drying,
            'milling':process_type.milling,
            'addition_preservative':process_type.addition_preservative,
            'blending':process_type.blending,
            'compression':process_type.compression,
            'tablet_coating':process_type.tablet_coating,
            'coating':process_type.coating,
            'inspection':process_type.inspection,
            'packing':process_type.packing,
            'metal_inspection':process_type.metal_inspection,
            'bmr_no': process_type.bmr_no
            }
        return {'value': result}
    
 
    @api.one
    @api.multi
    def allocate_batch_no(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}  
            cr.execute("UPDATE prakruti_batch_master AS b SET batch_allocated_by = 'tablet',batch_allocated_flag = 1 FROM(SELECT batch_id FROM prakruti_tablet_production WHERE  id= %s ) AS a WHERE a.batch_id = b.id",((temp.id),))
            cr.execute("UPDATE prakruti_tablet_production SET status = 'batch_alloted' WHERE id = %s",((temp.id),))
        return {}
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.status in ['batch_alloted']:
                raise UserError(_('Can\'t Delete, Since the Batch is Alloted'))
        return super(PrakrutiTabletProduction, self).unlink()    
    
    
    #_sql_constraints = [        
        #('production_uniq_with_batch_date','unique(batch_id,date)', 'This production Batch is already Entered for this Date. Please check and retry !'),       
        #('production_uniq_with_batch_subplant_date','unique(subplant_id,batch_id,date)', 'This batch is already in Use. Please check and retry !'),   
        #('production_uniq_with_batch_subplant','unique(subplant_id,batch_id)', 'This Subplant is already allocated to this Batch. Please check and retry !')
        #]
    
class PrakrutiTabletProductionSeiving(models.Model):
    _name='prakruti.tablet_production_sieving'
    _table ='prakruti_tablet_production_sieving'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    standard_time = fields.Char(string='Standard Time')
    equipment_code = fields.Many2one('prakruti.machine',string='Equipment')
    ingredient_name=fields.Many2one('product.product', string='Ingredient Name')
    sieve_id = fields.Many2one('prakruti.sieve_master',string='Seive Size')
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    weight_before= fields.Float(string='Weight Before',digits=(6,3))
    weight_after= fields.Float(string='Weight After',digits=(6,3))
    rejection=fields.Float(string='Rejection',digits=(6,3))
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')
    sieving_id = fields.Many2one('prakruti.tablet_production')
        
    #@api.one
    #@api.constrains('rejection')
    #def _check_rejection(self):
        #if self.rejection < 0:
            #raise ValidationError(
                #"Rejection can't be Negative !")  
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
    #def _check_weight_before(self, cr, uid, ids):
        #lines = self.browse(cr, uid, ids)
        #for temp in lines:
            #if temp.weight_before <= 0:
                #return False
            #return True
        
    #def _check_weight_after(self, cr, uid, ids):
        #lines = self.browse(cr, uid, ids)
        #for temp in lines:
            #if temp.weight_after <= 0:
                #return False
            #return True
        
        
    #_constraints = [
        
        #(_check_weight_before,'Weight before cannot be negative or zero!',['weight_before']),
        #(_check_weight_after,'Weight after cannot be negative or zero!',['weight_after']),
        #]
    
    
class PrakrutiTabletProductionBinder(models.Model):
    _name='prakruti.tablet_production_binder'
    _table ='prakruti_tablet_production_binder'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    standard_time = fields.Char(string='Standard Time')
    solvent = fields.Char(string='Name Of Solvent 1')
    solvent1 = fields.Char(string='Name Of Solvent 2')
    equipment_code = fields.Many2one('prakruti.machine',string='Equipment')
    binding_agent = fields.Char(string='Binding Agent')
    qty_solvent_1kg = fields.Float(string='Qty of solvent 1(KG)',digits=(6,3))
    qty_solvent_2kg = fields.Float(string='Qty of solvent 2(KG)',digits=(6,3))
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    qty_binder_solution = fields.Float(string='Qty of Binder Solution',digits=(6,3))
    temperature = fields.Float(string='Temp/Pressure/PH/RH',digits=(6,3))
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')
    binder_id = fields.Many2one('prakruti.tablet_production')
        
    #@api.one
    #@api.constrains('qty_solvent_1kg')
    #def _check_qty_solvent_1kg(self):
        #if self.qty_solvent_1kg <= 0:
            #raise ValidationError(
                #"Qty of solvent 1(KG) can't be Negative or 0!") 
        
    #@api.one
    #@api.constrains('qty_solvent_2kg')
    #def _check_qty_solvent_2kg(self):
        #if self.qty_solvent_2kg <= 0:
            #raise ValidationError(
                #"Qty of solvent 2(KG)can't be Negative or 0!") 
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
    #def _check_qty_binder(self, cr, uid, ids):
        #lines = self.browse(cr, uid, ids)
        #for temp in lines:
            #if temp.qty_binder_solution <= 0:
                #return False
            #return True
        
        
    #_constraints = [
        
        #(_check_qty_binder,'Qty of binder solution cannot be negative or zero!',['qty_binder_solution']),
        #]
    
    
class PrakrutiTabletProductionGranulation(models.Model):
    _name='prakruti.tablet_production_granulation'
    _table ='prakruti_tablet_production_granulation'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    standard_time = fields.Char(string='Standard Time')
    stage_id = fields.Many2one('prakruti.stage', string='Stage')
    equipment_code = fields.Many2one('prakruti.machine',string='Equipment')
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    qty_used = fields.Float(string='Qty Used',digits=(6,3))
    impellar = fields.Selection([('slow','Slow'),('fast','Fast')],string='Impellar')
    chopper = fields.Selection([('slow','Slow'),('fast','Fast')],string='Chopper')
    temperature = fields.Float(string='Temp/Pressure/PH/RH',digits=(6,3))
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')
    granulation_id = fields.Many2one('prakruti.tablet_production')
        
    #@api.one
    #@api.constrains('qty_used')
    #def _check_qty_used(self):
        #if self.qty_used <= 0:
            #raise ValidationError(
                #"Qty Used can't be Negative or 0!") 
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
    
class PrakrutiTabletProductionSemiDrying(models.Model):
    _name='prakruti.tablet_production_semi_drying'
    _table ='prakruti_tablet_production_semi_drying'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    standard_time = fields.Char(string='Standard Time')
    equipment_code = fields.Many2one('prakruti.machine',string='Equipment')
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    inlet =fields.Float(string='Temp Inlet',digits=(6,3))
    exhaust =fields.Float(string='Temp Exhaust',digits=(6,3))
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')    
    semi_drying_id = fields.Many2one('prakruti.tablet_production')
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
class PrakrutiTabletProductionFinalDrying(models.Model):
    _name='prakruti.tablet_production_final_drying'
    _table ='prakruti_tablet_production_final_drying'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    standard_time = fields.Char(string='Standard Time')
    equipment_code = fields.Many2one('prakruti.machine',string='Equipment')
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    inlet_air_flow =fields.Float(string='Inlet Air Flow',digits=(6,3))
    duration = fields.Datetime(string='Duration of Time')
    lod_of_granules= fields.Char(string='LOD of granules')
    inlet =fields.Float(string='Temp Inlet',digits=(6,3))
    exhaust =fields.Float(string='Temp Exhaust',digits=(6,3))
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')    
    final_drying_id = fields.Many2one('prakruti.tablet_production')
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
class PrakrutiTabletProductionMilling(models.Model):
    _name='prakruti.tablet_production_milling'
    _table ='prakruti_tablet_production_milling'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    standard_time = fields.Char(string='Standard Time')
    equipment_code = fields.Many2one('prakruti.machine',string='Equipment')
    ingredient_name=fields.Many2one('product.product', string='Ingredient Name')
    mesh_id = fields.Many2one('prakruti.mesh_master',string='Mesh Size')
    weight_before= fields.Float(string='Weight Before',digits=(6,3))
    weight_after= fields.Float(string='Weight After',digits=(6,3))
    rejection=fields.Float(string='Rejection',digits=(6,3))
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks') 
    
    
    #@api.one
    #@api.constrains('rejection')
    #def _check_rejection(self):
        #if self.rejection <= 0:
            #raise ValidationError(
                #"Rejection  can't be Negative or 0!") 
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
    #def _check_weight_before(self, cr, uid, ids):
        #lines = self.browse(cr, uid, ids)
        #for temp in lines:
            #if temp.weight_before <= 0:
                #return False
            #return True
        
    #def _check_weight_after(self, cr, uid, ids):
        #lines = self.browse(cr, uid, ids)
        #for temp in lines:
            #if temp.weight_after <= 0:
                #return False
            #return True
        
        
    #_constraints = [
        
        #(_check_weight_before,'Weight before cannot be negative or zero!',['weight_before']),
        #(_check_weight_after,'Weight after cannot be negative or zero!',['weight_after']),
        #]
    
    
    milling_id = fields.Many2one('prakruti.tablet_production')
    
class PrakrutiTabletProductionAPIAddition(models.Model):
    _name='prakruti.tablet_production_api_addition'
    _table ='prakruti_tablet_production_api_addition'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    standard_time = fields.Char(string='Standard Time')
    equipment_code = fields.Many2one('prakruti.machine',string='Equipment')
    ingredient_name=fields.Many2one('product.product', string='Ingredient Name')
    quantity = fields.Float(string='Quantity',digits=(6,3))
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time')
    temperature = fields.Float(string='Temp/Pressure/PH/RH',digits=(6,3))
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
    #def _check_quantity(self, cr, uid, ids):
        #lines = self.browse(cr, uid, ids)
        #for temp in lines:
            #if temp.quantity <= 0:
                #return False
            #return True
        
        
    #_constraints = [
        
        #(_check_quantity,'Qty cannot be negative or zero!',['quantity']),
        #]
    

    api_addition_id = fields.Many2one('prakruti.tablet_production')

class PrakrutiTabletProductionBlending(models.Model):
    _name='prakruti.tablet_production_blending'
    _table ='prakruti_tablet_production_blending'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    standard_time = fields.Char(string='Standard Time')
    equipment_code = fields.Many2one('prakruti.machine',string='Equipment')
    start_time = fields.Datetime(string='Time Start ')
    end_time = fields.Datetime(string='Time End ')
    input_qty = fields.Float(string='Input Qty',digits=(6,3))
    output_qty= fields.Float(string='Output Qty',digits=(6,3))
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')
    
    blending_id = fields.Many2one('prakruti.tablet_production')
    
    
    #@api.one
    #@api.constrains('input_qty')
    #def _check_input_qty(self):
        #if self.input_qty <= 0:
            #raise ValidationError(
                #"Input Qty can't be Negative or 0!") 
    
    
    #@api.one
    #@api.constrains('output_qty')
    #def _check_output_qty(self):
        #if self.output_qty <= 0:
            #raise ValidationError(
                #"Output Qty  can't be Negative or 0!") 
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
class PrakrutiTabletProductionCompression(models.Model):
    _name='prakruti.tablet_production_compression'
    _table ='prakruti_tablet_production_compression'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    standard_time = fields.Char(string='Standard Time')
    equipment_code = fields.Many2one('prakruti.machine',string='Equipment')
    qty_for_compression = fields.Float(string='Qty Before',digits=(6,3))
    qty_after_compression= fields.Float(string='Qty After',digits=(6,3))
    start_time = fields.Datetime(string='Start Time')
    end_time = fields.Datetime(string='End Time ')
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')    
    compression_id = fields.Many2one('prakruti.tablet_production')
    
    
    #@api.one
    #@api.constrains('qty_for_compression')
    #def _check_qty_for_compression(self):
        #if self.qty_for_compression <= 0:
            #raise ValidationError(
                #"Qty Taken for Compression can't be Negative or 0!") 
    
    
    #@api.one
    #@api.constrains('qty_after_compression')
    #def _check_qty_after_compression(self):
        #if self.qty_after_compression <= 0:
            #raise ValidationError(
                #"Qty After Compression can't be Negative or 0!") 
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
class PrakrutiTabletProductionCoatingPreparation(models.Model):
    _name='prakruti.tablet_production_coating_preparation'
    _table ='prakruti_tablet_production_coating_preparation'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    equipment_code = fields.Many2one('prakruti.machine',string='Equipment')
    qty_coating_material = fields.Float(string='Quantity Of Coating Material',digits=(6,3))
    qty_solvent = fields.Float(string='Quantity Of Solvent 1',digits=(6,3))
    solvent_qty = fields.Float(string='Quantity Of Solvent 2',digits=(6,3))
    temperature = fields.Float(string='Temp/Pressure/PH/RH',digits=(6,3))
    start_time = fields.Datetime(string='Start Time ')
    end_time = fields.Datetime(string='End Time ')
    input_qty = fields.Float(string='Input Qty',digits=(6,3))
    output_qty= fields.Float(string='Output Qty',digits=(6,3))
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')    
    coating_material_name = fields.Char(string='Coating Material name')
    solvent_name=fields.Char(string=' Solvent Name 1')
    name_solvent=fields.Char(string=' Solvent Name 2')
    standard_time = fields.Char(string='Std Time')    
    coating_preparation_id = fields.Many2one('prakruti.tablet_production')
    
    
    #@api.one
    #@api.constrains('qty_coating_material')
    #def _check_qty_coating_material(self):
        #if self.qty_coating_material <= 0:
            #raise ValidationError(
                #"Quantity Of Coating Material can't be Negative or 0!") 
    
    
    #@api.one
    #@api.constrains('qty_solvent')
    #def _check_qty_solvent(self):
        #if self.qty_solvent <= 0:
            #raise ValidationError(
                #"Quantity Of Solvent 1 can't be Negative or 0!") 
    
    
    #@api.one
    #@api.constrains('solvent_qty')
    #def _check_solvent_qty(self):
        #if self.solvent_qty <= 0:
            #raise ValidationError(
                #"Quantity Of Solvent 2 can't be Negative or 0!") 
    

    
    #@api.one
    #@api.constrains('input_qty')
    #def _check_input_qty(self):
        #if self.input_qty <= 0:
            #raise ValidationError(
                #"Input Qty can't be Negative or 0!") 
    
    
    #@api.one
    #@api.constrains('output_qty')
    #def _check_output_qty(self):
        #if self.output_qty <= 0:
            #raise ValidationError(
                #"Output Qty  can't be Negative or 0!") 
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")

class PrakrutiTabletProductionCoating(models.Model):
    _name='prakruti.tablet_production_coating'
    _table ='prakruti_tablet_production_coating'
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    standard_time = fields.Char(string='Standard Time')
    equipment_code = fields.Many2one('prakruti.machine',string='Equipment')
    start_time = fields.Datetime(string='Start Time ')
    end_time = fields.Datetime(string='End Time')
    input_qty = fields.Float(string='Input Qty',digits=(6,3))
    output_qty= fields.Float(string='Output Qty',digits=(6,3))
    pan_speed = fields.Float(string='Pan Speed',digits=(6,3))
    spray_rate = fields.Float(string='Spray Rate',digits=(6,3))
    tablet_bed_temp = fields.Float(string='Tablet BED Temp',digits=(6,3))
    automization_pressure = fields.Float(string='Automization Pressure',digits=(6,3))
    inlet =fields.Float(string='Temp Inlet',digits=(6,3))
    exhaust =fields.Float(string='Temp Exhaust',digits=(6,3))
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')    
    coating_id = fields.Many2one('prakruti.tablet_production')
    
    
    #@api.one
    #@api.constrains('input_qty')
    #def _check_input_qty(self):
        #if self.input_qty <= 0:
            #raise ValidationError(
                #"Input Qty can't be Negative or 0!") 
    
    
    #@api.one
    #@api.constrains('output_qty')
    #def _check_output_qty(self):
        #if self.output_qty <= 0:
            #raise ValidationError(
                #"Output Qty  can't be Negative or 0!") 
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
class PrakrutiTabletProductionTabletInspection(models.Model):
    _name='prakruti.tablet_production_tablet_inspection'
    _table ='prakruti_tablet_production_tablet_inspection'    
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    standard_time = fields.Char(string='Standard Time')
    equipment_code = fields.Many2one('prakruti.machine',string='Equipment')
    total_coated = fields.Float(string='Total Coated Tablets in Kg',digits=(6,3))
    rejected_tablets = fields.Float(string='Rejected Tablets',digits=(6,3))
    rejected_percentage = fields.Float(string='Rejection%',digits=(6,3))
    start_time = fields.Datetime(string='Start Time ')
    end_time = fields.Datetime(string='End Time')
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')
    
    
    inspection_id = fields.Many2one('prakruti.tablet_production')
    
    
    #@api.one
    #@api.constrains('total_coated')
    #def _check_total_coated(self):
        #if self.total_coated <= 0:
            #raise ValidationError(
                #"Total Coated Tablets in Kg can't be Negative or 0!") 
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
class PrakrutiTabletProductionMetalDetection(models.Model):
    _name='prakruti.tablet_production_metal_detection'
    _table ='prakruti_tablet_production_metal_detection'    
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    standard_time = fields.Char(string='Standard Time')
    equipment_code = fields.Many2one('prakruti.machine',string='Equipment')
    total_coated = fields.Float(string='Total Coated Tablets in Kg',digits=(6,3))
    rejected_tablets = fields.Float(string='Rejected Tablets',digits=(6,3))
    rejected_percentage = fields.Float(string='Rejection%',digits=(6,3))
    start_time = fields.Datetime(string='Start Time ')
    end_time = fields.Datetime(string='End Time')
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')
    metal_detection_id = fields.Many2one('prakruti.tablet_production')
    
    
    #@api.one
    #@api.constrains('total_coated')
    #def _check_total_coated(self):
        #if self.total_coated <= 0:
            #raise ValidationError(
                #"Total Coated Tablets in Kg can't be Negative or 0!") 
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
    
   
    
class PrakrutiTabletProductionPacking(models.Model):
    _name='prakruti.tablet_production_packing'
    _table ='prakruti_tablet_production_packing'    
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    standard_time = fields.Char(string='Standard Time')
    packing_style =fields.Char(string='Packing style')
    packing_qty =fields.Float(string='Packing Qty',digits=(6,3))
    equipment_code = fields.Many2one('prakruti.machine',string='Equipment')
    start_time = fields.Datetime(string='Start Time ')
    end_time = fields.Datetime(string='End Time')
    done_by = fields.Char(string='Done By')
    checked_by = fields.Char(string='Checked By')
    remarks = fields.Text(string='Remarks')    
    packing_id = fields.Many2one('prakruti.tablet_production')
        
    #@api.one
    #@api.constrains('start_time')
    #def _check_start_time(self):
        #if self.start_time < fields.Date.today():
            #raise ValidationError(
                #"Start date can't be less than current date!")  
        
    #@api.one
    #@api.constrains('end_time')
    #def _check_end_time(self):
        #if self.end_time < self.start_time:
            #raise ValidationError(
                #"End Date can't be less than start date!")
    
    #def _check_packing_qty(self, cr, uid, ids):
        #lines = self.browse(cr, uid, ids)
        #for temp in lines:
            #if temp.packing_qty <= 0:
                #return False
            #return True
        
        
    #_constraints = [
        
        #(_check_packing_qty,'Please Enter Packing Qty!',['packing_qty']),
        #]
    
class PrakrutiTabletProductionBreakdown(models.Model):
    _name = 'prakruti.production_tablet_breakdown'
    _table = 'prakruti_production_tablet_breakdown'
    _description = 'Prakruti Production Tablet Breakdown  '
    _order= "id desc"
    
    process_id = fields.Many2one('prakruti.process_order',string='Process Order',required="True")
    machine_id=fields.Many2one('prakruti.machine',string='Machine')
    date=fields.Date(string='Date', default=fields.Date.today)
    breakdown_id=fields.Many2one('prakruti.breakdown_item',string='Break Down Item')
    running_hours=fields.Char(string='Running Hours')
    breakdown_hours=fields.Char(string='Break Down Hours')
    remarks=fields.Text(string='Remarks')
    checked_by = fields.Many2one('res.users', string='Checked By')
    breakdown_grid_id = fields.Many2one('prakruti.tablet_production')