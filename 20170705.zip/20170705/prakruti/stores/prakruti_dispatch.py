# -*- coding: utf-8 -*-
from openerp.tools import image_resize_image_big
from openerp.exceptions import ValidationError
from openerp import api, fields, models, _
import openerp
from datetime import date, datetime
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from datetime import timedelta
from openerp.osv import osv,fields
from openerp import models, fields, api, _
from openerp.tools.translate import _
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
from lxml import etree
import cgi
import logging
import lxml.html
import lxml.html.clean as clean
import openerp.pooler as pooler
import random
import re
import socket
import threading
import time
from openerp.tools import image_resize_image_big
from openerp.tools import amount_to_text
from openerp.tools.amount_to_text import amount_to_text_in 
from openerp.tools.amount_to_text import amount_to_text_in_without_word_rupees 

class PrakrutiDispatch(models.Model):
    _name = 'prakruti.dispatch'
    _table = 'prakruti_dispatch'
    _order="id desc"
    _rec_name="dispatch_no"
    
    @api.one
    @api.multi
    def _get_auto(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        for temp in self:
            cr.execute('''select cast(extract (month from dispatch_date) as integer) as month ,cast(extract (year from dispatch_date) as integer) as year ,id from prakruti_dispatch where id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
                if month_value<=3:
                    year_value=year_value-1
                else:
                    year_value=year_value
                next_year=year_value+1
                dispay_year=str(next_year)[-2:]
                display_present_year=str(year_value)[-2:]
                        
                cr.execute('''select autogenerate_dispatch(%s)''', ((temp.id),)  ) 
                result = cr.dictfetchall()
                parent_invoice_id = 0
                for value in result: parent_invoice_id = value['autogenerate_dispatch'];
                auto_gen = int(parent_invoice_id)
                if len(str(auto_gen)) < 2:
                    auto_gen = '000'+ str(auto_gen)
                elif len(str(auto_gen)) < 3:
                    auto_gen = '00' + str(auto_gen)
                elif len(str(auto_gen)) == 3:
                    auto_gen = '0'+str(auto_gen)
                else:
                    auto_gen = str(auto_gen)
                for record in self :
                    if temp.product_type_id.group_code:
                        x[record.id] = 'DISP\\'+temp.product_type_id.group_code+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                    else:                        
                        x[record.id] = 'DISP\\'+'MISC'+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                cr.execute('''update prakruti_dispatch set dispatch_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
            return x

    dispatch_no = fields.Char(string='Dispatch No', default='New')
    dispatch_date = fields.Date('Dispatch Date', default= fields.Date.today)
    order_no = fields.Many2one('prakruti.sales_order', string='Order No')
    order_date = fields.Date('Order Date', store=True)
    dispatch_to = fields.Many2one('res.partner', string='Dispatch To')
    dis_no = fields.Char('Dis No', compute='_get_auto')
    auto_no = fields.Integer('Auto')
    req_no_control_id1 = fields.Integer('Auto Generating id',default= 0)
    grid_id = fields.One2many('prakruti.dispatch_line', 'main_id',string='Grid')
    company_id = fields.Many2one('res.company',string="Company")
    state =fields.Selection([
                ('draft','Draft'),
		('sent_to_qc','Sent To Quality Check'),
		('qc_done','QC Done'),
		('process_qa_done','QA Done'),
		('partially_confirmed','Partially Dispatched/Confirmed/Invoiced'),
		('invoice','Dispatched/Confirmed/Invoiced'),
		('without_qc_partially_confirmed','Without QC Partially Dispatched/Confirmed/Invoiced'),
		('without_qc_invoice','Without QC Dispatched/Confirmed/Invoiced'),
		('done','Done')
		], string= 'Status',default= 'draft', readonly=True)
    flag_count_accept = fields.Integer('Accepted Line is There',default= 0)
    flag_count_reject = fields.Integer('Rejected Line is There',default= 0)
    shipping_id = fields.Many2one('res.partner',string='Shipping Address')
    billing_id = fields.Many2one('res.partner',string='Billing Address')
    flag_count_par_reject = fields.Integer('Partial Rejected Line is There')
    product_type_id=fields.Many2one('product.group',string= 'Product Type')
    any_partial_line = fields.Integer(string= 'Any Partial Line',default=0)
    vehicle_no = fields.Char(string="Vehicle No.")
    transport_name = fields.Char(string="Name of the Transporter")
    flag_count = fields.Integer('Accepted Line is There',default= 1)
    quotation_no= fields.Char(string='Quotation No' ,readonly=True)
    quotation_date = fields.Date(string='Quotation Date' ,readonly=True)
    inquiry_date= fields.Date('Inquiry Date',readonly=True)
    inquiry_no = fields.Char(' Inquiry No', readonly=True)
    customer_id = fields.Many2one('res.partner',string="Customer")
    shipping_id = fields.Many2one('res.partner',string='Shipping Address')
    billing_id = fields.Many2one('res.partner',string='Billing Address')
    remarks = fields.Text(string="Remarks")
    #untaxed_amount = fields.Float(string="Untaxed Amount",digits=(6,3))
    #transporatation_charges=fields.Float(string='Transportation Charges',digits=(6,3))
    #final_grand_total = fields.Float(string=" Grand Total",digits=(6,3))
    terms =fields.Text('Terms and conditions')
    #order_type = fields.Selection([('with_tarrif','Sales'),('without_tarrif','PS')], string="Order Type")
    #assessable_value=fields.Float(string='Assessable Value(%)',digits=(6,3))
    #total_assessable_value= fields.Float(string='Total Assesable value',digits=(6,3))
    #assessable_subtotal=fields.Float(string='Assesable  Total',digits=(6,3))
    #subtotal= fields.Float(string='Sub Total',digits=(6,3))
    countflag = fields.Integer('Flag Line is There',default= 0)   
    #tax_line_id = fields.One2many('sales.dispatch.tax.line','ref_id',string='All Taxes')
    #new_bed_amt = fields.Float(string="BED Total",digits=(6,3))
    #new_ed_cess_amt = fields.Float(string="Ed Cess Total",digits=(6,3))
    #new_sec_cess_amt = fields.Float(string="Sec Cess Total",digits=(6,3))
    #new_total_tax = fields.Float(string="Total Tax",digits=(6,3))
    #new_total_vat = fields.Float(string="Total Vat",digits=(6,3))
    #new_total_cst = fields.Float(string="Total Cst",digits=(6,3))
    #new_total_sbc = fields.Float(string="Swachh Bharat",digits=(6,3))
    #new_total_kkc = fields.Float(string="Krishi Kalayan",digits=(6,3))
    flag_count_display_product = fields.Integer(default=0)    
    flag_rejected_count = fields.Integer('Flag', default=1)
    any_adv_payment =fields.Selection([
                    ('no', 'No'),
                    ('yes','Yes')
                    ], string= 'Any Advance Payment')
    advance_payment_type =fields.Selection([
                    ('cash', 'CASH'),
                    ('cheque','CHEQUE'),
                    ('demand_draft','DEMAND DRAFT')
                    ], string= 'Any Advance Payment Done By')
    cash_amount = fields.Float(string="Amount",digits=(6,3))
    cash_remarks = fields.Text(string="Remarks")    
    cheque_amount = fields.Float(string="Amount",digits=(6,3))
    cheque_no = fields.Integer(string="Cheque No.")
    cheque_remarks = fields.Text(string="Remarks")    
    draft_amount = fields.Float(string="Amount",digits=(6,3))
    draft_no = fields.Integer(string="Draft No.")
    draft_remarks = fields.Text(string="Remarks")  
    po_no= fields.Char(string='P.O No')
    #type_of_product = fields.Selection([
        #('extraction','Extraction'),
        #('formulation','Formulation')], default='extraction', string="Type of Product")
    #type_of_order = fields.Selection([
        #('sales','SALES'),
        #('ps','PHYSICIAN SAMPLE')
        #],default='sales',string="Type of Order")    
    slip_no= fields.Char(string='Slip No.',readonly=1)#20170420
    dispatch_id =fields.Many2one('res.users','Dispatch By') 
    requested_id =fields.Many2one('res.users','Requested By')
    quotation_id =fields.Many2one('res.users','Quotation By')
    order_id =fields.Many2one('res.users','Order By')
    reference_no= fields.Char(string='Ref No')
    reference_date= fields.Date(string='Ref Date')  
    product_id = fields.Many2one('product.product', related='grid_id.product_id', string='Product Name')  
    reject_flag = fields.Integer(string="Reject Flag",default=0)
    dispatch_flag = fields.Integer(string="Dispatch Flag",default=0)
    sent_to_qa_before_qc_test = fields.Integer(string="Sent to QA Before QC Test",default=0)
    #update_dispatch_flag = fields.Integer(string="Update Dispatch Flag",default=0)
    qc_check_flag = fields.Integer(string= 'QC Check Done',default=0,readonly=1)
    #GST ENTRY
    total_no_of_products = fields.Integer(string="Total No of Products")
    proportionate_amount_to_products = fields.Float(string="Proportionate Amount to Products")
    freight_charges = fields.Float(string="Freight Charges")
    loading_and_packing_charges = fields.Float(string="Loading and Packing Charges")
    insurance_charges = fields.Float(string="Insurance Charges")
    other_charges =  fields.Float(string="Other Charges")
    all_additional_charges = fields.Float(string="All Additional Charges")#SUM OF all charges like freight_charges loading_and_packing_charges insurance_charges other_charges
    total_amount_before_tax = fields.Float(string="Untaxed Amount")#SUM OF Taxable value after adding other charges
    total_cgst_amount = fields.Float(string="CGST Amount")
    total_sgst_amount = fields.Float(string="SGST Amount")
    total_igst_amount = fields.Float(string="IGST Amount")
    total_gst_amount = fields.Float(string="Total GST")  
    total_amount_after_tax = fields.Float(string="Grand Total")#SUM OF Subtotal of the grid
    
    @api.model
    def _default_company(self):
        return self.env['res.company']._company_default_get('res.partner')
    
    _defaults = {
        'company_id': _default_company, 
        'dispatch_id': lambda s, cr, uid, c:uid
        }
    
        
    def onchange_order_no(self, cr, uid, ids, order_no, context=None):
        process_type = self.pool.get('prakruti.sales_order').browse(cr, uid, order_no, context=context)
        result = {
            'dispatch_to': process_type.customer_id.id,
            'po_no': process_type.po_no,
            'order_date': process_type.order_date,
            'quotation_no': process_type.quotation_no,
            'quotation_date': process_type.quotation_date,
            'inquiry_date': process_type.inquiry_date,
            'inquiry_no': process_type.inquiry_no,
            'shipping_id': process_type.shipping_id.id,
            'billing_id': process_type.billing_id.id,
            'customer_id': process_type.customer_id.id,
            'product_type_id': process_type.product_type_id.id,
            #'untaxed_amount':process_type.untaxed_amount,
            #'transporatation_charges':process_type.transporatation_charges,
            #'subtotal':process_type.subtotal,
            #'final_grand_total':process_type.final_grand_total,
            'terms':process_type.terms,
            #'order_type':process_type.order_type,
            #'assessable_value':process_type.assessable_value,
            #'total_assessable_value':process_type.total_assessable_value,
            #'assessable_subtotal':process_type.assessable_subtotal,
            #'new_bed_amt':process_type.new_bed_amt,
            #'new_ed_cess_amt':process_type.new_ed_cess_amt,
            #'new_sec_cess_amt':process_type.new_sec_cess_amt,
            #'new_total_tax':process_type.new_total_tax,
            #'new_total_vat':process_type.new_total_vat,
            #'new_total_cst':process_type.new_total_cst,
            #'new_total_sbc':process_type.new_total_sbc,
            #'new_total_kkc':process_type.new_total_kkc,
            'cash_amount':process_type.cash_amount,
            'cash_remarks':process_type.cash_remarks,
            'cheque_amount':process_type.cheque_amount,
            'cheque_no':process_type.cheque_no,
            'cheque_remarks':process_type.cheque_remarks,
            'draft_amount':process_type.draft_amount,
            'draft_no':process_type.draft_no,
            'draft_remarks':process_type.draft_remarks,
            'advance_payment_type':process_type.advance_payment_type,
            'any_adv_payment':process_type.any_adv_payment,
            #'type_of_order':process_type.type_of_order,
            #'type_of_product':process_type.type_of_product,
            'slip_no':process_type.slip_no,
            'requested_id':process_type.requested_id.id,
            'order_id':process_type.order_id.id,
            'quotation_id':process_type.quotation_id.id,
            'reference_no':process_type.reference_no,
            'reference_date':process_type.reference_date,
            #GST ENtry
            'total_no_of_products':process_type.total_no_of_products,
            'proportionate_amount_to_products':process_type.proportionate_amount_to_products,
            'freight_charges':process_type.freight_charges,
            'loading_and_packing_charges':process_type.loading_and_packing_charges,
            'insurance_charges':process_type.insurance_charges,
            'other_charges':process_type.other_charges,
            'all_additional_charges':process_type.all_additional_charges,
            'total_amount_before_tax':process_type.total_amount_before_tax,
            'total_cgst_amount':process_type.total_cgst_amount,
            'total_sgst_amount':process_type.total_sgst_amount,
            'total_igst_amount':process_type.total_igst_amount,
            'total_gst_amount':process_type.total_gst_amount,
            'total_amount_after_tax':process_type.total_amount_after_tax
            
            }
        return {'value': result}
    
    def create(self, cr, uid, vals, context=None):
        onchangeResult = self.onchange_order_no(cr, uid, [], vals['order_no'])
        if onchangeResult.get('value') or onchangeResult['value'].get('order_date','dispatch_to','shipping_id','billing_id','product_type_id','inquiry_no','po_no','slip_no','customer_id','reference_no','reference_date','order_id','quotation_id','requested_id'):
            vals['order_date'] = onchangeResult['value']['order_date']
            vals['dispatch_to'] = onchangeResult['value']['dispatch_to']
            vals['shipping_id'] = onchangeResult['value']['shipping_id']
            vals['billing_id'] = onchangeResult['value']['billing_id']
            vals['product_type_id'] = onchangeResult['value']['product_type_id']
            vals['inquiry_no'] = onchangeResult['value']['inquiry_no']
            vals['po_no'] = onchangeResult['value']['po_no']
            vals['slip_no'] = onchangeResult['value']['slip_no']
            vals['customer_id'] = onchangeResult['value']['customer_id']
            vals['reference_no'] = onchangeResult['value']['reference_no']
            vals['reference_date'] = onchangeResult['value']['reference_date']
            vals['order_id'] = onchangeResult['value']['order_id']
            vals['quotation_id'] = onchangeResult['value']['quotation_id']
            vals['requested_id'] = onchangeResult['value']['requested_id']
        return super(PrakrutiDispatch, self).create(cr, uid, vals, context=context)
    
    def write(self, cr, uid, ids, vals, context=None):
        op=super(PrakrutiDispatch, self).write(cr, uid, ids, vals, context=context)
        for record in self.browse(cr, uid, ids, context=context):
            store_type=record.order_no.id
        onchangeResult = self.onchange_order_no(cr, uid, ids, store_type)
        if onchangeResult.get('value') or onchangeResult['value'].get('order_date','dispatch_to','shipping_id','billing_id','product_type_id','inquiry_no','po_no','slip_no','customer_id','reference_no','reference_date','order_id','quotation_id','requested_id'):
            vals['order_date'] = onchangeResult['value']['order_date']
            vals['dispatch_to'] = onchangeResult['value']['dispatch_to']
            vals['shipping_id'] = onchangeResult['value']['shipping_id']
            vals['billing_id'] = onchangeResult['value']['billing_id']
            vals['product_type_id'] = onchangeResult['value']['product_type_id']
            vals['inquiry_no'] = onchangeResult['value']['inquiry_no']
            vals['po_no'] = onchangeResult['value']['po_no']
            vals['slip_no'] = onchangeResult['value']['slip_no']
            vals['customer_id'] = onchangeResult['value']['customer_id']
            vals['reference_no'] = onchangeResult['value']['reference_no']
            vals['reference_date'] = onchangeResult['value']['reference_date']
            vals['order_id'] = onchangeResult['value']['order_id']
            vals['quotation_id'] = onchangeResult['value']['quotation_id']
            vals['requested_id'] = onchangeResult['value']['requested_id']
        return super(PrakrutiDispatch, self).write(cr, uid, ids, vals, context=context)
    
    @api.one
    @api.multi
    def action_list_products(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute("SELECT product_id,uom_id,specification_id,description,scheduled_qty,scheduled_date,status,quantity,unit_price,total,main_id,dispatched_qty,total_dispatched_qty,total_scheduled_qty,remaining_dispatched_qty,hsn_code,amount,discount_id,discount,taxable_value,prakruti_sales_order_item.proportionate_amount_to_products,taxable_value_with_charges,gst_rate,cgst_id,cgst_value,cgst_amount,sgst_id,sgst_value,sgst_amount,igst_id,igst_value,igst_amount FROM prakruti_sales_order INNER JOIN prakruti_sales_order_item ON prakruti_sales_order.id=prakruti_sales_order_item.main_id WHERE prakruti_sales_order_item.main_id = CAST(%s as integer) AND total_dispatched_qty != quantity ",((temp.order_no.id),))
            for item in cr.dictfetchall():
                print 'abcdeghhhhhhhhhhhhhhh'
                product_id=item['product_id']
                uom_id=item['uom_id']
                specification_id=item['specification_id']
                description =item['description']
                quantity=item['quantity']
                scheduled_qty=item['scheduled_qty']
                scheduled_date=item['scheduled_date']
                #tarrif_id=item['tarrif_id']
                unit_price=item['unit_price']
                #mrp=item['mrp']
                total=item['total']
                #total1=item['total1']
                #batch_no=item['batch_no']
                #mfg_date=item['mfg_date']
                #exp_date=item['exp_date']
                dispatched_qty=item['dispatched_qty']
                #type_of_product=item['type_of_product']
                #type_of_order=item['type_of_order']
                total_dispatch_qty =item['total_dispatched_qty']
                total_scheduled_qty =item['total_scheduled_qty']
                remaining_dispatched_qty =item['remaining_dispatched_qty']
                #GST Entry
                hsn_code= item['hsn_code']
                amount=item['amount']
                discount_id=item['discount_id']
                discount=item['discount']
                taxable_value=item['taxable_value']
                proportionate_amount_to_products=item['proportionate_amount_to_products']
                taxable_value_with_charges=item['taxable_value_with_charges']
                gst_rate=item['gst_rate']
                cgst_id=item['cgst_id']
                cgst_value=item['cgst_value']
                cgst_amount=item['cgst_amount']
                sgst_id=item['sgst_id']
                sgst_value=item['sgst_value']
                sgst_amount=item['sgst_amount']
                igst_id=item['igst_id']
                igst_value=item['igst_value']
                igst_amount=item['igst_amount']
                grid_down = self.pool.get('prakruti.dispatch_line').create(cr,uid, {
                    'product_id':product_id,
                    'uom_id':uom_id,
                    'specification_id':specification_id,
                    'description':description,
                    'ordered_qty':quantity,
                    'scheduled_date':scheduled_date,
                    'scheduled_qty':scheduled_qty,
                    'previous_dispatch_qty':dispatched_qty,
                    'dispatched_qty':total_scheduled_qty - total_dispatch_qty,
                    #'batch_no':batch_no,
                    #'mfg_date':mfg_date,
                    #'exp_date':exp_date,
                    'unit_price':unit_price,
                    #'mrp':mrp,
                    'total':total,
                    #'total1':total1,
                    #'tarrif_id':tarrif_id,
                    #'type_of_product':type_of_product,
                    #'type_of_order':type_of_order,
                    'total_dispatch_qty':total_dispatch_qty,
                    'total_scheduled_qty':total_scheduled_qty,
                    'remaining_dispatched_qty':total_scheduled_qty - total_dispatch_qty,
                    #GST Entry
                    'hsn_code': hsn_code,
                    'amount': amount,
                    'discount_id': discount_id,
                    'discount': discount,
                    'taxable_value': taxable_value,
                    'proportionate_amount_to_products':proportionate_amount_to_products,
                    'taxable_value_with_charges':taxable_value_with_charges,
                    'gst_rate': gst_rate,
                    'cgst_id':cgst_id,
                    'cgst_value': cgst_value,
                    'cgst_amount':cgst_amount,
                    'sgst_id':sgst_id,
                    'sgst_value': sgst_value,
                    'sgst_amount':sgst_amount,
                    'igst_id':igst_id,
                    'igst_value': igst_value,
                    'igst_amount':igst_amount,
                    
                    'main_id':temp.id,
                        })
            #cr.execute('''SELECT sales_order_tax_line.tax_type,tax_percent,tax_amount,total_value,ref_id FROM prakruti_sales_order
                     #INNER JOIN sales_order_tax_line ON 
                     #prakruti_sales_order.id = sales_order_tax_line.ref_id 
                    #WHERE sales_order_tax_line.ref_id = CAST(%s as integer)  ''',((temp.order_no.id),))
            #print 'temp.order_no.idtemp.order_no.idtemp.order_no.id',temp.order_no.id
            #for line in cr.dictfetchall():
                #tax_type=line['tax_type']
                #tax_percent=line['tax_percent']
                #tax_amount=line['tax_amount']
                #total_value=line['total_value']
                #grid_tax = self.pool.get('sales.dispatch.tax.line').create(cr,uid, {
                    #'tax_type':tax_type,
                    #'tax_percent':tax_percent,
                    #'tax_amount':tax_amount,
                    #'total_value':total_value,
                    #'ref_id':temp.id,
                    #})
            cr.execute("UPDATE  prakruti_dispatch SET flag_count_display_product = 1 WHERE prakruti_dispatch.id = cast(%s as integer)",((temp.id),))
        return {}
    
            
    @api.one
    @api.multi
    def action_delete_products(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute('''DELETE FROM prakruti_dispatch_line WHERE prakruti_dispatch_line.main_id = (%s)''', ((temp.id),))
            cr.execute('''DELETE FROM sales_dispatch_tax_line WHERE sales_dispatch_tax_line.ref_id = (%s)''', ((temp.id),))
            cr.execute("UPDATE  prakruti_dispatch SET flag_count =1 WHERE prakruti_dispatch.id = cast(%s as integer)",((temp.id),))
            cr.execute("UPDATE  prakruti_dispatch SET flag_count_display_product = 0 WHERE prakruti_dispatch.id = cast(%s as integer)",((temp.id),))
        return {}
    
    @api.one
    @api.multi 
    def validate_grid(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            for item in temp.grid_id:
                if item.status in ['rejected']:
                    temp.flag_count_reject = 1
                elif item.status in ['accepted','accept_under_deviation']:
                    temp.flag_count_accept = 1
                elif item.status in ['par_reject']:
                    temp.flag_count_par_reject = 1
                cr.execute("UPDATE  prakruti_dispatch SET state = 'validate' WHERE prakruti_dispatch.id = cast(%s as integer)",((temp.id),))
        return {}  
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['sent_to_qc','validate','sent_to_dispatch','qc_done','invoice']:
                raise UserError(_('Can\'t Delete...'))
        return super(PrakrutiDispatch, self).unlink() 
    
    @api.one
    @api.multi 
    def dispatch_to_qc(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {} 
            #template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Sales Dispatch')],context=context)[0]
            #email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
            if len(temp.grid_id) != 0 :
                qc_check = self.pool.get('prakruti.quality_check').create(cr,uid, {
                    'dispatch_no':temp.dispatch_no,
                    'dispatch_date':temp.dispatch_date,
                    'dispatch_to':temp.dispatch_to.id,
                    'order_no':temp.order_no.id,
                    'order_date':temp.order_date,
                    'customer_id':temp.customer_id.id,
                    'terms':temp.terms,
                    'inquiry_no':temp.inquiry_no,
                    'inquiry_date':temp.inquiry_date,
                    'quotation_no':temp.quotation_no,
                    'quotation_date':temp.quotation_date,
                    'shipping_id':temp.shipping_id.id,
                    'billing_id':temp.billing_id.id,
                    'product_type_id':temp.product_type_id.id,
                    'remarks':temp.remarks,
                    #'order_type':temp.order_type,
                    #'assessable_value':temp.assessable_value,
                    #'total_assessable_value':temp.total_assessable_value,
                    #'assessable_subtotal':temp.assessable_subtotal,
                    #'subtotal':temp.subtotal,                    
                    #'new_bed_amt':temp.new_bed_amt,
                    #'new_ed_cess_amt':temp.new_ed_cess_amt,
                    #'new_sec_cess_amt':temp.new_sec_cess_amt,
                    #'new_total_tax':temp.new_total_tax,
                    #'new_total_vat':temp.new_total_vat,
                    #'new_total_cst':temp.new_total_cst,
                    #'new_total_sbc':temp.new_total_sbc,
                    #'new_total_kkc':temp.new_total_kkc,
                    #'untaxed_amount':temp.untaxed_amount,
                    #'transporatation_charges':temp.transporatation_charges,
                    'requested_id':temp.requested_id.id,
                    'order_id':temp.order_id.id,
                    'quotation_id':temp.quotation_id.id,
                    'dispatch_id':temp.dispatch_id.id,
                    #'final_grand_total':temp.final_grand_total,
                    'reference_no':temp.reference_no
                    })
                qa_check = self.pool.get('prakruti.process_quality_control_qa').create(cr,uid, {
                    'dispatch_no':temp.dispatch_no,
                    'dispatch_date':temp.dispatch_date,
                    'dispatch_to':temp.dispatch_to.id,
                    'order_no':temp.order_no.id,
                    'order_date':temp.order_date,
                    'customer_id':temp.customer_id.id,
                    'requested_id':temp.requested_id.id,
                    'order_id':temp.order_id.id,
                    'quotation_id':temp.quotation_id.id,
                    'dispatch_id':temp.dispatch_id.id,
                    'reference_no':temp.reference_no,
                    'qc_check_flag':temp.qc_check_flag
                    })
                for item in temp.grid_id:
                    grid_qc_values = self.pool.get('prakruti.quality_check_line').create(cr,uid, {
                        'product_id':item.product_id.id,
                        'description':item.description,
                        'uom_id':item.uom_id.id,
                        'specification_id':item.specification_id.id,
                        'ordered_qty':item.ordered_qty,
                        'dispatched_qty':item.dispatched_qty,
                        'remarks':item.remarks,
                        'unit_price': item.unit_price,
                        #'tarrif_id':item.tarrif_id,
                        #'mrp':item.mrp,
                        #'total1':item.total1,
                        'batch_no':item.batch_no.id,
                        #'mfg_date':item.mfg_date,
                        #'exp_date':item.exp_date,
                        'total':item.total,
                        'dispatch_line_grid_id':item.id,
                        'state':'draft',
                        'check_line_id':qc_check
                        })
                    grid_qa_values = self.pool.get('prakruti.process_quality_control_line_qa').create(cr,uid, {
                        'product_id':item.product_id.id,
                        'description':item.description,
                        'uom_id':item.uom_id.id,
                        'specification_id':item.specification_id.id,
                        'ordered_qty':item.ordered_qty,
                        'dispatched_qty':item.dispatched_qty,
                        'remarks':item.remarks,
                        'unit_price': item.unit_price,
                        'batch_no':item.batch_no.id,
                        'total':item.total,
                        'dispatch_line_grid_id':item.id,
                        'state':'draft',
                        'qc_check_line_id':qa_check
                    })
            else:
                raise UserError(_('Please select the Order No. and list out the Products...'))
            cr.execute("UPDATE  prakruti_dispatch SET state = 'sent_to_qc' WHERE prakruti_dispatch.id = cast(%s as integer)",((temp.id),))
        return {}
    
    @api.one
    @api.multi 
    def dispatch_to_qa(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {} 
            if len(temp.grid_id) != 0:
                qa_check = self.pool.get('prakruti.quality_check_qa').create(cr,uid, {
                    'dispatch_no':temp.dispatch_no,
                    'dispatch_date':temp.dispatch_date,
                    'dispatch_to':temp.dispatch_to.id,
                    'order_no':temp.order_no.id,
                    'order_date':temp.order_date,
                    'customer_id':temp.customer_id.id,
                    'requested_id':temp.requested_id.id,
                    'order_id':temp.order_id.id,
                    'quotation_id':temp.quotation_id.id,
                    'dispatch_id':temp.dispatch_id.id,
                    'reference_no':temp.reference_no
                    })
                for item in temp.grid_id:
                    grid_values = self.pool.get('prakruti.quality_check_line_qa').create(cr,uid, {
                        'product_id':item.product_id.id,
                        'description':item.description,
                        'uom_id':item.uom_id.id,
                        'specification_id':item.specification_id.id,
                        'ordered_qty':item.ordered_qty,
                        'dispatched_qty':item.dispatched_qty,
                        'remarks':item.remarks,
                        'unit_price': item.unit_price,
                        'batch_no':item.batch_no.id,
                        'total':item.total,
                        'dispatch_line_grid_id':item.id,
                        'state':'draft',
                        'qc_check_line_id':qa_check
                    })
            else:
                raise UserError(_('Please select the Order No. and list out the Products...'))
            cr.execute("UPDATE  prakruti_dispatch SET state = 'sent_to_qa' WHERE prakruti_dispatch.id = cast(%s as integer)",((temp.id),))
            cr.execute("UPDATE prakruti_dispatch SET sent_to_qa_before_qc_test = 1 WHERE prakruti_dispatch.dispatch_no = %s", ((temp.dispatch_no),))
        return {}
    

    
    @api.one
    @api.multi
    def UpdateDispatchStock(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            for item in temp.grid_id:
                if item.status in ['rejected']:
                    temp.flag_count_reject = 1
                elif item.status in ['accepted','accept_under_deviation']:
                    temp.flag_count_accept = 1
                elif item.status in ['par_reject']:
                    temp.flag_count_par_reject = 1            
            cr.execute("SELECT count(id) as total_line FROM prakruti_dispatch_line WHERE main_id = %s AND send_status = 'dispatch'",((temp.id),))
            for item in cr.dictfetchall():
                total_line = item['total_line']            
            cr.execute("SELECT count(id) as avail_stock_line FROM prakruti_dispatch_line WHERE main_id = %s AND store_qty > dispatched_qty AND send_status = 'dispatch'",((temp.id),))
            for item in cr.dictfetchall():
                avail_stock_line = item['avail_stock_line']
            print 'TOTAL LINE',total_line
            print 'STOCK AVAILABILITY LINE',avail_stock_line
            if total_line == avail_stock_line:
                if temp.flag_count_accept or temp.flag_count_par_reject:
                    cr.execute("SELECT no_of_packings,packing_style,packing_details FROM prakruti_dispatch_line WHERE main_id = %s AND send_status = 'dispatch'",((temp.id),))
                    for item in cr.dictfetchall():
                        no_of_packings=item['no_of_packings']
                        packing_style=item['packing_style']
                        packing_details=item['packing_details']
                    if packing_details:
                        to_invoice= self.pool.get('prakruti.sales_invoice').create(cr,uid, {
                            'po_no':temp.po_no,
                            'dispatch_no':temp.dispatch_no,
                            'dispatch_date':temp.dispatch_date,
                            'order_no':temp.order_no.id,
                            'order_date':temp.order_date,
                            'customer_id':temp.dispatch_to.id,
                            'shipping_address':temp.shipping_id.id,
                            'billing_address':temp.billing_id.id,
                            'terms':temp.terms,
                            'inquiry_no':temp.inquiry_no,
                            'inquiry_date':temp.inquiry_date,
                            'quotation_no':temp.quotation_no,
                            'quotation_date':temp.quotation_date,
                            'shipping_id':temp.shipping_id.id,
                            'billing_id':temp.billing_id.id,
                            'product_type_id':temp.product_type_id.id,
                            'remarks':temp.remarks,
                            #'order_type':temp.order_type,
                            #'assessable_value':temp.assessable_value,
                            #'total_assessable_value':temp.total_assessable_value,
                            #'assessable_subtotal':temp.assessable_subtotal,
                            #'subtotal':temp.subtotal,
                            #'new_bed_amt':temp.new_bed_amt,
                            #'new_ed_cess_amt':temp.new_ed_cess_amt,
                            #'new_sec_cess_amt':temp.new_sec_cess_amt,
                            #'new_total_tax':temp.new_total_tax,
                            #'new_total_vat':temp.new_total_vat,
                            #'new_total_cst':temp.new_total_cst,
                            #'new_total_sbc':temp.new_total_sbc,
                            #'new_total_kkc':temp.new_total_kkc, 
                            #'untaxed_amount':temp.untaxed_amount,
                            #'transporatation_charges':temp.transporatation_charges,
                            #'final_grand_total':temp.final_grand_total,
                            'vehicle_no':temp.vehicle_no,
                            'state':'invoice',
                            'cash_amount':temp.cash_amount,
                            'cash_remarks':temp.cash_remarks,
                            'cheque_amount':temp.cheque_amount,
                            'cheque_no':temp.cheque_no,
                            'cheque_remarks':temp.cheque_remarks,
                            'draft_amount':temp.draft_amount,
                            'draft_no':temp.draft_no,
                            'draft_remarks':temp.draft_remarks,
                            'advance_payment_type':temp.advance_payment_type,
                            'any_adv_payment':temp.any_adv_payment,
                            #'type_of_order':temp.type_of_order,
                            #'type_of_product':temp.type_of_product,
                            'requested_id':temp.requested_id.id,
                            'order_id':temp.order_id.id,
                            'quotation_id':temp.quotation_id.id,
                            'dispatch_id':temp.dispatch_id.id,
                            'slip_no':temp.slip_no,
                            'reference_no':temp.reference_no,
                            'reference_date':temp.reference_date,
                            'total_no_of_products':temp.total_no_of_products,
                            'proportionate_amount_to_products':temp.proportionate_amount_to_products,
                            'freight_charges':temp.freight_charges,
                            'loading_and_packing_charges':temp.loading_and_packing_charges,
                            'insurance_charges':temp.insurance_charges,
                            'other_charges':temp.other_charges,
                            'all_additional_charges':temp.all_additional_charges,
                            'total_amount_before_tax':temp.total_amount_before_tax,
                            'total_cgst_amount':temp.total_cgst_amount,
                            'total_sgst_amount':temp.total_sgst_amount,
                            'total_igst_amount':temp.total_igst_amount,
                            'total_gst_amount':temp.total_gst_amount,
                            'total_amount_after_tax':temp.total_amount_after_tax
                                })                
                        to_gate_pass= self.pool.get('prakruti.gate_pass').create(cr,uid, {
                            'customer_id':temp.dispatch_to.id,
                            'dispatch_no':temp.dispatch_no,
                            'dispatch_date':temp.dispatch_date,
                            'vendor_id':temp.company_id.id,
                            'vehicle_no':temp.vehicle_no,
                            'transport_name':temp.transport_name,
                            'requested_id':temp.requested_id.id,
                            'order_id':temp.order_id.id,
                            'quotation_id':temp.quotation_id.id,
                            'dispatch_id':temp.dispatch_id.id,
                            'coming_from':'sales',
                            'document_type':'outward',
                            'reference_no':temp.reference_no,
                            'dc_no_outward_check':'True',
                            'e_way_bill_check':'applicable',
                            'customer_road_permit':'applicable',
                            'coa':'applicable',
                            'job_work_documents':'applicable'
                                })
                        #for tax_line in temp.tax_line_id:
                            #tax_values = self.pool.get('sales.invoice.tax.line').create(cr,uid,{
                                #'tax_type':tax_line.tax_type.id,
                                #'tax_percent':tax_line.tax_percent,
                                #'tax_amount':tax_line.tax_amount,
                                #'total_value':tax_line.total_value,
                                #'ref_id': to_invoice
                                #})
                        logistics_line = self.pool.get('prakruti.logistics_invoice_tracking').create(cr,uid, {
                            'order_no':temp.order_no.id,
                            'order_date':temp.order_date,
                            'dispatch_no':temp.dispatch_no,
                            'dispatch_date':temp.dispatch_date,
                            'customer_id':temp.dispatch_to.id,
                            'requested_id':temp.requested_id.id,
                            'order_id':temp.order_id.id,
                            'quotation_id':temp.quotation_id.id,
                            'dispatch_id':temp.dispatch_id.id,
                            'reference_no':temp.reference_no,
                            'dc_no_outward_check':'True',
                            'e_way_bill_check':'applicable',
                            'customer_road_permit':'applicable',
                            'coa':'applicable',
                            'job_work_documents':'applicable',
                            'coming_from':'sales'
                            })
                        for item_line in temp.grid_id:
                            product_line = self.pool.get('prakruti.sales_line_in_logistics').create(cr,uid, {
                                'product_id':item_line.product_id.id,
                                'uom_id':item_line.uom_id.id,
                                'quantity':item_line.accepted_qty,
                                'unit_price':item_line.unit_price,
                                #'no_of_packings': item_line.no_of_packings,
                                #'packing_style': item_line.packing_style,
                                'packing_details': item_line.packing_details,
                                #'extra_packing': item_line.extra_packing,
                                'logistics_line_id': logistics_line
                                })
                        # For Accepted Qty
                        cr.execute("SELECT count(id) as accept_line FROM prakruti_dispatch_line WHERE (status = 'accepted' or status = 'par_reject' or status = 'accept_under_deviation') AND main_id = %s AND send_status = 'dispatch'",((temp.id),))
                        for act_line in cr.dictfetchall():
                            accept_line=int(act_line['accept_line'])
                            print 'accept_lineaccept_lineaccept_line',accept_line
                        if accept_line > 0 or temp.flag_count_accept or temp.flag_count_par_reject:
                            cr.execute('''SELECT updatedispatchstock(%s)''', ((temp.id),))                        
                            cr.execute("SELECT product_id,uom_id,specification_id,description,ordered_qty,scheduled_date,scheduled_qty,dispatched_qty,unit_price,total,remarks,state,status,accepted_qty,rejected_qty,no_of_packings,packing_style,extra_packing,packing_details,hsn_code,amount,discount,discount_id,taxable_value,prakruti_dispatch_line.proportionate_amount_to_products,taxable_value_with_charges,gst_rate,cgst_id,cgst_value,cgst_amount,sgst_id,sgst_value,sgst_amount,igst_id,igst_value,igst_amount FROM prakruti_dispatch_line WHERE (status = 'accepted' or status = 'par_reject' or status = 'accept_under_deviation') AND main_id = %s AND send_status = 'dispatch'",((temp.id),))
                            for item in cr.dictfetchall():
                                grid_item= self.pool.get('prakruti.sales_invoice_line').create(cr,uid, {
                                    'product_id':item['product_id'],
                                    'uom_id':item['uom_id'],
                                    'specification_id':item['specification_id'],
                                    #'material_type':item['material_type'],
                                    'description':item['description'],
                                    'status':item['status'],
                                    'quantity':item['accepted_qty'],
                                    'unit_price': item['unit_price'],
                                    #'tarrif_id':item['tarrif_id'],
                                    #'mrp':item['mrp'],
                                    'total':item['total'],
                                    #'type_of_order':item['type_of_order'],
                                    #'type_of_product':item['type_of_product'],
                                    #'no_of_packings': item['no_of_packings'],
                                    #'extra_packing': item['extra_packing'],
                                    #'packing_style': item['packing_style'],
                                    'packing_details': item['packing_details'],
                                    #'batch_no':item['batch_no'],
                                    #GST Entry
                                    'hsn_code': item['hsn_code'],
                                    'amount':item['amount'],
                                    'discount_id':item['discount_id'],
                                    'discount':item['discount'],
                                    'taxable_value':item['taxable_value'],
                                    'proportionate_amount_to_products':item['proportionate_amount_to_products'],
                                    'taxable_value_with_charges':item['taxable_value_with_charges'],
                                    'gst_rate':item['gst_rate'],
                                    'cgst_id':item['cgst_id'],
                                    'cgst_value':item['cgst_value'],
                                    'cgst_amount':item['cgst_amount'],
                                    'sgst_id':item['sgst_id'],
                                    'sgst_value':item['sgst_value'],
                                    'sgst_amount':item['sgst_amount'],
                                    'igst_id':item['igst_id'],
                                    'igst_value':item['igst_value'],
                                    'igst_amount':item['igst_amount'],
                                    'main_id':to_invoice
                                    })
                                gate_pass_grid_item= self.pool.get('prakruti.gate_pass_line').create(cr,uid, {
                                    'product_id':item['product_id'],
                                    'uom_id':item['uom_id'],
                                    'unit_price': item['unit_price'],
                                    'quantity':item['accepted_qty'],
                                    #'no_of_packings': item['no_of_packings'],
                                    #'extra_packing': item['extra_packing'],
                                    #'pack_per_qty': item['packing_style'],
                                    'packing_details': item['packing_details'],
                                    'main_id':to_gate_pass
                                    })
                        cr.execute("UPDATE prakruti_sales_order_item AS b SET status =a.status,dispatched_qty =a.dispatched_qty,accepted_qty=a.accepted_qty,total_dispatched_qty =a.dispatched_qty + total_dispatched_qty,previous_dispatched_qty=a.dispatched_qty,remaining_dispatched_qty =a.total_scheduled_qty - a.dispatched_qty - a.total_dispatch_qty FROM (SELECT product_id,sum(dispatched_qty) as dispatched_qty,accepted_qty,total_scheduled_qty,total_dispatch_qty,prakruti_dispatch.order_no,prakruti_dispatch_line.status FROM prakruti_dispatch INNER JOIN prakruti_dispatch_line ON prakruti_dispatch.id = prakruti_dispatch_line.main_id WHERE prakruti_dispatch_line.main_id = %s AND send_status = 'dispatch' GROUP BY prakruti_dispatch.order_no,prakruti_dispatch_line.product_id,prakruti_dispatch_line.accepted_qty,prakruti_dispatch_line.total_scheduled_qty,prakruti_dispatch_line.total_dispatch_qty,prakruti_dispatch_line.status) AS a WHERE a.order_no = b.main_id AND a.product_id = b.product_id",((temp.id),))
                        if temp.qc_check_flag == 1:
                            cr.execute("SELECT count(prakruti_sales_order_item.id) as close_line FROM prakruti_sales_order_item JOIN prakruti_sales_order ON prakruti_sales_order_item.main_id = prakruti_sales_order.id JOIN prakruti_dispatch ON prakruti_dispatch.order_no = prakruti_sales_order.id WHERE total_dispatched_qty = quantity AND prakruti_dispatch.id= %s",((temp.id),))
                            for p_o_line in cr.dictfetchall():
                                close_line=p_o_line['close_line']
                            #NUMBER OF TOTAL LINE IN SALES ORDER
                            cr.execute("SELECT count(prakruti_sales_order_item.id) as total_line FROM prakruti_sales_order_item JOIN prakruti_sales_order ON prakruti_sales_order_item.main_id = prakruti_sales_order.id JOIN prakruti_dispatch ON prakruti_dispatch.order_no = prakruti_sales_order.id WHERE prakruti_dispatch.id= %s",((temp.id),))
                            for o_line in cr.dictfetchall():
                                total_line=o_line['total_line']
                            if total_line == close_line:
                                cr.execute("UPDATE prakruti_sales_order SET state = 'confirm' WHERE prakruti_sales_order.id = %s", ((temp.order_no.id),))
                                cr.execute("UPDATE prakruti_sales_quotation SET state = 'confirm' WHERE prakruti_sales_quotation.inquiry_no = %s", ((temp.inquiry_no),))
                                cr.execute("UPDATE prakruti_sales_inquiry SET state = 'confirm' WHERE prakruti_sales_inquiry.inquiry_no = %s", ((temp.inquiry_no),))
                                cr.execute("UPDATE prakruti_sales_order SET countflag = 1 WHERE prakruti_sales_order.id = %s", ((temp.order_no.id),))
                                cr.execute("UPDATE prakruti_dispatch SET state = 'invoice' WHERE prakruti_dispatch.order_no = %s", ((temp.order_no.id),))
                                cr.execute("UPDATE prakruti_production_slip SET state = 'confirm' WHERE prakruti_production_slip.inquiry_no = %s", ((temp.inquiry_no),))
                            else:
                                cr.execute("UPDATE prakruti_sales_order SET state = 'partial_order' WHERE prakruti_sales_order.id = %s", ((temp.order_no.id),))
                                cr.execute("UPDATE prakruti_production_slip SET state = 'partial_order' WHERE prakruti_production_slip.inquiry_no = %s", ((temp.inquiry_no),))
                                cr.execute("UPDATE prakruti_sales_quotation SET state = 'partial_order' WHERE prakruti_sales_quotation.inquiry_no = %s", ((temp.inquiry_no),))
                                cr.execute("UPDATE prakruti_sales_inquiry SET state = 'partial_order' WHERE prakruti_sales_inquiry.inquiry_no = %s", ((temp.inquiry_no),))
                                cr.execute("UPDATE prakruti_sales_order SET countflag = 2 WHERE prakruti_sales_order.id = %s", ((temp.order_no.id),))
                                cr.execute("UPDATE prakruti_dispatch SET state = 'partially_confirmed' WHERE prakruti_dispatch.order_no = %s", ((temp.order_no.id),)) 
                        else:
                            cr.execute("SELECT count(prakruti_sales_order_item.id) as closed_line FROM prakruti_sales_order_item JOIN prakruti_sales_order ON prakruti_sales_order_item.main_id = prakruti_sales_order.id JOIN prakruti_dispatch ON prakruti_dispatch.order_no = prakruti_sales_order.id WHERE total_dispatched_qty = quantity AND prakruti_dispatch.id= %s",((temp.id),))
                            for p_o_line in cr.dictfetchall():
                                closed_line=p_o_line['closed_line']
                            #NUMBER OF TOTAL LINE IN SALES ORDER
                            cr.execute("SELECT count(prakruti_sales_order_item.id) as total_line FROM prakruti_sales_order_item JOIN prakruti_sales_order ON prakruti_sales_order_item.main_id = prakruti_sales_order.id JOIN prakruti_dispatch ON prakruti_dispatch.order_no = prakruti_sales_order.id WHERE prakruti_dispatch.id= %s",((temp.id),))
                            for o_line in cr.dictfetchall():
                                total_line=o_line['total_line']
                            if total_line == closed_line:
                                cr.execute("UPDATE prakruti_sales_order SET state = 'without_qc_invoice' WHERE prakruti_sales_order.id = %s", ((temp.order_no.id),))
                                cr.execute("UPDATE prakruti_sales_quotation SET state = 'without_qc_invoice' WHERE prakruti_sales_quotation.inquiry_no = %s", ((temp.inquiry_no),))
                                cr.execute("UPDATE prakruti_sales_inquiry SET state = 'without_qc_invoice' WHERE prakruti_sales_inquiry.inquiry_no = %s", ((temp.inquiry_no),))
                                cr.execute("UPDATE prakruti_sales_order SET countflag = 3 wHERE prakruti_sales_order.id = %s", ((temp.order_no.id),))
                                cr.execute("UPDATE prakruti_dispatch SET state = 'without_qc_invoice' WHERE prakruti_dispatch.order_no = %s", ((temp.order_no.id),))
                                cr.execute("UPDATE prakruti_production_slip SET state = 'without_qc_invoice' WHERE prakruti_production_slip.inquiry_no = %s", ((temp.inquiry_no),))
                            else:
                                cr.execute("UPDATE prakruti_sales_order SET state = 'without_qc_partially_confirmed' WHERE prakruti_sales_order.id = %s", ((temp.order_no.id),))
                                cr.execute("UPDATE prakruti_production_slip SET state = 'without_qc_partially_confirmed' WHERE prakruti_production_slip.inquiry_no = %s", ((temp.inquiry_no),))
                                cr.execute("UPDATE prakruti_sales_quotation SET state = 'without_qc_partially_confirmed' WHERE prakruti_sales_quotation.inquiry_no = %s", ((temp.inquiry_no),))
                                cr.execute("UPDATE prakruti_sales_inquiry SET state = 'without_qc_partially_confirmed' WHERE prakruti_sales_inquiry.inquiry_no = %s", ((temp.inquiry_no),))
                                cr.execute("UPDATE prakruti_sales_order SET countflag = 4 WHERE prakruti_sales_order.id = %s", ((temp.order_no.id),))
                                cr.execute("UPDATE prakruti_dispatch SET state = 'without_qc_partially_confirmed' WHERE prakruti_dispatch.order_no = %s", ((temp.order_no.id),))
                    else:
                        raise UserError(_('Oops...! Please Enter Packing Details.'))
                            
                #NUMBER OF REJECTED LINE IN DISPATCH
                cr.execute("SELECT count(prakruti_dispatch_line.id) as reject_line FROM prakruti_dispatch_line WHERE prakruti_dispatch_line.status= 'rejected' and prakruti_dispatch_line.main_id = %s",((temp.id),))
                for o_line in cr.dictfetchall():
                    reject_line=o_line['reject_line']
                cr.execute("SELECT count(prakruti_dispatch_line.id) as total_line FROM prakruti_dispatch_line WHERE prakruti_dispatch_line.main_id = %s",((temp.id),))
                for o_line in cr.dictfetchall():
                    total_line=o_line['total_line']
                if reject_line==total_line:
                    cr.execute("UPDATE prakruti_dispatch SET reject_flag = 1 WHERE prakruti_dispatch.dispatch_no = %s", ((temp.dispatch_no),))
                    cr.execute("UPDATE prakruti_dispatch SET state='done' WHERE prakruti_dispatch.dispatch_no = %s", ((temp.dispatch_no),))
                #cr.execute("UPDATE prakruti_dispatch SET state='done' WHERE prakruti_dispatch.dispatch_no = %s", ((temp.dispatch_no),))
            else:
                raise UserError(_('Not Enough Stock'))
        return {}
    
    @api.one
    @api.multi
    def check_stock(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
                cr.execute("UPDATE prakruti_dispatch_line SET store_qty= qty_aval FROM ( SELECT product_id,(sum(qty_in) - sum(qty_out)) as qty_aval,id FROM ( SELECT stock_move.product_id, case when move_dest_id > 0 then product_qty else 0 end as qty_out, case when move_dest_id > 0 then 0 else product_qty end as qty_in,main_id,prakruti_dispatch_line.id FROM product_template INNER JOIN product_product  ON product_product.product_tmpl_id = product_template.id INNER JOIN stock_move ON stock_move.product_id = product_product.id INNER JOIN prakruti_dispatch_line ON prakruti_dispatch_line.product_id = stock_move.product_id    WHERE prakruti_dispatch_line.main_id = %s and location_dest_id = 12  AND stock_move.state = 'done')as a GROUP BY product_id,id) as b WHERE b.id = prakruti_dispatch_line.id",((temp.id),))
        return {}
    
    
    
class PrakrutiDispatchLine(models.Model):
    _name = 'prakruti.dispatch_line'
    _table = 'prakruti_dispatch_line'
    
    product_id  = fields.Many2one('product.product', string="Product Name",readonly=True)
    uom_id = fields.Many2one('product.uom',string="UOM",readonly=True)
    specification_id = fields.Many2one('product.specification.main', string = "Specification",readonly=True)
    #material_type= fields.Selection([('extraction','Extraction'),('formulation','Formulation')], string= 'Material Type', default= 'extraction',readonly=True)
    description = fields.Text(string="Description",readonly=True)
    ordered_qty = fields.Float('Ordered Qty',readonly=True,digits=(6,3))
    scheduled_date = fields.Date('Scheduled Date',readonly=True)
    scheduled_qty = fields.Float('Scheduled Qty',readonly=True,digits=(6,3))
    dispatched_qty = fields.Float('Dispatch Qty',digits=(6,3))#Should not exceeds total_scheduled_qty
    remarks = fields.Text(string="Remarks")
    main_id = fields.Many2one('prakruti.dispatch',string="Grid",readonly=True)
    state =fields.Selection([
                ('draft','Draft'),
		('sent_to_qc','Sent To Quality Check'),
		('sent_to_dispatch','Sent to Dispatch'),
		('qc_done','QC Done'),
		('invoice','Invoice'),
		], string= 'States',default= 'draft')
    status = fields.Selection([
		('accepted', 'Accepted'),
		('par_reject', 'Par. Rejected'),
		('rejected','Rejected'),
                ('accept_under_deviation','Accepted Under Deviation')
		], string= 'Status',readonly=True)
    accepted_qty = fields.Float(string= 'Accept. Qty.',digits=(6,3))
    rejected_qty = fields.Float(string= 'Reject. Qty.',digits=(6,3))
    previous_dispatch_qty = fields.Float(string= 'Prev. Disp. Qty.',digits=(6,3))
    total_dispatch_qty = fields.Float(string= 'Dispatched Qty.',digits=(6,3),readonly=1)
    quantity = fields.Float(string = "Req.Qty",digits=(6,3))
    batch_no= fields.Many2one('prakruti.batch_master',string= 'Batch No')
    #mfg_date = fields.Date(string='Mfg. Date')
    #exp_date = fields.Date(string="Expiry Date")
    #net_weight = fields.Float(string='Net Weight',digits=(6,3))
    #gross_weight = fields.Float(string="Gross Weight",digits=(6,3))
    #dc_no = fields.Char(string='DC No')
    #tarrif_id=fields.Text(string='Tarrif')
    #mrp=fields.Float(string="MRP",digits=(6,3))
    #total1= fields.Float(string='Total1',digits=(6,3)) 
    unit_price=fields.Float(string="Unit Price",digits=(6,3))
    packing_style = fields.Float('Packing Style',default=0,digits=(6,3))
    no_of_packings = fields.Float('Packing Per Qty',default=0,digits=(6,3))
    #type_of_product = fields.Selection(related='main_id.type_of_product', string="Type of Product",store=True)
    #type_of_order = fields.Selection(related='main_id.type_of_order',string="Type of Order",store=True)
    extra_packing= fields.Float(string= "(+)Extra Packing",default=0,digits=(6,3))
    #2017-05-17
    total_scheduled_qty = fields.Float(string="Total Sch Qty",readonly=True,digits=(6,3),default=0)
    remaining_dispatched_qty = fields.Float(string="Remaining Dispatch Qty",readonly=True,digits=(6,3),default=0)
    store_qty = fields.Float(string="Store Qty",digits=(6,3),readonly=1)
    packing_details = fields.Char('Packing Details')
    send_status = fields.Selection([('dispatch','Dispatch'),('hold','Hold')],default='dispatch',string= 'Status')
    total= fields.Float(string='Total')        
    #GST ENTRY ADDED HERE
    hsn_code = fields.Char(string='HSN/SAC')
    amount = fields.Float(string= 'Amount')
    discount_id = fields.Many2one('account.other.tax',string= 'Discount(%)',domain=[('select_type', '=', 'discount')])
    discount = fields.Float(related='discount_id.per_amount',string= 'Discount(%)',default=0,store=1)
    taxable_value = fields.Float(string= 'Taxable Value')
    proportionate_amount_to_products = fields.Float(string="Proportionate Amount to Products")
    taxable_value_with_charges = fields.Float(string= 'Taxable Value With Charges')
    gst_rate = fields.Float(string= 'GST Rate')    
    cgst_id = fields.Many2one('account.other.tax',string= 'CGST Rate',domain=[('select_type', '=', 'cgst')])
    cgst_value = fields.Float(string= 'CGST Value',default=0)
    cgst_amount = fields.Float(string= 'CGST Amount')    
    sgst_id = fields.Many2one('account.other.tax',string= 'SGST Rate',domain=[('select_type', '=', 'sgst')])
    sgst_value = fields.Float(string= 'SGST Value',default=0)
    sgst_amount = fields.Float(string= 'SGST Amount')    
    igst_id = fields.Many2one('account.other.tax',string= 'IGST Rate',domain=[('select_type', '=', 'igst')])
    igst_value = fields.Float(string= 'IGST Value',default=0)
    igst_amount = fields.Float(string= 'IGST Amount')
    
    def onchange_product(self, cr, uid, ids, product_id, context=None):
        line3 = 0.0
        qty_aval = 0.0
        cr.execute("""SELECT qty_aval FROM (SELECT uom, product_id, name, qty_in, qty_out, qty_in - qty_out as qty_aval FROM ( SELECT uom,product_id, name, sum(qty_out) as qty_out, sum(qty_in) as qty_in FROM ( SELECT product_uom.name as uom,stock_move.product_id, product_product.name_template as name, picking_id, case when move_dest_id > 0 then product_qty else 0 end as qty_out, case when move_dest_id > 0 then 0 else product_qty end as qty_in FROM product_uom INNER JOIN product_template ON product_uom.id = product_template.uom_id INNER JOIN product_product ON product_product.product_tmpl_id = product_template.id INNER JOIN stock_move ON stock_move.product_id = product_product.id WHERE location_dest_id = 12  AND stock_move.state = 'done' AND product_product.id = CAST(%s as integer)) as a group by product_id, name, uom ) as a ) AS b ORDER BY product_id""", ((product_id),))
        for line in cr.dictfetchall():
            line3 = line['qty_aval']
        print 'AVAILABLE STOCK',line3
        return {'value' :{
                          'store_qty': line3 or 0.0
                          }}
    
    
    def _check_dispatched_qty(self, cr, uid, ids):
        lines = self.browse(cr, uid, ids)
        for line in lines:
            if line.dispatched_qty > line.total_scheduled_qty:
                return False
            return True
        
    def _check_accepted_qty(self, cr, uid, ids):
        lines = self.browse(cr, uid, ids)
        for line in lines:
            if line.accepted_qty > line.total_scheduled_qty:
                return False
            return True
        
    _constraints = [
        (_check_dispatched_qty, 'Dispatched quantity cannot be greater than Scheduled Qty !', ['dispatched_qty']),
        (_check_accepted_qty, 'Accepted quantity cannot be greater than Scheduled Qty !', ['accepted_qty'])
    ]
    
#class PrakrutiSalesDispatchTaxLine(models.Model):
    #_name = 'sales.dispatch.tax.line'
    #_table = 'sales_dispatch_tax_line'
    #_description = 'Prakruti Sales Dispatch Tax Line'
    #_order= "id desc"
    
    #ref_id = fields.Many2one('prakruti.dispatch',string="Reference Id")
    #tax_type = fields.Many2one('account.other.tax', string='Taxes', domain=[('active', '=', True)])
    #tax_percent = fields.Float(related='tax_type.per_amount',string="Tax %",store=1,readonly=1,digits=(6,3))
    #tax_amount = fields.Float(related='tax_type.amount',string="Tax Amt.",store=1,readonly=1,digits=(6,3))
    #total_value = fields.Float(string="Total Value",readonly=1,digits=(6,3))