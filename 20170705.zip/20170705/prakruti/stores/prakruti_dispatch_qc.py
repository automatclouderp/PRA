# -*- coding: utf-8 -*-
from openerp import models, fields, api,_
from openerp.tools import amount_to_text
from openerp.tools.amount_to_text import amount_to_text_in 
from openerp.tools.amount_to_text import amount_to_text_in_without_word_rupees 
import openerp
from datetime import date, datetime
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from datetime import timedelta
from openerp.osv import osv,fields
from openerp import models, fields, api, _
from openerp.tools.translate import _
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
from lxml import etree
import cgi
import logging
import lxml.html
import lxml.html.clean as clean
import openerp.pooler as pooler
import random
import re
import socket
import threading
import time
from openerp.tools import image_resize_image_big

class PrakrutiQualityCheck(models.Model):
    _name =  'prakruti.quality_check'
    _table = 'prakruti_quality_check'
    _description = 'Dispatched item Quality Check'
    _order="id desc"
    _rec_name= "dispatch_no" 
    
    checked_by = fields.Many2one('res.users',string = 'Checked By')
    qc_date = fields.Date('QC Date', default=fields.Date.today)
    dispatch_no = fields.Char('Dispatch No', readonly=True)
    dispatch_date = fields.Date('Dispatch Date', readonly=True)
    order_no = fields.Many2one('prakruti.sales_order', string='Order No',readonly=True)
    order_date = fields.Date('Order Date', readonly=True)
    dispatch_to = fields.Many2one('res.partner', string='Dispatch To', readonly=True)
    state =fields.Selection([
		('draft','Draft'),
		('validate','Validated'),
		('qc_done','QC Done'),
		('qc_ha','QC HA')
		],default= 'draft', string= 'Status', readonly=True)  
    store_incharge = fields.Many2one('res.users', string="Store Incharge")
    quality_incharge = fields.Many2one('res.users', string="Quality Incharge")
    check_line = fields.One2many('prakruti.quality_check_line','check_line_id')
    quotation_no= fields.Char(string='Quotation No' ,readonly=True)
    quotation_date = fields.Date(string='Quotation Date' ,readonly=True)
    inquiry_date= fields.Date('Inquiry Date',readonly=True)
    inquiry_no = fields.Char(' Inquiry No', readonly=True)
    customer_id = fields.Many2one('res.partner',string="Customer")
    shipping_id = fields.Many2one('res.partner',string='Shipping Address')
    billing_id = fields.Many2one('res.partner',string='Billing Address')
    remarks = fields.Text(string="Remarks")
    terms =fields.Text('Terms and conditions')
    #order_type = fields.Selection([('with_tarrif','Sales'),('without_tarrif','PS')], string="Order Type")
    #assessable_value=fields.Float(string='Assessable Value(%)',digits=(6,3))
    #total_assessable_value= fields.Float(string='Total Assesable value',digits=(6,3))
    #assessable_subtotal=fields.Float(string='Assesable  Total',digits=(6,3))
    #subtotal= fields.Float(string='Sub Total',digits=(6,3))
    
    #tax_line_id = fields.One2many('sales.dispatchqc.tax.line','ref_id',string='All Taxes')
    #new_bed_amt = fields.Float(string="New BED Total",readonly=1,digits=(6,3))
    #new_ed_cess_amt = fields.Float(string="New Ed Cess Total",readonly=1,digits=(6,3))
    #new_sec_cess_amt = fields.Float(string="New Sec Cess Total",readonly=1,digits=(6,3))
    #new_total_tax = fields.Float(string="New Total Tax",readonly=1,digits=(6,3))
    #new_total_vat = fields.Float(string="New Total Vat",readonly=1,digits=(6,3))
    #new_total_cst = fields.Float(string="New Total Cst",readonly=1,digits=(6,3))
    #new_total_sbc = fields.Float(string="New Swachh Bharat",readonly=1,digits=(6,3))
    #new_total_kkc = fields.Float(string="New Krishi Kalayan",readonly=1,digits=(6,3))
    #untaxed_amount = fields.Float(string="Untaxed Amount",digits=(6,3))
    #transporatation_charges=fields.Float(string='Transportation Charges',digits=(6,3))
    #final_grand_total = fields.Float(string=" Grand Total",digits=(6,3))
    flag_rejected_count = fields.Integer('Flag', default=1)
    dispatch_id =fields.Many2one('res.users','Dispatch By') 
    requested_id =fields.Many2one('res.users','Requested By')
    quotation_id =fields.Many2one('res.users','Quotation By')
    order_id =fields.Many2one('res.users','Order By')
    reference_no= fields.Char(string='Ref No')  
    product_id = fields.Many2one('product.product', related='check_line.product_id', string='Product Name') 
    
    _defaults = {
        'checked_by': lambda s, cr, uid, c:uid,
        'store_incharge': lambda s, cr, uid, c:uid,
        'quality_incharge': lambda s, cr, uid, c:uid
        }
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['draft','qc_done','qc_ha']:
                raise UserError(_('Can\'t Delete...'))
        return super(PrakrutiQualityCheck, self).unlink()
    
    @api.one
    @api.multi 
    def validate(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        count_value= 0
        accept_value = 0
        for temp in self:
            cr.execute(''' SELECT count(id) as status_marked FROM prakruti_quality_check_line WHERE (status = 'accepted' OR status = 'rejected') AND check_line_id = %s''',((temp.id),))
            for no_of_line in cr.dictfetchall():
                status_marked = int(no_of_line['status_marked'])
            if status_marked == len(temp.check_line):
                cr.execute("UPDATE prakruti_quality_check SET state = 'validate' WHERE id=%s",((temp.id),))
                cr.execute("SELECT count(id) as count_value FROM prakruti_quality_check_line WHERE status = 'rejected' AND check_line_id = %s",((temp.id),))
                for item in cr.dictfetchall():
                    count_value=int(item['count_value'])
                    print '------------------------1111111111111111111111111111-------------------',count_value
                    if count_value >= accept_value:
                        cr.execute("update prakruti_quality_check set flag_rejected_count =2 where id=%s",((temp.id),))
                cr.execute("SELECT count(id) as accept_value FROM prakruti_quality_check_line WHERE status = 'accepted' AND check_line_id = %s",((temp.id),))
                for item in cr.dictfetchall():
                    accept_value=int(item['accept_value'])    
                    print '--------------------------------00000000000000000000000000000000-------------------------------------------',accept_value
                    if count_value == accept_value:
                        print '------------------------------updateeeeeeeeeeeeee---------------------------------------------',accept_value
                        cr.execute("UPDATE prakruti_quality_check set flag_rejected_count =2 where id=%s",((temp.id),))
                    elif count_value == 0:
                        print '------------------------------count_value---------------------------------------------',count_value
                        cr.execute("UPDATE prakruti_quality_check set flag_rejected_count =4 where id=%s",((temp.id),))
                        cr.execute("UPDATE prakruti_dispatch set flag_rejected_count =4 where dispatch_no=%s",((temp.dispatch_no),))
            else:
                raise UserError(_('Please Enter Accepted Qty\nPlease Check Status'))
        return {}
    
    @api.one
    @api.multi 
    def update_to_dispatch(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            if temp.quality_incharge and temp.checked_by:
                cr.execute("UPDATE prakruti_dispatch set state ='qc_done',qc_check_flag=1 where dispatch_no=%s",((temp.dispatch_no),))
                cr.execute("UPDATE prakruti_process_quality_control_qa SET qc_check_flag=1 WHERE dispatch_no=%s",((temp.dispatch_no),))
                cr.execute("UPDATE prakruti_dispatch_line AS b SET accepted_qty =a.accepted_qty,rejected_qty=a.rejected_qty,state = a.state,status = a.status,dispatched_qty = a.accepted_qty FROM(SELECT check_line_id,dispatch_line_grid_id,product_id,accepted_qty,rejected_qty,state,status,scheduled_qty FROM prakruti_quality_check_line WHERE check_line_id= %s ) AS a WHERE a.dispatch_line_grid_id = b.id AND a.product_id = b.product_id",((temp.id),))
                cr.execute("UPDATE prakruti_quality_check SET state = 'qc_done' WHERE prakruti_quality_check.dispatch_no = %s", ((temp.dispatch_no),))
            else:
                raise UserError(_('Please Select the Quality Incharge and Checked By Person'))
        return {}
    
    @api.one
    @api.multi 
    def quality_to_ha(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            if temp.quality_incharge and temp.checked_by:
                cr.execute("UPDATE prakruti_quality_check SET state ='qc_ha' WHERE id=%s",((temp.id),))
                quality_ha = self.pool.get('prakruti.quality_check_ha').create(cr,uid, {
                        'qc_date':temp.qc_date,
                        'dispatch_no':temp.dispatch_no,
                        'dispatch_date':temp.dispatch_date,
                        'checked_by':temp.checked_by.id,
                        'order_no':temp.order_no.id,
                        'order_date':temp.order_date,
                        'dispatch_to':temp.dispatch_to.id,
                        'store_incharge':temp.store_incharge.id,
                        'quality_incharge':temp.quality_incharge.id,
                        })
                for item in temp.check_line:
                    grid_values = self.pool.get('prakruti.quality_check_line_ha').create(cr,uid, {
                        'product_id': item.product_id.id,
                        'uom_id': item.uom_id.id,
                        'specification_id':item.specification_id.id,
                        'description': item.description,
                        'ordered_qty': item.ordered_qty,
                        'dispatched_qty': item.dispatched_qty,
                        'accepted_qty':item.accepted_qty,
                        'rejected_qty':item.rejected_qty,      
                        'status': item.status,     
                        'test_result': item.test_result,
                        'remarks':item.remarks,
                        'scheduled_qty':item.scheduled_qty,
                        'dispatch_line_grid_id':item.dispatch_line_grid_id,
                        'qc_check_line_id': quality_ha
                        })
            else:
                raise UserError(_('Please Select the Quality Incharge and Checked By Person'))
            cr.execute("UPDATE prakruti_quality_check SET flag_rejected_count =3 WHERE id=%s",((temp.id),))
        return {}
    
class PrakrutiQualityControlLine(models.Model):
    _name = 'prakruti.quality_check_line'
    _table = 'prakruti_quality_check_line'
    
    check_line_id = fields.Many2one('prakruti.quality_check', ondelete='cascade')
    product_id = fields.Many2one('product.product',string='Product Name')
    uom_id = fields.Many2one('product.uom',string='UOM')
    description = fields.Text(string='Description')
    specification_id = fields.Many2one('product.specification.main', string = "Specification")
    ar_no = fields.Many2one('prakruti.specification.ar.no', string = "AR No.")
    ordered_qty = fields.Float('Ordered Qty',digits=(6,3))
    dispatched_qty = fields.Float('Dispatched Qty',digits=(6,3))
    remarks = fields.Text(string="Remarks")
    status = fields.Selection([
		('accepted', 'Accepted'),
		('par_reject', 'Par. Rejected'),
                ('accept_under_deviation','Accepted Under Deviation'),
		('rejected','Rejected')
		],default= 'rejected', string= 'Status')
    state =fields.Selection([
		('draft','Draft'),
		('qc_done','QC Done'),
		('qc_ha','QC HA')
		],default='qc_done', string= 'State', readonly=True)
    test_result = fields.Text('Test Result')
    accepted_qty = fields.Float(string= 'Accept. Qty.',digits=(6,3))
    rejected_qty = fields.Float(string= 'Reject. Qty.', store=True , compute='_compute_rejected_qty',digits=(6,3))
    scheduled_qty = fields.Float('Scheduled Qty',digits=(6,3))
    dispatch_line_grid_id = fields.Integer(string= 'Dispatch Line Grid ID')
    quantity = fields.Float(string = "Req.Qty",digits=(6,3))
    batch_no= fields.Many2one('prakruti.batch_master',string= 'Batch No')
    #batch_no= fields.Text(string= 'Batch No')
    #mfg_date = fields.Date(string='Mfg. Date')
    #exp_date = fields.Date(string="Expiry Date")
    #tarrif_id=fields.Text(string='Tarrif')
    #mrp=fields.Float(string="MRP",digits=(6,3))
    total= fields.Float(string='Total',digits=(6,3)) 
    #total1= fields.Float(string='Total1',digits=(6,3)) 
    unit_price=fields.Float(string="Unit Price",digits=(6,3))
    
    @api.one
    @api.constrains('rejected_qty')
    def _check_rejected_qty(self):
        if self.rejected_qty < 0:
            raise ValidationError(
                "Rejected Qty. !!! Can't be Negative") 
    
    @api.depends('dispatched_qty','accepted_qty')
    def _compute_rejected_qty(self):
        print 'automatautomat-----------------1'
        for order in self:
            print 'automatautomat-----------------2'
            rejected_qty = 0.0            
            order.update({                
                'rejected_qty': order.dispatched_qty - order.accepted_qty 
            })
    @api.onchange('status')
    def onchange_status(self):
        if self.status == 'accepted':
            self.accepted_qty = self.dispatched_qty
            self.test_result = 'TESTED OK'
        elif self.status == 'rejected':
            self.rejected_qty = self.dispatched_qty
            self.accepted_qty = 0.0
            self.test_result = 'TESTED OK'
        elif self.status == 'par_reject':
            self.accepted_qty = self.dispatched_qty
            self.rejected_qty = 0.0
            self.test_result = 'PARTIAL'
        elif self.status == 'accept_under_deviation':
            self.accepted_qty = self.dispatched_qty
            self.rejected_qty = 0.0
            self.test_result = 'Accept Under Deviation'
        else:
            self.accepted_qty = 0.0
            self.rejected_qty = 0.0
            self.test_result = 'NO SELECTION'    
    
#class PrakrutiSalesDispatchQCTaxLine(models.Model):
    #_name = 'sales.dispatchqc.tax.line'
    #_table = 'sales_dispatchqc_tax_line'
    #_description = 'Prakruti DispatchQC Tax Line'
    #_order= "id desc"
    
    #ref_id = fields.Many2one('prakruti.quality_check',string="Reference Id")
    #tax_type = fields.Many2one('account.other.tax', string='Taxes', domain=[('active', '=', True)])
    #tax_percent = fields.Float(related='tax_type.per_amount',string="Tax %",store=1,readonly=1,digits=(6,3))
    #tax_amount = fields.Float(related='tax_type.amount',string="Tax Amt.",store=1,readonly=1,digits=(6,3))
    #total_value = fields.Float(string="Total Value",readonly=1,digits=(6,3))