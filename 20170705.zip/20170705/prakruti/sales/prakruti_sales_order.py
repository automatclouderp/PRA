# -*- coding: utf-8 -*-
import time
from openerp.tools import image_resize_image_big
from openerp.exceptions import ValidationError
from openerp import api, fields, models, _
import openerp
from datetime import date, datetime
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from datetime import timedelta
from openerp.osv import osv,fields
from openerp import models, fields, api, _
from openerp.tools.translate import _
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
from lxml import etree
import cgi
import logging
import lxml.html
import lxml.html.clean as clean
import openerp.pooler as pooler
import random
import re
import socket
import threading
import time
from openerp.tools import image_resize_image_big
from openerp.tools import amount_to_text
from openerp.tools.amount_to_text import amount_to_text_in 
from openerp.tools.amount_to_text import amount_to_text_in_without_word_rupees 

class PrakrutiSalesOrder(models.Model):
    _name = 'prakruti.sales_order'
    _table = "prakruti_sales_order"
    _description = 'Prakruti Sales Order Information'
    _order="id desc"
    _rec_name= "order_no"
    
    
    @api.one
    @api.multi
    def _get_auto(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        for temp in self:
            cr.execute('''select cast(extract (month from order_date) as integer) as month ,cast(extract (year from order_date) as integer) as year ,id from prakruti_sales_order where id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
                if month_value<=3:
                    year_value=year_value-1
                else:
                    year_value=year_value
                next_year=year_value+1
                dispay_year=str(next_year)[-2:]
                display_present_year=str(year_value)[-2:]
                        
                cr.execute('''select autogenerate_sales_order(%s)''', ((temp.id),)  ) 
                result = cr.dictfetchall()
                parent_invoice_id = 0
                for value in result: parent_invoice_id = value['autogenerate_sales_order'];
                auto_gen = int(parent_invoice_id)
                if len(str(auto_gen)) < 2:
                    auto_gen = '000'+ str(auto_gen)
                elif len(str(auto_gen)) < 3:
                    auto_gen = '00' + str(auto_gen)
                elif len(str(auto_gen)) == 3:
                    auto_gen = '0'+str(auto_gen)
                else:
                    auto_gen = str(auto_gen)
                for record in self :
                    if temp.product_type_id.group_code:
                        x[record.id] = 'SO\\'+temp.product_type_id.group_code+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                    else:                        
                        x[record.id] = 'SO\\'+'MISC'+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                    cr.execute('''UPDATE prakruti_sales_order SET order_no =%s WHERE id=%s ''', ((x[record.id]),(temp.id),)  )
            return x
    
    countflag = fields.Integer('Flag Line is There',default= 0)
    order_no = fields.Char(string='Order No', readonly=True)
    order_date = fields.Date(string='Order Date', default= fields.Date.today, required=True)
    quotation_no= fields.Char(string='Quotation No' ,readonly=True)
    quotation_date = fields.Date(string='Quotation Date' ,readonly=True)
    inquiry_date= fields.Date('Inquiry Date',readonly=True)
    inquiry_no = fields.Char(' Inquiry No', readonly=True)
    customer_id = fields.Many2one('res.partner',string="Customer")
    product_type_id=fields.Many2one('product.group',string= 'Product Type')
    shipping_id = fields.Many2one('res.partner',string='Shipping Address')
    billing_id = fields.Many2one('res.partner',string='Billing Address')
    remarks = fields.Text(string="Remarks")
    #untaxed_amount = fields.Float(string="Untaxed Amount",store=True,readonly=True,digits=(6,3))
    #transporatation_charges=fields.Float(string='Transportation Charges',digits=(6,3))
    #final_grand_total = fields.Float(string=" Grand Total",digits=(6,3))
    ord_no = fields.Char('Order Number', compute='_get_auto')
    auto_no = fields.Integer('Auto')
    req_no_control_id1 = fields.Integer('Auto Generating id',default= 0)
    grid_id = fields.One2many('prakruti.sales_order_item', 'main_id',string='Grid')
    #tax_line_id = fields.One2many('sales.order.tax.line','ref_id',string='All Taxes')
    terms =fields.Text('Terms and conditions')
    #order_type = fields.Selection([('with_tarrif','Sales'),('without_tarrif','PS')], string="Order Type")
    #assessable_value=fields.Float(string='Assessable Value(%)',digits=(6,3))
    #total_assessable_value= fields.Float(string='Total Assesable value',readonly=True,digits=(6,3))
    #assessable_subtotal=fields.Float(string='Assessable  Total',store=True,readonly=True,digits=(6,3))
    #subtotal= fields.Float(string='Sub Total',store=True,readonly=True,digits=(6,3))
    #new_bed_amt = fields.Float(string="BED Total",readonly=1,digits=(6,3))
    #new_ed_cess_amt = fields.Float(string="Ed Cess Total",readonly=1,digits=(6,3))
    #new_sec_cess_amt = fields.Float(string="Sec Cess Total",readonly=1,digits=(6,3))
    #new_total_tax = fields.Float(string="Total Tax",readonly=1,digits=(6,3))
    #new_total_vat = fields.Float(string="Total Vat",readonly=1,digits=(6,3))
    #new_total_cst = fields.Float(string="Total Cst",readonly=1,digits=(6,3))
    #new_total_sbc = fields.Float(string="Swachh Bharat",readonly=1,digits=(6,3))
    #new_total_kkc = fields.Float(string="Krishi Kalayan",readonly=1,digits=(6,3))
    balance_line = fields.Integer('Any Balance Line',default=0,readonly=1)    
    cash_amount = fields.Float(string="Amount",digits=(6,3),default=0)
    cash_remarks = fields.Text(string="Remarks")    
    cheque_amount = fields.Float(string="Amount",digits=(6,3),default=0)
    cheque_no = fields.Integer(string="Cheque No.")
    cheque_remarks = fields.Text(string="Remarks")    
    draft_amount = fields.Float(string="Amount",digits=(6,3),default=0)
    draft_no = fields.Integer(string="Draft No.")
    draft_remarks = fields.Text(string="Remarks")
    #calculation_flag = fields.Integer(string="Is Calculation Clicked",default=0)
    amount_flag = fields.Integer(string="Is Payment Done",default=0)        
    slip_no= fields.Char(string='Slip No.')
    po_no= fields.Char(string='P.O No')    
    requested_id =fields.Many2one('res.users','Requested By',readonly=True)
    quotation_id =fields.Many2one('res.users','Quotation By',readonly=True)
    order_id =fields.Many2one('res.users','Order By')
    reference_no= fields.Char(string='Ref No')
    reference_date= fields.Date(string='Ref Date')
    revise_flag= fields.Integer(string='Revised No.',default=0) 
    revise_comments= fields.Text(string='Revised Comments') 
    product_id = fields.Many2one('product.product', related='grid_id.product_id', string='Product Name')    
    state =fields.Selection([
        ('order','Order'),
        ('slip_request','Production Slip Issued'),
        ('partially_confirmed','Production Slip Partially Confirmed'),
        ('production_slip_confirmed','Production Slip Confirmed'),
        ('partial_order','Partially Dispatched/Confirmed/Invoiced'),
        ('confirm','Dispatched/Confirmed/Invoiced'),
        ('without_qc_partially_confirmed','With out QC Partially Dispatched/Confirmed/Invoiced'),
        ('without_qc_invoice','With out QC Dispatched/Confirmed/Invoiced'),
        ('rejected','Rejected')
        ],default= 'order', string= 'Status')
    #type_of_product = fields.Selection([
        #('extraction','Extraction'),
        #('formulation','Formulation')], default='extraction', string="Type of Product")
    #type_of_order = fields.Selection([
        #('sales','SALES'),
        #('ps','PHYSICIAN SAMPLE')
        #],default='sales',string="Type of Order")
    any_adv_payment =fields.Selection([
        ('no', 'No'),
        ('yes','Yes')
        ],default='no' ,string= 'Any Advance Payment')
    advance_payment_type =fields.Selection([
        ('cash', 'CASH'),
        ('cheque','CHEQUE'),
        ('demand_draft','DEMAND DRAFT')
        ], string= 'Done By')
    company_id = fields.Many2one('res.company',string="Company")
    revised_status = fields.Selection([('revised','Revised')],string= 'Revised Status')
    #GST ENTRY
    total_no_of_products = fields.Integer(string="Total No of Products",readonly=1)
    proportionate_amount_to_products = fields.Float(string="Proportionate Amount to Products")
    freight_charges = fields.Float(string="Freight Charges")
    loading_and_packing_charges = fields.Float(string="Loading and Packing Charges")
    insurance_charges = fields.Float(string="Insurance Charges")
    other_charges =  fields.Float(string="Other Charges")
    all_additional_charges = fields.Float(string="All Additional Charges",readonly=1)#SUM OF all charges like freight_charges loading_and_packing_charges insurance_charges other_charges   
    total_amount_before_tax = fields.Float(string="Untaxed Amount",readonly=1)#SUM OF Taxable value after adding other charges
    total_cgst_amount = fields.Float(string="CGST Amount",readonly=1)
    total_sgst_amount = fields.Float(string="SGST Amount",readonly=1)
    total_igst_amount = fields.Float(string="IGST Amount",readonly=1)
    total_gst_amount = fields.Float(string="Total GST",readonly=1)  
    total_amount_after_tax = fields.Float(string="Total",readonly=1)#SUM OF Subtotal of the grid
    grand_total= fields.Float(string='Grand Total',digits=(6,3),readonly=1)
    grand_total_in_words= fields.Text(compute= '_get_total_in_words',string='Total in words')
    
    @api.depends('total_amount_after_tax','grand_total')
    def _get_total_in_words(self):
        for order in self:
            total_amount_after_tax = val1 = grand_total = 0.0
            val1_in_words = ""
            for line in order.grid_id:
                if line.status == 'open':
                    val1 = order.grand_total
                    val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
                    order.update({                    
                        'grand_total_in_words': val1_in_words.upper()
                        })
    
    
    #@api.depends('grid_id.total')
    #def _compute_total_amount_after_tax(self):
        #for order in self:
            #total_amount_after_tax = line_amount =0
            #for line in order.grid_id:
                #line_amount += line.total
                #order.update({
                    #'total_amount_after_tax': line_amount
                    #})
    
    
    #@api.depends('total_cgst_amount','total_sgst_amount','total_igst_amount')
    #def _compute_total_gst_amount(self):
        #for order in self:
            #total_gst_amount = 0
            #order.update({
                #'total_gst_amount': order.total_cgst_amount + order.total_sgst_amount + order.total_igst_amount
                #})
    
    
    #@api.depends('grid_id.igst_amount')
    #def _compute_total_igst_amount(self):
        #for order in self:
            #total_igst_amount = t_igst_amount =0
            #for line in order.grid_id:
                #t_igst_amount += line.igst_amount
                #order.update({
                    #'total_igst_amount': t_igst_amount
                    #})
    
    
    #@api.depends('grid_id.sgst_amount')
    #def _compute_total_sgst_amount(self):
        #for order in self:
            #total_sgst_amount = t_sgst_amount =0
            #for line in order.grid_id:
                #t_sgst_amount += line.sgst_amount
                #order.update({
                    #'total_sgst_amount': t_sgst_amount
                    #})
    
    
    #@api.depends('grid_id.cgst_amount')
    #def _compute_total_cgst_amount(self):
        #for order in self:
            #total_cgst_amount = t_cgst_amount = 0
            #for line in order.grid_id:
                #t_cgst_amount += line.cgst_amount
                #order.update({
                    #'total_cgst_amount': t_cgst_amount
                    #})
    
    
    #@api.depends('grid_id.taxable_value_with_charges')
    #def _compute_total_amount_before_tax(self):
        #for order in self:
            #total_amount_before_tax = taxed_value_with_charges =0
            #for line in order.grid_id:
                #taxed_value_with_charges += line.taxable_value_with_charges
                #order.update({
                    #'total_amount_before_tax': taxed_value_with_charges
                    #})
    
    
    #@api.depends('grid_id.quantity','grid_id.unit_price')
    #def _compute_total_no_of_products(self):
        #for order in self:
            #total_no_of_products = 0
            #order.update({
                #'total_no_of_products': len(order.grid_id)
                #})
    
    #@api.depends('freight_charges', 'loading_and_packing_charges','insurance_charges', 'other_charges')
    #def _compute_all_additional_charges(self):
        #for order in self:
            #all_additional_charges = 0.0            
            #order.update({                
                #'all_additional_charges': order.freight_charges + order.loading_and_packing_charges + order.insurance_charges + order.other_charges
            #})
    
    #@api.depends('freight_charges', 'loading_and_packing_charges','insurance_charges', 'other_charges','total_no_of_products')
    #def _compute_proportionate_amount_to_products(self):
        #for order in self:
            #proportionate_amount_to_products = 0.0            
            #order.update({                
                #'proportionate_amount_to_products': order.all_additional_charges/len(order.grid_id)
            #})
    
    
    #@api.one
    #@api.constrains('final_grand_total')
    #def _check_final_grand_total(self):
        #if self.final_grand_total < 0:
            #raise ValidationError(
                #"Please Check the Advance Payment Details\n Since Grand Total is going Negative")
    
    @api.one
    @api.constrains('draft_amount')
    def _check_draft_amount(self):
        if self.draft_amount < 0:
            raise ValidationError(
                "Draft Amount !!! Can't be Negative") 
    
    @api.one
    @api.constrains('cash_amount')
    def _check_cash_amount(self):
        if self.cash_amount < 0:
            raise ValidationError(
                "Cash Amount !!! Can't be Negative") 
    
    @api.one
    @api.constrains('cheque_amount')
    def _check_cheque_amount(self):
        if self.cheque_amount < 0:
            raise ValidationError(
                "Check Amount !!! Can't be Negative")  
    
    @api.multi
    def unlink(self):
        raise UserError(_('Can\'t Delete'))
        return super(PrakrutiSalesOrder, self).unlink() 
    
    #@api.onchange('tax_line_id')
    #def onchange_tax_line_id(self):
        #self.calculation_flag=0
    
    #@api.one
    #@api.constrains('transporatation_charges')
    #def _check_transporatation_charges(self):
        #if self.transporatation_charges < 0:
            #raise ValidationError(
                #"Transportation Charges !!! Can't be Negative")   
        
    @api.one
    @api.constrains('order_date')
    def _check_order_date(self):
        if self.order_date < fields.Date.today():
            raise ValidationError(
                "Order Date can't be less than current date!")
    
    
        
    #@api.model
    #def _default_company(self):
        #return self.env['res.company']._company_default_get('res.partner')
    
   
    
    _defaults = {
        'quotation_no':'Direct Order',
        'order_no':'New',
        'order_id': lambda s, cr, uid, c:uid,
        #'company_id': _default_company, 
        }
    
    @api.onchange('any_adv_payment')
    def onchange_any_adv_payment(self):
        if self.any_adv_payment == 'no':
            self.advance_payment_type = None
    
    @api.onchange('advance_payment_type')
    def onchange_advance_payment_type(self):
        if self.advance_payment_type == 'cash':
            self.cheque_amount = 0
            self.cheque_no = 0
            self.cheque_remarks = ''
            self.draft_amount = 0
            self.draft_no = 0
            self.draft_remarks = ''
        if self.advance_payment_type == 'cheque':
            self.cash_amount = 0
            self.cash_remarks = ''
            self.draft_amount = 0
            self.draft_no = 0
            self.draft_remarks = ''
        if self.advance_payment_type == 'demand_draft':
            self.cash_amount = 0
            self.cash_remarks = ''
            self.cheque_amount = 0
            self.cheque_no = 0
            self.cheque_remarks = ''
        else:
            self.cash_amount = 0
            self.cash_remarks = ''
            self.cheque_amount = 0
            self.cheque_no = 0
            self.cheque_remarks = ''
            self.draft_amount = 0
            self.draft_no = 0
            self.draft_remarks = ''
        
        
    @api.one
    @api.multi 
    def action_reject(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            if temp.remarks:
                cr.execute("UPDATE  prakruti_sales_order SET state = 'rejected' WHERE prakruti_sales_order.id = %s and customer_id = %s",((temp.id),(temp.customer_id.id),))
                cr.execute("UPDATE  prakruti_sales_inquiry SET state = 'rejected' WHERE prakruti_sales_inquiry.inquiry_no = %s and customer_id = %s ",((temp.inquiry_no),(temp.customer_id.id),))
                cr.execute("UPDATE  prakruti_sales_quotation SET state = 'rejected' WHERE prakruti_sales_quotation.inquiry_no = %s and customer_id = %s",((temp.inquiry_no),(temp.customer_id.id),))
            else:
                raise UserError(_('Please Enter Remarks...'))
        return {}
    
    @api.one
    @api.multi 
    def order_to_slip(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            if temp.any_adv_payment == 'yes':
                if not(temp.cash_amount or temp.draft_amount or temp.cheque_amount):
                    raise UserError (_('Please Enter Adv. Payment Details'))
            if temp.revise_flag == 0:
                print '9999999999999999999999999999999999999'
                cr.execute("SELECT count(id) as no_of_open_line FROM prakruti_sales_order_item WHERE total_scheduled_qty != quantity AND main_id = %s",((temp.id),))
                for line in cr.dictfetchall():
                    no_of_open_line=line['no_of_open_line']
                cr.execute("SELECT count(id) as no_of_req_date_entry_line FROM prakruti_sales_order_item WHERE total_scheduled_qty != quantity AND cast(extract (month from req_date) as integer) > 0 AND main_id = %s",((temp.id),))
                for line in cr.dictfetchall():
                    no_of_req_date_entry_line=line['no_of_req_date_entry_line']
                if no_of_open_line == no_of_req_date_entry_line:
                    for item in temp.grid_id:
                        if item.total_scheduled_qty != item.quantity:
                            temp.balance_line = 1
                        elif item.status in ['wait']:
                            temp.balance_line = 1
                        else:
                            temp.balance_line = 0
                    cr.execute("SELECT count(id) as balance_line_count FROM prakruti_sales_order_item WHERE total_scheduled_qty != quantity AND main_id = %s",((temp.id),))
                    for line in cr.dictfetchall():
                        balance_line_count=int(line['balance_line_count'])
                    if balance_line_count:
                        production_slip = self.pool.get('prakruti.production_slip').create(cr,uid, {
                            'order_no':temp.order_no,
                            'order_date':temp.order_date,
                            'product_type_id':temp.product_type_id.id,
                            'produc_remarks':temp.remarks,
                            'customer_id':temp.customer_id.id,
                            'terms':temp.terms,
                            'inquiry_no':temp.inquiry_no,
                            'inquiry_date':temp.inquiry_date,
                            'quotation_no':temp.quotation_no,
                            'quotation_date':temp.quotation_date,
                            'shipping_id':temp.shipping_id.id,
                            'billing_id':temp.billing_id.id,
                            'remarks':temp.remarks,
                            #'order_type':temp.order_type,
                            'requested_id':temp.requested_id.id,
                            'quotation_id':temp.quotation_id.id,
                            'order_id':temp.order_id.id,
                            'reference_no':temp.reference_no,
                            'reference_date':temp.reference_date      
                            })
                        cr.execute("UPDATE  prakruti_sales_order SET state = 'slip_request' WHERE prakruti_sales_order.id = cast(%s as integer)",((temp.id),))
                        cr.execute("UPDATE  prakruti_sales_inquiry SET state = 'slip_request' WHERE prakruti_sales_inquiry.inquiry_no = %s ", ((temp.inquiry_no),))
                        cr.execute("UPDATE  prakruti_sales_quotation SET state = 'slip_request' WHERE prakruti_sales_quotation.inquiry_no = %s ", ((temp.inquiry_no),))
                    else:
                        raise UserError(_('No Item to give to an Production'))
                    template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Sales Order')],context=context)[0]
                    email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
                    cr.execute("SELECT product_id,prakruti_sales_order_item.id,quantity,balance_qty,uom_id,description,specification_id,req_date,unit_price,total,remarks,total_scheduled_qty,total_dispatched_qty FROM prakruti_sales_order_item WHERE total_scheduled_qty != quantity AND main_id = %s",((temp.id),))
                    for line in cr.dictfetchall():
                        product_id=line['product_id']
                        quantity=line['balance_qty']
                        balance_qty=line['balance_qty']
                        uom_id=line['uom_id']
                        description=line['description']
                        specification_id=line['specification_id']
                        req_date=line['req_date']
                        unit_price=line['unit_price']
                        #tarrif_id=line['tarrif_id']
                        #mrp=line['mrp']
                        #total1=line['total1']
                        #batch_no=line['batch_no']
                        #mfg_date=line['mfg_date']
                        #exp_date=line['exp_date']
                        total=line['total']
                        remarks=line['remarks']
                        so_line_grid_id=line['id']
                        total_ordered_qty=line['quantity']
                        total_scheduled_qty=line['total_scheduled_qty']
                        total_dispatched_qty=line['total_dispatched_qty']
                        ordered_qty=line['quantity']
                        grid_values = self.pool.get('prakruti.production_slip_line').create(cr,uid, {
                            'product_id':product_id,
                            'quantity':quantity,
                            'balance_qty':balance_qty,
                            'uom_id':uom_id,
                            'description':description,
                            'specification_id':specification_id,
                            'req_date':req_date,
                            'unit_price':unit_price,
                            #'tarrif_id':tarrif_id,
                            #'mrp':mrp,
                            #'total1':total1,
                            #'batch_no':batch_no,
                            #'mfg_date':mfg_date,
                            #'exp_date':exp_date,
                            'total':total,
                            'remarks':remarks,
                            'so_line_grid_id':so_line_grid_id,
                            'total_ordered_qty':total_ordered_qty,
                            #2017-05-17
                            'ordered_qty':ordered_qty,
                            'total_scheduled_qty':total_scheduled_qty,
                            'total_dispatch_qty':total_dispatched_qty,
                            'main_id':production_slip
                            })
                else:
                    raise UserError(_("Please Enter Required Date..."))
            if temp.revise_flag > 0:
                if not temp.revise_comments:
                    raise UserError(_('Please Enter Revise Comments'))
                if temp.revise_comments:
                    print 'Entered Reviced Comments'   
                    cr.execute("SELECT count(id) as no_of_open_line FROM prakruti_sales_order_item WHERE total_scheduled_qty != quantity AND main_id = %s",((temp.id),))
                    for line in cr.dictfetchall():
                        no_of_open_line=line['no_of_open_line']
                    cr.execute("SELECT count(id) as no_of_req_date_entry_line FROM prakruti_sales_order_item WHERE total_scheduled_qty != quantity AND cast(extract (month from req_date) as integer) > 0 AND main_id = %s",((temp.id),))
                    for line in cr.dictfetchall():
                        no_of_req_date_entry_line=line['no_of_req_date_entry_line']
                    if no_of_open_line == no_of_req_date_entry_line:
                        for item in temp.grid_id:
                            if item.total_scheduled_qty != item.quantity:
                                temp.balance_line = 1
                            elif item.status in ['wait']:
                                temp.balance_line = 1
                            else:
                                temp.balance_line = 0
                        cr.execute("SELECT count(id) as balance_line_count FROM prakruti_sales_order_item WHERE total_scheduled_qty != quantity AND main_id = %s",((temp.id),))
                        for line in cr.dictfetchall():
                            balance_line_count=int(line['balance_line_count'])
                        if balance_line_count:
                            production_slip = self.pool.get('prakruti.production_slip').create(cr,uid, {
                                'order_no':temp.order_no,
                                'order_date':temp.order_date,
                                'product_type_id':temp.product_type_id.id,
                                'produc_remarks':temp.remarks,
                                'customer_id':temp.customer_id.id,
                                'terms':temp.terms,
                                'inquiry_no':temp.inquiry_no,
                                'inquiry_date':temp.inquiry_date,
                                'quotation_no':temp.quotation_no,
                                'quotation_date':temp.quotation_date,
                                'shipping_id':temp.shipping_id.id,
                                'billing_id':temp.billing_id.id,
                                'remarks':temp.remarks,
                                #'order_type':temp.order_type,
                                'requested_id':temp.requested_id.id,
                                'quotation_id':temp.quotation_id.id,
                                'order_id':temp.order_id.id,
                                'reference_no':temp.reference_no,
                                'reference_date':temp.reference_date      
                                })
                            cr.execute("UPDATE  prakruti_sales_order SET state = 'slip_request' WHERE prakruti_sales_order.id = cast(%s as integer)",((temp.id),))
                            cr.execute("UPDATE  prakruti_sales_inquiry SET state = 'slip_request' WHERE prakruti_sales_inquiry.inquiry_no = %s ", ((temp.inquiry_no),))
                            cr.execute("UPDATE  prakruti_sales_quotation SET state = 'slip_request' WHERE prakruti_sales_quotation.inquiry_no = %s ", ((temp.inquiry_no),))
                        else:
                            raise UserError(_('No Item to give to an Production'))
                        template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Sales Order')],context=context)[0]
                        email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
                        cr.execute("SELECT product_id,prakruti_sales_order_item.id,quantity,balance_qty,uom_id,description,specification_id,req_date,unit_price,total,remarks,total_scheduled_qty,total_dispatched_qty FROM prakruti_sales_order_item WHERE total_scheduled_qty != quantity AND main_id = %s",((temp.id),))
                        for line in cr.dictfetchall():
                            product_id=line['product_id']
                            quantity=line['balance_qty']
                            balance_qty=line['balance_qty']
                            uom_id=line['uom_id']
                            description=line['description']
                            specification_id=line['specification_id']
                            req_date=line['req_date']
                            unit_price=line['unit_price']
                            #tarrif_id=line['tarrif_id']
                            #mrp=line['mrp']
                            #total1=line['total1']
                            #batch_no=line['batch_no']
                            #mfg_date=line['mfg_date']
                            #exp_date=line['exp_date']
                            total=line['total']
                            remarks=line['remarks']
                            so_line_grid_id=line['id']
                            total_ordered_qty=line['quantity']
                            total_scheduled_qty=line['total_scheduled_qty']
                            total_dispatched_qty=line['total_dispatched_qty']
                            ordered_qty=line['quantity']
                            grid_values = self.pool.get('prakruti.production_slip_line').create(cr,uid, {
                                'product_id':product_id,
                                'quantity':quantity,
                                'balance_qty':balance_qty,
                                'uom_id':uom_id,
                                'description':description,
                                'specification_id':specification_id,
                                'req_date':req_date,
                                'unit_price':unit_price,
                                #'tarrif_id':tarrif_id,
                                #'mrp':mrp,
                                #'total1':total1,
                                #'batch_no':batch_no,
                                #'mfg_date':mfg_date,
                                #'exp_date':exp_date,
                                'total':total,
                                'remarks':remarks,
                                'so_line_grid_id':so_line_grid_id,
                                'total_ordered_qty':total_ordered_qty,
                                #2017-05-17
                                'ordered_qty':ordered_qty,
                                'total_scheduled_qty':total_scheduled_qty,
                                'total_dispatch_qty':total_dispatched_qty,
                                'main_id':production_slip
                                })
                    else:
                        raise UserError(_("Please Enter Required Date..."))
        return {}
    
    
    @api.one
    @api.multi
    def action_performa_invoice(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            #template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Sales Order Proforma')],context=context)[0]
            #email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
            sales_order = self.pool.get('prakruti.sales_proforma_invoice').create(cr,uid, {
                'customer_id':temp.customer_id.id,
                'terms':temp.terms,
                'inquiry_no':temp.inquiry_no,
                'inquiry_date':temp.inquiry_date,
                'quotation_no':temp.quotation_no,
                'quotation_date':temp.quotation_date,
                'shipping_id':temp.shipping_id.id,
                'billing_id':temp.billing_id.id,
                'product_type_id':temp.product_type_id.id,
                'remarks':temp.remarks,
                #'order_type':temp.order_type,
                'order_date':temp.order_date,
                'order_no':temp.order_no,
                #'assessable_value':temp.assessable_value,
                #'total_assessable_value':temp.total_assessable_value,
                #'assessable_subtotal':temp.assessable_subtotal,
                #'subtotal':temp.subtotal,
                #'new_bed_amt':temp.new_bed_amt,
                #'new_ed_cess_amt':temp.new_ed_cess_amt,
                #'new_sec_cess_amt':temp.new_sec_cess_amt,
                #'new_total_tax':temp.new_total_tax,
                #'new_total_vat':temp.new_total_vat,
                #'new_total_cst':temp.new_total_cst,
                #'new_total_sbc':temp.new_total_sbc,
                #'new_total_kkc':temp.new_total_kkc,
                #'untaxed_amount':temp.untaxed_amount,
                #'transporatation_charges':temp.transporatation_charges,
                #'final_grand_total':temp.final_grand_total,
                'cash_amount':temp.cash_amount,
                'cash_remarks':temp.cash_remarks,
                'cheque_amount':temp.cheque_amount,
                'cheque_no':temp.cheque_no,
                'cheque_remarks':temp.cheque_remarks,
                'draft_amount':temp.draft_amount,
                'draft_no':temp.draft_no,
                'draft_remarks':temp.draft_remarks,
                'advance_payment_type':temp.advance_payment_type,
                'any_adv_payment':temp.any_adv_payment,
                'total_no_of_products':temp.total_no_of_products,
                'proportionate_amount_to_products':temp.proportionate_amount_to_products,
                'freight_charges':temp.freight_charges,
                'loading_and_packing_charges':temp.loading_and_packing_charges,
                'insurance_charges':temp.insurance_charges,
                'other_charges':temp.other_charges,
                'all_additional_charges':temp.all_additional_charges,
                'total_amount_before_tax':temp.total_amount_before_tax,
                'total_cgst_amount':temp.total_cgst_amount,
                'total_sgst_amount':temp.total_sgst_amount,
                'total_igst_amount':temp.total_igst_amount,
                'total_gst_amount':temp.total_gst_amount,
                'total_amount_after_tax':temp.total_amount_after_tax,
                'reference_no':temp.reference_no,
                'reference_date':temp.reference_date  
                })
            for item in temp.grid_id:
                grid_values = self.pool.get('prakruti.sales_proforma_invoice_item').create(cr,uid, {
                    'product_id': item.product_id.id,
                    'quantity': item.quantity,
                    'uom_id': item.uom_id.id,
                    'description':item.description,
                    'specification_id':item.specification_id.id,
                    'unit_price': item.unit_price,
                    #'tarrif_id':item.tarrif_id,
                    #'mrp':item.mrp,
                    #'total1':item.total1,
                    #'batch_no':item.batch_no.id,
                    'mfg_date':item.mfg_date,
                    'exp_date':item.exp_date,
                    'total':item.total,
                    'scheduled_date':item.scheduled_date,
                    'scheduled_qty':item.scheduled_qty,
                    'req_date':item.req_date,
                    'remarks':item.remarks,
                    'hsn_code': item.hsn_code,
                    'amount': item.amount,
                    'discount_id': item.discount_id.id,
                    'discount': item.discount,
                    'taxable_value': item.taxable_value,
                    'proportionate_amount_to_products':item.proportionate_amount_to_products,
                    'taxable_value_with_charges':item.taxable_value_with_charges,
                    'gst_rate': item.gst_rate,
                    'cgst_id':item.cgst_id.id,
                    'cgst_value': item.cgst_value,
                    'cgst_amount':item.cgst_amount,
                    'sgst_id':item.sgst_id.id,
                    'sgst_value': item.sgst_value,
                    'sgst_amount':item.sgst_amount,
                    'igst_id':item.igst_id.id,
                    'igst_value': item.igst_value,
                    'igst_amount':item.igst_amount,
                    'main_id':sales_order
                 })
            #for tax_line in temp.tax_line_id:
                #tax_values = self.pool.get('sales.proforma.tax.line').create(cr,uid,{
                    #'tax_type':tax_line.tax_type.id,
                    #'tax_percent':tax_line.tax_percent,
                    #'tax_amount':tax_line.tax_amount,
                    #'total_value':tax_line.total_value,
                    #'ref_id':sales_order
                    #})
        return {}

    @api.one
    @api.multi
    def revise_order(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            if temp.revise_comments:
                revise_values = self.pool.get('prakruti.sales_order').create(cr,uid,{
                    'countflag':temp.countflag,
                    'order_no':temp.order_no,
                    'order_date':temp.order_date,
                    'quotation_no':temp.quotation_no,
                    'quotation_date':temp.quotation_date,
                    'inquiry_no':temp.inquiry_no,
                    'inquiry_date':temp.inquiry_date,
                    'customer_id':temp.customer_id.id,
                    'product_type_id':temp.product_type_id.id,
                    'shipping_id':temp.shipping_id.id,
                    'billing_id':temp.billing_id.id,
                    'remarks':temp.remarks,
                    #'untaxed_amount':temp.untaxed_amount,
                    #'transporatation_charges':temp.transporatation_charges,
                    #'final_grand_total':temp.final_grand_total,
                    'terms':temp.terms,
                    #'order_type':temp.order_type,
                    #'assessable_value':temp.assessable_value,
                    #'total_assessable_value':temp.total_assessable_value,
                    #'assessable_subtotal':temp.assessable_subtotal,
                    #'subtotal':temp.subtotal,
                    #'new_bed_amt':temp.new_bed_amt,
                    #'new_ed_cess_amt':temp.new_ed_cess_amt,
                    #'new_sec_cess_amt':temp.new_sec_cess_amt,
                    #'new_total_tax':temp.new_total_tax,
                    #'new_total_vat':temp.new_total_vat,
                    #'new_total_cst':temp.new_total_cst,
                    #'new_total_sbc':temp.new_total_sbc,
                    #'new_total_kkc':temp.new_total_kkc,
                    'balance_line':temp.balance_line,
                    'cash_amount':temp.cash_amount,
                    'cash_remarks':temp.cash_remarks,
                    'cheque_amount':temp.cheque_amount,
                    'cheque_no':temp.cheque_no,
                    'cheque_remarks':temp.cheque_remarks,
                    'draft_amount':temp.draft_amount,
                    'draft_no':temp.draft_no,
                    'draft_remarks':temp.draft_remarks,
                    #'calculation_flag':temp.calculation_flag,
                    'amount_flag':temp.amount_flag,
                    'slip_no':temp.slip_no,
                    'po_no':temp.po_no,
                    'requested_id':temp.requested_id.id,
                    'quotation_id':temp.quotation_id.id,
                    'order_id':temp.order_id.id,
                    'reference_no':temp.reference_no,
                    'reference_date':temp.reference_date,
                    'product_id':temp.product_id.id,
                    'state':temp.state,
                    #'type_of_product':temp.type_of_product,
                    #'type_of_order':temp.type_of_order,
                    'any_adv_payment':temp.any_adv_payment,
                    'advance_payment_type':temp.advance_payment_type,
                    'ord_no' : temp.ord_no,
                    'auto_no' : temp.auto_no,
                    'req_no_control_id1' : temp.req_no_control_id1,
                    'total_no_of_products':temp.total_no_of_products,
                    'proportionate_amount_to_products':temp.proportionate_amount_to_products,
                    'freight_charges':temp.freight_charges,
                    'loading_and_packing_charges':temp.loading_and_packing_charges,
                    'insurance_charges':temp.insurance_charges,
                    'other_charges':temp.other_charges,
                    'all_additional_charges':temp.all_additional_charges,
                    'total_amount_before_tax':temp.total_amount_before_tax,
                    'total_cgst_amount':temp.total_cgst_amount,
                    'total_sgst_amount':temp.total_sgst_amount,
                    'total_igst_amount':temp.total_igst_amount,
                    'total_gst_amount':temp.total_gst_amount,
                    'total_amount_after_tax':temp.total_amount_after_tax,
                    'revise_flag':0
                    })
                for line in temp.grid_id:
                    grid_entry = self.pool.get('prakruti.sales_order_item').create(cr,uid,{
                        'product_id':line.product_id.id,
                        'uom_id':line.uom_id.id,
                        'specification_id':line.specification_id.id,
                        'description':line.description,
                        #'tarrif_id':line.tarrif_id,
                        'quantity':line.quantity,
                        'unit_price':line.unit_price,
                        #'mrp':line.mrp,
                        'remarks':line.remarks,
                        'total':line.total,
                        #'total1':line.total1,
                        #'batch_no':line.batch_no.id,
                        #'mfg_date':line.mfg_date,
                        #'exp_date':line.exp_date,
                        'scheduled_date':line.scheduled_date,
                        'scheduled_qty':line.scheduled_qty,
                        'req_date':line.req_date,
                        'balance_qty':line.balance_qty,
                        'dispatched_qty':line.dispatched_qty,
                        'accepted_qty':line.accepted_qty,
                        #'type_of_product':line.type_of_product,
                        #'type_of_order':line.type_of_order,
                        'status':line.status,
                        'state':line.state,
                        'total_dispatched_qty':line.total_dispatched_qty,
                        'total_scheduled_qty':line.total_scheduled_qty,
                        'previous_scheduled_qty':line.previous_scheduled_qty,
                        'previous_dispatched_qty':line.previous_dispatched_qty,
                        'remaining_dispatched_qty':line.remaining_dispatched_qty,
                        
                        'hsn_code': line.hsn_code,
                        'amount': line.amount,
                        'discount_id': line.discount_id.id,
                        'discount': line.discount,
                        'taxable_value': line.taxable_value,
                        'proportionate_amount_to_products':line.proportionate_amount_to_products,
                        'taxable_value_with_charges':line.taxable_value_with_charges,
                        'gst_rate': line.gst_rate,
                        'cgst_id':line.cgst_id.id,
                        'cgst_value': line.cgst_value,
                        'cgst_amount':line.cgst_amount,
                        'sgst_id':line.sgst_id.id,
                        'sgst_value': line.sgst_value,
                        'sgst_amount':line.sgst_amount,
                        'igst_id':line.igst_id.id,
                        'igst_value': line.igst_value,
                        'igst_amount':line.igst_amount,
                        'main_id':revise_values
                        })
                #for tax_line in temp.tax_line_id:
                    #grid_tax_entry = self.pool.get('sales.order.tax.line').create(cr,uid,{
                        #'tax_type':tax_line.tax_type.id,
                        #'tax_percent':tax_line.tax_percent,
                        #'tax_amount':tax_line.tax_amount,
                        #'total_value':tax_line.total_value,
                        #'select_type':tax_line.select_type,
                        #'ref_id':revise_values
                        #})
                cr.execute("UPDATE prakruti_sales_inquiry SET revised_status = 'revised' WHERE prakruti_sales_inquiry.inquiry_no = %s and customer_id = %s ",((temp.inquiry_no),(temp.customer_id.id),))
                cr.execute("UPDATE prakruti_sales_quotation SET revised_status = 'revised' WHERE prakruti_sales_quotation.inquiry_no = %s and customer_id = %s",((temp.inquiry_no),(temp.customer_id.id),))
                cr.execute("UPDATE prakruti_sales_order SET revise_flag = revise_flag + 1,revised_status = 'revised' WHERE id = %s",((temp.id),))
                if temp.slip_no:
                    cr.execute("UPDATE prakruti_production_slip SET revised_status = 'revised' WHERE prakruti_production_slip.slip_no = %s or prakruti_production_slip.order_no = %s",((temp.slip_no),(temp.order_no),))
            else:
                raise UserError(_('Please enter Revised Comments'))
        return {}
    
    @api.one
    @api.multi
    def calculate_total(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute(''' SELECT update_sales_order_gst_calculation(%s)''',((temp.id),)) 
        return {} 

    #@api.one
    #@api.multi
    #def action_calculate(self):
        #cr = self.env.cr
        #uid = self.env.uid
        #ids = self.ids
        #context = 'context'
        #for temp in self:
            #cr.execute("UPDATE prakruti_sales_order SET calculation_flag = 1 WHERE id=%s",((temp.id),))
            #cr.execute(''' SELECT update_sales_order_calculation(%s)''',((temp.id),))
            ##For Bed Amount Setting to Zero if not present
            #cr.execute("SELECT count(id) as bed_line FROM sales_order_tax_line WHERE select_type = 'bed' AND ref_id = %s",((temp.id),))
            #for line in cr.dictfetchall():
                #bed_line=int(line['bed_line'])
            #print 'bed_line',bed_line
            #if not bed_line:
                #cr.execute("UPDATE prakruti_sales_order SET new_bed_amt = 0.0 WHERE id = %s",((temp.id),))
            ##For Ed Cess Amount Setting to Zero if not present
            #cr.execute("SELECT count(id) as ed_cess_line FROM sales_order_tax_line WHERE select_type = 'ed_cess' AND ref_id = %s",((temp.id),))
            #for line in cr.dictfetchall():
                #ed_cess_line=int(line['ed_cess_line'])
            #print 'ed_cess_line',ed_cess_line
            #if not ed_cess_line:
                #cr.execute("UPDATE prakruti_sales_order SET new_ed_cess_amt = 0.0 WHERE id = %s",((temp.id),))
            ##For Sec Cess Amount Setting to Zero if not present
            #cr.execute("SELECT count(id) as sec_cess_line FROM sales_order_tax_line WHERE select_type = 'sec_cess' AND ref_id = %s",((temp.id),))
            #for line in cr.dictfetchall():
                #sec_cess_line=int(line['sec_cess_line'])
            #print 'sec_cess_line',sec_cess_line
            #if not sec_cess_line:
                #cr.execute("UPDATE prakruti_sales_order SET new_sec_cess_amt = 0.0 WHERE id = %s",((temp.id),))
            ##For Tax Amount Setting to Zero if not present
            #cr.execute("SELECT count(id) as tax_line FROM sales_order_tax_line WHERE select_type = 'tax' AND ref_id = %s",((temp.id),))
            #for line in cr.dictfetchall():
                #tax_line=int(line['tax_line'])
            #print 'tax_line',tax_line
            #if not tax_line:
                #cr.execute("UPDATE prakruti_sales_order SET new_total_tax = 0.0 WHERE id = %s",((temp.id),))
            ##For Cst Amount Setting to Zero if not present
            #cr.execute("SELECT count(id) as cst_line FROM sales_order_tax_line WHERE select_type = 'cst' AND ref_id = %s",((temp.id),))
            #for line in cr.dictfetchall():
                #cst_line=int(line['cst_line'])
            #print 'cst_line',cst_line
            #if not cst_line:
                #cr.execute("UPDATE prakruti_sales_order SET new_total_cst = 0.0 WHERE id = %s",((temp.id),))
            ##For Vat Amount Setting to Zero if not present
            #cr.execute("SELECT count(id) as vat_line FROM sales_order_tax_line WHERE select_type = 'vat' AND ref_id = %s",((temp.id),))
            #for line in cr.dictfetchall():
                #vat_line=int(line['vat_line'])
            #print 'vat_line',vat_line
            #if not vat_line:
                #cr.execute("UPDATE prakruti_sales_order SET new_total_vat = 0.0 WHERE id = %s",((temp.id),))
            ##For kkc Amount Setting to Zero if not present
            #cr.execute("SELECT count(id) as kkc_line FROM sales_order_tax_line WHERE select_type = 'krishi_kalyan' AND ref_id = %s",((temp.id),))
            #for line in cr.dictfetchall():
                #kkc_line=int(line['kkc_line'])
            #print 'kkc_line',kkc_line
            #if not kkc_line:
                #cr.execute("UPDATE prakruti_sales_order SET new_total_kkc = 0.0 WHERE id = %s",((temp.id),))
            ##For sbc Amount Setting to Zero if not present
            #cr.execute("SELECT count(id) as sbc_line FROM sales_order_tax_line WHERE select_type = 'swach_bharat' AND ref_id = %s",((temp.id),))
            #for line in cr.dictfetchall():
                #sbc_line=int(line['sbc_line'])
            #print 'sbc_line',sbc_line
            #if not sbc_line:
                #cr.execute("UPDATE prakruti_sales_order SET new_total_sbc = 0.0 WHERE id = %s",((temp.id),))
            ##For Assessable Amount Setting to Zero if not present
            #cr.execute("SELECT count(id) as assessable_line FROM sales_order_tax_line WHERE select_type = 'assessable' AND ref_id = %s",((temp.id),))
            #for line in cr.dictfetchall():
                #assessable_line=int(line['assessable_line'])
            #print 'assessable_line',assessable_line
            #if not assessable_line:
                #cr.execute("UPDATE prakruti_sales_order SET assessable_value = 0.0,total_assessable_value = 0.0 WHERE id = %s",((temp.id),))
        #return {}



#class PrakrutiSalesOrderTaxLine(models.Model):
    #_name = 'sales.order.tax.line'
    #_table = 'sales_order_tax_line'
    #_description = 'Prakruti Sales Order Tax Line'
    #_order= "id desc"
    
    #ref_id = fields.Many2one('prakruti.sales_order',string="Reference Id")
    #tax_type = fields.Many2one('account.other.tax', string='Taxes', domain=[('active', '=', True)],required=True)
    #tax_percent = fields.Float(related='tax_type.per_amount',string="Tax %",store=1,readonly=1,digits=(6,3))
    #tax_amount = fields.Float(related='tax_type.amount',string="Tax Amt.",store=1,readonly=1,digits=(6,3))
    #total_value = fields.Float(string="Total Value",readonly=1,digits=(6,3))
    #select_type=fields.Selection([
        #('tax','TAX'),
        #('vat','VAT'),
        #('cst','CST'),
        #('bed','EXCISE DUTY'),
        #('ed_cess','ED CESS'),
        #('sec_cess','SEC CESS'),
        #('swach_bharat','SWACH BHARAT'),
        #('krishi_kalyan','KRISHI KALYAN'),
        #('assessable','ABATEMENT')
        #],string='Tax Type',related='tax_type.select_type',store=1,readonly=1)
    
class PrakrutiSalesOrderItem(models.Model):
    _name = 'prakruti.sales_order_item'
    _table = "prakruti_sales_order_item"
    _description = 'Prakruti Sales Order Item Information'
    
    main_id = fields.Many2one('prakruti.sales_order',string="Grid")
    product_id  = fields.Many2one('product.product', string="Product",readonly=True)
    uom_id = fields.Many2one('product.uom',string="UOM",readonly=True)
    specification_id = fields.Many2one('product.specification.main', string = "Specification")
    description = fields.Text(string="Description",readonly=True)
    #tarrif_id=fields.Text(string='Tarrif')
    quantity = fields.Float(string = "Qty",readonly=True,digits=(6,3))
    unit_price=fields.Float(string="Unit Price",digits=(6,3))
    #mrp=fields.Float(string="MRP",digits=(6,3))
    remarks = fields.Text(string="Remarks") 
    #total1= fields.Float(string='Assessable Value',readonly=True,digits=(6,3)) 
    #batch_no= fields.Many2one('prakruti.batch_master',string= 'Batch No')
    mfg_date = fields.Date(string='Mfg. Date')
    exp_date = fields.Date(string="Expiry Date")
    scheduled_date = fields.Date('Sch. Date', readonly= True)
    scheduled_qty = fields.Float('Sch. Qty', readonly= True,default=0,digits=(6,3))
    req_date = fields.Date('Required Date')
    balance_qty = fields.Float(string="Balance Qty",digits=(6,3))
    dispatched_qty=fields.Float(string="Dispatch Qty",digits=(6,3))
    accepted_qty=fields.Float(string="Accepted Qty",digits=(6,3))
    #type_of_product = fields.Selection(related='main_id.type_of_product', string="Type of Product",store=True)
    #type_of_order = fields.Selection(related='main_id.type_of_order',string="Type of Order",store=True)
    status = fields.Selection([
        ('open', 'Open'),
        ('wait','Waiting'),
        ('close','Closed'),
        ('accepted', 'Accepted'),
        ('par_reject', 'Par. Rejected'),
        ('rejected','Rejected'),
        ('accept_under_deviation','Accepted Under Deviation')
        ],default= 'open', string= 'Status')    
    state =fields.Selection([
        ('order','Order'),
        ('slip_request','Production Slip Issued'),
        ('partially_confirmed','Production Slip Partially Confirmed'),
        ('production_slip_confirmed','Production Slip Confirmed'),
        ('partial_order','Partially Dispatched/Confirmed/Invoiced'),
        ('confirm','Dispatched/Confirmed/Invoiced'),
        ('without_qc_partially_confirmed','With out QC Partially Dispatched/Confirmed/Invoiced'),
        ('without_qc_invoice','With out QC Dispatched/Confirmed/Invoiced'),
        ('rejected','Rejected')
        ],default= 'order', string= 'Status')
    total_dispatched_qty=fields.Float(string="Total Dispatch Qty",readonly=True,digits=(6,3),default=0)
    #2017-05-17 ADDED
    total_scheduled_qty = fields.Float(string="Total Sch Qty",readonly=True,digits=(6,3),default=0)
    previous_scheduled_qty = fields.Float(string="Previous Sch Qty",readonly=True,digits=(6,3),default=0)
    previous_dispatched_qty = fields.Float(string="Previous Dispatch Qty",readonly=True,digits=(6,3),default=0)
    remaining_dispatched_qty = fields.Float(string="Remaining Dispatch Qty",readonly=True,digits=(6,3),default=0)
    total= fields.Float(string='Total',readonly=1)        
    #GST ENTRY ADDED HERE
    hsn_code = fields.Char(string='HSN/SAC')
    amount = fields.Float(string= 'Amount',readonly=1)
    discount_id = fields.Many2one('account.other.tax',string= 'Discount(%)',domain=[('select_type', '=', 'discount')])
    discount = fields.Float(string= 'Discount(%)',default=0)
    taxable_value = fields.Float(string= 'Taxable Value',readonly=1)
    proportionate_amount_to_products = fields.Float(related='main_id.proportionate_amount_to_products', string="Proportionate Amount to Products",store=1)
    taxable_value_with_charges = fields.Float(string= 'Taxable Value With Charges',readonly=1)
    gst_rate = fields.Float(string= 'GST Rate',readonly=1)    
    cgst_id = fields.Many2one('account.other.tax',string= 'CGST Rate',domain=[('select_type', '=', 'cgst')])
    cgst_value = fields.Float(related='cgst_id.per_amount',string= 'CGST Value',default=0,store=1)
    cgst_amount = fields.Float(string= 'CGST Amount',readonly=1)    
    sgst_id = fields.Many2one('account.other.tax',string= 'SGST Rate',domain=[('select_type', '=', 'sgst')])
    sgst_value = fields.Float(related='sgst_id.per_amount',string= 'SGST Value',default=0,store=1)
    sgst_amount = fields.Float(string= 'SGST Amount',readonly=1)    
    igst_id = fields.Many2one('account.other.tax',string= 'IGST Rate',domain=[('select_type', '=', 'igst')])
    igst_value = fields.Float(related='igst_id.per_amount',string= 'IGST Value',default=0,store=1)
    igst_amount = fields.Float(string= 'IGST Amount',readonly=1)
    
    #@api.depends('cgst_amount','sgst_amount','igst_amount','taxable_value_with_charges')
    #def _compute_total(self):
        #for order in self:
            #total = 0.0            
            #order.update({                
                #'total': order.taxable_value_with_charges + order.cgst_amount + order.sgst_amount + order.igst_amount
            #})
    
    #@api.depends('igst_value', 'taxable_value_with_charges')
    #def _compute_igst_amount(self):
        #for order in self:
            #igst_amount = 0.0            
            #order.update({                
                #'igst_amount': order.taxable_value_with_charges * (order.igst_value/100)
            #})
    
    #@api.depends('sgst_value', 'taxable_value_with_charges')
    #def _compute_sgst_amount(self):
        #for order in self:
            #sgst_amount = 0.0            
            #order.update({                
                #'sgst_amount': order.taxable_value_with_charges * (order.sgst_value/100)
            #})
    
    #@api.depends('cgst_value', 'taxable_value_with_charges')
    #def _compute_cgst_amount(self):
        #for order in self:
            #cgst_amount = 0.0            
            #order.update({                
                #'cgst_amount': order.taxable_value_with_charges * (order.cgst_value/100)
            #})
    
    #@api.depends('cgst_value', 'sgst_value', 'igst_value')
    #def _compute_gst_rate(self):
        #for order in self:
            #gst_rate = 0.0            
            #order.update({                
                #'gst_rate': order.cgst_value + order.sgst_value + order.igst_value
            #})
    
    #@api.depends('taxable_value', 'proportionate_amount_to_products')
    #def _compute_taxable_value_with_charges(self):
        #for order in self:
            #taxable_value_with_charges = 0.0            
            #order.update({                
                #'taxable_value_with_charges': order.taxable_value + order.proportionate_amount_to_products 
            #})
    
    #@api.depends('total_scheduled_qty', 'unit_price')
    #def _compute_amount(self):
        #for order in self:
            #amount = 0.0            
            #order.update({                
                #'amount': order.total_scheduled_qty * order.unit_price 
            #})
    
    #@api.depends('total_scheduled_qty', 'unit_price','amount','discount','discount_id')
    #def _compute_taxable_value(self):
        #for order in self:
            #taxable_value = 0.0            
            #order.update({                
                #'taxable_value': order.amount - (order.amount*(order.discount/100)) 
            #})
    
    #@api.one
    #@api.constrains('exp_date')
    #def _check_expiry_date(self):
        #if self.exp_date < self.mfg_date:
            #raise ValidationError(
                #"Expiry Date can't be less than Manufactured date!")
    
    #@api.one
    #@api.constrains('mrp')
    #def _check_mrp(self):
        #if self.mrp < 0:
            #raise ValidationError(
                #"MRP !!! Can't be Negative")

    @api.one
    @api.constrains('req_date')
    def _check_req_date(self):
        if self.req_date < fields.Date.today():
            raise ValidationError(
                "Required Date can't be less than current date!")
    
    @api.one
    @api.constrains('unit_price')
    def _check_unit_price(self):
        if self.unit_price <= 0:
            raise ValidationError(
                "Unit Price !!! Can't be Negative OR 0 ")
       
    def onchange_product(self, cr, uid, ids, product_id, context=None):
        cr.execute('SELECT  product_uom.id AS uom_id,product_uom.name, product_template.name FROM product_uom INNER JOIN product_template ON  product_uom.id=product_template.uom_id  WHERE  product_template.id=cast(%s as integer)  ', ((product_id),))
        for values in cr.dictfetchall():
            uom_id = values['uom_id']
            return {'value' :{ 'uom_id': uom_id }}
