# -*- coding: utf-8 -*-
import time
from openerp.tools import image_resize_image_big
from openerp.exceptions import ValidationError
from openerp import api, fields, models, _
import openerp
from datetime import date, datetime
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from datetime import timedelta
from openerp.osv import osv,fields
from openerp import models, fields, api, _
from openerp.tools.translate import _
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
from lxml import etree
import cgi
import logging
import lxml.html
import lxml.html.clean as clean
import openerp.pooler as pooler
import random
import re
import socket
import threading
import time
from openerp.tools import image_resize_image_big
from openerp.tools import amount_to_text
from openerp.tools.amount_to_text import amount_to_text_in 
from openerp.tools.amount_to_text import amount_to_text_in_without_word_rupees 

class PrakrutiSalesInquiry(models.Model):
    _name = 'prakruti.sales_inquiry'
    _table = "prakruti_sales_inquiry"
    _description = 'Prakruti Sales Inquiry Information'
    _order="id desc"
    _rec_name= "inquiry_no"
    
    reference_no= fields.Char(string='Ref No')
    revision_no = fields.Char(' Rev No')
    inquiry_date= fields.Date('Inquiry Date', default=fields.Date.today,readonly=True)
    inquiry_no = fields.Char(' Inquiry No',readonly=True,default='New')
    requested_id =fields.Many2one('res.users','Requested By',readonly=True)
    customer_id = fields.Many2one('res.partner',string="Customer", required=True)
    remarks = fields.Text(string="Remarks")
    terms_id=fields.Text('Terms and conditions')
    grid_id = fields.One2many('prakruti.sales_inquiry_item', 'main_id',string='Grid')
    product_type_id=fields.Many2one('product.group',string= 'Product Type')
    state =fields.Selection([
                    ('inquiry', 'Inquiry'),
                    ('quotation','Quotation'),
                    ('order','Order'),
                    ('slip_request','Production Slip Issued'),
                    ('partially_confirmed','Production Slip Partially Confirmed'),
                    ('production_slip_confirmed','Production Slip Confirmed'),
                    ('partial_order','Partially Dispatched/Confirmed/Invoiced'),
                    ('confirm','Dispatched/Confirmed/Invoiced'),
                    ('without_qc_partially_confirmed','With out QC Partially Dispatched/Confirmed/Invoiced'),
                    ('without_qc_invoice','With out QC Dispatched/Confirmed/Invoiced'),
                    ('rejected','Rejected')
                    ],default= 'inquiry', string= 'Status')
    inq_no = fields.Char('Inquiry Number', compute='_get_auto')
    auto_no = fields.Integer('Auto')
    req_no_control_id1 = fields.Integer('Auto Generating id',default= 0)
    shipping_id = fields.Many2one('res.partner',string='Shipping Address')
    billing_id = fields.Many2one('res.partner',string='Billing Address')
    reference_date= fields.Date(string='Ref Date', default=fields.Date.today) 
    product_id = fields.Many2one('product.product', related='grid_id.product_id', string='Product Name')    
    company_id = fields.Many2one('res.company',string="Company") 
    revised_status = fields.Selection([('revised','Revised')],string= 'Revised Status')   
    
    
    def _check_the_grid(self, cr, uid, ids, context=None, * args):
        for line_id in self.browse(cr, uid, ids, context=context):
            if len(line_id.grid_id) == 0:
                return False
        return True
     
    _constraints = [
         (_check_the_grid, 'Enter Some Products To Proceed Further !', ['grid_id'])
    ]
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['quotation','order','rejected']:
                raise UserError(_('Can\'t Delete, Since the Inquiry went for further Process.'))
        return super(PrakrutiSalesInquiry, self).unlink() 
    
    @api.one
    @api.multi
    def _get_auto(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        for temp in self:
            cr.execute('''select cast(extract (month from inquiry_date) as integer) as month ,cast(extract (year from inquiry_date) as integer) as year ,id from prakruti_sales_inquiry where id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
                if month_value<=3:
                    year_value=year_value-1
                else:
                    year_value=year_value
                next_year=year_value+1
                dispay_year=str(next_year)[-2:]
                display_present_year=str(year_value)[-2:]
                cr.execute('''select autogenerate_sales_inquiry(%s)''', ((temp.id),)  ) 
                result = cr.dictfetchall()
                parent_invoice_id = 0
                for value in result: parent_invoice_id = value['autogenerate_sales_inquiry'];
                auto_gen = int(parent_invoice_id)
                if len(str(auto_gen)) < 2:
                    auto_gen = '000'+ str(auto_gen)
                elif len(str(auto_gen)) < 3:
                    auto_gen = '00' + str(auto_gen)
                elif len(str(auto_gen)) == 3:
                    auto_gen = '0'+str(auto_gen)
                else:
                    auto_gen = str(auto_gen)
                for record in self :
                    if temp.product_type_id.group_code:
                        x[record.id] = 'SI\\'+temp.product_type_id.group_code+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                    else:                        
                        x[record.id] = 'SI\\'+'MISC'+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                    cr.execute('''update prakruti_sales_inquiry set inquiry_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
            return x
 
    @api.one
    @api.multi
    def action_to_quotation(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}  
            template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Sales Inquiry')],context=context)[0]
            email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True) 
            cr.execute("SELECT count(id) as no_of_line FROM prakruti_sales_inquiry_item WHERE main_id = %s",((temp.id),))
            for line in cr.dictfetchall():
                no_of_line = line['no_of_line']            
            cr.execute("SELECT count(distinct(product_id)) as no_of_product_line FROM prakruti_sales_inquiry_item WHERE main_id = %s",((temp.id),))
            for line in cr.dictfetchall():
                no_of_product_line = line['no_of_product_line']
            if no_of_line == no_of_product_line:
                sales_quotation = self.pool.get('prakruti.sales_quotation').create(cr,uid, {
                    'reference_no':temp.reference_no,   
                    'revision_no':temp.revision_no,
                    'customer_id':temp.customer_id.id,
                    'shipping_id':temp.shipping_id.id,
                    'billing_id':temp.billing_id.id,
                    'terms_id':temp.terms_id,
                    'inquiry_no':temp.inquiry_no,
                    'remarks':temp.remarks,
                    'product_type_id':temp.product_type_id.id,
                    'requested_id':temp.requested_id.id,
                    'inquiry_date':temp.inquiry_date,
                    'reference_date':temp.reference_date   
                    })
                for item in temp.grid_id:
                    grid_values = self.pool.get('prakruti.sales_quotation_line').create(cr,uid, {
                        'product_id':item.product_id.id,
                        'uom_id':item.uom_id.id,
                        'description':item.description,
                        'specification_id':item.specification_id.id,
                        'material_type':item.material_type,
                        'quantity':item.quantity,
                        'remarks':item.remarks,
                        'actual_unit_price':item.actual_unit_price,
                        'hsn_code':item.hsn_code,
                        'main_id':sales_quotation
                    })
            else:
                raise UserError(_('Can\'t Proceed, Since Product line is having Duplicate Entries.'))
            cr.execute("UPDATE  prakruti_sales_inquiry SET state = 'quotation' WHERE prakruti_sales_inquiry.id = cast(%s as integer)",((temp.id),))
        return {}
    
    
    #@api.model
    #def _default_company(self):
        #return self.env['res.company']._company_default_get('res.partner')
    
    _defaults = {
        'requested_id': lambda s, cr, uid, c:uid,
        'revision_no':lambda s, cr, uid, c:uid,
        'product_type_id':5,
        #'company_id': _default_company, 
        }
    
class PrakrutiSalesInquiryItem(models.Model):
    _name = 'prakruti.sales_inquiry_item'
    _table = "prakruti_sales_inquiry_item"
    _description = 'Prakruti Sales Inquiry Item Information'
   
    product_id  = fields.Many2one('product.product', string="Product Name",required=True)
    uom_id = fields.Many2one('product.uom',string="UOM",required=True)
    specification_id = fields.Many2one('product.specification.main', string = "Specification")
    material_type= fields.Selection([('extraction','Extraction'),('formulation','Formulation')], string= 'Material Type', default= 'extraction')
    description = fields.Text(string="Description")
    remarks = fields.Text(string="Remarks")
    quantity = fields.Float(string = "Req Qty",required=True,digits=(6,3))
    main_id = fields.Many2one('prakruti.sales_inquiry',string="Grid", ondelete='cascade')
    customer_id = fields.Many2one(related='main_id.customer_id',string= 'Customer Name')
    actual_unit_price=fields.Float(string="Unit Price",digits=(6,3))
    hsn_code = fields.Char(string='HSN/SAC')
    
    def _check_qty(self, cr, uid, ids):
        lines = self.browse(cr, uid, ids)
        for line in lines:
            if line.quantity <= 0:
                return False
        return True
     
    _constraints = [
         (_check_qty, 'Requested quantity cannot be negative or zero !', ['quantity'])
    ]
    
    @api.onchange('product_id')
    def onchange_product_id(self):
        if self.product_id:
            self.specification_id = False
       
    def onchange_product(self, cr, uid, ids, product_id, context=None):
        cr.execute('SELECT  product_uom.id AS uom_id,product_uom.name,product_template.name as description,product_template.list_price as actual_unit_price,product_template.hsn_code as hsn_code FROM product_uom INNER JOIN product_template ON product_uom.id=product_template.uom_id INNER JOIN product_product ON product_template.id=product_product.product_tmpl_id WHERE product_product.id=cast(%s as integer)', ((product_id),))
        for values in cr.dictfetchall():
            uom_id = values['uom_id']
            description = values['description']
            actual_unit_price = values['actual_unit_price']
            hsn_code = values['hsn_code']
            return {'value' :{ 'uom_id': uom_id,'description':description,'actual_unit_price':actual_unit_price,'hsn_code':hsn_code }}