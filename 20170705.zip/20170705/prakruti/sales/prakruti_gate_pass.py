# -*- coding: utf-8 -*-
from openerp import models, fields, api
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp.exceptions import ValidationError
import re
import logging
######################################################################################

class PrakrutiGatePass(models.Model):
    _name= 'prakruti.gate_pass'
    _table= 'prakruti_gate_pass'
    _description= 'This Screen will generate Gate Pass for the vehicle' 
    _order= 'id desc'
    _rec_name= 'pass_no'   
    
    order_no = fields.Many2one('prakruti.sales_order', string='Order No',readonly=True)
    sales_order_date = fields.Date(string='Sales Order Date', readonly=True)
    pass_no= fields.Char(string='Gate Pass No.', default= 'New', readonly=True)
    pass_date= fields.Date('Date', default= fields.Date.today,required=True)
    gp_no= fields.Char('Pass No', compute= '_get_auto')
    auto_no= fields.Integer('Auto')
    req_no_control_id= fields.Integer('Auto Generating id', default= 0)    
    grid_id= fields.One2many('prakruti.gate_pass_line', 'main_id',string= 'Grid')
    company_id= fields.Many2one('res.company', string= "Company",readonly=True)
    vendor_id= fields.Many2one('res.partner', string= "Vendor Name", readonly=True)
    po_no = fields.Char(string='Order No', readonly=True)
    order_date = fields.Date(string='Order Date',readonly=True)
    customer_id= fields.Many2one('res.partner', string= "Customer Name", readonly=True)
    qa_no = fields.Char(string='Analysis No', readonly=True)
    pr_no = fields.Char(string='Requisition No', readonly=True)
    qo_no = fields.Char(string='Quotation No', readonly=True)
    req_no =fields.Char(string='Request No', readonly=True)
    vendor_reference = fields.Char(string='Vendor/Supplier Reference', readonly= "True" )
    payment = fields.Char(string='Mode/Terms of Payments')
    destination = fields.Char(string='Destination')
    other_reference = fields.Char(string='Other Reference')
    maintanence_manager = fields.Many2one('res.users',string="Maintanence Manager")
    purchase_manager = fields.Many2one('res.users',string="Purchase Manager", readonly= "True" )
    stores_incharge = fields.Many2one('res.users','Stores Incharge')  
    terms_of_delivery = fields.Text(string='Terms of Delivery')
    request_date = fields.Date(string = "Requisition Date")
    amount_untaxed= fields.Float(string='Untaxed Amount',digits=(6,3))
    company_address = fields.Many2one('res.company',string='Company Address', readonly= "True" )
    delivery_address = fields.Many2one('res.company',string='Dispatch To', readonly= "True" )
    total_discount = fields.Float(string="Total Discount",digits=(6,3))
    total_tax = fields.Float(string="Total Tax",digits=(6,3))
    dispatch_through = fields.Char(string='Dispatch Through', readonly= "True" )
    excise_id = fields.Many2one('account.other.tax', string='Excise Duty', domain=['|', ('active', '=', False), ('active', '=', True)])
    excise_duty = fields.Float(related='excise_id.per_amount',string= 'Excise Duty(%)',store=True,digits=(6,3))
    total_excise_duty = fields.Float(string= 'Total Excise Duty',digits=(6,3))
    purchase_type = fields.Many2one('product.group',string= 'Purchase Type')
    remarks= fields.Text(string= "Remarks")
    coming_from =fields.Selection([
		('sales_return', 'Sales Return'),
		('sales', 'Sales'),
		('purchase', 'Purchase'),
		], string='Coming From',readonly=True)
    document_type = fields.Selection([
		('outward', 'OUTWARD'),
		('inward', 'INWARD'),
		], string='Type of Document',readonly=True)
    dispatch_no = fields.Char(string='Dispatch No', readonly=True)
    dispatch_date= fields.Date('Dispatch Date', readonly=True)
    vehicle_no = fields.Char(string='Vehicle No')
    time = fields.Datetime('Time of Movement')
    security_id = fields.Many2one('res.users', string='Security Incharge')
    plant_incharge = fields.Many2one('res.users', string='Plant Incharge')
    transport_name = fields.Char(string='Name of the Transporter')
    driver_name = fields.Char(string='Name of the Driver')
    entry_no = fields.Char(string='Security Register Entry No.')
    document_no= fields.Char(string='Doc No.')
    rev_no= fields.Char(string='Rev No.')
    date= fields.Date(string='Date')
    state =fields.Selection([
        ('draft', 'Draft'),
        ('checked', 'Checked')], string='Status',readonly=True,default='draft')
    order_close_flag= fields.Integer('Close The Order', default= 0)
    order_close_pending= fields.Integer('Pending Order', default= 0)
    #Payment Terms
    any_adv_payment =fields.Selection([
                    ('no', 'No'),
                    ('yes','Yes')
                    ], string= 'Any Advance Payment')
    advance_payment_type =fields.Selection([
                    ('cash', 'CASH'),
                    ('cheque','CHEQUE'),
                    ('demand_draft','DEMAND DRAFT')
                    ], string= 'Done By')
    cash_amount = fields.Float(string="Amount",digits=(6,3))
    cash_remarks = fields.Text(string="Remarks")    
    cheque_amount = fields.Float(string="Amount",digits=(6,3))
    cheque_no = fields.Integer(string="Cheque No.")
    cheque_remarks = fields.Text(string="Remarks")
    draft_amount = fields.Float(string="Amount",digits=(6,3))
    draft_no = fields.Integer(string="Draft No.")
    draft_remarks = fields.Text(string="Remarks")
    dispatch_id =fields.Many2one('res.users','Dispatch By') 
    requested_id =fields.Many2one('res.users','Requested By')
    quotation_id =fields.Many2one('res.users','Quotation By')
    order_id =fields.Many2one('res.users','Order By')
    reference_no= fields.Char(string='Ref No') 
    product_id = fields.Many2one('product.product', related='grid_id.product_id', string='Product Name')
    #CHECKLIST FOR INWARD AND OUTWARD
    invoice_no_check = fields.Boolean(string= 'Invoice Copy')
    dc_no_inward_check = fields.Selection([('applicable','Applicable'),('not_applicable','Not Applicable')],default='applicable',string= 'Delivery Challan')
    mod_vat_copy_collected_check = fields.Selection([('applicable','Applicable'),('not_applicable','Not Applicable')],default='applicable',string= 'Does MOD VAT Copy Collected')
    po_no_check = fields.Selection([('applicable','Applicable'),('not_applicable','Not Applicable')],default='applicable',string= 'Purchase Order No')
    does_lr_copy_received_check = fields.Selection([('applicable','Applicable'),('not_applicable','Not Applicable')],default='applicable',string= 'Does LR Copy Received')
    #OUTWARD
    dc_no_outward_check = fields.Boolean(string= 'Delivery Challan')
    e_way_bill_check = fields.Selection([('applicable','Applicable'),('not_applicable','Not Applicable')],default='applicable',string= 'E-Sugama Bill')
    customer_road_permit = fields.Selection([('applicable','Applicable'),('not_applicable','Not Applicable')],default='applicable',string= 'Customer Road Permit')
    coa = fields.Selection([('applicable','Applicable'),('not_applicable','Not Applicable')],default='applicable',string= 'Purchase Order No')
    job_work_documents = fields.Selection([('applicable','Applicable'),('not_applicable','Not Applicable')],default='applicable',string= 'Job Work Documents')
    job_work_documents_remarks = fields.Text(string='Type of Transfer for Job Work') 
    completed_id = fields.Many2one('res.users',string= 'Completed By')
    completed_date = fields.Datetime(string= 'Completed Date',default= fields.Date.today)
    #GST ENTRY
    no_of_product = fields.Integer(string= "No of Products")
    amount_taxed= fields.Float(string='Taxed Amount')    
    total_cgst= fields.Float(string='Total CGST')
    total_sgst= fields.Float(string='Total SGST')
    total_igst= fields.Float(string='Total IGST')
    total_gst= fields.Float(string='Total GST')
    insurance_charges = fields.Float(string="Insurance Charges" ,digits=(6,3))
    frieght_charges_applied = fields.Selection([('yes','Yes'),('no','No')], string="Freight Charge Applied", default='no')
    frieght_charges = fields.Float(string="Frieght Charges" ,digits=(6,3))
    additional_charges = fields.Float(string='Additional Charges' ,digits=(6,3))
    packing_charges = fields.Float(string='Packing & Forwarding' ,digits=(6,3))
    grand_total= fields.Float(string='Grand Total')
    
    @api.onchange('job_work_documents')
    def _onchange_job_work_documents(self):
        if self.job_work_documents == 'not_applicable':
            self.job_work_documents_remarks = ''
    
    @api.one
    @api.constrains('pass_date')
    def _check_pass_date(self):
        if self.pass_date < fields.Date.today():
            raise ValidationError(
                "Can\'t Select Back Date")    
    
    @api.one
    @api.multi
    def _get_auto(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        for temp in self:
            cr.execute('''select cast(extract (month from pass_date) as integer) as month ,cast(extract (year from pass_date) as integer) as year ,id from prakruti_gate_pass where id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
                if month_value<=3:
                    year_value=year_value-1
                else:
                    year_value=year_value
                next_year=year_value+1
                dispay_year=str(next_year)[-2:]
                display_present_year=str(year_value)[-2:]
                cr.execute('''select autogenerate_gate_pass_no(%s)''', ((temp.id),)  ) 
                result = cr.dictfetchall()
                parent_invoice_id = 0
                for value in result: parent_invoice_id = value['autogenerate_gate_pass_no'];
                auto_gen = int(parent_invoice_id)
                if len(str(auto_gen)) < 2:
                    auto_gen = '000'+ str(auto_gen)
                elif len(str(auto_gen)) < 3:
                    auto_gen = '00' + str(auto_gen)
                elif len(str(auto_gen)) == 3:
                    auto_gen = '0'+str(auto_gen)
                else:
                    auto_gen = str(auto_gen)
                for record in self :
                    x[record.id] = 'GP-'+str(auto_gen) +'/'+str(display_present_year)+'-'+str(dispay_year)
                cr.execute('''update prakruti_gate_pass set pass_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
            return x
    
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['draft','checked']:
                raise UserError(_('Can\'t Delete record went to further process'))
        return super(PrakrutiGatePass, self).unlink()
    
    @api.model
    def _default_company(self):
        return self.env['res.company']._company_default_get('res.partner')
    
    _defaults = {
        'company_id': _default_company,
        'completed_id': lambda s, cr, uid, c:uid
        }
    
    @api.one
    @api.multi 
    def action_checked_incoming_sales_grn(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        c_line = 0
        t_line = 0
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            #template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Gate Pass')],context=context)[0]
            #email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True) 
            grn_sales = self.pool.get('prakruti.sales_return_grn').create(cr,uid, {
                'return_type':'return_by_customer',
                'order_no':temp.order_no.id,
                'order_date':temp.sales_order_date,
                'customer_id':temp.customer_id.id,
                'company_id':temp.company_id.id
                })
            for item in temp.grid_id:
                grid_values = self.pool.get('prakruti.sales_return_grn_line').create(cr,uid, {
                    'product_id': item.product_id.id,
                    'uom_id': item.uom_id.id,
                    'description': item.description,
                    'quantity': item.quantity,
                    'rejected_qty': item.recieved_qty,
                    'grn_line_id': grn_sales
                    })
            cr.execute("UPDATE prakruti_gate_pass SET state = 'checked' WHERE prakruti_gate_pass.id = CAST(%s as integer)",((temp.id),))
            #cr.execute('''UPDATE prakruti_purchase_requisition SET state = 'checked' where prakruti_purchase_requisition.requisition_no = %s ''', ((temp.pr_no),))
        return {}
    
    @api.one
    @api.multi 
    def action_checked_outgoing(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        c_line = 0
        t_line = 0
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            if temp.dc_no_outward_check and temp.e_way_bill_check and temp.customer_road_permit and temp.coa and temp.job_work_documents:
                template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Gate Pass Outgoing')],context=context)[0]
                email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True) 
                cr.execute("UPDATE prakruti_gate_pass SET state = 'checked' WHERE prakruti_gate_pass.id = CAST(%s as integer)",((temp.id),))
                #cr.execute('''UPDATE prakruti_purchase_requisition SET state = 'checked' where prakruti_purchase_requisition.requisition_no = %s ''', ((temp.pr_no),))
            else:
                raise UserError(_('Please enter Checklist'))
        return {}
    
    @api.one
    @api.multi 
    def action_checked_incoming(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        line1 = 0
        c_line = 0
        t_line = 0
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            if temp.invoice_no_check and temp.dc_no_inward_check and temp.mod_vat_copy_collected_check and temp.po_no_check and temp.does_lr_copy_received_check:
                cr.execute("SELECT count(id) as no_balance_line FROM prakruti_gate_pass_line  WHERE balance_qty =0  and main_id = CAST(%s as integer)",((temp.id),))
                for no_line in cr.dictfetchall():
                    no_balance_line = no_line['no_balance_line']
                if no_balance_line:
                    cr.execute("UPDATE prakruti_purchase_line AS b SET status= 'close', balance_qty = a.balance_qty, no_of_packings = a.no_of_packings, pack_per_qty = a.pack_per_qty, extra_packing = a.extra_packing FROM(SELECT main_id,purchase_line_common_id,product_id,balance_qty,status,no_of_packings,pack_per_qty,extra_packing FROM prakruti_gate_pass_line WHERE main_id= %s ) AS a WHERE a.purchase_line_common_id = b.id AND a.product_id = b.product_id and a.balance_qty = 0",((temp.id),))
                cr.execute("SELECT count(id) as open_balance_line FROM prakruti_gate_pass_line  WHERE balance_qty !=0  and main_id = CAST(%s as integer)",((temp.id),))
                for open_line in cr.dictfetchall():
                    open_balance_line = open_line['open_balance_line']
                if open_balance_line:
                    cr.execute("UPDATE prakruti_purchase_line AS b SET balance_qty = a.balance_qty, no_of_packings = a.no_of_packings, pack_per_qty = a.pack_per_qty, extra_packing = a.extra_packing FROM(SELECT main_id,purchase_line_common_id,product_id,balance_qty,status,no_of_packings,pack_per_qty,extra_packing FROM prakruti_gate_pass_line WHERE main_id= %s ) AS a WHERE a.purchase_line_common_id = b.id AND a.product_id = b.product_id",((temp.id),))
                    cr.execute("UPDATE prakruti_purchase_order SET state = 'order' WHERE prakruti_purchase_order.po_no = %s",((temp.po_no),))
                grn_analysis = self.pool.get('prakruti.grn_analysis').create(cr,uid, {
                    'cash_amount':temp.cash_amount,
                    'cash_remarks':temp.cash_remarks,
                    'cheque_amount':temp.cheque_amount,
                    'cheque_no':temp.cheque_no,
                    'cheque_remarks':temp.cheque_remarks,
                    'draft_amount':temp.draft_amount,
                    'draft_no':temp.draft_no,
                    'draft_remarks':temp.draft_remarks,
                    'advance_payment_type':temp.advance_payment_type,
                    'any_adv_payment':temp.any_adv_payment,
                    'po_no':temp.po_no,
                    'qa_no':temp.qa_no,
                    'pr_no':temp.pr_no,
                    'qo_no':temp.qo_no,
                    'req_no':temp.req_no,
                    'vendor_reference':temp.vendor_reference,
                    'payment':temp.payment,
                    'destination':temp.destination,
                    'other_reference':temp.other_reference,
                    'maintanence_manager':temp.maintanence_manager.id,
                    'purchase_manager':temp.purchase_manager.id,
                    'stores_incharge':temp.stores_incharge.id,
                    'terms_of_delivery':temp.terms_of_delivery,
                    'vendor_id': temp.vendor_id.id,
                    'state':'grn_analysis',
                    'remarks':temp.remarks,
                    'request_date':temp.request_date,
                    'order_date':temp.order_date,                        
                    'amount_untaxed':temp.amount_untaxed,
                    'additional_charges':temp.additional_charges,
                    'grand_total':temp.grand_total,
                    'frieght_charges_applied':temp.frieght_charges_applied,
                    'frieght_charges':temp.frieght_charges,
                    'packing_charges':temp.packing_charges,
                    'total_discount':temp.total_discount,
                    'total_tax':temp.total_tax,
                    'dispatch_through':temp.dispatch_through,
                    'excise_duty':temp.excise_duty,
                    'total_excise_duty':temp.total_excise_duty,
                    'purchase_type':temp.purchase_type.id,
                    'transporter_name':temp.transport_name
                    })
                for item in temp.grid_id:
                    grid_values = self.pool.get('prakruti.grn_analysis_line').create(cr,uid, {
                        'product_id': item.product_id.id,
                        'description': item.description,
                        'actual_quantity': item.quantity,
                        'accepted_qty': item.recieved_qty,
                        'quantity': item.recieved_qty,
                        'uom_id': item.uom_id.id,
                        'scheduled_date': item.scheduled_date,                   
                        'unit_price': item.unit_price,
                        'discount': item.discount,
                        'tax_price': item.tax_price,
                        'tax_id': item.tax_id.id,
                        'subtotal': item.subtotal,
                        'remarks':item.remarks,
                        'packing_style': item.no_of_packings,
                        'received_per_qty': item.pack_per_qty,
                        'extra_packing': item.extra_packing,
                        'purchase_line_common_id':item.purchase_line_common_id,
                        'analysis_line_id': grn_analysis
                        })
                cr.execute("UPDATE  prakruti_gate_pass SET state = 'checked' WHERE prakruti_gate_pass.id = %s",((temp.id),))
                cr.execute('''UPDATE prakruti_purchase_requisition SET state = 'checked' where prakruti_purchase_requisition.requisition_no = %s  ''', ((temp.pr_no),))
            else:
                raise UserError(_('Please enter Checklist'))
            template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Gate Pass Incoming')],context=context)[0]
            email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
        return {}
    
    
    
    
class PrakrutiGatePassLine(models.Model):
    _name= 'prakruti.gate_pass_line'
    _table= 'prakruti_gate_pass_line'
    
    product_id= fields.Many2one('product.product', string= "Product Name", readonly=True)    
    description = fields.Text(string='Description')
    uom_id = fields.Many2one('product.uom',string='UOM')
    scheduled_date =fields.Datetime(string='Due On')
    unit_price = fields.Float(string='Unit price',digits=(6,3))
    discount = fields.Float(string='Discount(%)',digits=(6,3))
    tax_id = fields.Many2one('account.other.tax', string='Taxes', domain=['|', ('active', '=', False), ('active', '=', True)])
    tax_price = fields.Float(related='tax_id.per_amount',string='Taxes', store=True,digits=(6,3)) 
    no_of_packings= fields.Float(string= "No. of Packings",digits=(6,3))
    pack_per_qty= fields.Float(string= "Packing Per. Qty.",digits=(6,3)) 
    extra_packing= fields.Float(string= "(+)Extra Packing",default=0,digits=(6,3))
    quantity= fields.Float(string= 'Ordered Qty.',digits=(6,3)) 
    recieved_qty= fields.Float(string= 'Received Qty.',compute='_compute_received_quantity',store=True,digits=(6,3)) 
    remarks= fields.Text(string= "Remarks")
    main_id = fields.Many2one('prakruti.gate_pass', string= "Grid Line") 
    status = fields.Selection([
		('open', 'Open'),
		('close','Close')],default= 'open', string= 'Status')
    balance_qty = fields.Float(string="Balance Qty",compute='_compute_balance_qty',store=True,digits=(6,3))
    purchase_line_common_id = fields.Integer(string="Purchase Line ID")  
    packing_details = fields.Char('Packing Details')
    #GST REQUIREMENT
    hsn_code = fields.Char(string='HSN/SAC',readonly=1)
    discount_id = fields.Many2one('account.other.tax', string='Discount', domain=['|', ('active', '=', False), ('active', '=', True)])
    discount_rate = fields.Float(string='Discount Rate' ,digits=(6,3),default=0)
    discount_value = fields.Float(string= 'Discount Amount',digits=(6,3)) 
    taxable_value = fields.Float(string= 'Taxable Value',digits=(6,3))
    total= fields.Float(string='Total',digits=(6,3))
    cgst_id = fields.Many2one('account.other.tax', string='CGST Rate', domain=['|', ('active', '=', False), ('active', '=', True)])
    cgst_rate = fields.Float(string='CGST Rate' ,digits=(6,3),default=0)
    cgst_value = fields.Float(string= 'CGST Amount',digits=(6,3))
    sgst_id = fields.Many2one('account.other.tax', string='SGST Rate', domain=['|', ('active', '=', False), ('active', '=', True)])
    sgst_rate = fields.Float(string='SGST Rate' ,digits=(6,3),default=0)
    sgst_value = fields.Float(string= 'SGST Amount',digits=(6,3)) 
    igst_id = fields.Many2one('account.other.tax', string='IGST Rate', domain=['|', ('active', '=', False), ('active', '=', True)])
    igst_rate = fields.Float(string='IGST Rate' ,digits=(6,3),default=0)
    igst_value = fields.Float(string= 'IGST Amount',digits=(6,3)) 
    taxable_value_after_adding_other= fields.Float(string='Taxable Value After Adding Other Charges',digits=(6,3))
    packing_charges = fields.Float(string='Packing Charges')
    frieght_charges = fields.Float(string='Frieght Charges')
    additional_charges = fields.Float(string='Additional Charges')
    no_of_product = fields.Integer(string= "No of Products")
    subtotal = fields.Float(string= 'Sub Total',digits=(6,3))
    insurance_charges = fields.Float(string='Insurance Charges') 
   
    
    @api.depends('quantity','recieved_qty')
    def _compute_balance_qty(self):
        for order in self:
            balance_qty = 0.0            
            order.update({                
                'balance_qty': order.quantity - order.recieved_qty 
            })
    
    @api.depends('no_of_packings','pack_per_qty','extra_packing')
    def _compute_received_quantity(self):
        for order in self:
            recieved_qty = 0.0
            order.update({
                    'recieved_qty': ((order.no_of_packings * order.pack_per_qty) + order.extra_packing)
                    })