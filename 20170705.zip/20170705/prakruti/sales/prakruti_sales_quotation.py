# -*- coding: utf-8 -*-
import time
from openerp.tools import image_resize_image_big
from openerp.exceptions import ValidationError
from openerp import api, fields, models, _
import openerp
from datetime import date, datetime
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from datetime import timedelta
from openerp.osv import osv,fields
from openerp import models, fields, api, _
from openerp.tools.translate import _
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
from lxml import etree
import cgi
import logging
import lxml.html
import lxml.html.clean as clean
import openerp.pooler as pooler
import random
import re
import socket
import threading
import time
from openerp.tools import image_resize_image_big
from openerp.tools import amount_to_text
from openerp.tools.amount_to_text import amount_to_text_in 
from openerp.tools.amount_to_text import amount_to_text_in_without_word_rupees 
#########################################################################################################

class PrakrutiSalesQuotation(models.Model):
    _name = 'prakruti.sales_quotation'
    _table = 'prakruti_sales_quotation'
    _description = 'Prakruti Sales Quotation Information'
    _order= "id desc"
    _rec_name= "quotation_no"
    
    
    @api.one
    @api.multi
    def _get_automatic_no(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        for temp in self:
            cr.execute('''select cast(extract (month from quotation_date) as integer) as month ,cast(extract (year from quotation_date) as integer) as year,id from prakruti_sales_quotation where id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
                if month_value<=3:
                    year_value=year_value-1
                else:
                    year_value=year_value
                next_year=year_value+1
                dispay_year=str(next_year)[-2:]
                display_present_year=str(year_value)[-2:]
                        
                cr.execute('''select autogenerate_sales_quotation(%s)''', ((temp.id),)  ) 
                result = cr.dictfetchall()
                parent_invoice_id = 0
                for value in result: parent_invoice_id = value['autogenerate_sales_quotation'];
                auto_gen = int(parent_invoice_id)
                if len(str(auto_gen)) < 2:
                    auto_gen = '000'+ str(auto_gen)
                elif len(str(auto_gen)) < 3:
                    auto_gen = '00' + str(auto_gen)
                elif len(str(auto_gen)) == 3:
                    auto_gen = '0'+str(auto_gen)
                else:
                    auto_gen = str(auto_gen)
                for record in self :
                    if temp.product_type_id.group_code:
                        x[record.id] = 'SQ\\'+temp.product_type_id.group_code+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                    else:                        
                        x[record.id] = 'SQ\\'+'MISC'+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                    cr.execute('''update prakruti_sales_quotation set quotation_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
            return x
    
    _defaults = {
        'inquiry_no':'Direct Quotation',
        'quotation_no':'New',
        'quotation_id': lambda s, cr, uid, c:uid,
        'indent_disable_id':1,
        }
        
    
    product_type_id=fields.Many2one('product.group',string= 'Product Type')
    inquiry_no = fields.Char(' Inquiry No',readonly=True)
    inquiry_date= fields.Date('Inquiry Date')
    customer_id = fields.Many2one('res.partner',string="Customer", required=True)
    quotation_date = fields.Date (string='Quotation Date', default= fields.Date.today)
    quotation_no = fields.Char(string='Quotation No', readonly=True)
    shipping_id = fields.Many2one('res.partner',string='Shipping Address')
    billing_id = fields.Many2one('res.partner',string='Billing Address')
    remarks = fields.Text(string="Remarks")
    qo_no = fields.Char('Quotation Number', compute='_get_automatic_no')
    auto_no = fields.Integer('Auto')
    req_no_control_id = fields.Integer('Auto Generating id',default= 0)
    grid_id = fields.One2many('prakruti.sales_quotation_line', 'main_id',string='Grid')
    #tax_line_id = fields.One2many('sales.quotation.tax.line','ref_id',string='All Taxes')
    terms = fields.Text(string='Terms & Conditions')
    remarks = fields.Text(string='Remarks')
    #order_type = fields.Selection([('with_tarrif','Sales'),('without_tarrif','PS')], string="Order Type", default='with_tarrif')
    requested_id =fields.Many2one('res.users','Requested By',readonly=True)
    quotation_id =fields.Many2one('res.users','Quotation By')
    reference_no= fields.Char(string='Ref No')
    reference_date= fields.Date(string='Ref Date') 
    product_id = fields.Many2one('product.product', related='grid_id.product_id', string='Product Name')
    #CALCULATION PART
    #assessable_value=fields.Float(string='Assessable Value(%)',digits=(6,3))
    #total_assessable_value= fields.Float(string='Total Assesable value',digits=(6,3))
    #assessable_subtotal=fields.Float(string='Assesable  Total',digits=(6,3))
    #subtotal= fields.Float(string='Sub Total',digits=(6,3))
    #untaxed_amount = fields.Float(string="Untaxed Amount",digits=(6,3))
    #transporatation_charges=fields.Float(string='Transportation Charges',digits=(6,3))
    #final_grand_total = fields.Float(string=" Grand Total",digits=(6,3))
    #new_bed_amt = fields.Float(string="BED Total",readonly=1,digits=(6,3))
    #new_ed_cess_amt = fields.Float(string="Ed Cess Total",readonly=1,digits=(6,3))
    #new_sec_cess_amt = fields.Float(string="Sec Cess Total",readonly=1,digits=(6,3))
    #new_total_tax = fields.Float(string="Total Tax",readonly=1,digits=(6,3))
    #new_total_vat = fields.Float(string="Total Vat",readonly=1,digits=(6,3))
    #new_total_cst = fields.Float(string="Total Cst",readonly=1,digits=(6,3))
    #new_total_sbc = fields.Float(string="Swachh Bharat",readonly=1,digits=(6,3))
    #new_total_kkc = fields.Float(string="Krishi Kalayan",readonly=1,digits=(6,3))
    #calculation_flag = fields.Integer(string="Is Calculation Clicked",default=0)
    state =fields.Selection([
                    ('quotation','Quotation'),
                    ('order','Order'),
                    ('slip_request','Production Slip Issued'),
                    ('partially_confirmed','Production Slip Partially Confirmed'),
                    ('production_slip_confirmed','Production Slip Confirmed'),
                    ('partial_order','Partially Dispatched/Confirmed/Invoiced'),
                    ('confirm','Dispatched/Confirmed/Invoiced'),
                    ('without_qc_partially_confirmed','With out QC Partially Dispatched/Confirmed/Invoiced'),
                    ('without_qc_invoice','With out QC Dispatched/Confirmed/Invoiced'),
                    ('rejected','Rejected')
                    ],default= 'quotation', string= 'Status')
    #type_of_product = fields.Selection([
        #('extraction','Extraction'),
        #('formulation','Formulation')], default='extraction', string="Type of Product")
    #type_of_order = fields.Selection([
        #('sales','SALES'),
        #('ps','PHYSICIAN SAMPLE')
        #],default='sales',string="Type of Order")
    company_id = fields.Many2one('res.company',string="Company")
    revised_status = fields.Selection([('revised','Revised')],string= 'Revised Status')
    
    #GST ENTRY
    total_no_of_products = fields.Integer(string="Total No of Products",compute= '_compute_total_no_of_products')
    proportionate_amount_to_products = fields.Float(string="Proportionate Amount to Products",compute= '_compute_proportionate_amount_to_products')
    freight_charges = fields.Float(string="Freight Charges")
    loading_and_packing_charges = fields.Float(string="Loading and Packing Charges")
    insurance_charges = fields.Float(string="Insurance Charges")
    other_charges =  fields.Float(string="Other Charges")
    all_additional_charges = fields.Float(string="All Additional Charges",compute= '_compute_all_additional_charges')#SUM OF all charges like freight_charges loading_and_packing_charges insurance_charges other_charges   
    total_amount_before_tax = fields.Float(string="Untaxed Amount",compute= '_compute_total_amount_before_tax')#SUM OF Taxable value after adding other charges
    total_cgst_amount = fields.Float(string="CGST Amount",compute= '_compute_total_cgst_amount')
    total_sgst_amount = fields.Float(string="SGST Amount",compute= '_compute_total_sgst_amount')
    total_igst_amount = fields.Float(string="IGST Amount",compute= '_compute_total_igst_amount')
    total_gst_amount = fields.Float(string="Total GST",compute= '_compute_total_gst_amount')  
    total_amount_after_tax = fields.Float(string="Grand Total",compute= '_compute_total_amount_after_tax')#SUM OF Subtotal of the grid
    grand_total_in_words= fields.Text(compute= '_get_total_in_words',string='Total in words')
    type_of_gst = fields.Selection([
        ('cgst_sgst','CGST/SGST'),('igst','IGST')],default='cgst_sgst',string='Type Of GST')
    
    @api.depends('total_amount_after_tax')
    def _get_total_in_words(self):
        for order in self:
            total_amount_after_tax = val1 = 0.0
            val1_in_words = ""
            val1 = order.total_amount_after_tax
            val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            order.update({                    
                'grand_total_in_words': val1_in_words.upper()
                })
    
    
    
    @api.depends('grid_id.total')
    def _compute_total_amount_after_tax(self):
        for order in self:
            total_amount_after_tax = line_amount =0
            for line in order.grid_id:
                line_amount += line.total
                order.update({
                    'total_amount_after_tax': line_amount
                    })
    
    
    @api.depends('total_cgst_amount','total_sgst_amount','total_igst_amount')
    def _compute_total_gst_amount(self):
        for order in self:
            total_gst_amount = 0
            order.update({
                'total_gst_amount': order.total_cgst_amount + order.total_sgst_amount + order.total_igst_amount
                })
    
    
    @api.depends('grid_id.igst_amount')
    def _compute_total_igst_amount(self):
        for order in self:
            total_igst_amount = t_igst_amount =0
            for line in order.grid_id:
                t_igst_amount += line.igst_amount
                order.update({
                    'total_igst_amount': t_igst_amount
                    })
    
    
    @api.depends('grid_id.sgst_amount')
    def _compute_total_sgst_amount(self):
        for order in self:
            total_sgst_amount = t_sgst_amount =0
            for line in order.grid_id:
                t_sgst_amount += line.sgst_amount
                order.update({
                    'total_sgst_amount': t_sgst_amount
                    })
    
    
    @api.depends('grid_id.cgst_amount')
    def _compute_total_cgst_amount(self):
        for order in self:
            total_cgst_amount = t_cgst_amount = 0
            for line in order.grid_id:
                t_cgst_amount += line.cgst_amount
                order.update({
                    'total_cgst_amount': t_cgst_amount
                    })
    
    
    @api.depends('grid_id.taxable_value_with_charges')
    def _compute_total_amount_before_tax(self):
        for order in self:
            total_amount_before_tax = taxed_value_with_charges =0
            for line in order.grid_id:
                taxed_value_with_charges += line.taxable_value_with_charges
                order.update({
                    'total_amount_before_tax': taxed_value_with_charges
                    })
    
    
    @api.depends('grid_id.quantity')
    def _compute_total_no_of_products(self):
        for order in self:
            total_no_of_products = no_of_qty = 0
            for line in order.grid_id:
                no_of_qty += line.quantity
                order.update({
                    'total_no_of_products': no_of_qty
                    })
    
    @api.depends('freight_charges', 'loading_and_packing_charges','insurance_charges', 'other_charges')
    def _compute_all_additional_charges(self):
        for order in self:
            all_additional_charges = 0.0            
            order.update({                
                'all_additional_charges': order.freight_charges + order.loading_and_packing_charges + order.insurance_charges + order.other_charges
            })
    
    @api.depends('freight_charges', 'loading_and_packing_charges','insurance_charges', 'other_charges','total_no_of_products')
    def _compute_proportionate_amount_to_products(self):
        for order in self:
            proportionate_amount_to_products = 0.0
            order.update({                
                'proportionate_amount_to_products': order.all_additional_charges/order.total_no_of_products
            })
    
    
    
    #@api.onchange('tax_line_id')
    #def onchange_tax_line_id(self):
        #self.calculation_flag=0
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['quotation','order','rejected']:
                raise UserError(_('Can\'t Delete, Since the Quotation went for further Process.'))
        return super(PrakrutiSalesQuotation, self).unlink() 
    
    #@api.one
    #@api.constrains('transporatation_charges')
    #def _check_transporatation_charges(self):
        #if self.transporatation_charges < 0:
            #raise ValidationError(
                #"Transportation Charges !!! Can't be Negative")    
    @api.one
    @api.constrains('quotation_date')
    def _check_quotation_date(self):
        if self.quotation_date < fields.Date.today():
            raise ValidationError(
                "Quotation Date can't be less than current date!")
    
    @api.one
    @api.multi
    def action_to_order(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            type_of_gst = ''
            for line in temp.grid_id:
                cr.execute("SELECT prakruti_sales_quotation_line.unit_price, prakruti_sales_quotation_line.actual_unit_price FROM public.prakruti_sales_quotation, public.prakruti_sales_quotation_line WHERE prakruti_sales_quotation.id = prakruti_sales_quotation_line.main_id AND prakruti_sales_quotation_line.product_id = CAST(%s AS INTEGER) AND prakruti_sales_quotation.id = CAST(%s AS INTEGER)", ((line.product_id.id),(temp.id),))
                for item in cr.dictfetchall():
                    unit_price = item['unit_price']
                    actual_unit_price = item['actual_unit_price']
                print '-------------------------------PRODUCT ID----------------------------------------------',line.product_id.id
                print '-------------------------------PRODUCT NAME----------------------------------------------',line.product_id.name_template
                print '-------------------------------UNIT PRICE----------------------------------------------',unit_price
                print '-------------------------------ACTUAL UNIT PRICE----------------------------------------------',actual_unit_price
                if unit_price < actual_unit_price:
                    raise UserError(_('Your Entered Sales Price is %s for the Product [ %s ] which is not equal to the Actual Sales Price i.e. %s') %(unit_price,line.product_id.name_template,actual_unit_price))
            cr.execute("SELECT unit_price FROM prakruti_sales_quotation_line WHERE main_id = %s",((temp.id),))
            for line in cr.dictfetchall():
                unit_price = line['unit_price']
            cr.execute("SELECT prakruti_sales_quotation.type_of_gst as type_of_gst,cgst_value,sgst_value,igst_value FROM prakruti_sales_quotation_line INNER JOIN prakruti_sales_quotation ON prakruti_sales_quotation_line.main_id = prakruti_sales_quotation.id WHERE main_id = %s",((temp.id),))
            for line in cr.dictfetchall():
                type_of_gst = line['type_of_gst']
                cgst_value = line['cgst_value']
                sgst_value = line['sgst_value']
                igst_value = line['igst_value']
                print '.............................TYPE OF SALE.........................................',type_of_gst
                print '.............................CGST VALUE...........................................',cgst_value
                print '.............................SGST VALUE...........................................',sgst_value
                print '.............................IGST VALUE...........................................',igst_value
                if type_of_gst == 'cgst_sgst':
                    if cgst_value:
                        if not sgst_value:
                            raise UserError(_('Please Enter Equal Tax for SGST Also'))
                    if sgst_value:
                        if not cgst_value: 
                            raise UserError(_('Please Enter Equal Tax for CGST Also'))               
                    if (cgst_value + sgst_value) in [0,5,12,18,28]:
                        if igst_value:
                            raise UserError(_('You are not supposed to enter IGST details'))
                        if cgst_value:
                            if not sgst_value:
                                raise UserError(_('Please Enter Equal Tax for SGST Also'))
                        if sgst_value:
                            if not cgst_value:
                                raise UserError(_('Please Enter Equal Tax for CGST Also'))
                    else:
                        raise UserError(_('Please Enter Proper Tax Details'))
                elif type_of_gst == 'igst':
                    if cgst_value:
                        raise UserError(_('Sorry You are not supposed to enter CGST Details'))
                    if sgst_value:
                        raise UserError(_('Sorry You are not supposed to enter SGST Details'))
                    if (igst_value) not in [0,5,12,18,28]:
                        raise UserError(_('Please Enter Proper Tax Details'))
                else:
                    raise UserError(_('Sorry Please Select GST TYPE'))
            if unit_price != 0:
                sales_order = self.pool.get('prakruti.sales_order').create(cr,uid, {
                    'customer_id':temp.customer_id.id,
                    'terms':temp.terms,
                    'requested_id':temp.requested_id.id,
                    'quotation_id':temp.quotation_id.id,
                    'inquiry_no':temp.inquiry_no,
                    'inquiry_date':temp.inquiry_date,
                    'quotation_no':temp.quotation_no,
                    'quotation_date':temp.quotation_date,
                    'shipping_id':temp.shipping_id.id,
                    'billing_id':temp.billing_id.id,
                    'product_type_id':temp.product_type_id.id,
                    'remarks':temp.remarks,
                    #'order_type':temp.order_type,
                    #'assessable_value':temp.assessable_value,
                    #'total_assessable_value':temp.total_assessable_value,
                    #'assessable_subtotal':temp.assessable_subtotal,
                    #'subtotal':temp.subtotal,                    
                    #'new_bed_amt':temp.new_bed_amt,
                    #'new_ed_cess_amt':temp.new_ed_cess_amt,
                    #'new_sec_cess_amt':temp.new_sec_cess_amt,
                    #'new_total_tax':temp.new_total_tax,
                    #'new_total_vat':temp.new_total_vat,
                    #'new_total_cst':temp.new_total_cst,
                    #'new_total_sbc':temp.new_total_sbc,
                    #'new_total_kkc':temp.new_total_kkc,
                    #'untaxed_amount':temp.untaxed_amount,
                    #'transporatation_charges':temp.transporatation_charges,
                    #'final_grand_total':temp.final_grand_total,                   
                    #'type_of_order':temp.type_of_order,
                    #'type_of_product':temp.type_of_product,
                    'total_no_of_products':temp.total_no_of_products,
                    'proportionate_amount_to_products':temp.proportionate_amount_to_products,
                    'freight_charges':temp.freight_charges,
                    'loading_and_packing_charges':temp.loading_and_packing_charges,
                    'insurance_charges':temp.insurance_charges,
                    'other_charges':temp.other_charges,
                    'all_additional_charges':temp.all_additional_charges,
                    'total_amount_before_tax':temp.total_amount_before_tax,
                    'total_cgst_amount':temp.total_cgst_amount,
                    'total_sgst_amount':temp.total_sgst_amount,
                    'total_igst_amount':temp.total_igst_amount,
                    'total_gst_amount':temp.total_gst_amount,
                    'total_amount_after_tax':temp.total_amount_after_tax,
                    
                    
                    'reference_no':temp.reference_no,
                    'reference_date':temp.reference_date      
                    })
                for item in temp.grid_id:
                    grid_values = self.pool.get('prakruti.sales_order_item').create(cr,uid, {
                        'product_id': item.product_id.id,
                        'quantity': item.quantity,
                        'balance_qty': item.quantity,
                        'uom_id': item.uom_id.id,
                        'description':item.description,
                        'specification_id':item.specification_id.id,
                        'unit_price': item.unit_price,
                        'actual_unit_price':item.actual_unit_price,
                        #'tarrif_id':item.tarrif_id,
                        #'mrp':item.mrp,
                        #'total1':item.total1,
                        #'batch_no':item.batch_no,
                        #'mfg_date':item.mfg_date,
                        #'exp_date':item.exp_date,
                        'total':item.total,
                        'remarks':item.remarks,                    
                        #'type_of_order':temp.type_of_order,
                        #'type_of_product':temp.type_of_product,
                        
                        'hsn_code': item.hsn_code,
                        'amount': item.amount,
                        'discount_id': item.discount_id.id,
                        'discount': item.discount,
                        'taxable_value': item.taxable_value,
                        'proportionate_amount_to_products':item.proportionate_amount_to_products,
                        'taxable_value_with_charges':item.taxable_value_with_charges,
                        'gst_rate': item.gst_rate,
                        'cgst_id':item.cgst_id.id,
                        'cgst_value': item.cgst_value,
                        'cgst_amount':item.cgst_amount,
                        'sgst_id':item.sgst_id.id,
                        'sgst_value': item.sgst_value,
                        'sgst_amount':item.sgst_amount,
                        'igst_id':item.igst_id.id,
                        'igst_value': item.igst_value,
                        'igst_amount':item.igst_amount,
                        
                        'main_id':sales_order
                    })
                #for tax_line in temp.tax_line_id:
                    #tax_values = self.pool.get('sales.order.tax.line').create(cr,uid,{
                        #'tax_type':tax_line.tax_type.id,
                        #'tax_percent':tax_line.tax_percent,
                        #'tax_amount':tax_line.tax_amount,
                        #'total_value':tax_line.total_value,
                        #'ref_id':sales_order
                        #})
                cr.execute("UPDATE  prakruti_sales_quotation SET state = 'order' WHERE prakruti_sales_quotation.id = cast(%s as integer)",((temp.id),))
                cr.execute("UPDATE  prakruti_sales_inquiry SET state = 'order' WHERE prakruti_sales_inquiry.inquiry_no = %s",((temp.inquiry_no),))
            else:
                raise UserError(_("Unit Price Not Yet Entered"))
            template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Sales Quotation')],context=context)[0]
            email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True) 
        return {}
    
    #Hidden due to GSt Entry
    #@api.one
    #@api.multi
    #def action_calculate(self):
        #cr = self.env.cr
        #uid = self.env.uid
        #ids = self.ids
        #context = 'context'
        #for temp in self:
            #cr.execute(''' SELECT update_sales_quotation_calculation(%s)''',((temp.id),))          
            #cr.execute("UPDATE prakruti_sales_quotation SET calculation_flag = 1 WHERE id=%s",((temp.id),))
            ##For Bed Amount Setting to Zero if not present
            #cr.execute("SELECT count(id) as bed_line FROM sales_quotation_tax_line WHERE select_type = 'bed' AND ref_id = %s",((temp.id),))
            #for line in cr.dictfetchall():
                #bed_line=int(line['bed_line'])
            #print 'bed_line',bed_line
            #if not bed_line:
                #cr.execute("UPDATE prakruti_sales_quotation SET new_bed_amt = 0.0 WHERE id = %s",((temp.id),))
            ##For Ed Cess Amount Setting to Zero if not present
            #cr.execute("SELECT count(id) as ed_cess_line FROM sales_quotation_tax_line WHERE select_type = 'ed_cess' AND ref_id = %s",((temp.id),))
            #for line in cr.dictfetchall():
                #ed_cess_line=int(line['ed_cess_line'])
            #print 'ed_cess_line',ed_cess_line
            #if not ed_cess_line:
                #cr.execute("UPDATE prakruti_sales_quotation SET new_ed_cess_amt = 0.0 WHERE id = %s",((temp.id),))
            ##For Sec Cess Amount Setting to Zero if not present
            #cr.execute("SELECT count(id) as sec_cess_line FROM sales_quotation_tax_line WHERE select_type = 'sec_cess' AND ref_id = %s",((temp.id),))
            #for line in cr.dictfetchall():
                #sec_cess_line=int(line['sec_cess_line'])
            #print 'sec_cess_line',sec_cess_line
            #if not sec_cess_line:
                #cr.execute("UPDATE prakruti_sales_quotation SET new_sec_cess_amt = 0.0 WHERE id = %s",((temp.id),))
            ##For Tax Amount Setting to Zero if not present
            #cr.execute("SELECT count(id) as tax_line FROM sales_quotation_tax_line WHERE select_type = 'tax' AND ref_id = %s",((temp.id),))
            #for line in cr.dictfetchall():
                #tax_line=int(line['tax_line'])
            #print 'tax_line',tax_line
            #if not tax_line:
                #cr.execute("UPDATE prakruti_sales_quotation SET new_total_tax = 0.0 WHERE id = %s",((temp.id),))
            ##For Cst Amount Setting to Zero if not present
            #cr.execute("SELECT count(id) as cst_line FROM sales_quotation_tax_line WHERE select_type = 'cst' AND ref_id = %s",((temp.id),))
            #for line in cr.dictfetchall():
                #cst_line=int(line['cst_line'])
            #print 'cst_line',cst_line
            #if not cst_line:
                #cr.execute("UPDATE prakruti_sales_quotation SET new_total_cst = 0.0 WHERE id = %s",((temp.id),))
            ##For Vat Amount Setting to Zero if not present
            #cr.execute("SELECT count(id) as vat_line FROM sales_quotation_tax_line WHERE select_type = 'vat' AND ref_id = %s",((temp.id),))
            #for line in cr.dictfetchall():
                #vat_line=int(line['vat_line'])
            #print 'vat_line',vat_line
            #if not vat_line:
                #cr.execute("UPDATE prakruti_sales_quotation SET new_total_vat = 0.0 WHERE id = %s",((temp.id),))
            ##For kkc Amount Setting to Zero if not present
            #cr.execute("SELECT count(id) as kkc_line FROM sales_quotation_tax_line WHERE select_type = 'krishi_kalyan' AND ref_id = %s",((temp.id),))
            #for line in cr.dictfetchall():
                #kkc_line=int(line['kkc_line'])
            #print 'kkc_line',kkc_line
            #if not kkc_line:
                #cr.execute("UPDATE prakruti_sales_quotation SET new_total_kkc = 0.0 WHERE id = %s",((temp.id),))
            ##For sbc Amount Setting to Zero if not present
            #cr.execute("SELECT count(id) as sbc_line FROM sales_quotation_tax_line WHERE select_type = 'swach_bharat' AND ref_id = %s",((temp.id),))
            #for line in cr.dictfetchall():
                #sbc_line=int(line['sbc_line'])
            #print 'sbc_line',sbc_line
            #if not sbc_line:
                #cr.execute("UPDATE prakruti_sales_quotation SET new_total_sbc = 0.0 WHERE id = %s",((temp.id),))
            ##For Assessable Amount Setting to Zero if not present
            #cr.execute("SELECT count(id) as assessable_line FROM sales_quotation_tax_line WHERE select_type = 'assessable' AND ref_id = %s",((temp.id),))
            #for line in cr.dictfetchall():
                #assessable_line=int(line['assessable_line'])
            #print 'assessable_line',assessable_line
            #if not assessable_line:
                #cr.execute("UPDATE prakruti_sales_quotation SET assessable_value = 0.0,total_assessable_value = 0.0 WHERE id = %s",((temp.id),))           
        #return {}
    
    
    
    
    
#Hidden due to GST Entry
#class PrakrutiSalesQuotationTaxLine(models.Model):
    #_name = 'sales.quotation.tax.line'
    #_table = 'sales_quotation_tax_line'
    #_description = 'Prakruti Sales Quotation Tax Line'
    #_order= "id desc"
    
    #ref_id = fields.Many2one('prakruti.sales_quotation',string="Reference Id")
    #tax_type = fields.Many2one('account.other.tax', string='Taxes', domain=[('active', '=', True)],required=True)
    #tax_percent = fields.Float(related='tax_type.per_amount',string="Tax %",store=1,readonly=1,digits=(6,3))
    #tax_amount = fields.Float(related='tax_type.amount',string="Tax Amt.",store=1,readonly=1,digits=(6,3))
    #total_value = fields.Float(string="Total Value",readonly=1,digits=(6,3))
    #select_type=fields.Selection([
        #('tax','TAX'),
        #('vat','VAT'),
        #('cst','CST'),
        #('bed','EXCISE DUTY'),
        #('ed_cess','ED CESS'),
        #('sec_cess','SEC CESS'),
        #('swach_bharat','SWACH BHARAT'),
        #('krishi_kalyan','KRISHI KALYAN'),
        #('assessable','ABATEMENT')
        #],string='Tax Type',related='tax_type.select_type',store=1,readonly=1)
    
        
class PrakrutiSalesQuotationLine(models.Model):
    _name = 'prakruti.sales_quotation_line'
    _table = 'prakruti_sales_quotation_line'
    _description = 'Prakruti Sales Quotation Information Line'
    _order= "id desc"
    
    #tarrif_id=fields.Text(string='Tarrif')
    #mrp=fields.Float(string="MRP", store=True,digits=(6,3))
    #total1= fields.Float(string='Assessable Value', readonly=True,digits=(6,3))     
    #batch_no = fields.Char(string="Batch No")
    #mfg_date = fields.Date(string='Mfg. Date')
    #exp_date = fields.Date(string="Expiry Date")
    #order_type = fields.Selection(related='main_id.order_type',string="Order Type",store=True)
    #type_of_product = fields.Selection(related='main_id.type_of_product', string="Type of Product",store=True)
    #type_of_order = fields.Selection(related='main_id.type_of_order',string="Type of Order",store=True)
    
    main_id = fields.Many2one('prakruti.sales_quotation',string="Grid")
    product_id  = fields.Many2one('product.product', string="Product Name",required=True)
    uom_id = fields.Many2one('product.uom',string="UOM",required=True)
    specification_id = fields.Many2one('product.specification.main', string = "Specification")
    description = fields.Text(string="Description")    
    actual_unit_price=fields.Float(string="Actual Unit Price",digits=(6,3))
    quantity = fields.Float(string = "Qty",required=True,digits=(6,3))
    unit_price=fields.Float(string="Unit Price",digits=(6,3))
    remarks = fields.Text(string="Remarks")
    total= fields.Float(string='Total',compute= '_compute_total')        
    #GST ENTRY ADDED HERE
    hsn_code = fields.Char(string='HSN/SAC')
    amount = fields.Float(string= 'Amount',compute= '_compute_amount')
    discount_id = fields.Many2one('account.other.tax',string= 'Discount(%)',domain=[('select_type', '=', 'discount')])
    discount = fields.Float(string= 'Discount(%)',default=0)
    taxable_value = fields.Float(string= 'Taxable Value',compute= '_compute_taxable_value')
    proportionate_amount_to_products = fields.Float(related='main_id.proportionate_amount_to_products', string="Proportionate Amount to Products")
    taxable_value_with_charges = fields.Float(string= 'Taxable Value With Charges',compute= '_compute_taxable_value_with_charges')
    gst_rate = fields.Float(string= 'GST Rate',compute= '_compute_gst_rate')    
    cgst_id = fields.Many2one('account.other.tax',string= 'CGST Rate',domain=[('select_type', '=', 'cgst')])
    cgst_value = fields.Float(related='cgst_id.per_amount',string= 'CGST Value',default=0,store=1)
    cgst_amount = fields.Float(string= 'CGST Amount',compute= '_compute_cgst_amount')    
    sgst_id = fields.Many2one('account.other.tax',string= 'SGST Rate',domain=[('select_type', '=', 'sgst')])
    sgst_value = fields.Float(related='sgst_id.per_amount',string= 'SGST Value',default=0,store=1)
    sgst_amount = fields.Float(string= 'SGST Amount',compute= '_compute_sgst_amount')    
    igst_id = fields.Many2one('account.other.tax',string= 'IGST Rate',domain=[('select_type', '=', 'igst')])
    igst_value = fields.Float(related='igst_id.per_amount',string= 'IGST Value',default=0,store=1)
    igst_amount = fields.Float(string= 'IGST Amount',compute= '_compute_igst_amount')
    
    @api.depends('cgst_amount','sgst_amount','igst_amount','taxable_value_with_charges')
    def _compute_total(self):
        for order in self:
            total = 0.0            
            order.update({                
                'total': order.taxable_value_with_charges + order.cgst_amount + order.sgst_amount + order.igst_amount
            })
    
    @api.depends('igst_value', 'taxable_value_with_charges')
    def _compute_igst_amount(self):
        for order in self:
            igst_amount = 0.0            
            order.update({                
                'igst_amount': order.taxable_value_with_charges * (order.igst_value/100)
            })
    
    @api.depends('sgst_value', 'taxable_value_with_charges')
    def _compute_sgst_amount(self):
        for order in self:
            sgst_amount = 0.0            
            order.update({                
                'sgst_amount': order.taxable_value_with_charges * (order.sgst_value/100)
            })
    
    @api.depends('cgst_value', 'taxable_value_with_charges')
    def _compute_cgst_amount(self):
        for order in self:
            cgst_amount = 0.0            
            order.update({                
                'cgst_amount': order.taxable_value_with_charges * (order.cgst_value/100)
            })
    
    @api.depends('cgst_value', 'sgst_value', 'igst_value')
    def _compute_gst_rate(self):
        for order in self:
            gst_rate = 0.0            
            order.update({                
                'gst_rate': order.cgst_value + order.sgst_value + order.igst_value
            })
    
    @api.depends('taxable_value', 'proportionate_amount_to_products')
    def _compute_taxable_value_with_charges(self):
        for order in self:
            taxable_value_with_charges = 0.0            
            order.update({                
                'taxable_value_with_charges': order.taxable_value + order.proportionate_amount_to_products 
            })
    
    @api.depends('quantity', 'unit_price')
    def _compute_amount(self):
        for order in self:
            amount = 0.0            
            order.update({                
                'amount': order.quantity * order.unit_price 
            })
    
    @api.depends('quantity', 'unit_price','amount','discount')
    def _compute_taxable_value(self):
        for order in self:
            taxable_value = 0.0            
            order.update({                
                'taxable_value': order.amount - (order.amount*(order.discount/100)) 
            }) 
    
    #@api.one
    #@api.constrains('mrp')
    #def _check_mrp(self):
        #if self.mrp < 0:
            #raise ValidationError(
                #"MRP !!! Can't be Negative")
       
    def onchange_product(self, cr, uid, ids, product_id, context=None):
        cr.execute('SELECT  product_uom.id AS uom_id,product_uom.name,product_template.name as description,product_template.list_price as unit_price FROM product_uom INNER JOIN product_template ON product_uom.id=product_template.uom_id INNER JOIN product_product ON product_template.id=product_product.product_tmpl_id WHERE product_product.id=cast(%s as integer)', ((product_id),))
        for values in cr.dictfetchall():
            uom_id = values['uom_id']
            description = values['description']
            unit_price = values['unit_price']
            return {'value' :{ 'uom_id': uom_id,'description':description,'unit_price':unit_price }}
    
    @api.one
    @api.constrains('exp_date')
    def _check_expiry_date(self):
        if self.exp_date < self.mfg_date:
            raise ValidationError(
                "Expiry Date can't be less than Manufactured date!")
    
    @api.one
    @api.constrains('unit_price')
    def _check_unit_price(self):
        if self.unit_price <= 0:
            raise ValidationError(
                "Unit Price !!! Can't be Negative OR 0 ")
    
    @api.one
    @api.constrains('quantity')
    def _check_quantity(self):
        if self.quantity <= 0:
            raise ValidationError(
                "Quantity !!! Can't be Negative OR 0 ")