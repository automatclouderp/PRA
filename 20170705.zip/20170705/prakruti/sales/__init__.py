# -*- coding: utf-8 -*-
from . import prakruti_sales_inquiry
from . import prakruti_sales_quotation
from . import prakruti_sales_order
from . import prakruti_sales_invoice
from . import prakruti_sales_proforma_invoice
from . import prakruti_sales_return
from . import prakruti_gate_pass
from . import prakruti_gate_pass_manual