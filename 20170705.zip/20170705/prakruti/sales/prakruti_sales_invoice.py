# -*- coding: utf-8 -*-
from openerp import models, fields, api
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
import re
import logging
from openerp.tools import amount_to_text
from openerp.tools.amount_to_text import amount_to_text_in 
from openerp.tools.amount_to_text import amount_to_text_in_without_word_rupees
from openerp import models, fields, api,_
from datetime import date, datetime
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp import tools
from datetime import timedelta
from openerp.osv import osv,fields
from openerp import models, fields, api, _
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
from lxml import etree
import cgi
import logging
import lxml.html
import lxml.html.clean as clean
import openerp.pooler as pooler
import random
import re
import socket
import threading
import time
from openerp.tools import image_resize_image_big
#########################################################################################################

class PrakrutiSalesInvoice(models.Model):
    _name = 'prakruti.sales_invoice'
    _table = "prakruti_sales_invoice"
    _description = 'Prakruti Sales Invoice Information'
    _order="id desc"
    _rec_name="order_no"
    
    @api.one
    @api.multi
    def _get_auto(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        for temp in self :
            cr.execute('''select cast(extract (month from invoice_date) as integer) as month ,cast(extract (year from invoice_date) as integer) as year ,id from prakruti_sales_invoice where id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
            if month_value<=3:
                year_value=year_value-1
            else:
                year_value=year_value
            next_year=year_value+1
            dispay_year=str(next_year)[-2:]
            display_present_year=str(year_value)[-2:]
            cr.execute('''select autogenerate_sales_invoice(%s)''', ((temp.id),)  ) 
            result = cr.dictfetchall()
            parent_invoice_id = 0
            for value in result: parent_invoice_id = value['autogenerate_sales_invoice'];
            auto_gen = int(parent_invoice_id)
            if len(str(auto_gen)) < 2:
                auto_gen = '000'+ str(auto_gen)
            elif len(str(auto_gen)) < 3:
                auto_gen = '00' + str(auto_gen)
            elif len(str(auto_gen)) == 3:
                auto_gen = '0'+str(auto_gen)
            else:
                auto_gen = str(auto_gen)
            for record in self :
                if record.invoice_type == 'commercial_invoice':
                    x[record.id] = 'SINV\\'+'CI-'+str(auto_gen) +'\\'+str(display_present_year)+'-'+str(dispay_year)
                    cr.execute('''UPDATE prakruti_sales_invoice SET invoice_no =%s WHERE id=%s ''', ((x[record.id]),(temp.id),))
                elif record.invoice_type == 'export_invoice':
                    x[record.id] = 'SINV\\'+'EI-'+str(auto_gen) +'\\'+str(display_present_year)+'-'+str(dispay_year)
                    cr.execute('''UPDATE prakruti_sales_invoice SET invoice_no =%s WHERE id=%s ''', ((x[record.id]),(temp.id),))
                else:
                    raise UserError(_('Oops...! Please Select Proper Invoice...'))
        return x
    
    #deemed_export_amount= fields.Float(string='Deemed Export Grand Total',compute='_compute_deemed_export_amount',digits=(6,3))
    #deemed_export_amount_in_words=fields.Text(compute='_compute_deemed_export_amount_in_words',string='Deemed Export Grand Total in Words')
    #domestic_ct1_amount= fields.Float(string='Domestic Ct1 Grand Total',compute='_compute_domestic_ct1_amount',digits=(6,3))
    #domestic_ct1_amount_in_words=fields.Text(compute='_compute_domestic_ct1_amount_in_words',string='Domestic Ct1 Grand Total in Words')
    #excise_amount= fields.Float(string='Excise Grand Total',compute='_compute_excise_amount',digits=(6,3))
    #excise_amount_in_words=fields.Text(compute='_compute_excise_amount_in_words',string='Excise Grand Total in Words')
    #meis_amount= fields.Float(string='Meis Grand Total',compute='_compute_meis_amount',digits=(6,3))
    #meis_amount_in_words=fields.Text(compute='_compute_meis_amount_in_words',string='Meis Grand Total in Words')
    #processing_amount= fields.Float(string='Processing Grand Total',compute='_compute_processing_amount',digits=(6,3))
    #processing_amount_in_words=fields.Text(compute='_compute_processing_amount_in_words',string='Processing Grand Total in Words')
    #raw_material_amount= fields.Float(string='Raw Material Grand Total',compute='_compute_raw_material_amount',digits=(6,3))
    #raw_material_amount_in_words=fields.Text(compute='_compute_raw_material_amount_in_words',string='Raw Material Grand Total in Words')
    #export_commercial_amount= fields.Float(string='Export Commercial Invoice Grand Total',compute='_compute_export_commercial_amount',digits=(6,3))
    #export_commercial_amount_in_words=fields.Text(compute='_compute_export_commercial_amount_in_words',string='Export Commercial Invoice Grand Total in Words')            
    #trading_amount= fields.Float(string='Trading Invoice Grand Total',compute='_compute_trading_amount',digits=(6,3))
    #trading_amount_in_words=fields.Text(compute='_compute_trading_amount_in_words',string='Trading Invoice Grand Total in Words')
    #trading_bed_amount_in_words=fields.Text(compute='_compute_trading_bed_amount_in_words',string='Trading Invoice Bed Grand Total in Words')  
    #formulation_amount= fields.Float(string='Formulation Excise Invoice Grand Total',compute='_compute_formulation_amount',digits=(6,3))
    #formulation_amount_in_words=fields.Text(compute='_compute_formulation_amount_in_words',string='Formulation Excise Invoice Grand Total in Words')
    #formulation_assessable_value= fields.Float(string='Formulation Excise Invoice Assesable Total',compute='_compute_assessable_line_subtotal',digits=(6,3))
    #formulation_bed_iamt_amount= fields.Float(string='Formulation Excise Invoice Bed Total',compute='_compute_bed_line_subtotal',digits=(6,3))
    #formulation_ed_cess_iamt_amount= fields.Float(string='Formulation Excise Invoice Ed Cess Total',compute='_compute_ed_cess_line_subtotal',digits=(6,3))
    #formulation_sec_cess_iamt_amount= fields.Float(string='Formulation Excise Invoice Sec Cess Total',compute='_compute_sec_cess_line_subtotal',digits=(6,3))            
    #commercial_sales_invoice_amount= fields.Float(string='Commercial Invoice Grand Total',compute='_compute_commercial_sales_invoice_amount',digits=(6,3))
    #commercial_sales_invoice_amount_in_words=fields.Text(compute='_compute_commercial_sales_invoice_amount_in_words',string='Commercial Invoice Grand Total in Words')
    #formulation_bed_iamt_amount_in_words=fields.Text(compute='_compute_formulation_bed_iamt_amount_in_words',string='Formulation Bed Amount in Words')
    invoice_type = fields.Selection([
        ('commercial_invoice','Commercial Invoice'),
        ('export_invoice','Export Invoice')
        ], string="Invoice Type", default='commercial_invoice')
    invoice_no = fields.Char('Invoice No:', readonly=True, default='New')
    invoice_date = fields.Date('Invoice Date',default= fields.Date.today)
    order_no = fields.Many2one('prakruti.sales_order', string='Order No',readonly=True)
    order_date = fields.Date('Order Date.',readonly=True)
    supplier_ref = fields.Char('Buyer/Customer Reference')
    other_ref = fields.Char('Other Referrence')
    customer_id = fields.Many2one ('res.partner',string= 'Customer',readonly=True)
    billing_id = fields.Many2one('res.partner',string='Billing Address')
    shipping_id = fields.Many2one('res.partner',string='Shipping Address')
    dispatch_through = fields.Char(string='Dispatch Through')
    destination = fields.Char(string='Destination')
    terms_delivery = fields.Char('Terms Of Delivery')
    delivery_note= fields.Integer(' Delivery Note')
    delivery_date = fields.Date('Delivery Date')
    terms_payment = fields.Char('Terms Of Payment')
    bl_no = fields.Char('B/L No')
    bl_date = fields.Date('B/L Date')
    vessal_name = fields.Char('Vessal Name')
    country_origin = fields.Char('Country Origin')
    invoice_datetime =fields.Datetime(string='Date and time of issue of invoice')
    goods_datetime =fields.Datetime(string='Date and time of Removal of Goods')
    vehicle_no = fields.Char(string='Motor Vehicle No')
    exporter_datetime =fields.Datetime(string='Exporters Ref Date and time ')
    product_type_id=fields.Many2one('product.group',string= 'Product Type')
    order_type = fields.Selection([('with_tarrif','Sales'),('without_tarrif','PS')], string="Order Type", default='without_tarrif')
    company_address = fields.Many2one('res.company',string='Company Address')
    #subtotal= fields.Float(string='Sub Total',readonly=True,digits=(6,3))
    #assessable_value=fields.Float(string='Assessable Value(%)',digits=(6,3))
    #total_assessable_value= fields.Float(string='Total Assesable value',readonly=True,digits=(6,3))
    #assessable_subtotal=fields.Float(string='Assesable  Total',readonly=True,digits=(6,3))
    #bed_type= fields.Many2one('account.other.tax', string='BED TYPE', domain=[('active', '=', True),('select_type','=','bed')])
    #bed_percentage = fields.Float(related='bed_type.per_amount',string="BED %", store=True,readonly=True,digits=(6,3))
    #bed_qty = fields.Float(related='bed_type.amount',string="BED Qty.", store=True,readonly=True,digits=(6,3))
    #bed_amt = fields.Float(string="BED Total",readonly=True,digits=(6,3))
    #what_is_bed_type=fields.Selection([('per_amount','%'),('amount','Amount')],related='bed_type.tax_type',string='What is Bed Type',store=True)
    #ed_cess_type = fields.Many2one('account.other.tax', string='ED CESS TYPE', domain=[('active', '=', True),('select_type','=','ed_cess')])
    #ed_cess_percentage = fields.Float(related='ed_cess_type.per_amount',string="Ed Cess %", store=True,readonly=True,digits=(6,3))
    #ed_cess_qty = fields.Float(related='ed_cess_type.amount',string="Ed Cess Qty.", store=True,readonly=True,digits=(6,3))
    #ed_cess_amt = fields.Float(string="Ed Cess Total",readonly=True,digits=(6,3))
    #what_is_ed_cess_type=fields.Selection([('per_amount','%'),('amount','Amount')],related='ed_cess_type.tax_type',string='What is Ed Cess Type',store=True)
    #sec_cess_type = fields.Many2one('account.other.tax', string='SEC CESS TYPE', domain=[('active', '=', True),('select_type','=','sec_cess')])
    #sec_cess_percentage = fields.Float(related='sec_cess_type.per_amount',string="Sec Cess %", store=True,readonly=True,digits=(6,3))
    #sec_cess_qty = fields.Float(related='sec_cess_type.amount',string="Sec Cess Qty.", store=True,readonly=True,digits=(6,3))
    #sec_cess_amt = fields.Float(string="Sec Cess Total",readonly=True,digits=(6,3))
    #what_is_sec_cess_type=fields.Selection([('per_amount','%'),('amount','Amount')],related='sec_cess_type.tax_type',string='What is Sec Cess Type',store=True)
    #tax_id = fields.Many2one('account.other.tax', string='Tax', domain=[('active', '=', True),('select_type','=','tax')])
    #tax_value = fields.Float(related='tax_id.per_amount',string='Tax %', store=True,readonly=True,digits=(6,3))
    #total_tax = fields.Float(string="Total Tax",readonly=True,digits=(6,3))
    #vat_id = fields.Many2one('account.other.tax', string='Vat', domain=[('active', '=', True),('select_type','=','vat')])
    #vat_value = fields.Float(related='vat_id.per_amount',string='Vat %', store=True,readonly=True,digits=(6,3))
    #total_vat = fields.Float(string="Total Vat",readonly=True,digits=(6,3))
    #cst_id = fields.Many2one('account.other.tax', string='Cst', domain=[('active', '=', True),('select_type','=','cst')])
    #cst_value = fields.Float(related='cst_id.per_amount',string='Cst %', store=True,readonly=True,digits=(6,3))
    #total_cst = fields.Float(string="Total Cst",readonly=True,digits=(6,3))
    #sbc_id =  fields.Many2one('account.other.tax', string='Swachh Bharat', domain=[('active', '=', True),('select_type','=','swach_bharat')])
    #sbc_value = fields.Float(related='sbc_id.per_amount',string='Swachh %', store=True,readonly=True,digits=(6,3))
    #total_sbc = fields.Float(string="Swachh Bharat Cess",readonly=True,digits=(6,3))
    #kkc_id =  fields.Many2one('account.other.tax', string='Krishi Kalyan', domain=[('active', '=', True),('select_type','=','krishi_kalyan')])
    #kkc_value = fields.Float(related='kkc_id.per_amount',string='Krishi %', store=True,readonly=True,digits=(6,3))
    #total_kkc = fields.Float(string="Krishi Kalayan Cess",readonly=True,digits=(6,3))
    #tax_line_id = fields.One2many('sales.invoice.tax.line','ref_id',string='All Taxes')
    #new_bed_amt = fields.Float(string="New BED Total",readonly=1,digits=(6,3))
    #new_bed_percent = fields.Float(string="New BED Percent",readonly=1,digits=(6,3))
    #new_bed_value = fields.Float(string="New BED Value",readonly=1,digits=(6,3))
    #new_bed_type = fields.Char(string='Type',readonly=1)
    #new_ed_cess_amt = fields.Float(string="New Ed Cess Total",readonly=1,digits=(6,3))
    #new_ed_cess_percent = fields.Float(string="New ED Cess Percent",readonly=1,digits=(6,3))
    #new_ed_cess_value = fields.Float(string="New ED Cess Value",readonly=1,digits=(6,3))
    #new_ed_cess_type = fields.Char(string='Type',readonly=1)
    #new_sec_cess_amt = fields.Float(string="New Sec Cess Total",readonly=1,digits=(6,3))
    #new_sec_cess_percent = fields.Float(string="New Sec Cess Percent",readonly=1,digits=(6,3))
    #new_sec_cess_value = fields.Float(string="New Sec Cess Value",readonly=1,digits=(6,3))
    #new_sec_cess_type = fields.Char(string='Type',readonly=1)
    #new_total_tax = fields.Float(string="New Total Tax",readonly=1,digits=(6,3))
    #new_tax_percent = fields.Float(string="New Tax Percent",readonly=1,digits=(6,3))
    #new_tax_value = fields.Float(string="New Tax Value",readonly=1,digits=(6,3))
    #new_total_vat = fields.Float(string="New Total Vat",readonly=1,digits=(6,3))
    #new_vat_percent = fields.Float(string="New Vat Percent",readonly=1,digits=(6,3))
    #new_vat_value = fields.Float(string="New Vat Value",readonly=1,digits=(6,3))
    #new_total_cst = fields.Float(string="New Total Cst",readonly=1,digits=(6,3))
    #new_cst_percent = fields.Float(string="New Cst Percent",readonly=1,digits=(6,3))
    #new_cst_value = fields.Float(string="New Cst Value",readonly=1,digits=(6,3))
    #new_total_sbc = fields.Float(string="New Swachh Bharat",readonly=1,digits=(6,3))
    #new_sbc_percent = fields.Float(string="New Sbc Percent",readonly=1,digits=(6,3))
    #new_sbc_value = fields.Float(string="New Sbc Value",readonly=1,digits=(6,3))
    #new_total_kkc = fields.Float(string="New Krishi Kalayan",readonly=1,digits=(6,3))
    #new_kkc_percent = fields.Float(string="New Kkc Percent",readonly=1,digits=(6,3))
    #new_kkc_value = fields.Float(string="New Kkc Value",readonly=1,digits=(6,3))
    remarks = fields.Text(string="Remarks")
    serial_no = fields.Char(string='Serial No')
    form_to_recieve = fields.Char(string='Form to Recieve')
    excise_declaration = fields.Text(string="Excise declaration")
    #untaxed_amount = fields.Float(string="Untaxed Amount",readonly=True,digits=(6,3))
    #transporatation_charges=fields.Float(string='Trasportation Charges',digits=(6,3))
    #final_grand_total = fields.Float(string=" Grand Total",readonly=True,digits=(6,3))
    state =fields.Selection([
            ('inquiry', 'Inquiry'),
            ('quotation','Quotation'),
            ('order','Order'),
            ('partially_confirmed','Partially Invoiced'),
            ('invoice','Invoice'),
            ('return','Returned')
            ],default= 'invoice', string= 'Status')
    grid_id = fields.One2many('prakruti.sales_invoice_line', 'main_id',string='Grid')
    inv_no = fields.Char('Order Number', compute='_get_auto')
    auto_no = fields.Integer('Auto')
    req_no_control_id = fields.Integer('Auto Generating id',default= 0)
    dispatch_no = fields.Char(string='Dispatch No',readonly=True)
    dispatch_date = fields.Date('Dispatch Date',readonly=True)
    vat_tin = fields.Char('Companys VAT TIN')
    buyer_vat_tin = fields.Char('Buyers VAT TIN')
    cst_no = fields.Char('Companys CST No')
    buyer_cst_no = fields.Char('Buyers CST No')
    tax_no = fields.Char('TAX No')
    pan_no = fields.Char('PAN No')
    excise_regn_no = fields.Char('Excise regn No')
    port_of_landing = fields.Char('Port Of landing')
    port_of_discharge = fields.Char('Port Of Discharge')
    bank_details = fields.Char('Bank Details')
    #grand_total_in_words= fields.Text( compute= '_get_grand_total_in_words' ,method=True, string='Grand Total in words')
    #cess_amount_in_words=fields.Text(compute='_get_cess_amount_in_words',string='Amount of Cess in words')
    #final_grand_total_in_words=fields.Text(compute='_get_final_grand_total_in_words',string='Final Grand total in words')
    #fomulation_commercial_final_grand_total_in_words=fields.Text(compute='_get_fomulation_commercial_final_grand_total_in_words',string='Formulation Grand total in words')
    dispatch_id =fields.Many2one('res.users','Dispatch By') 
    requested_id =fields.Many2one('res.users','Requested By')
    quotation_id =fields.Many2one('res.users','Quotation By')
    order_id =fields.Many2one('res.users','Order By') 
    return_id =fields.Many2one('res.users','Return By') 
    #Payment Terms
    any_adv_payment =fields.Selection([
                    ('no', 'No'),
                    ('yes','Yes')
                    ], string= 'Any Advance Payment',readonly=1)
    advance_payment_type =fields.Selection([
                    ('cash', 'CASH'),
                    ('cheque','CHEQUE'),
                    ('demand_draft','DEMAND DRAFT')
                    ], string= 'Any Advance Payment Done By',readonly=1)
    cash_amount = fields.Float(string="Amount",readonly=1,digits=(6,3))
    cash_remarks = fields.Text(string="Remarks",readonly=1)    
    cheque_amount = fields.Float(string="Amount",readonly=1,digits=(6,3))
    cheque_no = fields.Integer(string="Cheque No.",readonly=1)
    cheque_remarks = fields.Text(string="Remarks",readonly=1)    
    draft_amount = fields.Float(string="Amount",readonly=1,digits=(6,3))
    draft_no = fields.Integer(string="Draft No.",readonly=1)
    draft_remarks = fields.Text(string="Remarks",readonly=1)
    #po_no = fields.Many2one('prakruti.purchase_order',string='P.O No.')    
    po_no = fields.Char(string='P.O No.')
    # FOR NEW CALCULATION ITS BEING ADDED   
    #type_of_product = fields.Selection([
        #('extraction','Extraction'),
        #('formulation','Formulation')], default='extraction', string="Type of Product")
    #type_of_order = fields.Selection([
        #('sales','SALES'),
        #('ps','PHYSICIAN SAMPLE')
        #],default='sales',string="Type of Order")   
    slip_no= fields.Char(string='Slip No.',readonly=1)#20170420
    reference_no= fields.Char(string='Ref No')
    reference_date= fields.Date(string='Ref Date') 
    product_id = fields.Many2one('product.product', related='grid_id.product_id', string='Product Name')
    
    
    
    #GST ENTRY
    total_no_of_products = fields.Integer(string="Total No of Products",compute= '_compute_total_no_of_products')
    proportionate_amount_to_products = fields.Float(string="Proportionate Amount to Products",compute= '_compute_proportionate_amount_to_products')
    freight_charges = fields.Float(string="Freight Charges")
    loading_and_packing_charges = fields.Float(string="Loading and Packing Charges")
    insurance_charges = fields.Float(string="Insurance Charges")
    other_charges =  fields.Float(string="Other Charges")
    all_additional_charges = fields.Float(string="All Additional Charges",compute= '_compute_all_additional_charges')#SUM OF all charges like freight_charges loading_and_packing_charges insurance_charges other_charges  
    total_amount_before_tax = fields.Float(string="Untaxed Amount",compute= '_compute_total_amount_before_tax')#SUM OF Taxable value after adding other charges
    total_cgst_amount = fields.Float(string="CGST Amount",compute= '_compute_total_cgst_amount')
    total_sgst_amount = fields.Float(string="SGST Amount",compute= '_compute_total_sgst_amount')
    total_igst_amount = fields.Float(string="IGST Amount",compute= '_compute_total_igst_amount')
    
    total_gst_amount = fields.Float(string="Total GST",compute= '_compute_total_gst_amount')  
    
    total_amount_after_tax = fields.Float(string="Total",compute= '_compute_total_amount_after_tax')#SUM OF Subtotal of the grid
    grand_total= fields.Float(string='Grand Total',compute= '_compute_grand_total')
    grand_total_in_words= fields.Text(compute= '_get_total_in_words',string='Total in words')
    
    type_of_gst = fields.Selection([
        ('cgst_sgst','CGST/SGST'),('igst','IGST')],default='cgst_sgst',string='Type Of GST')
    
    @api.depends('total_amount_after_tax','grand_total')
    def _get_total_in_words(self):
        for order in self:
            grand_total = val1 = 0.0
            val1_in_words = ""
            val1 = order.grand_total
            val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            order.update({                    
                'grand_total_in_words': val1_in_words.upper()
                })
    
    @api.model
    def _default_company(self):
        return self.env['res.company']._company_default_get('res.partner')
    
    _defaults = {
        'company_address': _default_company,
        'return_id': lambda s, cr, uid, c:uid
        }
    
    
    @api.depends('total_amount_after_tax','cash_amount','cheque_amount','draft_amount')
    def _compute_grand_total(self):
        for order in self:
            grand_total = total_amount_after_tax = draft_amount = cheque_amount = cash_amount = 0
            order.update({
                'grand_total': order.total_amount_after_tax - order.cash_amount - order.cheque_amount - order.draft_amount
                })
    
    
    @api.depends('grid_id.total')
    def _compute_total_amount_after_tax(self):
        for order in self:
            total_amount_after_tax = line_amount =0
            for line in order.grid_id:
                line_amount += line.total
                order.update({
                    'total_amount_after_tax': line_amount
                    })
    
    
    @api.depends('total_cgst_amount','total_sgst_amount','total_igst_amount')
    def _compute_total_gst_amount(self):
        for order in self:
            total_gst_amount = 0
            order.update({
                'total_gst_amount': order.total_cgst_amount + order.total_sgst_amount + order.total_igst_amount
                })
    
    
    @api.depends('grid_id.igst_amount')
    def _compute_total_igst_amount(self):
        for order in self:
            total_igst_amount = t_igst_amount =0
            for line in order.grid_id:
                t_igst_amount += line.igst_amount
                order.update({
                    'total_igst_amount': t_igst_amount
                    })
    
    
    @api.depends('grid_id.sgst_amount')
    def _compute_total_sgst_amount(self):
        for order in self:
            total_sgst_amount = t_sgst_amount =0
            for line in order.grid_id:
                t_sgst_amount += line.sgst_amount
                order.update({
                    'total_sgst_amount': t_sgst_amount
                    })
    
    
    @api.depends('grid_id.cgst_amount')
    def _compute_total_cgst_amount(self):
        for order in self:
            total_cgst_amount = t_cgst_amount = 0
            for line in order.grid_id:
                t_cgst_amount += line.cgst_amount
                order.update({
                    'total_cgst_amount': t_cgst_amount
                    })
    
    
    @api.depends('grid_id.taxable_value_with_charges')
    def _compute_total_amount_before_tax(self):
        for order in self:
            total_amount_before_tax = taxed_value_with_charges =0
            for line in order.grid_id:
                taxed_value_with_charges += line.taxable_value_with_charges
                order.update({
                    'total_amount_before_tax': taxed_value_with_charges
                    })
    
    
    @api.depends('grid_id.quantity')
    def _compute_total_no_of_products(self):
        for order in self:
            total_no_of_products = no_of_qty = 0
            for line in order.grid_id:
                no_of_qty += line.quantity
                order.update({
                    'total_no_of_products': no_of_qty
                    })
    
    @api.depends('freight_charges', 'loading_and_packing_charges','insurance_charges', 'other_charges')
    def _compute_all_additional_charges(self):
        for order in self:
            all_additional_charges = 0.0            
            order.update({                
                'all_additional_charges': order.freight_charges + order.loading_and_packing_charges + order.insurance_charges + order.other_charges
            })
    
    @api.depends('freight_charges', 'loading_and_packing_charges','insurance_charges', 'other_charges','total_no_of_products')
    def _compute_proportionate_amount_to_products(self):
        for order in self:
            proportionate_amount_to_products = 0.0            
            order.update({                
                'proportionate_amount_to_products': order.all_additional_charges/order.total_no_of_products
            })    
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['inquiry','quotation','order','invoice','return']:
                raise UserError(_('Can\'t Delete...'))
        return super(PrakrutiSalesInvoice, self).unlink() 
    
    
    
    
    def _check_invoice_type(self, cr, uid, ids):
        lines = self.browse(cr, uid, ids)
        for line in lines:
            if not line.invoice_type:
                return False
        return True
     
    _constraints = [
         (_check_invoice_type, 'Oops...! Please Select Proper Invoice...', ['invoice_type'])
    ]
    
    
    #def update_sales_order_tax_line(self, cr, uid, ids, context=None, *args):
        #for temp in self.browse(cr, uid, ids, context={}):
            #print 'update_sales_order_tax_lineupdate_sales_order_tax_lineupdate_sales_order_tax_lineupdate_sales_order_tax_lineupdate_sales_order_tax_line' * 100
            #cr.execute(''' INSERT INTO sales_order_tax_line(tax_type,tax_percent,tax_amount,total_value,select_type,ref_id)SELECT sales_invoice_tax_line.tax_type,sales_invoice_tax_line.tax_percent,sales_invoice_tax_line.tax_amount,sales_invoice_tax_line.total_value,sales_invoice_tax_line.select_type,prakruti_sales_invoice.order_no FROM sales_invoice_tax_line INNER JOIN prakruti_sales_invoice ON prakruti_sales_invoice.id = sales_invoice_tax_line.ref_id WHERE sales_invoice_tax_line.tax_type NOT IN(SELECT sales_order_tax_line.tax_type FROM sales_order_tax_line  INNER JOIN prakruti_sales_invoice ON prakruti_sales_invoice.order_no = sales_order_tax_line.ref_id INNER JOIN sales_invoice_tax_line ON sales_invoice_tax_line.ref_id = prakruti_sales_invoice.id WHERE sales_invoice_tax_line.ref_id = %s) AND sales_invoice_tax_line.ref_id = %s; ''',((temp.id),(temp.id),))
        #return {}
    
    #@api.one
    #@api.multi 
    #def action_calculate(self):
        #print '9' * 100
        #cr = self.env.cr
        #uid = self.env.uid
        #ids = self.ids
        #context = 'context'
        #print '10' * 100        
        #for temp in self:
            #cr.execute(''' SELECT update_sales_invoice_calculation(%s)''',((temp.id),))
            #cr.execute(''' UPDATE prakruti_sales_invoice_line as b set sec_cess_ipercentage = a.new_sec_cess_percent,ed_cess_ipercentage = a.new_ed_cess_percent,bed_iamt=a.new_bed_amt,bed_ipercentage = a.new_bed_percent,assessable_value = a.assessable_value,bed_itype =a.new_bed_type,ed_cess_itype =a.new_ed_cess_type,sec_cess_itype =a.new_sec_cess_type,ed_cess_iamt = a.new_ed_cess_amt,sec_cess_iamt = a.new_sec_cess_amt,iv_assessable_value=a.total_assessable_value FROM( SELECT new_sec_cess_percent,new_ed_cess_percent,new_bed_percent,assessable_value,new_bed_type,new_ed_cess_type,new_sec_cess_type,id,new_bed_amt,new_ed_cess_amt,new_sec_cess_amt,total_assessable_value FROM prakruti_sales_invoice WHERE id= %s ) as a WHERE a.id = b.main_id ''',((temp.id),))
        #return {}    
    
    
    @api.one
    @api.multi 
    def invoice_to_return(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            return_order_line = self.pool.get('prakruti.sales_return').create(cr,uid, {
                'order_no':temp.order_no.id,
                'order_date':temp.order_date,
                'invoice_no':temp.invoice_no,
                'invoice_date':temp.invoice_date,
                'dispatch_to':temp.customer_id.id,
                'company_id':temp.company_address.id,
                'product_type_id':temp.product_type_id.id,
                'dispatch_id':temp.dispatch_id.id,
                'order_id':temp.order_id.id,
                'quotation_id':temp.quotation_id.id,
                'requested_id':temp.requested_id.id,
                'return_id':temp.return_id.id,
                'return_type':'return_by_customer',
                'reference_no':temp.reference_no,
                'reference_date':temp.reference_date
                 })
            for item_line in temp.grid_id:
                product_line = self.pool.get('prakruti.sales_return_items').create(cr,uid, {
                    'product_id':item_line.product_id.id,
                    'uom_id':item_line.uom_id.id,
                    'specification_id':item_line.specification_id.id,
                    'description':item_line.description,
                    'rejected_qty':item_line.quantity,
                    'ordered_qty':item_line.quantity,
                    'unit_price':item_line.unit_price,
                    'batch_no':item_line.batch_no.id,
                    'main_id': return_order_line
                    })
            tracking_order_line = self.pool.get('prakruti.logistics_invoice_tracking').create(cr,uid, {
                'order_no':temp.order_no.id,
                'order_date':temp.order_date,
                'customer_id':temp.customer_id.id,
                'invoice_no':temp.invoice_no,
                'invoice_date':temp.invoice_date,
                'reference_no':temp.reference_no,
                'dispatch_id':temp.dispatch_id.id,
                'order_id':temp.order_id.id,
                'quotation_id':temp.quotation_id.id,
                'requested_id':temp.requested_id.id,
                 })
            for item_line in temp.grid_id:
                product_line = self.pool.get('prakruti.sales_line_in_logistics').create(cr,uid, {
                    'product_id':item_line.product_id.id,
                    'uom_id':item_line.uom_id.id,
                    'quantity':item_line.quantity,
                    'unit_price': item_line.unit_price,
                    #'no_of_packings': item_line.no_of_packings,
                    #'packing_style': item_line.packing_style,
                    #'extra_packing': item_line.extra_packing,
                    'packing_details': item_line.packing_details,
                    'logistics_line_id': tracking_order_line
                    })
            gatepass_order_line = self.pool.get('prakruti.gate_pass').create(cr,uid, {
                'order_no':temp.order_no.id,
                'sales_order_date':temp.order_date,
                'customer_id':temp.customer_id.id,
                'vendor_id':temp.customer_id.id,
                'company_id':temp.company_address.id,
                'coming_from':'sales_return',
                'document_type':'inward',
                'reference_no':temp.reference_no
                 })
            for item_line in temp.grid_id:
                product_line = self.pool.get('prakruti.gate_pass_line').create(cr,uid, {
                    'product_id':item_line.product_id.id,
                    'uom_id':item_line.uom_id.id,
                    'unit_price': item_line.unit_price,
                    'description': item_line.description,
                    'recieved_qty':item_line.quantity,
                    'quantity':item_line.quantity,
                    'main_id': gatepass_order_line
                    })
            cr.execute("UPDATE prakruti_sales_invoice SET state = 'return' WHERE prakruti_sales_invoice.id = cast(%s as integer)",((temp.id),))
        return {}
    
    #@api.depends('grid_id.quantity','grid_id.unit_price','bed_type','total_assessable_value','bed_percentage','bed_qty','bed_amt')
    #def _get_grand_total_in_words(self):
        #for order in self:
            #bed_amt =val1=0.0
            #val1_in_words = ""
            #bed_amt= (order.total_assessable_value )* (order.bed_percentage/100)
            
            #val1 = bed_amt
            #val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            #print 'Grand Total in Words--------------------Grand Total in Words',val1_in_words.title()
            #order.update({                    
                #'grand_total_in_words': val1_in_words.title()
                #})
                
    #@api.depends('grid_id.quantity','grid_id.unit_price','bed_type','total_assessable_value','bed_percentage','bed_qty','bed_amt')
    #def _get_cess_amount_in_words(self):
        #for order in self:
            #sec_cess_amt =val1=0.0
            #val1_in_words = ""
            #sec_cess_amt= ((order.new_bed_amt )* (order.new_ed_cess_percent/100))
            
            #val1 = sec_cess_amt
            #val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            #print 'Cess Amount in Words-----------------------Cess Amount in Words',val1_in_words.title()
            #order.update({                    
                #'cess_amount_in_words': val1_in_words.title()
                #})
                
    #@api.depends('grid_id.quantity','grid_id.unit_price','bed_type','total_assessable_value','bed_percentage','bed_qty','bed_amt')
    #def _get_final_grand_total_in_words(self):
        #for order in self:
            #final_grand_total =val1=0.0
            #val1_in_words = ""
            #final_grand_total=(order.untaxed_amount )+(order.transporatation_charges )+(order.total_tax )+(order.total_sbc )+(order.total_kkc )-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
            
            #val1 = final_grand_total
            #val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            #print 'Final Grand Total in Words---------------------------------Final Grand Total in Words',val1_in_words.title()
            #order.update({                    
                #'final_grand_total_in_words': val1_in_words.title()
                #})
                
    #@api.depends('grid_id.quantity','grid_id.unit_price','bed_type','total_assessable_value','bed_percentage','bed_qty','bed_amt')
    #def _get_fomulation_commercial_final_grand_total_in_words(self):
        #for order in self:
            #final_grand_total =val1=0.0
            #val1_in_words = ""
            #final_grand_total=(order.untaxed_amount )+(order.transporatation_charges )+(order.new_total_tax )+(order.new_total_sbc )+(order.new_total_kkc)+(order.new_total_vat)+(order.new_total_cst)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
            
            #val1 = final_grand_total
            #val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            #print 'Formulation Commercial Final Grand Total in Words---------------------------------Formulation Commercial Final Grand Total in Words',val1_in_words.title()
            #order.update({                    
                #'fomulation_commercial_final_grand_total_in_words': val1_in_words.title()
                #})
            
    #@api.depends('subtotal','transporatation_charges')
    #def _compute_deemed_export_amount(self):
        #deemed_export_amount = subtotal = transporatation_charges = 0.0
        #for order in self:
            #order.update({
                #'deemed_export_amount': (order.subtotal)+(order.transporatation_charges)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
                    #})
            
    #@api.depends('subtotal','transporatation_charges')
    #def _compute_deemed_export_amount_in_words(self):
        #for order in self:
            #final_grand_total =val1=0.0
            #val1_in_words = ""
            #final_grand_total=(order.subtotal)+(order.transporatation_charges)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
            #val1 = final_grand_total
            #val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            #print 'Final Grand Total in Words---------------------------------Final Grand Total in Words',val1_in_words.title()
            #order.update({                    
                #'deemed_export_amount_in_words': val1_in_words.title()
                #})
    
    ##In Print for Domestic CT1 Invoice
    #@api.depends('subtotal','transporatation_charges','new_vat_value')
    #def _compute_domestic_ct1_amount(self):
        #domestic_ct1_amount = subtotal = transporatation_charges = new_vat_value =0.0
        #for order in self:
            #order.update({
                #'domestic_ct1_amount': (order.subtotal)+(order.transporatation_charges) + (order.new_vat_value)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
                    #})
            
    #@api.depends('subtotal','transporatation_charges','new_vat_value')
    #def _compute_domestic_ct1_amount_in_words(self):
        #for order in self:
            #final_grand_total =val1=0.0
            #val1_in_words = ""
            #final_grand_total=(order.subtotal)+(order.transporatation_charges) + (order.new_vat_value)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
            #val1 = final_grand_total
            #val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            #print 'Final Grand Total in Words---------------------------------Final Grand Total in Words',val1_in_words.title()
            #order.update({                    
                #'domestic_ct1_amount_in_words': val1_in_words.title()
                #})
    
    ##In Print for Excise Invoice
    #@api.depends('subtotal','transporatation_charges','new_bed_value','new_cst_value')
    #def _compute_excise_amount(self):
        #excise_amount = subtotal = transporatation_charges = new_bed_value = new_cst_value = 0.0
        #for order in self:
            #order.update({
                #'excise_amount': (order.subtotal)+(order.transporatation_charges) + (order.new_bed_value) + (order.new_cst_value)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
                    #})
            
    #@api.depends('subtotal','transporatation_charges','new_bed_value','new_cst_value')
    #def _compute_excise_amount_in_words(self):
        #for order in self:
            #final_grand_total =val1=0.0
            #val1_in_words = ""
            #final_grand_total=(order.subtotal)+(order.transporatation_charges) + (order.new_bed_value) + (order.new_cst_value)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
            #val1 = final_grand_total
            #val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            #print 'Final Grand Total in Words---------------------------------Final Grand Total in Words',val1_in_words.title()
            #order.update({                    
                #'excise_amount_in_words': val1_in_words.title()
                #})
    
    ##In Print for Meis Invoice
    #@api.depends('subtotal','new_vat_value')
    #def _compute_meis_amount(self):
        #meis_amount = subtotal = new_vat_value = 0.0
        #for order in self:
            #order.update({
                #'meis_amount': (order.subtotal)+(order.new_vat_value)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
                    #})
            
    #@api.depends('subtotal','new_vat_value')
    #def _compute_meis_amount_in_words(self):
        #for order in self:
            #final_grand_total =val1=0.0
            #val1_in_words = ""
            #final_grand_total=(order.subtotal)+(order.new_vat_value)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
            #val1 = final_grand_total
            #val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            #print 'Final Grand Total in Words---------------------------------Final Grand Total in Words',val1_in_words.title()
            #order.update({                    
                #'meis_amount_in_words': val1_in_words.title()
                #})
    
    ##In Print for Processing Invoice
    #@api.depends('subtotal','new_sbc_value','new_kkc_value')
    #def _compute_processing_amount(self):
        #processing_amount = subtotal = new_sbc_value = new_kkc_value = 0.0
        #for order in self:
            #order.update({
                #'processing_amount': (order.subtotal)+(order.new_sbc_value)+(order.new_kkc_value)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
                    #})
            
    #@api.depends('subtotal','new_sbc_value','new_kkc_value')
    #def _compute_processing_amount_in_words(self):
        #for order in self:
            #final_grand_total =val1=0.0
            #val1_in_words = ""
            #final_grand_total=(order.subtotal)+(order.new_sbc_value)+(order.new_kkc_value)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
            #val1 = final_grand_total
            #val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            #print 'Final Grand Total in Words---------------------------------Final Grand Total in Words',val1_in_words.title()
            #order.update({                    
                #'processing_amount_in_words': val1_in_words.title()
                #})
    
    ##In Print for Raw Material Invoice
    #@api.depends('subtotal','new_cst_value')
    #def _compute_raw_material_amount(self):
        #raw_material_amount = subtotal = new_cst_value = 0.0
        #for order in self:
            #order.update({
                #'raw_material_amount': (order.subtotal)+(order.new_cst_value)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
                    #})
            
    #@api.depends('subtotal','new_cst_value')
    #def _compute_raw_material_amount_in_words(self):
        #for order in self:
            #final_grand_total =val1=0.0
            #val1_in_words = ""
            #final_grand_total=(order.subtotal)+(order.new_cst_value)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
            #val1 = final_grand_total
            #val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            #print 'Final Grand Total in Words---------------------------------Final Grand Total in Words',val1_in_words.title()
            #order.update({                    
                #'raw_material_amount_in_words': val1_in_words.title()
                #})
    
    ##In Print for Export Commercial Invoice
    #@api.depends('subtotal')
    #def _compute_export_commercial_amount(self):
        #export_commercial_amount = 0.0
        #for order in self:
            #order.update({
                #'export_commercial_amount': (order.subtotal)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
                    #})
            
    #@api.depends('subtotal')
    #def _compute_export_commercial_amount_in_words(self):
        #for order in self:
            #final_grand_total =val1=0.0
            #val1_in_words = ""
            #final_grand_total=(order.subtotal)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
            #val1 = final_grand_total
            #val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            #print 'Final Grand Total in Words---------------------------------Final Grand Total in Words',val1_in_words.title()
            #order.update({                    
                #'export_commercial_amount_in_words': val1_in_words.title()
                #})
    
    ##In Print for Trading Invoice
    #@api.depends('subtotal','new_cst_value','new_bed_value')
    #def _compute_trading_amount(self):
        #trading_amount = 0.0
        #for order in self:
            #order.update({
                #'trading_amount': (order.subtotal) + (order.new_cst_value) + (order.new_bed_value)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
                    #})
            
    #@api.depends('subtotal','new_cst_value','new_bed_value')
    #def _compute_trading_amount_in_words(self):
        #for order in self:
            #final_grand_total =val1=0.0
            #val1_in_words = ""
            #final_grand_total=(order.subtotal) + (order.new_cst_value) + (order.new_bed_value)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
            #val1 = final_grand_total
            #val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            #print 'Final Grand Total in Words---------------------------------Final Grand Total in Words',val1_in_words.title()
            #order.update({                    
                #'trading_amount_in_words': val1_in_words.title()
                #})
            
    #@api.depends('new_bed_value')
    #def _compute_trading_bed_amount_in_words(self):
        #for order in self:
            #final_grand_total =val1=0.0
            #val1_in_words = ""
            #final_grand_total=(order.new_bed_value)
            #val1 = final_grand_total
            #val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            #print 'Final Grand Total in Words---------------------------------Final Grand Total in Words',val1_in_words.title()
            #order.update({                    
                #'trading_bed_amount_in_words': val1_in_words.title()
                #})
    
    ##In Print for Formulation Excise Invoice
    #@api.depends('subtotal','new_bed_value')
    #def _compute_formulation_amount(self):
        #formulation_amount = 0.0
        #for order in self:
            #order.update({
                #'formulation_amount': (order.subtotal) + (order.new_bed_value)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
                    #})
            
    #@api.depends('subtotal','new_bed_value')
    #def _compute_formulation_amount_in_words(self):
        #for order in self:
            #final_grand_total =val1=0.0
            #val1_in_words = ""
            #final_grand_total=(order.subtotal) + (order.new_bed_value)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
            #val1 = final_grand_total
            #val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            #print 'Final Grand Total in Words---------------------------------Final Grand Total in Words',val1_in_words.title()
            #order.update({                    
                #'formulation_amount_in_words': val1_in_words.title()
                #})  
    
    ##In Print for Commercial Sales Invoice
    #@api.depends('subtotal')
    #def _compute_commercial_sales_invoice_amount(self):
        #commercial_sales_invoice_amount = 0.0
        #for order in self:
            #order.update({
                #'commercial_sales_invoice_amount': (order.subtotal)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
                    #})
            
    #@api.depends('subtotal')
    #def _compute_commercial_sales_invoice_amount_in_words(self):
        #for order in self:
            #final_grand_total =val1=0.0
            #val1_in_words = ""
            #final_grand_total=(order.subtotal)-(order.cash_amount)-(order.cheque_amount)-(order.draft_amount)
            #val1 = final_grand_total
            #val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            #print 'Final Grand Total in Words---------------------------------Final Grand Total in Words',val1_in_words.title()
            #order.update({                    
                #'commercial_sales_invoice_amount_in_words': val1_in_words.title()
                #})
            
    #@api.depends('grid_id.iv_assessable_value')
    #def _compute_assessable_line_subtotal(self):
        #for order in self:
            #formulation_assessable_value  = total_amount = 0.0
            #for line in order.grid_id:
                #total_amount += line.iv_assessable_value
                #order.update({
                    #'formulation_assessable_value': total_amount
                    #})
                
    #@api.depends('grid_id.bed_iamt')
    #def _compute_bed_line_subtotal(self):
        #for order in self:
            #formulation_bed_iamt_amount  = total_amount = 0.0
            #for line in order.grid_id:
                #total_amount += line.bed_iamt
                #order.update({
                    #'formulation_bed_iamt_amount': total_amount
                    #})
            
    #@api.depends('grid_id.bed_iamt')
    #def _compute_formulation_bed_iamt_amount_in_words(self):
        #for order in self:
            #total_amount = 0.0
            #for line in order.grid_id:
                #total_amount += line.bed_iamt
            #final_grand_total =val1=0.0
            #val1_in_words = ""
            #final_grand_total=total_amount
            #val1 = final_grand_total
            #val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            #print 'CENTRAL EXCISE DUTY IN WORDS',val1_in_words.title()
            #order.update({                    
                #'formulation_bed_iamt_amount_in_words': val1_in_words.title()
                #})
                
    #@api.depends('grid_id.ed_cess_iamt')
    #def _compute_ed_cess_line_subtotal(self):
        #for order in self:
            #formulation_ed_cess_iamt_amount  = total_amount = 0.0
            #for line in order.grid_id:
                #total_amount += line.ed_cess_iamt
                #order.update({
                    #'formulation_ed_cess_iamt_amount': total_amount
                    #})
                
    #@api.depends('grid_id.sec_cess_iamt')
    #def _compute_sec_cess_line_subtotal(self):
        #for order in self:
            #formulation_sec_cess_iamt_amount  = total_amount = 0.0
            #for line in order.grid_id:
                #total_amount += line.sec_cess_iamt
                #order.update({
                    #'formulation_sec_cess_iamt_amount': total_amount
                    #})
    
    #def print_commercial_sales_invoice(self, cr, uid, ids, context=None):
        #datas = {
                 #'model': 'prakruti.sales_invoice',
                 #'ids': ids,
                 #'form': self.read(cr, uid, ids, context=context),
        #}
        #return {'type': 'ir.actions.report.xml', 'report_name': 'prakruti.report_sales_invoice', 'datas': datas, 'nodestroy': True};
    
    
    #def print_export_sales_invoice(self, cr, uid, ids, context=None):
        #datas = {
                 #'model': 'prakruti.sales_invoice',
                 #'ids': ids,
                 #'form': self.read(cr, uid, ids, context=context),
        #}
        #return {'type': 'ir.actions.report.xml', 'report_name': 'prakruti.report_sales_invoice1', 'datas': datas, 'nodestroy': True};
    
    #def print_excise_invoice(self, cr, uid, ids, context=None):
        #datas = {
                 #'model': 'prakruti.sales_invoice',
                 #'ids': ids,
                 #'form': self.read(cr, uid, ids, context=context),
        #}
        #return {'type': 'ir.actions.report.xml', 'report_name': 'prakruti.report_sales_invoice2', 'datas': datas, 'nodestroy': True};
    
    #def print_meis_invoice(self, cr, uid, ids, context=None):
        #datas = {
                 #'model': 'prakruti.sales_invoice',
                 #'ids': ids,
                 #'form': self.read(cr, uid, ids, context=context),
        #}
        #return {'type': 'ir.actions.report.xml', 'report_name': 'prakruti.report_sales_invoice3', 'datas': datas, 'nodestroy': True};
    
    
    #def print_processing_invoice(self, cr, uid, ids, context=None):
        #datas = {
                 #'model': 'prakruti.sales_invoice',
                 #'ids': ids,
                 #'form': self.read(cr, uid, ids, context=context),
        #}
        #return {'type': 'ir.actions.report.xml', 'report_name': 'prakruti.report_sales_invoice4', 'datas': datas, 'nodestroy': True};
    
    
    #def print_raw_material_invoice(self, cr, uid, ids, context=None):
        #datas = {
                 #'model': 'prakruti.sales_invoice',
                 #'ids': ids,
                 #'form': self.read(cr, uid, ids, context=context),
        #}
        #return {'type': 'ir.actions.report.xml', 'report_name': 'prakruti.report_sales_invoice5', 'datas': datas, 'nodestroy': True};
    
    #def print_commercial_invoice(self, cr, uid, ids, context=None):
        #datas = {
                 #'model': 'prakruti.sales_invoice',
                 #'ids': ids,
                 #'form': self.read(cr, uid, ids, context=context),
        #}
        #return {'type': 'ir.actions.report.xml', 'report_name': 'prakruti.report_sales_invoice6', 'datas': datas, 'nodestroy': True};
    
    
    #def print_trading_invoice(self, cr, uid, ids, context=None):
        #datas = {
                 #'model': 'prakruti.sales_invoice',
                 #'ids': ids,
                 #'form': self.read(cr, uid, ids, context=context),
        #}
        #return {'type': 'ir.actions.report.xml', 'report_name': 'prakruti.report_sales_invoice7', 'datas': datas, 'nodestroy': True};
    
    #def print_excise_sales_invoice(self, cr, uid, ids, context=None):
        #datas = {
                 #'model': 'prakruti.sales_invoice',
                 #'ids': ids,
                 #'form': self.read(cr, uid, ids, context=context),
        #}
        #return {'type': 'ir.actions.report.xml', 'report_name': 'prakruti.report_sales_invoice11', 'datas': datas, 'nodestroy': True};
    
    #def print_commercial_invoice_sales(self, cr, uid, ids, context=None):
        #datas = {
                 #'model': 'prakruti.sales_invoice',
                 #'ids': ids,
                 #'form': self.read(cr, uid, ids, context=context),
        #}
        #return {'type': 'ir.actions.report.xml', 'report_name': 'prakruti.report_sales_invoice12', 'datas': datas, 'nodestroy': True};
    
    
#class PrakrutiSalesInvoiceTaxLine(models.Model):
    #_name = 'sales.invoice.tax.line'
    #_table = 'sales_invoice_tax_line'
    #_description = 'Prakruti Sales Invoice Tax Line'
    #_order= "id desc"
    
    #ref_id = fields.Many2one('prakruti.sales_invoice',string="Reference Id")
    #tax_type = fields.Many2one('account.other.tax', string='Taxes', domain=[('active', '=', True)],required=True,store=True)
    #tax_percent = fields.Float(related='tax_type.per_amount',string="Tax %",store=1,readonly=1,digits=(6,3))
    #tax_amount = fields.Float(related='tax_type.amount',string="Tax Amt.",store=1,readonly=1,digits=(6,3))
    #total_value = fields.Float(string="Total Value",readonly=1,digits=(6,3))
    #select_type=fields.Selection([
        #('tax','TAX'),
        #('vat','VAT'),
        #('cst','CST'),
        #('bed','EXCISE DUTY'),
        #('ed_cess','ED CESS'),
        #('sec_cess','SEC CESS'),
        #('swach_bharat','SWACH BHARAT'),
        #('krishi_kalyan','KRISHI KALYAN'),
        #('assessable','ABATEMENT')
        #],string='Select Type',related='tax_type.select_type',store=1,readonly=1)
    
class PrakrutiSalesInvoiceLine(models.Model):
    _name = 'prakruti.sales_invoice_line'
    _table = "prakruti_sales_invoice_line" 
    
    product_id  = fields.Many2one('product.product', string="Product Name",required=True)
    uom_id = fields.Many2one('product.uom',string="UOM")
    specification_id = fields.Many2one('product.specification.main', string = "Specification")
    description = fields.Text(string="Description")
    #tarrif_id=fields.Text(string='Tarrif')
    quantity = fields.Float(string = "Qty",digits=(6,3))
    unit_price=fields.Float(string="Unit Price",digits=(6,3))
    #mrp=fields.Float(string="MRP",digits=(6,3))
    remarks = fields.Text(string="Remarks") 
    #total1= fields.Float(string='Assessable Value',readonly=True,digits=(6,3))
    #mfg_date = fields.Date(string='Mfg. Date')
    #exp_date = fields.Date(string="Expiry Date")
    main_id = fields.Many2one('prakruti.sales_invoice',string="Grid")
    #order_type = fields.Selection(related='main_id.order_type',string="Order Type", default='without_tarrif',store=True)
    #total_assessable_value= fields.Float(string='Total Assesable value',digits=(6,3))
    #assessable_subtotal=fields.Float(string='Assesable  Total',readonly=True,digits=(6,3))
    #subtotal= fields.Float(string='Sub Total',readonly=True,digits=(6,3))
    #bed_itype= fields.Char(string='BED TYPE')
    #bed_ipercentage = fields.Float(string="BED %",digits=(6,3))
    #bed_iqty = fields.Float(string="BED qty",digits=(6,3))
    #bed_iamt = fields.Float(string="BED Total",readonly=True,digits=(6,3))
    #what_is_bed_type=fields.Selection([('per_amount','%'),('amount','Amount')],string='What is Bed Type')
    #ed_cess_itype = fields.Char(string='ED CESS TYPE')
    #ed_cess_iqty = fields.Float(string="Ed Cess qty",digits=(6,3))
    #ed_cess_ipercentage = fields.Float(string="Ed Cess %",digits=(6,3))
    #ed_cess_iamt = fields.Float(string="Ed Cess Total",readonly=True,digits=(6,3))
    #what_is_ed_cess_type=fields.Selection([('per_amount','%'),('amount','Amount')],string='What is Ed Cess Type')
    #sec_cess_itype = fields.Char(string='SEC CESS TYPE')
    #sec_cess_iqty = fields.Float(string="Sec Cess qty",digits=(6,3))
    #sec_cess_ipercentage = fields.Float(string="Sec Cess %",digits=(6,3))
    #sec_cess_iamt = fields.Float(string="Sec Cess Total",readonly=True,digits=(6,3))
    #what_is_sec_cess_type=fields.Selection([('per_amount','%'),('amount','Amount')],string='What is Sec Cess Type')
    #assessable_value=fields.Float(related='main_id.assessable_value',string='Assessable Value(%)',store=True,digits=(6,3))
    #iv_assessable_value=fields.Float(string="IV Assessable Value",readonly=True,digits=(6,3))
    status = fields.Selection([
		('accepted', 'Accepted'),
		('par_reject', 'Par. Rejected'),
		('rejected','Rejected')
		], string= 'Status')       
    # FOR NEW CALCULATION ITS BEING ADDED   
    #type_of_product = fields.Selection(related='main_id.type_of_product', string="Type of Product",store=True)
    #type_of_order = fields.Selection(related='main_id.type_of_order',string="Type of Order",store=True)
    packing_style = fields.Float('Packing Style',digits=(6,3))
    no_of_packings = fields.Float('Packing Per Qty',digits=(6,3))
    extra_packing= fields.Float(string= "(+)Extra Packing",default=0,digits=(6,3))
    batch_no= fields.Many2one('prakruti.batch_master',string= 'Batch No')
    packing_details = fields.Char('Packing Details')
    total= fields.Float(string='Total',compute= '_compute_total')        
    #GST ENTRY ADDED HERE
    hsn_code = fields.Char(string='HSN/SAC')
    amount = fields.Float(string= 'Amount',compute= '_compute_amount')
    discount_id = fields.Many2one('account.other.tax',string= 'Discount(%)',domain=[('select_type', '=', 'discount')])
    discount = fields.Float(string= 'Discount(%)',default=0)
    taxable_value = fields.Float(string= 'Taxable Value',compute= '_compute_taxable_value')
    proportionate_amount_to_products = fields.Float(related='main_id.proportionate_amount_to_products', string="Proportionate Amount to Products")
    taxable_value_with_charges = fields.Float(string= 'Taxable Value With Charges',compute= '_compute_taxable_value_with_charges')
    gst_rate = fields.Float(string= 'GST Rate',compute= '_compute_gst_rate')    
    cgst_id = fields.Many2one('account.other.tax',string= 'CGST Rate',domain=[('select_type', '=', 'cgst')])
    cgst_value = fields.Float(related='cgst_id.per_amount',string= 'CGST Value',default=0)
    cgst_amount = fields.Float(string= 'CGST Amount',compute= '_compute_cgst_amount')    
    sgst_id = fields.Many2one('account.other.tax',string= 'SGST Rate',domain=[('select_type', '=', 'sgst')])
    sgst_value = fields.Float(related='sgst_id.per_amount',string= 'SGST Value',default=0)
    sgst_amount = fields.Float(string= 'SGST Amount',compute= '_compute_sgst_amount')    
    igst_id = fields.Many2one('account.other.tax',string= 'IGST Rate',domain=[('select_type', '=', 'igst')])
    igst_value = fields.Float(related='igst_id.per_amount',string= 'IGST Value',default=0)
    igst_amount = fields.Float(string= 'IGST Amount',compute= '_compute_igst_amount')
    
    @api.depends('cgst_amount','sgst_amount','igst_amount','taxable_value_with_charges')
    def _compute_total(self):
        for order in self:
            total = 0.0            
            order.update({                
                'total': order.taxable_value_with_charges + order.cgst_amount + order.sgst_amount + order.igst_amount
            })
    
    @api.depends('igst_value', 'taxable_value_with_charges')
    def _compute_igst_amount(self):
        for order in self:
            igst_amount = 0.0            
            order.update({                
                'igst_amount': order.taxable_value_with_charges * (order.igst_value/100)
            })
    
    @api.depends('sgst_value', 'taxable_value_with_charges')
    def _compute_sgst_amount(self):
        for order in self:
            sgst_amount = 0.0            
            order.update({                
                'sgst_amount': order.taxable_value_with_charges * (order.sgst_value/100)
            })
    
    @api.depends('cgst_value', 'taxable_value_with_charges')
    def _compute_cgst_amount(self):
        for order in self:
            cgst_amount = 0.0            
            order.update({                
                'cgst_amount': order.taxable_value_with_charges * (order.cgst_value/100)
            })
    
    @api.depends('cgst_value', 'sgst_value', 'igst_value')
    def _compute_gst_rate(self):
        for order in self:
            gst_rate = 0.0            
            order.update({                
                'gst_rate': order.cgst_value + order.sgst_value + order.igst_value
            })
    
    @api.depends('taxable_value', 'proportionate_amount_to_products')
    def _compute_taxable_value_with_charges(self):
        for order in self:
            taxable_value_with_charges = 0.0            
            order.update({                
                'taxable_value_with_charges': order.taxable_value + order.proportionate_amount_to_products 
            })
    
    @api.depends('quantity', 'unit_price')
    def _compute_amount(self):
        for order in self:
            amount = 0.0            
            order.update({                
                'amount': order.quantity * order.unit_price 
            })
    
    @api.depends('quantity', 'unit_price','amount','discount','discount_id')
    def _compute_taxable_value(self):
        for order in self:
            taxable_value = 0.0            
            order.update({                
                'taxable_value': order.amount - (order.amount*(order.discount/100)) 
            })  
    
    #@api.one
    #@api.constrains('mrp')
    #def _check_mrp(self):
        #if self.mrp < 0:
            #raise ValidationError(
                #"MRP !!! Can't be Negative or 0")

    
    @api.one
    @api.constrains('unit_price')
    def _check_unit_price(self):
        if self.unit_price <= 0:
            raise ValidationError(
                "Unit Price !!! Can't be Negative or 0")