# -*- coding: utf-8 -*-
import time
from openerp.tools import image_resize_image_big
from openerp.exceptions import ValidationError
from openerp import api, fields, models, _
from openerp.exceptions import except_orm, Warning as UserError 
import openerp
from datetime import date, datetime
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from datetime import timedelta
from openerp.osv import osv,fields
from openerp import models, fields, api, _
from openerp.tools.translate import _
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
from lxml import etree
import cgi
import logging
import lxml.html
import lxml.html.clean as clean
import openerp.pooler as pooler
import random
import re
import socket
import threading
import time
from openerp.tools import image_resize_image_big
from openerp.tools import amount_to_text
from openerp.tools.amount_to_text import amount_to_text_in 
from openerp.tools.amount_to_text import amount_to_text_in_without_word_rupees 


####################################################################



class PrakrutiProductionSlip(models.Model):
    _name= 'prakruti.production_slip'
    _table= 'prakruti_production_slip'
    _description= 'This Screen will confirm the Order raise from the Sales Order' 
    _order= 'id desc'
    _rec_name= 'slip_no'  
        
    slip_no= fields.Char(string='Slip No.', default= 'New')
    slip_date= fields.Date('Slip Date', default= fields.Date.today)    
    sl_no= fields.Char('Slip No', compute= '_get_auto')
    auto_no= fields.Integer('Auto')
    req_no_control_id= fields.Integer('Auto Generating id', default= 0)    
    grid_id= fields.One2many('prakruti.production_slip_line', 'main_id',string= 'Grid')    
    company_id= fields.Many2one('res.company',string='Company Address')
    order_no= fields.Char(string='Order No.', default= 'New')
    order_date= fields.Date('Order Date')
    product_type_id=fields.Many2one('product.group',string= 'Product Type')
    quotation_no= fields.Char(string='Quotation No' ,readonly=True)
    quotation_date = fields.Date(string='Quotation Date' ,readonly=True)
    inquiry_date= fields.Date('Inquiry Date',readonly=True)
    inquiry_no = fields.Char(' Inquiry No', readonly=True)
    customer_id = fields.Many2one('res.partner',string="Customer")    
    billing_id = fields.Many2one('res.partner',string='Billing Address')
    remarks = fields.Text(string="Remarks")
    terms =fields.Text('Terms and conditions')
    #order_type = fields.Selection([('with_tarrif','With Tarrif'),('without_tarrif','Without Tarrif')], string="Order Type")
    
    state= fields.Selection(
        [
        ('slip_request','Production Slip Issued'),
        ('partially_confirmed','Production Slip Partially Confirmed'),
        ('production_slip_confirmed','Production Slip Confirmed'),
        ('partial_order','Partially Dispatched/Confirmed/Invoiced'),
        ('confirm','Dispatched/Confirmed/Invoiced'),
        ('without_qc_partially_confirmed','With out QC Partially Dispatched/Confirmed/Invoiced'),
        ('without_qc_invoice','With out QC Dispatched/Confirmed/Invoiced'),
        ('rejected','Rejected')
        ], string= 'Status', default= 'slip_request')
    requested_id =fields.Many2one('res.users','Requested By',readonly=True)
    quotation_id =fields.Many2one('res.users','Quotation By',readonly=True)
    order_id =fields.Many2one('res.users','Order By')
    reference_no= fields.Char(string='Ref No') 
    product_id = fields.Many2one('product.product', related='grid_id.product_id', string='Product Name')
    all_send_to_request = fields.Integer(string='All Send To Request',default=0,readonly=1)
    all_send_to_planning = fields.Integer(string='All Send To Planning',default=0,readonly=1)
    revised_status = fields.Selection([('revised','Revised')],string= 'Revised Status')
    
    @api.multi
    def unlink(self):
        raise UserError(_('Can\'t Delete...'))
        return super(PrakrutiProductionSlip, self).unlink()
    
    @api.one
    @api.multi
    def _get_auto(self):
        x = {}
        total_ordered_qty=0
        quantity=0
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        for temp in self:
            cr.execute('''select cast(extract (month from slip_date) as integer) as month ,cast(extract (year from slip_date) as integer) as year ,id from prakruti_production_slip where id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
                if month_value<=3:
                    year_value=year_value-1
                else:
                    year_value=year_value
                next_year=year_value+1
                dispay_year=str(next_year)[-2:]
                display_present_year=str(year_value)[-2:]
                cr.execute('''select autogenerate_slip_no(%s)''', ((temp.id),)  ) 
                result = cr.dictfetchall()
                parent_invoice_id = 0
                for value in result: parent_invoice_id = value['autogenerate_slip_no'];
                auto_gen = int(parent_invoice_id)
                if len(str(auto_gen)) < 2:
                    auto_gen = '000'+ str(auto_gen)
                elif len(str(auto_gen)) < 3:
                    auto_gen = '00' + str(auto_gen)
                elif len(str(auto_gen)) == 3:
                    auto_gen = '0'+str(auto_gen)
                else:
                    auto_gen = str(auto_gen)
                for record in self :
                    cr.execute("SELECT total_ordered_qty,quantity FROM prakruti_production_slip_line WHERE main_id = CAST(%s AS INTEGER)",((temp.id),))
                    for line in cr.dictfetchall():
                        total_ordered_qty = line['total_ordered_qty']
                        quantity = line['quantity']
                    if temp.product_type_id.group_code and (total_ordered_qty == quantity):
                        x[record.id] = 'PS\\'+temp.product_type_id.group_code+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                    elif total_ordered_qty != quantity:
                        x[record.id] = 'PS-PENDING\\'+temp.product_type_id.group_code+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                    else:                        
                        x[record.id] = 'PS\\'+'MISC'+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                cr.execute('''update prakruti_production_slip set slip_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
            return x
    
    @api.model
    def _default_company(self):
        return self.env['res.company']._company_default_get('res.partner')
    
    _defaults = {
        'company_id': _default_company
        }
        
        
    @api.one
    @api.multi 
    def action_reject(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {} 
            template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Production Slip Rejected')],context=context)[0]
            email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
            if temp.remarks:
                cr.execute("UPDATE  prakruti_production_slip SET state = 'rejected' WHERE prakruti_production_slip.id = %s and customer_id = %s",((temp.id),(temp.customer_id.id),))
                cr.execute("UPDATE  prakruti_sales_order SET remarks= 'Rejected From Production',state = 'rejected' WHERE prakruti_sales_order.order_no = %s and customer_id = %s ",((temp.order_no),(temp.customer_id.id),))
            else:
                raise UserError(_('Please Enter Remarks...'))
        return {}
    
    
    @api.one
    @api.multi 
    def to_salesorder(self):
        scheduled_qty = 0
        scheduled_date = ''
        balance_qty = 0
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {} 
            template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Production Slip')],context=context)[0]
            email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
            cr.execute("SELECT balance_qty,scheduled_date,scheduled_qty FROM prakruti_production_slip_line WHERE main_id = %s",((temp.id),))
            for line in cr.dictfetchall():
                balance_qty = line['balance_qty']
                scheduled_date = line['scheduled_date']
                scheduled_qty = line['scheduled_qty']
            if scheduled_qty:
                cr.execute("UPDATE prakruti_sales_order_item AS b SET previous_scheduled_qty=a.scheduled_qty,total_scheduled_qty =a.scheduled_qty + total_scheduled_qty FROM(SELECT main_id,so_line_grid_id,product_id,scheduled_qty FROM prakruti_production_slip_line WHERE main_id= %s ) AS a WHERE a.so_line_grid_id = b.id AND a.product_id = b.product_id",((temp.id),))
                cr.execute("UPDATE prakruti_sales_order_item AS b SET scheduled_date =a.scheduled_date,scheduled_qty=a.scheduled_qty,state = 'partially_confirmed', balance_qty = a.balance_qty FROM(SELECT main_id,so_line_grid_id,product_id,scheduled_date,scheduled_qty, quantity,balance_qty FROM prakruti_production_slip_line WHERE main_id= %s ) AS a WHERE a.so_line_grid_id = b.id AND a.product_id = b.product_id",((temp.id),))         
                cr.execute("UPDATE prakruti_sales_order_item AS b SET state = 'production_slip_confirmed',status = 'close' FROM(SELECT main_id,so_line_grid_id,product_id,balance_qty FROM prakruti_production_slip_line WHERE main_id= %s ) AS a WHERE a.so_line_grid_id = b.id AND a.product_id = b.product_id AND b.balance_qty = 0",((temp.id),))
                cr.execute("UPDATE prakruti_sales_order AS b SET slip_no =a.slip_no FROM(SELECT slip_no,order_no FROM prakruti_production_slip WHERE id= %s AND order_no=%s) AS a WHERE a.order_no = b.order_no",((temp.id),(temp.order_no),))
                cr.execute("SELECT count(id) as no_of_closed_line FROM prakruti_production_slip_line WHERE balance_qty = 0 and main_id = %s",((temp.id),))
                for line in cr.dictfetchall():
                    no_of_closed_line = line['no_of_closed_line']       
                cr.execute("SELECT count(id) as no_of_line FROM prakruti_production_slip_line WHERE main_id = %s",((temp.id),))
                for line in cr.dictfetchall():
                    no_of_line = line['no_of_line']
                if no_of_line == no_of_closed_line:
                    cr.execute("UPDATE prakruti_sales_order SET state = 'production_slip_confirmed' WHERE prakruti_sales_order.order_no = %s",((temp.order_no),)) 
                    cr.execute("UPDATE prakruti_sales_inquiry SET state = 'production_slip_confirmed' WHERE prakruti_sales_inquiry.inquiry_no = %s ", ((temp.inquiry_no),))
                    cr.execute("UPDATE prakruti_sales_quotation SET state = 'production_slip_confirmed' WHERE prakruti_sales_quotation.inquiry_no = %s ", ((temp.inquiry_no),))
                    cr.execute("UPDATE prakruti_production_slip SET state = 'production_slip_confirmed' WHERE prakruti_production_slip.id = %s ", ((temp.id),))
                else:
                    cr.execute("UPDATE prakruti_sales_order SET state = 'partially_confirmed' WHERE prakruti_sales_order.order_no = %s",((temp.order_no),)) 
                    cr.execute("UPDATE prakruti_sales_inquiry SET state = 'partially_confirmed' WHERE prakruti_sales_inquiry.inquiry_no = %s ", ((temp.inquiry_no),))
                    cr.execute("UPDATE prakruti_sales_quotation SET state = 'partially_confirmed' WHERE prakruti_sales_quotation.inquiry_no = %s ", ((temp.inquiry_no),))   
                    cr.execute("UPDATE prakruti_production_slip SET state = 'partially_confirmed' WHERE prakruti_production_slip.id = %s ", ((temp.id),))   
            else:
                raise UserError(_('Oops...! Please Enter Scheduled Qty.'))    
        return True
        
        
    @api.one
    @api.multi 
    def raise_bmr_requisition(self):
        slip_no = ''
        product_id = 0
        quantity = 0
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr.execute("SELECT count(id) as bmr_flag_status FROM prakruti_production_slip_line WHERE main_id = %s AND bmr_status = 'True' AND planning_status = 'True' AND bmr_flag = 0 AND planning_flag = 1 AND planning_done = 'True'",((temp.id),))
            for line in cr.dictfetchall():
                bmr_flag_status = line['bmr_flag_status']
            if bmr_flag_status >= 1:
                cr.execute("SELECT prakruti_production_slip.slip_no as slip_no,product_id,quantity FROM prakruti_production_slip_line INNER JOIN prakruti_production_slip ON prakruti_production_slip_line.main_id = prakruti_production_slip.id WHERE main_id = %s AND bmr_status = 'True' AND planning_status = 'True' AND bmr_flag = 0 AND planning_flag = 1 AND planning_done = 'True'",((temp.id),))
                for line in cr.dictfetchall():
                    slip_no = line['slip_no']
                    product_id = line['product_id']
                    quantity = line['quantity']
                    bmr_requisition = self.pool.get('prakruti.bmr_requisition').create(cr,uid,{
                        'slip_no':slip_no,
                        'product_id':product_id,
                        'batch_size':quantity
                        })
                cr.execute("UPDATE prakruti_production_slip_line SET bmr_flag = 1 WHERE main_id = %s AND bmr_status = 'True' AND planning_status = 'True' AND planning_flag = 1 AND planning_done = 'True'",((temp.id),))
                cr.execute("SELECT count(id) as flag_line FROM prakruti_production_slip_line WHERE main_id = %s AND bmr_flag = 1 AND planning_done = 'True'",((temp.id),))
                for line in cr.dictfetchall():
                    flag_line = line['flag_line']
                cr.execute("SELECT count(id) as total_line FROM prakruti_production_slip_line WHERE main_id = %s",((temp.id),))
                for line in cr.dictfetchall():
                    total_line = line['total_line']
                if total_line == flag_line:
                    cr.execute("UPDATE prakruti_production_slip SET all_send_to_request = 1 WHERE id = %s",((temp.id),))
            else:
                raise UserError(_('No Any Product to send for BMR Request (or)\nPlanning Not done Yet'))
        return {}
        
        
    @api.one
    @api.multi 
    def raise_planning(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr.execute("SELECT count(id) as planning_flag_status FROM prakruti_production_slip_line WHERE main_id = %s AND planning_status = 'True' AND planning_flag = 0",((temp.id),))
            for line in cr.dictfetchall():
                planning_flag_status = line['planning_flag_status']
            if planning_flag_status >= 1:
                cr.execute("SELECT prakruti_production_slip.slip_no,product_id,quantity,store_qty,prakruti_production_slip_line.id as line_id FROM prakruti_production_slip INNER JOIN prakruti_production_slip_line ON prakruti_production_slip_line.main_id = prakruti_production_slip.id WHERE main_id = %s AND planning_status = 'True' AND planning_flag = 0",((temp.id),))
                for line in cr.dictfetchall():
                    product_id = line['product_id']
                    quantity = line['quantity']
                    line_id = line['line_id']
                    slip_no = line['slip_no']
                    availble_stock_qty = line['store_qty']
                    production_planning = self.pool.get('prakruti.production_planning').create(cr,uid,{
                        'slip_no':slip_no,
                        'product_id':product_id,
                        'ps_line_grid_id':line_id,
                        'output_yield_qty':quantity,
                        'availble_stock_qty':availble_stock_qty
                        })
                cr.execute("UPDATE prakruti_production_slip_line SET planning_flag = 1 WHERE planning_status = 'True' AND main_id = %s",((temp.id),))
                cr.execute("SELECT count(id) as flag_line FROM prakruti_production_slip_line WHERE main_id = %s AND planning_flag = 1",((temp.id),))
                for line in cr.dictfetchall():
                    flag_line = line['flag_line']
                cr.execute("SELECT count(id) as total_line FROM prakruti_production_slip_line WHERE main_id = %s",((temp.id),))
                for line in cr.dictfetchall():
                    total_line = line['total_line']
                if total_line == flag_line:
                    cr.execute("UPDATE prakruti_production_slip SET all_send_to_planning = 1 WHERE id = %s",((temp.id),))
            else:
                raise UserError(_('No Any Product to send for Planning'))
        return {}
    
    @api.one
    @api.multi
    def check_stock(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
                cr.execute("UPDATE prakruti_production_slip_line SET store_qty= qty_aval FROM ( SELECT product_id,(sum(qty_in) - sum(qty_out)) as qty_aval,id FROM ( SELECT stock_move.product_id, case when move_dest_id > 0 then product_qty else 0 end as qty_out, case when move_dest_id > 0 then 0 else product_qty end as qty_in,main_id,prakruti_production_slip_line.id FROM product_template INNER JOIN product_product  ON product_product.product_tmpl_id = product_template.id INNER JOIN stock_move ON stock_move.product_id = product_product.id INNER JOIN prakruti_production_slip_line ON prakruti_production_slip_line.product_id = stock_move.product_id    WHERE prakruti_production_slip_line.main_id = %s and location_dest_id = 12  AND stock_move.state = 'done')as a GROUP BY product_id,id) as b WHERE b.id = prakruti_production_slip_line.id",((temp.id),))
        return {}
    
class PrakrutiProductionSlipLine(models.Model):
    _name= 'prakruti.production_slip_line'
    _table= 'prakruti_production_slip_line'
    
    product_id= fields.Many2one('product.product', string= "Product")
    description= fields.Text(string= 'Description')
    uom_id= fields.Many2one('product.uom', string="UOM")
    specification_id= fields.Many2one('product.specification.main', string= "Specification")
    quantity= fields.Float(string= 'Req. Qty.',digits=(6,3))
    req_date= fields.Date('Req. Date')
    remarks= fields.Text(string= "Remarks")
    main_id = fields.Many2one('prakruti.production_slip', string= "Grid Line")
    scheduled_date = fields.Date('Sch. Date')
    scheduled_qty = fields.Float('Sch. Qty.',default=0,digits=(6,3))
    so_line_grid_id = fields.Integer('Sales Order Line Grid ID')
    unit_price=fields.Float(string="Unit Price",digits=(6,3))
    #batch_no= fields.Many2one('prakruti.batch_master',string= 'Batch No')
    #mfg_date = fields.Date(string='Mfg. Date')
    #exp_date = fields.Date(string="Expiry Date")
    #tarrif_id=fields.Text(string='Tarrif')
    #mrp=fields.Float(string="MRP",digits=(6,3))
    total= fields.Float(string='Total',digits=(6,3)) 
    #total1= fields.Float(string='Total1',digits=(6,3))
    balance_qty = fields.Float(string="Balance Qty",compute='_compute_balance_qty',store=True,default=0,digits=(6,3))
    total_dispatch_qty = fields.Float(string= 'Total Disp. Qty.',store=True,default=0,digits=(6,3))
    total_ordered_qty = fields.Float('Total Ordered Qty.',digits=(6,3))
    #avail_stock = fields.Float(string= 'Avail. Stock',default=0,digits=(6,3))
    #2017-05-17
    ordered_qty = fields.Float(string="Ordered Qty",digits=(6,3),default=0,readonly=True)
    total_scheduled_qty = fields.Float(string="Total Sch Qty",digits=(6,3),default=0,readonly=True)
    total_dispatched_qty=fields.Float(string="Total Dispatch Qty",readonly=True,digits=(6,3),default=0)
    store_qty = fields.Float(string="Available Qty",digits=(6,3))
    bmr_status = fields.Boolean(string="BMR Request", default='1')
    bmr_flag = fields.Integer(string='BMR Request Flag',default=0,readonly=1)
    planning_status = fields.Boolean(string="Planning Request", default=1)
    planning_flag = fields.Integer(string='Planning Flag',default=0,readonly=1)
    planning_done = fields.Boolean(string='Planning Done',default=0,readonly=1)
    
    @api.depends('quantity','scheduled_qty')
    def _compute_balance_qty(self):
        for order in self:
            balance_qty = 0.0            
            order.update({                
                'balance_qty': order.quantity - order.scheduled_qty 
            }) 
    
    @api.one
    @api.constrains('balance_qty')
    def _check_balance_qty(self):
        if self.balance_qty < 0:
            raise ValidationError(
                "Balance Qty !!! Can't be Negative")     
    @api.one
    @api.constrains('scheduled_date')
    def _check_scheduled_date(self):
        if self.scheduled_date < fields.Date.today():
            raise ValidationError(
                "Scheduled Date can't be less than current date!")