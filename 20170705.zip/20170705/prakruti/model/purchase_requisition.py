import openerp
from datetime import date, datetime
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from datetime import timedelta
from openerp.osv import osv,fields
from openerp import models, fields, api, _
from openerp.tools.translate import _
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
from lxml import etree
import cgi
import logging
import lxml.html
import lxml.html.clean as clean
import openerp.pooler as pooler
import random
import re
import socket
import threading
import time


class PurchaseRequisitionFromStores(models.Model):
    _name = 'prakruti.purchase_requisition'
    _table = 'prakruti_purchase_requisition'
    _description = 'Purchase Requisition From Stores'
    _rec_name = 'requisition_no'
    _order="id desc"
        
    requisition_date = fields.Datetime(string = "Requisition Date")
    requisition_no = fields.Char(string = "Requisition No", readonly=True)
    document_no = fields.Char(string ="Document No" , default='PPPL-PUR-F-004' , readonly=True)
    revision_no = fields.Char(string = "Rev. No", default='01' , readonly=True)
    remarks = fields.Text(string="Remarks")
    default_pr_date = fields.Char(string="Document Date" , default= fields.Date.today , readonly=True)
    prepared_by = fields.Many2one('res.users','Prepared By',readonly=True)
    plant_manager = fields.Many2one('res.users',string="Plant Manager",required=True)
    stores_incharge = fields.Many2one('res.users',string="Stores Incharge",required=True)
    purchase_manager = fields.Many2one('res.users',string="Purchase Manager",required=True)
    to_name = fields.Many2one('res.users',string="Name", required= True)
    state = fields.Selection([
		('requisition', 'Requisition'),
		('partial_confirm','Requisition Partial Confirmed'),
		('approve', 'Requisition Approval'),
		('partially_approved', 'Requisition Partially Approval'),
		('requisition_analysis','Requisition Analysis'),
		('partial_analysis','Requisition Partial Analysis'),
		('request','Request'),
		('quotation','Quotation'),
                ('analysis','Quotation Analysis'),
                ('order','Order'),
                ('rejected','Rejected'),
                ('confirm','Order Confirm'),
                ('in_transit','Logistic In Transit'),
                ('deliver',' Gate Pass'),
                ('checked','GRN Analysis'),
                ('grn','GRN'),
                ('qc_check','QC Check'),
                ('validate','Validated'),
                ('qc_ha','QC Higher Approval'),
                ('qc_check_done','QC Check Done'),
                ('done','Done'),  ],default= 'requisition', string= 'Status')
    requisition_line = fields.One2many('prakruti.purchase_requisition_line','order_id',string='Order Lines')
    name1 = fields.Char('name1')
    requistion_no = fields.Char('Purchase Requisition Number', compute='_get_auto', readonly=True)    
    auto_no = fields.Integer('Auto')
    req_no_control_id = fields.Integer('Auto Generating id',default= 0)
    purchase_type = fields.Many2one('product.group',string= 'Purchase Type')
    is_duplicate = fields.Boolean(string= 'Is a Duplicate',default=False,readonly=True)
    duplicate_flag = fields.Char(string= 'Duplicate Flag',default=0,readonly=True) 
    product_id = fields.Many2one('product.product', related='requisition_line.product_id', string='Product Name')
    company_id = fields.Many2one('res.company',string='Company Address')
    revised_status = fields.Selection([('revised','Revised')],string= 'Revised Status')
    
    
    @api.one
    @api.multi
    def _get_auto(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        for temp in self :
            cr.execute('''select cast(extract (month from requisition_date) as integer) as month ,cast(extract (year from requisition_date) as integer) as year ,id from prakruti_purchase_requisition where id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
            if month_value<=3:
                year_value=year_value-1
            else:
                year_value=year_value
            next_year=year_value+1
            dispay_year=str(next_year)[-2:]
            display_present_year=str(year_value)[-2:]
            cr.execute('''select autogenerate_purchase_requistion(%s)''', ((temp.id),)  ) 
            result = cr.dictfetchall()
            parent_invoice_id = 0
            for value in result: parent_invoice_id = value['autogenerate_purchase_requistion'];
            auto_gen = int(parent_invoice_id)
            if len(str(auto_gen)) < 2:
                auto_gen = '000'+ str(auto_gen)
            elif len(str(auto_gen)) < 3:
                auto_gen = '00' + str(auto_gen)
            elif len(str(auto_gen)) == 3:
                auto_gen = '0'+str(auto_gen)
            else:
                auto_gen = str(auto_gen)
            for record in self :
                if temp.purchase_type.group_code:
                    x[record.id] ='PR\\'+ temp.purchase_type.group_code+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                else:                        
                    x[record.id] ='PR\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                cr.execute('''update prakruti_purchase_requisition set requisition_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
        return x
    
    def copy(self, cr, uid, id, default=None, context=None):
        raise osv.except_osv(_('Forbbiden to duplicate'), _('It Is not possible to duplicate from here...'))
    
    @api.one
    @api.multi
    def duplicate_requisition(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {} 
            template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Purchase Requisition Duplicate')],context=context)[0]
            email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
            d_request = self.pool.get('prakruti.purchase_requisition').create(cr,uid, {
                'requisition_no':'Duplicate',
                'requisition_date':temp.requisition_date,
                'prepared_by':temp.prepared_by.id,
                'document_no':temp.document_no,
                'revision_no':temp.revision_no,
                'remarks':temp.remarks,
                'default_pr_date':temp.default_pr_date,
                'state':'requisition',
                'name1':temp.name1,
                'purchase_type':temp.purchase_type.id,
                'plant_manager':temp.plant_manager.id,
                'stores_incharge':temp.stores_incharge.id,
                'purchase_manager':temp.purchase_manager.id,
                'to_name':temp.to_name.id,
                'is_duplicate':'True',
                'duplicate_flag': 1
                })
            for item in temp.requisition_line:
                grid_values = self.pool.get('prakruti.purchase_requisition_line').create(cr,uid, {
                    'product_id': item.product_id.id,
                    'uom_id': item.uom_id.id,
                    'description': item.description,
                    'quantity_req': item.quantity_req,
                    'suggested_packing_size': item.suggested_packing_size,
                    'required_date': item.required_date,
                    'current_date': item.current_date,
                    'remarks': item.remarks,
                    'stock_on_pr_date_ref': item.stock_on_pr_date_ref,
                    'last_purchase_date': item.last_purchase_date,
                    'order_id': d_request
                    })
        return {}  
    
    #@api.model
    #def _default_company(self):
        #return self.env['res.company']._company_default_get('res.users')
    
    
    _defaults = {
        'requisition_date':lambda *a: time.strftime('%Y-%m-%d'),
        'requisition_no':'New',
        'prepared_by': lambda s, cr, uid, c:uid,
        #'company_id': _default_company
        }
    
    @api.multi
    def onchange_state(self, state_id):
        if state_id:
            state = self.env['res.country.state'].browse(state_id)
            return {'value': {'country_id': state.country_id.id}}
        return {'value': {}}
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['request','approve','requisition_analysis','rejected','quotation','analysis','order','confirm']:
                raise UserError(_('Can\'t Delete, Since the Requisition went for further Process.'))
        return super(PurchaseRequisitionFromStores, self).unlink() 
    
    @api.one
    @api.multi
    def action_approve_requistion(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        gf = 0
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            req_approve = self.pool.get('prakruti.purchase_requisition_approve').create(cr,uid, {
                'requisition_date':temp.requisition_date,
                'purchase_type':temp.purchase_type.id,
                'state': 'approve',
                'requisition_no':temp.requisition_no,
                'remarks':temp.remarks,
                'purchase_manager':temp.purchase_manager.id,
                'plant_manager':temp.plant_manager.id,
                'stores_incharge':temp.stores_incharge.id,
                'maintanence_manager':temp.prepared_by.id,
                'prepared_by':temp.prepared_by.id,
                'to_name':temp.to_name.id,
                })
            for item in temp.requisition_line:
                grid_values = self.pool.get('prakruti.purchase_requisition_approve_line').create(cr,uid, {
                    'product_id': item.product_id.id,
                    'description': item.description,
                    'quantity_req': item.quantity_req,
                    'quantity': item.quantity_req,
                    'uom_id': item.uom_id.id,
                    'required_date': item.required_date,
                    'remarks': item.remarks,
                    'suggested_packing_size': item.suggested_packing_size,
                    'stock_on_pr_date_ref': item.stock_on_pr_date_ref,
                    'last_purchase_date': item.last_purchase_date,
                    'last_price': item.last_price,
                    'last_purchase_vendor_id': item.last_purchase_vendor_id.id,
                    'hsn_code':item.hsn_code,
                    'order_id': req_approve
                    })
            cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'approve' WHERE prakruti_purchase_requisition_approve.id = cast(%s as integer)",((temp.id),))
            cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'approve' WHERE prakruti_purchase_requisition.id = cast(%s as integer)",((temp.id),))
            template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Purchase Requisition')],context=context)[0]
            email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
        return {}
    
    def _check_the_grid(self, cr, uid, ids, context=None, * args):
        for line_id in self.browse(cr, uid, ids, context=context):
            if len(line_id.requisition_line) == 0:
                return False
        return True
    
    
    _constraints = [
         (_check_the_grid, 'Sorry !!!, Please enter some products to procced further, Thank You !', ['requisition_line']),
    ]
    
    def send_mail_quotation(self, cr, uid, ids, context=None):
        for temp in self.browse(cr, uid, ids, context={}):
            template_id = self.pool.get('email.template').search(cr,uid,[('name','=','PR - Send by Email')],context=context)[0]
            email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
        return True
    
class PurchaseRequisitionLine(models.Model):
    _name = 'prakruti.purchase_requisition_line'
    _table = 'prakruti_purchase_requisition_line'
    
    product_id = fields.Many2one('product.product' , string="Product Name", required=True)
    description = fields.Text(string = "Description ")
    quantity_req = fields.Float(string = "Required Qty", required=True  ,digits=(6,3))
    suggested_packing_size = fields.Float(string="Suggested Packing Size",digits=(6,3))
    required_date = fields.Date(string="Required Date")
    current_date = fields.Date(string="Current Date")
    remarks = fields.Text(string="Remarks")
    uom_id = fields.Many2one('product.uom',string="UOM",required=True)    
    stock_on_pr_date_ref = fields.Float(string="Available Stock",store=True,readonly=True ,digits=(6,3))
    last_purchase_date= fields.Date(string="Last Purchase Date",store=True,readonly=True)
    last_purchase_vendor_id= fields.Many2one('res.partner',string="Last Purchase Vendor Name",readonly=True)  
    order_id = fields.Many2one('prakruti.purchase_requisition', string='Order Reference', index=True, ondelete='cascade')
    last_price = fields.Float(string = "Last Purchase Price", readonly=True,digits=(6,3))
    group_ref = fields.Integer(string="Product Group")
    hsn_code = fields.Char(string='HSN/SAC')
    
    _defaults = {
        'required_date':lambda *a: time.strftime('%Y-%m-%d'),
        'current_date':lambda *a: time.strftime('%Y-%m-%d')
        }
    
    def _date_validation(self, cr, uid, ids, context=None):
        obj = self.browse(cr, uid, ids[0], context=context)
        required_date = obj.required_date
        current_date = obj.current_date
        if required_date < current_date:
            return False
        return True    
    
    def _check_qty(self, cr, uid, ids):
        lines = self.browse(cr, uid, ids)
        for line in lines:
            if line.quantity_req <= 0:
                return False
        return True
     
    _constraints = [
         (_check_qty, 'Order quantity cannot be negative or zero !', ['quantity_req']),
         (_date_validation, 'Your Required date should not be less than Current date',['required_date']),
    ]
    
    _sql_constraints=[
        
        ('unique_product_id','unique(product_id, order_id)', 'Item(s) should be Unique')
        ]
    
    def onchange_product(self, cr, uid, ids, product_id, context=None):
        qty_aval = 0.0
        line1 = 0
        line2 = ''
        line3 = 0
        line4 = False
        line5 = False
        uom_name = ''
        line6 = 0
        line7 = 0
        hsn_code = ''
        line8 = ''
        cr.execute('SELECT product_uom.id AS uom_id, product_uom.name AS uom_name, product_template.name AS description,product_template.group_ref AS group_ref,product_template.hsn_code AS hsn_code FROM product_uom INNER JOIN product_template ON product_uom.id=product_template.uom_id INNER JOIN product_product ON product_template.id=product_product.product_tmpl_id WHERE product_product.id = cast(%s as integer)', ((product_id),))
        for line in cr.dictfetchall():
            line1 = line['uom_id']
            line2 = line['description']
            line7 = line['group_ref']
            line8 = line['hsn_code']
        cr.execute('''SELECT qty_aval FROM (SELECT uom, product_id, name, qty_in, qty_out, qty_in - qty_out as qty_aval FROM ( SELECT uom,product_id, name, sum(qty_out) as qty_out, sum(qty_in) as qty_in FROM ( SELECT product_uom.name as uom,stock_move.product_id, product_product.name_template as name, picking_id, case when move_dest_id > 0 then product_qty else 0 end as qty_out, case when move_dest_id > 0 then 0 else product_qty end as qty_in FROM product_uom INNER JOIN product_template ON product_uom.id = product_template.uom_id INNER JOIN product_product ON product_product.product_tmpl_id = product_template.id INNER JOIN stock_move ON stock_move.product_id = product_product.id WHERE location_dest_id = 12  AND stock_move.state = 'done' AND product_product.id = CAST(%s as integer)) as a group by product_id, name, uom ) as a ) AS b ORDER BY product_id''', ((product_id),))
        for line in cr.dictfetchall():
            line3 = line['qty_aval']
        cr.execute('''  SELECT ppl.unit_price AS last_price,ppo.vendor_id AS last_purchase_vendor_name, order_date AS purchase_date FROM prakruti_purchase_order AS ppo INNER JOIN prakruti_purchase_line AS ppl ON ppo.id = ppl.purchase_line_id WHERE ppl.product_id = CAST(%s as integer) and ppo.state = 'order_close' order by ppo.id DESC LIMIT 1''', ((product_id),))
        for line in cr.dictfetchall():
            line6 = line['last_price']
            line4 = line['purchase_date']
            line5 = line['last_purchase_vendor_name']
        print 'UOM ID',line1
        print 'AVAILABLE STOCK',line3
        print 'PRODUCT NAME',line2
        print 'VENDOR  NAME',line5
        print 'LAST PRICE',line6
        print 'PRODUCT GROUP',line7
        return {'value' :{'uom_id':line1,
                          'description':line2,
                          'stock_on_pr_date_ref': line3 or 0.0,
                          'last_purchase_date': line4, 
                          'last_purchase_vendor_id': line5,
                          'last_price':line6,
                          'group_ref':line7,
                          'hsn_code':line8 or ''
                          }}
        
    def create(self, cr, uid, vals, context=None):
        onchangeResult = self.onchange_product(cr, uid, [], vals['product_id'])
        if onchangeResult.get('value') or onchangeResult['value'].get('stock_on_pr_date_ref','last_purchase_date','last_purchase_vendor_id','last_price'):
            vals['stock_on_pr_date_ref'] = onchangeResult['value']['stock_on_pr_date_ref']
            vals['last_purchase_date'] = onchangeResult['value']['last_purchase_date']
            vals['last_purchase_vendor_id'] = onchangeResult['value']['last_purchase_vendor_id']
            vals['last_price'] = onchangeResult['value']['last_price']
        return super(PurchaseRequisitionLine, self).create(cr, uid, vals, context=context)
    
    def write(self, cr, uid, ids, vals, context=None):
        op=super(PurchaseRequisitionLine, self).write(cr, uid, ids, vals, context=context)
        for record in self.browse(cr, uid, ids, context=context):
            store_type=record.product_id.id
        onchangeResult = self.onchange_product(cr, uid, ids, store_type)
        if onchangeResult.get('value') or onchangeResult['value'].get('stock_on_pr_date_ref','last_purchase_date','last_purchase_vendor_id','last_price'):
            vals['stock_on_pr_date_ref'] = onchangeResult['value']['stock_on_pr_date_ref']
            vals['last_purchase_date'] = onchangeResult['value']['last_purchase_date']
            vals['last_purchase_vendor_id'] = onchangeResult['value']['last_purchase_vendor_id']
            vals['last_price'] = onchangeResult['value']['last_price']
        return super(PurchaseRequisitionLine, self).write(cr, uid, ids, vals, context=context)