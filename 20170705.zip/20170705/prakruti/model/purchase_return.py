import time
import openerp
from datetime import date, datetime
from openerp import models, fields, api
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from openerp.tools.translate import _
from datetime import timedelta
##################################################################################################

class PrakrutiPurchaseReturnItems(models.Model):
    _name = 'prakruti.purchase_return'
    _table= 'prakruti_purchase_return'
    _description = 'Managing Purchase Returned Items'
    _order = 'id desc'
    _rec_name="mrn_no"
    
    invoice_no = fields.Many2one('prakruti.purchase_invoice',string='Select Invoice No.')
    invoice_date=fields.Date('Invoice Date')
    pr_no = fields.Char(string="Requisition No" , readonly=True)
    pr_date= fields.Date(string="Requisition Date", readonly=True)
    po_no = fields.Char(string='Order No', readonly=True)
    order_date= fields.Date(string="Order Date", readonly=True)
    vendor_id = fields.Many2one('res.partner',string="Vendor Name", readonly=True)
    return_date= fields.Date(string="Return Date",default=fields.Date.today)
    return_line = fields.One2many('prakruti.purchase_return_line','return_line_id',string='Purchase Return Line')
    order_date = fields.Date(string='Order Date', readonly= "True")
    stores_incharge = fields.Many2one('res.users','Stores Incharge')
    dispatch_asst = fields.Many2one('res.users','Dispatch Assistant')
    doc_no=fields.Char('Doc. No',default='PPPL-STR-F-002')
    rev_no=fields.Char('Rev. No',default='02')
    doc_date=fields.Date('Document Date',default= fields.Date.today)
    company_address = fields.Many2one('res.company',string='Company Address', readonly= "True")
    purchase_manager = fields.Many2one('res.users',string="Purchase Manager")
    dispatch_through = fields.Char(string='Dispatch Through')
    total= fields.Float(string='Total',store=True ,digits=(6,3))
    flag_display_product= fields.Integer(string='Product List Shown',default=0)
    flag_delete_product= fields.Integer(string='Product List Deleted',default=0)
    #Selection Based on MRN NUmber dated 20170408
    mrn_no = fields.Many2one('prakruti.return_items',string='MRN No.')
    mrn_date=fields.Date('MRN Date') 
    product_id = fields.Many2one('product.product', related='return_line.product_id', string='Product Name')
    
    def onchange_mrn_no(self, cr, uid, ids, mrn_no, context=None):
        process_type = self.pool.get('prakruti.return_items').browse(cr, uid, mrn_no, context=context)
        result = {
            'po_no':process_type.po_no,
            'order_date':process_type.order_date,
            'vendor_id':process_type.vendor_id.id,
            'company_address':process_type.company_address.id
            }
        return {'value': result}
        
    def create(self, cr, uid, vals, context=None):
        onchangeResult = self.onchange_mrn_no(cr, uid, [], vals['mrn_no'])
        if onchangeResult.get('value') or onchangeResult['value'].get('po_no','order_date','vendor_id','company_address'):
            vals['po_no'] = onchangeResult['value']['po_no']
            vals['order_date'] = onchangeResult['value']['order_date']
            vals['vendor_id'] = onchangeResult['value']['vendor_id']
            vals['company_address'] = onchangeResult['value']['company_address']
        return super(PrakrutiPurchaseReturnItems, self).create(cr, uid, vals, context=context)
    
    def write(self, cr, uid, ids, vals, context=None):
        op=super(PrakrutiPurchaseReturnItems, self).write(cr, uid, ids, vals, context=context)
        for record in self.browse(cr, uid, ids, context=context):
            store_type=record.mrn_no.id
        onchangeResult = self.onchange_mrn_no(cr, uid, ids, store_type)
        if onchangeResult.get('value') or onchangeResult['value'].get('po_no','order_date','vendor_id','company_address'):
            vals['po_no'] = onchangeResult['value']['po_no']
            vals['order_date'] = onchangeResult['value']['order_date']
            vals['vendor_id'] = onchangeResult['value']['vendor_id']
            vals['company_address'] = onchangeResult['value']['company_address']
        return super(PrakrutiPurchaseReturnItems, self).write(cr, uid, ids, vals, context=context)
    
    
    @api.multi
    def unlink(self):
        raise UserError(_('Can\'t Delete'))
        return super(PrakrutiPurchaseReturnItems, self).unlink()
    
    @api.one
    @api.multi
    def action_list_products(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute("SELECT product_id,uom_id,description,unit_price,no_of_packing,packing_size,return_qty,prakruti_return_items_line.remarks,return_line_id FROM prakruti_return_items INNER JOIN prakruti_return_items_line ON prakruti_return_items.id=prakruti_return_items_line.return_line_id WHERE prakruti_return_items_line.return_line_id = CAST(%s as integer)",((temp.mrn_no.id),))
            for item in cr.dictfetchall():
                product_id=item['product_id']
                description =item['description']
                uom_id=item['uom_id']
                return_qty=item['return_qty']
                no_of_packing=item['no_of_packing']
                packing_size=item['packing_size']
                unit_price=item['unit_price']
                remarks=item['remarks']
                grid_down = self.pool.get('prakruti.purchase_return_line').create(cr,uid, {
                    'product_id':product_id,
                    'description': description,
                    'uom_id': uom_id,
                    'no_of_packings':no_of_packing,
                    'pack_per_qty':packing_size,
                    'quantity':return_qty,            
                    'unit_price': unit_price,
                    'remarks':remarks,
                    'return_line_id':temp.id,
                        })
            cr.execute("UPDATE  prakruti_purchase_return SET flag_display_product = 1 WHERE prakruti_purchase_return.id = cast(%s as integer)",((temp.id),))
            cr.execute("UPDATE  prakruti_purchase_return SET flag_delete_product = 0 WHERE prakruti_purchase_return.id = cast(%s as integer)",((temp.id),))
        return {}
    
    @api.one
    @api.multi
    def action_delete_products(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute('''DELETE FROM prakruti_purchase_return_line WHERE prakruti_purchase_return_line.return_line_id = (%s)''', ((temp.id),))
            cr.execute("UPDATE  prakruti_purchase_return SET flag_display_product = 0 WHERE prakruti_purchase_return.id = cast(%s as integer)",((temp.id),))
            cr.execute("UPDATE  prakruti_purchase_return SET flag_delete_product = 1 WHERE prakruti_purchase_return.id = cast(%s as integer)",((temp.id),))
        return {}
    
class PrakrutiPurchaseReturnItemsLine(models.Model):
    _name="prakruti.purchase_return_line"
    _table= 'prakruti_purchase_return_line'
    
    return_line_id = fields.Many2one('prakruti.purchase_return', ondelete='cascade')
    
    product_id= fields.Many2one('product.product', string="Product", readonly=True)
    description = fields.Char(string="Description", readonly=True)
    uom_id = fields.Many2one('product.uom', string="UOM", readonly=True)
    return_qty= fields.Float(string="Return Qty" ,digits=(6,3))
    quantity= fields.Float(string="Qty" ,digits=(6,3))
    total= fields.Float(string='Total' ,digits=(6,3))
    no_of_packings =  fields.Float(string="No. of Packing" ,digits=(6,3))
    pack_per_qty = fields.Float(string="Packing Per Qty." ,digits=(6,3))
    extra_packing= fields.Float(string= "(+)Extra Packing",default=0 ,digits=(6,3))
    unit_price = fields.Float(string='Unit price' ,digits=(6,3))
    remarks= fields.Char(string="Remarks")