import time
import openerp
from datetime import date, datetime
from openerp import models, fields, api
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from openerp.tools.translate import _
from datetime import timedelta

###########################################################################################

class PrakrutiInspectionDetails(models.Model):
    _name ='prakruti.inspection_details'
    _table = "prakruti_inspection_details"
    _description ='Recieved Products Inspection Details'
    _order = 'id desc'
    
    pr_no = fields.Char(string='PR No')
    po_no = fields.Char(string="PO No/Issue No")
    qr_no = fields.Char(string="QR No")
    invoice_no = fields.Char(string="Invoice No")
    grn_no = fields.Char(string='GRN No')
    vendor_id = fields.Many2one('res.partner',string="Vendor Name")
    verified_date = fields.Date(string="Verified Date", default= fields.Date.today,readonly=True)
    verified_by = fields.Many2one('res.users',string="Verified By")
    status = fields.Char(string="Status")    
    state = fields.Selection([
                ('confirm','Order Confirm'),
                ('accept','Accept PO'),
                ('accept_items','Accept Items')],default= 'accept', string= 'States')    
    inspection_line= fields.One2many('prakruti.inspection_details_line','inspection_line_id',string='Purchase Order Line') 
    product_id = fields.Many2one('product.product', related='inspection_line.product_id', string='Product Name')
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['confirm','accept','accept_items']:
                raise UserError(_('Can\'t Delete, Since the dispatch QC went for further Process.'))
        return super(PrakrutiInspectionDetails, self).unlink() 
    
    @api.one
    @api.multi 
    def accept_order_items(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
                        
            return_items = self.pool.get('prakruti.return_items').create(cr,uid, {
                'po_no':temp.po_no,
                'pr_no':temp.pr_no,
                'vendor_id':temp.vendor_id.id,
                })
            for item in temp.inspection_line:
                grid_values = self.pool.get('prakruti.return_items_line').create(cr,uid, {
                   'product_id': item.product_id.id,
                   'description': item.description,
                   'return_qty': item.actual_qty - item.verified_qty,
                   'uom_id': item.uom_id.id,
                   'return_line_id': return_items
                })                
        cr.execute("UPDATE prakruti_inspection_details SET state = 'accept_items' WHERE prakruti_inspection_details.id = cast(%s as integer)", ((temp.id),))
        cr.execute('''SELECT UpdatePurchaseStock(%s)''', ((temp.id),)  )
    
    _defaults = {
        'verified_by': lambda s, cr, uid, c:uid 
        }
    
class PrakrutiInspectionDetailsLine(models.Model):
    _name ='prakruti.inspection_details_line'
    _table='prakruti_inspection_details_line'
    
    inspection_line_id = fields.Many2one('prakruti.inspection_details', ondelete='cascade')    
    product_id= fields.Many2one('product.product', string="Product")
    description = fields.Char(string="Description")
    uom_id = fields.Many2one('product.uom', string="UOM")
    remarks= fields.Char(string="Remarks")
    status= fields.Char(string="Status")
    actual_qty= fields.Float(string="Actual Qty" ,digits=(6,3))
    verified_qty = fields.Float(string="Verified Qty" ,digits=(6,3))