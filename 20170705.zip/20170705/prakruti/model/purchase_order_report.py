# -*- coding: utf-8 -*-
import time
from openerp.report import report_sxw
from openerp.osv import osv
from openerp import pooler


from openerp.tools import amount_to_text_en
from openerp.tools.translate import _
from openerp.tools import amount_to_text
from openerp.tools.amount_to_text import amount_to_text_in 


class purchase_order_report(report_sxw.rml_parse):

    def __init__(self, cr, uid, name, context):		
        super(purchase_order_report, self).__init__(cr, uid, name, context)
        self.localcontext.update({
	    'convert': self.convert,
            'get_total_qty': self.get_total_qty,
            'time':time,
            'amount_to_text_in': amount_to_text_in            
            })

    def convert(self, amount, cur):
        amt_en = amount_to_text_en.amount_to_text(amount, 'en', cur)
        return amt_en
 
    
  

    def get_total_qty(self, name):       
        tot=0        
        for i in name:            
            tot=i.req_qty+tot
        return tot

report_sxw.report_sxw('report.purchase.order.report','purchase.order','addons/prakruti/report/purchase_order_report_new.rml',parser=purchase_order_report)