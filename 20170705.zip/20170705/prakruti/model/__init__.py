# -*- coding: utf-8 -*-
from . import res_partner
from . import product_template
from . import product_specification
from . import purchase_requisition
from . import purchase_requisition_approve
from . import purchase_requistion_analysis
from . import price_request
from . import purchase_order_quotation
from . import purchase_order_quotation_anaysis
from . import purchase_order
from . import grn_inspection_details
from . import purchase_return_items
from . import purchase_return
from . import purchase_invoice
from . import grn_analysis
from . import specification_ar_no
from . import prakruti_stock_adjustments


