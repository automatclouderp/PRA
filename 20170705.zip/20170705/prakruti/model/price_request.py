import time
import openerp
from datetime import date, datetime
from openerp import models, fields, api
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from openerp.tools.translate import _
from datetime import timedelta 
from openerp.exceptions import ValidationError



class PrakrutiPriceRequest(models.Model):
    _name = 'prakruti.price_request'
    _table = 'prakruti_price_request'
    _rec_name = 'inquiry_no'
    _order="id desc"
    
    request_date = fields.Date(string = "Requisition Date", default= fields.Date.today)
    inquiry_date = fields.Date(string = "Request Date", default= fields.Date.today )
    inquiry_no = fields.Char(string = "Request No", readonly=True)
    request_no = fields.Char(string = "Requisition No", readonly=True)
    terms_and_conditions = fields.Text()
    prepared_by = fields.Many2one('res.users','Prepared By',readonly=True)
    approved_by = fields.Many2one('res.users','Approved By', readonly=True)
    stores_incharge = fields.Many2one('res.users',string="Stores Incharge")
    request_order_line = fields.One2many('prakruti.price_request_line','request_line_id',string="Please Enter Some Product")
    vendor_list_line = fields.One2many('prakruti.vendor_list_line','vendor_line_id', string="Please Enter Some Vendor",)
    remarks = fields.Text(string="Remarks")
    on_save = fields.Char('Grid Validation', compute='_on_save')
    purchase_type = fields.Many2one('product.group',string= 'Purchase Type')    
    state = fields.Selection([
		('requisition', 'Requisition'),
		('request','Request'),
		('quotation','Quotation'),
                ('analysis','Quotation Analysis'),
                ('order','Order'),
                ('confirm','Order Confirm'),
                ('reject','Rejected'),
                ('short_close','Short Close')],default= 'request', string= 'Status')
    quotation_status = fields.Selection([
                ('hold', 'Hold'),
		('accepted','Accepted')])
    inq_no = fields.Char('Price Request Number', compute='_get_auto', readonly=True)
    auto_no = fields.Integer('Auto')
    req_no_control_id = fields.Integer('Auto Generating id',default= 0) 
    product_id = fields.Many2one('product.product', related='request_order_line.product_id', string='Product Name')
    revised_status = fields.Selection([('revised','Revised')],string= 'Revised Status')
    
    @api.one
    @api.multi
    def _get_auto(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids   
        for temp in self:
            cr.execute('''select cast(extract (month from inquiry_date) as integer) as month ,cast(extract (year from inquiry_date) as integer) as year ,id from prakruti_price_request where id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
            if month_value<=3:
                year_value=year_value-1
            else:                
                year_value=year_value
            next_year=year_value+1
            dispay_year=str(next_year)[-2:]
            display_present_year=str(year_value)[-2:]
            cr.execute('''select autogenerate_price_request(%s)''', ((temp.id),)  ) 
            result = cr.dictfetchall()
            parent_invoice_id = 0
            for value in result: parent_invoice_id = value['autogenerate_price_request'];
            auto_gen = int(parent_invoice_id)
            if len(str(auto_gen)) < 2:
                auto_gen = '000'+ str(auto_gen)
            elif len(str(auto_gen)) < 3:
                auto_gen = '00' + str(auto_gen)
            elif len(str(auto_gen)) == 3:
                auto_gen = '0'+str(auto_gen)
            else:
                auto_gen = str(auto_gen)
            for record in self :
                print '--------------------------------4------------------------------------------',record.purchase_type.id
                if temp.purchase_type.group_code:
                    x[record.id] ='PI\\'+ temp.purchase_type.group_code+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                else:                        
                    x[record.id] ='PI\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                cr.execute('''update prakruti_price_request set inquiry_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
        return x
    
    
    
    
    @api.one
    @api.multi
    def _on_save(self):
        pr_no = {}
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        for temp in self:
            cr.execute('''select count(id) as grid_id  from prakruti_price_request_line where request_line_id=%s''',((temp.id),))
            print 'temp.idtemp.idtemp.idtemp.idtemp.id',temp.id
            for item in cr.dictfetchall():
                grid_id=int(item['grid_id'])
                print 'grid_idgrid_idgrid_id',grid_id
                
            cr.execute('''select count(id) as ven_id  from prakruti_vendor_list_line where vendor_line_id=%s''',((temp.id),))
            print 'temp.idtemp.idtemp.idtemp.idtemp.id',temp.id
            for item in cr.dictfetchall():
                ven_id=int(item['ven_id'])
                print 'ven_idven_idven_idven_id',ven_id
                
                if (grid_id <=0  & ven_id <=0 ) :
                    raise UserError(_('Please Enter atleast 1 Material to Create Request')) 
            return pr_no   
    
    
    
    _defaults = {
        'inquiry_no':'New',
        'request_no':'Direct Request',
        'prepared_by': lambda s, cr, uid, c:uid,
        'approved_by': lambda s, cr, uid, c:uid        
        }
    
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['quotation','analysis','order','confirm']:
                raise UserError(_('Can\'t Delete, Since the Request went for further Process.'))
        return super(PrakrutiPriceRequest, self).unlink()
    
    
    @api.one
    @api.multi
    def action_quotation(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            if len(temp.vendor_list_line) == 0:
                print '-------------------------vendor_list_line--------------------------------',len(temp.vendor_list_line)
                raise UserError(_('Please Enter atleast 1 Vendor'))
            else:
                for vendor_grid in temp.vendor_list_line:
                    quotation_id = self.pool.get('prakruti.purchase_order_quotation').create(cr,uid, {
                            'qo_no':   'From Request',
                            'vendor_id': vendor_grid.vendor_id.id,
                            'order_date':temp.request_date,
                            'pr_request_common_id':temp.id,
                            'state':'quotation',
                            'purchase_type':temp.purchase_type.id,
                            'maintanence_manager':temp.prepared_by.id,
                            'purchase_manager':temp.prepared_by.id,
                            'stores_incharge':temp.stores_incharge.id,
                            'quotation_status':'hold',
                            'inq_no':temp.inquiry_no,
                            'pr_no':temp.request_no,
                            'remarks':temp.remarks,
                            'request_date':temp.request_date,
                            })
                    
                    for line in temp.request_order_line:
                            product = self.pool.get('prakruti.purchase_quotation_line').create(cr,uid, {
                                'product_id': line.product_id.id,
                                'description':line.description,
                                'uom_id':line.uom_id.id,
                                'quantity':line.quantity_req,
                                'hsn_code':line.hsn_code,
                                'purchase_line_id': quotation_id,                            
                                })
                            
                    cr.execute("UPDATE  prakruti_price_request SET state = 'quotation' WHERE prakruti_price_request.id = cast(%s as integer)",((temp.id),))
                    cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'quotation' WHERE prakruti_purchase_requisition.requisition_no = %s ", ((temp.request_no),))
                    cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'quotation' WHERE prakruti_purchase_requistion_analysis.request_no = %s ", ((temp.request_no),))
                    cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'quotation' WHERE prakruti_purchase_requisition_approve.requisition_no = %s",((temp.request_no),))
        return True
    
    
    def _check_the_main_grid(self, cr, uid, ids, context=None, * args):
        for line_id in self.browse(cr, uid, ids, context=context):
            if len(line_id.request_order_line) == 0:
                return False
        return True   
    
    def _check_the_vendor_grid(self, cr, uid, ids, context=None, * args):
        for line_id in self.browse(cr, uid, ids, context=context):
            if len(line_id.vendor_list_line) == 0:
                return False
        return True
    
    _constraints = [
         (_check_the_vendor_grid, 'Sorry !!!, Please enter some vendor/supplier details to procced further, Thank You !', ['vendor_list_line']),
         (_check_the_main_grid, 'Sorry !!!, Please enter some products to procced further, Thank You !', ['request_order_line'])
    ]

class PurchaseRequisitionLine(models.Model):
    _name = 'prakruti.price_request_line'
    _table = 'prakruti_price_request_line'
    
    request_line_id = fields.Many2one('prakruti.price_request', ondelete='cascade')    
    product_id = fields.Many2one('product.product',string="Product Name", required=True)
    description = fields.Text(string = "Description")
    quantity_req = fields.Float(string = "Qty. Req.", required=True ,digits=(6,3))
    uom_id = fields.Many2one('product.uom',string="UOM",required= True)
    required_date = fields.Date(string="Req. Date")
    remarks = fields.Text(string="Remarks")
    last_price = fields.Float(string = "Last Purchase Price", readonly=True ,digits=(6,3))
    last_purchase_vendor_id= fields.Many2one('res.partner',string="Last Purchase Vendor Name",readonly=True)
    last_purchase_date= fields.Date(string="Last Purchase Date",store=True,readonly=True)
    hsn_code = fields.Char(string='HSN/SAC')

    def onchange_product(self, cr, uid, ids, product_id, context=None):
        cr.execute('SELECT  product_uom.id AS uom_id,product_product.default_code as description  FROM product_uom INNER JOIN product_template ON  product_uom.id=product_template.uom_id  INNER JOIN product_product ON product_product.product_tmpl_id =product_template.id WHERE  product_template.id = cast(%s as integer)', ((product_id),))
        for values in cr.dictfetchall():
            uom_id = values['uom_id']
            return {'value' :{ 'uom_id': uom_id}}

    def _check_qty(self, cr, uid, ids):
         lines = self.browse(cr, uid, ids)
         for line in lines:
             if line.quantity_req <= 0:
                 return False
         return True
     
    _constraints = [
         (_check_qty, 'Order quantity cannot be negative or zero !', ['quantity_req']),
    ]



class VendorRequisitionLine(models.Model):
    _name = 'prakruti.vendor_list_line'
    
    @api.one
    @api.constrains('vendor_id')
    def _check_vendor_id(self):
        if not self.vendor_id:
            raise ValidationError(
                "Please Check the Vendor")
    
    vendor_line_id = fields.Many2one('prakruti.price_request', ondelete='cascade')    
    vendor_id = fields.Many2one('res.partner',string="Vendor Name")    
    address_type = fields.Char(string="Type of Address", related='vendor_id.type_of_address')
    address = fields.Char(string="Address", related='vendor_id.street') 
    remarks = fields.Text(string="Remarks")