# -*- coding: utf-8 -*-
import openerp
from datetime import date, datetime
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from datetime import timedelta
from openerp.osv import osv,fields
from openerp import models, fields, api, _
from openerp.tools.translate import _
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
from lxml import etree
import cgi
import logging
import lxml.html
import lxml.html.clean as clean
import openerp.pooler as pooler
import random
import re
import socket
import threading
import time
from openerp.tools import image_resize_image_big
from openerp.tools import amount_to_text
from openerp.tools.amount_to_text import amount_to_text_in 
from openerp.tools.amount_to_text import amount_to_text_in_without_word_rupees 
from openerp.exceptions import ValidationError


class PrakrutiPurchaseOrder(models.Model):
    _name =  'prakruti.purchase_order'
    _table = 'prakruti_purchase_order'
    _description = 'Purchase Order'
    _rec_name = 'po_no'    
    _order="id desc"
    
    auto_no = fields.Integer('Auto')
    req_no_control_id = fields.Integer('Auto Generating id',default= 0)
    requistion_no= fields.Char(string='PO No',compute= '_get_auto', readonly=True) 
    po_no = fields.Char(string='Order No', readonly=True)
    pr_no = fields.Char(string='Requisition No', readonly=True)
    qa_no = fields.Char(string='Analysis No', readonly=True)
    qo_no = fields.Char(string='Quotation No', readonly=True)
    req_no =fields.Char(string='Request No', readonly=True)
    vendor_id = fields.Many2one('res.partner',string='Vendor/Supplier')
    logo = fields.Binary(related='company_address.logo')
    vendor_reference = fields.Char(string='Vendor/Supplier Reference')
    other_reference = fields.Char(string='Other Reference')
    request_date = fields.Date(string = "Requisition Date")
    order_date = fields.Date(string='Order Date', default= fields.Date.today, required=True)
    destination = fields.Char(string='Destination')
    company_address = fields.Many2one('res.company',string='Company Address')
    delivery_address = fields.Many2one('res.company',string='Dispatch To',readonly=True)
    payment = fields.Char(string='Mode/Terms of Payments')
    terms_of_delivery = fields.Text(string='Terms of Delivery')
    remarks=fields.Text('Remarks')
    order_line = fields.One2many('prakruti.purchase_line','purchase_line_id',string='Purchase Order Line')
    total_discount = fields.Float(string="Total Discount" , compute='_compute_discount_amount', store=True ,digits=(6,3))
    amount_untaxed= fields.Float(string='Untaxed Amount',compute= '_compute_untaxed_amount',store=True ,digits=(6,3))
    dispatch_through = fields.Char(string='Dispatch Through')
    prepared_by = fields.Many2one('res.users','Prepared By',readonly=True)
    maintanence_manager = fields.Many2one('res.users',string="Maintanence Manager", required=True)    
    purchase_manager = fields.Many2one('res.users',string="Purchase Manager", required=True)
    stores_incharge = fields.Many2one('res.users',string="Stores Incharge")
    purchase_type = fields.Many2one('product.group',string= 'Purchase Type')
    state = fields.Selection([
		('requisition', 'Requisition'),
		('request','Request'),
		('quotation','Quotation'),
                ('analysis','Quotation Analysis'),
                ('order','Order'),
                ('confirm','Open Order'),
                ('order_close','Order Closed'),
                ('reject','Rejected'),
                ('short_close','Short Close')],default= 'order', string= 'Status')
    pr_common_id = fields.Integer('PR SCREEN COMMON ID')
    grand_total_in_words= fields.Text(compute= '_get_total_in_words',string='Total in words')
    currency_id = fields.Many2one('res.currency', 'Currency')
    prakruti_stock_id = fields.Integer('SCREEN COMMON ID')
    discounted_total = fields.Float(string= 'Discounted Total',compute= '_compute_discounted_total',store= True ,digits=(6,3))
    order_close_flag = fields.Integer(string='Close the Order',default=0)
    any_adv_payment =fields.Selection([
                    ('no', 'No'),
                    ('yes','Yes')
                    ], string= 'Any Advance Payment')
    advance_payment_type =fields.Selection([
                    ('cash', 'CASH'),
                    ('cheque','CHEQUE'),
                    ('demand_draft','DEMAND DRAFT')
                    ], string= 'Done By')
    cash_amount = fields.Float(string="Amount" ,digits=(6,3),default=0)
    cash_remarks = fields.Text(string="Remarks")    
    cheque_amount = fields.Float(string="Amount" ,digits=(6,3),default=0)
    cheque_no = fields.Integer(string="Cheque No.")
    cheque_remarks = fields.Text(string="Remarks")    
    draft_amount = fields.Float(string="Amount" ,digits=(6,3),default=0)
    draft_no = fields.Integer(string="Draft No.")
    draft_remarks = fields.Text(string="Remarks") 
    product_id = fields.Many2one('product.product', related='order_line.product_id', string='Product Name')
    short_close_remarks = fields.Text(string="Remarks For Short Close")
    revise_flag= fields.Integer(string='Revised No.',default=0) 
    revise_comments= fields.Text(string='Revised Comments')
    revised_status = fields.Selection([('revised','Revised')],string= 'Revised Status')    
    # Previous Code  (Not in use)
    excise_id = fields.Many2one('account.other.tax', string='Excise Duty', domain=['|', ('active', '=', False), ('active', '=', True)])
    excise_duty = fields.Float(related='excise_id.per_amount',string= 'Excise Duty(%)',store=True,readonly=True ,digits=(6,3))
    total_excise_duty = fields.Float(string= 'Total Excise Duty',compute= '_compute_excise_duty' ,digits=(6,3))
    total_tax = fields.Float(string="Total Tax" , compute='_compute_tax_total_amount', store=True ,digits=(6,3))
    #GST ENTRY
    no_of_product = fields.Integer(string= "No of Products")
    amount_taxed= fields.Float(string='Taxed Amount',digits=(6,3),readonly=1)    
    total_cgst= fields.Float(string='Total CGST',digits=(6,3),readonly=1)
    total_sgst= fields.Float(string='Total SGST',digits=(6,3),readonly=1)
    total_igst= fields.Float(string='Total IGST',digits=(6,3),readonly=1)
    total_gst= fields.Float(string='Total GST',digits=(6,3),readonly=1)
    insurance_charges = fields.Float(string="Insurance Charges" ,digits=(6,3))
    frieght_charges_applied = fields.Selection([('yes','Yes'),('no','No')], string="Freight Charge Applied", default='no')
    frieght_charges = fields.Float(string="Frieght Charges" ,digits=(6,3))
    additional_charges = fields.Float(string='Additional Charges' ,digits=(6,3))
    packing_charges = fields.Float(string='Packing & Forwarding' ,digits=(6,3))
    grand_total= fields.Float(string='Total',digits=(6,3),readonly=1)
    grand_total_after_payments= fields.Float(string='Grand Total',digits=(6,3),readonly=1)
                
    #@api.depends('order_line.taxable_value_after_adding_other')
    #def _compute_taxed_amount(self):
        #for order in self:
            #amount_taxed = 0.0
            #for line in order.order_line:
                #amount_taxed += line.taxable_value_after_adding_other
                #order.update({
                    #'amount_taxed': amount_taxed
                    #})
    
    #@api.depends('order_line.cgst_value')
    #def _compute_total_cgst(self):
        #for order in self:
            #cgst_value = 0.0
            #for line in order.order_line:
                #cgst_value += line.cgst_value
                #order.update({
                    #'total_cgst': cgst_value
                    #})
                
    #@api.depends('order_line.sgst_value')
    #def _compute_total_sgst(self):
        #for order in self:
            #sgst_value = 0.0
            #for line in order.order_line:
                #sgst_value += line.sgst_value
                #order.update({
                    #'total_sgst': sgst_value
                    #})
                
                
    #@api.depends('order_line.igst_value')
    #def _compute_total_igst(self):
        #for order in self:
            #igst_value = 0.0
            #for line in order.order_line:
                #igst_value += line.igst_value
                #order.update({
                    #'total_igst': igst_value
                    #})
    
    #@api.depends('order_line.cgst_value','order_line.sgst_value','order_line.igst_value')
    #def _compute_total_gst(self):
        #for order in self:
            #total_gst = 0.0
            #cgst_value = 0.0
            #sgst_value = 0.0
            #igst_value = 0.0
            #for line in order.order_line:
                #cgst_value += line.cgst_value
                #sgst_value += line.sgst_value
                #igst_value += line.igst_value
                #total_gst = cgst_value + sgst_value + igst_value
                #order.update({
                    #'total_gst': total_gst
                    #})
                
    #@api.depends('order_line.subtotal')
    #def _compute_grand_total(self):
        #for order in self:
            #grand_total = 0.0
            #for line in order.order_line:
                #grand_total += line.subtotal
                #order.update({
                    #'grand_total': grand_total
                    #})
    
    
    #@api.depends('order_line.quantity','order_line.unit_price')
    #def _total_no_of_product(self):
        #for order in self:
            #total_no_of_product = 0
            #total_no_of_product = len(order.order_line)
            #order.update({
                #'no_of_product': total_no_of_product
                #})
    
    @api.one
    @api.constrains('vendor_id')
    def _check_vendor_id(self):
        if not self.vendor_id:
            raise ValidationError(
                "Please Check the Vendor")

    @api.one
    @api.multi
    def revise_order(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            if temp.revise_comments:
                revise_values = self.pool.get('prakruti.purchase_order').create(cr,uid,{
                    'auto_no':temp.auto_no,
                    'req_no_control_id':temp.req_no_control_id,
                    'requistion_no':temp.requistion_no,
                    'po_no':temp.po_no,
                    'pr_no':temp.pr_no,
                    'qa_no':temp.qa_no,
                    'qo_no':temp.qo_no,
                    'req_no':temp.req_no,
                    'vendor_id':temp.vendor_id.id,
                    'logo':temp.logo,
                    'vendor_reference':temp.vendor_reference,
                    'other_reference':temp.other_reference,
                    'request_date':temp.request_date,
                    'order_date':temp.order_date,
                    'destination':temp.destination,
                    'company_address':temp.company_address.id,
                    'delivery_address':temp.delivery_address.id,
                    'payment':temp.payment,
                    'terms_of_delivery':temp.terms_of_delivery,
                    'remarks':temp.remarks,
                    'total_discount':temp.total_discount,
                    'total_tax':temp.total_tax,
                    'amount_untaxed':temp.amount_untaxed,
                    'dispatch_through':temp.dispatch_through,
                    'prepared_by':temp.prepared_by.id,
                    'maintanence_manager':temp.maintanence_manager.id,
                    'purchase_manager':temp.purchase_manager.id,
                    'stores_incharge':temp.stores_incharge.id,
                    'purchase_type':temp.purchase_type.id,
                    'state':temp.state,
                    'pr_common_id':temp.pr_common_id,
                    'grand_total_in_words':temp.grand_total_in_words,
                    'currency_id':temp.currency_id.id,
                    'prakruti_stock_id':temp.prakruti_stock_id,
                    'excise_id':temp.excise_id.id,
                    'excise_duty':temp.excise_duty,
                    'total_excise_duty':temp.total_excise_duty,
                    'discounted_total':temp.discounted_total,
                    'order_close_flag':temp.order_close_flag,
                    'any_adv_payment':temp.any_adv_payment,
                    'advance_payment_type':temp.advance_payment_type,
                    'cash_amount':temp.cash_amount,
                    'cash_remarks':temp.cash_remarks,
                    'cheque_amount':temp.cheque_amount,
                    'cheque_no':temp.cheque_no,
                    'cheque_remarks':temp.cheque_remarks,
                    'draft_amount':temp.draft_amount,
                    'draft_no':temp.draft_no,
                    'draft_remarks':temp.draft_remarks,
                    'product_id':temp.product_id.id,
                    'short_close_remarks':temp.short_close_remarks,
                    #GST Entry
                    'no_of_product':temp.no_of_product,
                    'amount_taxed':temp.amount_taxed,
                    'total_cgst':temp.total_cgst,
                    'total_sgst':temp.total_sgst,
                    'total_igst':temp.total_igst,
                    'total_gst':temp.total_gst,
                    'insurance_charges':temp.insurance_charges,
                    'frieght_charges_applied':temp.frieght_charges_applied,
                    'frieght_charges':temp.frieght_charges,
                    'packing_charges':temp.packing_charges,
                    'additional_charges':temp.additional_charges,
                    'grand_total':temp.grand_total,
                    'grand_total_after_payments':temp.grand_total_after_payments,
                    'revise_flag':0
                    })
                for line in temp.order_line:
                    grid_entry = self.pool.get('prakruti.purchase_line').create(cr,uid,{
                        'product_id':line.product_id.id,
                        'description':line.description,
                        'p_type':line.p_type,
                        'scheduled_date':line.scheduled_date,
                        'unit_price':line.unit_price,
                        'uom_id':line.uom_id.id,
                        'discount':line.discount,
                        'tax_type':line.tax_type,
                        'tax_id':line.tax_id.id,
                        'tax_price':line.tax_price,
                        'pr_common_id':line.pr_common_id,
                        'currency_id':line.currency_id.id,
                        'prakruti_stock_id':line.prakruti_stock_id,
                        'remarks':line.remarks,
                        'vendor_id':line.vendor_id.id,
                        'status':line.status,
                        'balance_qty':line.balance_qty,
                        'no_of_packings':line.no_of_packings,
                        'pack_per_qty':line.pack_per_qty,
                        'extra_packing':line.extra_packing,
                        'quantity':line.quantity,
                        'tax_value':line.tax_value,
                        'excise_duty':line.excise_duty,
                        'total_excise_duty':line.total_excise_duty,
                        'after_discount':line.after_discount,
                        #GST ENTRY
                        'hsn_code': line.hsn_code,
                        'discount_id':line.discount_id.id,
                        'discount_rate':line.discount_rate,
                        'discount_value':line.discount_value,
                        'taxable_value': line.taxable_value,
                        'total':line.total,
                        'cgst_id':line.cgst_id.id,
                        'cgst_rate':line.cgst_rate,
                        'cgst_value': line.cgst_value,
                        'sgst_id':line.sgst_id.id,
                        'sgst_rate':line.sgst_rate,
                        'sgst_value': line.sgst_value,
                        'igst_id':line.igst_id.id,
                        'igst_rate':line.igst_rate,
                        'igst_value': line.igst_value,
                        'taxable_value_after_adding_other':line.taxable_value_after_adding_other,
                        'subtotal': line.subtotal,
                        'no_of_product':line.no_of_product,
                        'packing_charges':line.packing_charges,
                        'frieght_charges':line.frieght_charges,
                        'additional_charges':line.additional_charges,
                        'insurance_charges':line.insurance_charges,
                        #GST ENTRY
                        'purchase_line_id':revise_values
                        })
                cr.execute("UPDATE prakruti_purchase_order SET revise_flag = revise_flag + 1,revised_status = 'revised' WHERE id = %s",((temp.id),))
                cr.execute("UPDATE prakruti_purchase_order_quotation_analysis SET revised_status = 'revised' WHERE prakruti_purchase_order_quotation_analysis.pr_no = %s AND prakruti_purchase_order_quotation_analysis.qa_no = %s", ((temp.pr_no),(temp.qa_no)))
                cr.execute("UPDATE prakruti_purchase_order_quotation SET revised_status = 'revised' WHERE prakruti_purchase_order_quotation.pr_no = %s AND prakruti_purchase_order_quotation.qo_no = %s", ((temp.pr_no),(temp.qo_no),))
                cr.execute("UPDATE prakruti_price_request SET revised_status = 'revised' WHERE prakruti_price_request.request_no = %s AND prakruti_price_request.inquiry_no = %s", ((temp.pr_no),(temp.req_no)))
                cr.execute("UPDATE prakruti_purchase_requistion_analysis SET revised_status = 'revised' WHERE prakruti_purchase_requistion_analysis.request_no = %s ", ((temp.pr_no),))
                cr.execute("UPDATE prakruti_purchase_requisition_approve SET revised_status = 'revised' WHERE prakruti_purchase_requisition_approve.requisition_no = %s",((temp.pr_no),))
                cr.execute("UPDATE prakruti_purchase_requisition SET revised_status = 'revised' WHERE prakruti_purchase_requisition.requisition_no = %s ", ((temp.pr_no),))
            else:
                raise UserError(_('Please Enter Revised Comments'))
        return {}
    
    @api.one
    @api.multi 
    def short_close_order(self):        
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            if temp.short_close_remarks:
                cr.execute("UPDATE  prakruti_purchase_order SET state = 'short_close' WHERE prakruti_purchase_order.id = cast(%s as integer)", ((temp.id),))
                cr.execute("UPDATE  prakruti_purchase_order_quotation_analysis SET state = 'short_close' WHERE prakruti_purchase_order_quotation_analysis.pr_no = %s AND prakruti_purchase_order_quotation_analysis.qa_no = %s", ((temp.pr_no),(temp.qa_no)))
                cr.execute("UPDATE  prakruti_purchase_order_quotation SET state = 'short_close' WHERE prakruti_purchase_order_quotation.pr_no = %s AND prakruti_purchase_order_quotation.qo_no = %s", ((temp.pr_no),(temp.qo_no),))
                cr.execute("UPDATE  prakruti_price_request SET state = 'short_close' WHERE prakruti_price_request.request_no = %s AND prakruti_price_request.inquiry_no = %s", ((temp.pr_no),(temp.req_no)))
                cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'requisition_analysis' WHERE prakruti_purchase_requistion_analysis.request_no = %s ", ((temp.pr_no),))
                template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Purcahse Order Short Close')],context=context)[0]
                email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
            else:
                raise UserError(_('Please enter remarks for Short Close'))
        return {}
    
    #@api.one
    #@api.multi 
    #def action_calculate(self):        
        #cr = self.env.cr
        #uid = self.env.uid
        #ids = self.ids
        #context = 'context'
        #for temp in self:
            #cr.execute('''SELECT update_purchase_order_calculation(%s)''',((temp.id),))
        #return {}        
        
    @api.one
    @api.multi 
    def reject_order(self):        
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            if temp.remarks:
                cr.execute("UPDATE prakruti_purchase_order SET state = 'reject' WHERE prakruti_purchase_order.pr_no = %s and vendor_id = %s" ,((temp.pr_no),(temp.vendor_id.id),))
                cr.execute("UPDATE prakruti_purchase_order_quotation_analysis SET state = 'reject' WHERE prakruti_purchase_order_quotation_analysis.pr_no = %s and vendor_id = %s",((temp.pr_no),(temp.vendor_id.id),))
                cr.execute("UPDATE prakruti_purchase_order_quotation SET state = 'reject' WHERE prakruti_purchase_order_quotation.pr_no = %s and vendor_id = %s",((temp.pr_no),(temp.vendor_id.id),))
                cr.execute("UPDATE prakruti_logistics_po_tracking SET state = 'reject' WHERE prakruti_logistics_po_tracking.po_no = %s and vendor_id = %s",((temp.po_no),(temp.vendor_id.id),))
                cr.execute("SELECT count(prakruti_purchase_requistion_analysis_line.id) as total_line FROM prakruti_purchase_requistion_analysis_line INNER JOIN prakruti_purchase_requistion_analysis ON prakruti_purchase_requistion_analysis_line.requistion_line_id = prakruti_purchase_requistion_analysis.id INNER JOIN prakruti_purchase_order ON prakruti_purchase_requistion_analysis.request_no = prakruti_purchase_order.pr_no WHERE prakruti_purchase_requistion_analysis.request_no = %s AND prakruti_purchase_order.id = %s",((temp.pr_no),(temp.id),))
                for line in cr.dictfetchall():
                    total_line = line['total_line']
                cr.execute("SELECT count(id) as grid_line FROM prakruti_purchase_line WHERE purchase_line_id = %s",((temp.id),))
                for line in cr.dictfetchall():
                    grid_line = line['grid_line']
                if grid_line == total_line:
                    cr.execute("UPDATE prakruti_purchase_requistion_analysis AS b SET state = 'rejected' FROM(SELECT prakruti_purchase_order.id,prakruti_purchase_order.pr_no FROM prakruti_purchase_order WHERE prakruti_purchase_order.id= %s AND prakruti_purchase_order.pr_no = %s) AS a WHERE a.pr_no = b.request_no",((temp.id),(temp.pr_no)))
                    cr.execute("UPDATE prakruti_purchase_requisition_approve AS b SET state = 'rejected' FROM(SELECT prakruti_purchase_order.id,prakruti_purchase_order.pr_no FROM prakruti_purchase_order WHERE prakruti_purchase_order.id= %s AND prakruti_purchase_order.pr_no = %s) AS a WHERE a.pr_no = b.requisition_no",((temp.id),(temp.pr_no)))
                    cr.execute("UPDATE prakruti_purchase_requisition AS b SET state = 'rejected' FROM(SELECT prakruti_purchase_order.id,prakruti_purchase_order.pr_no FROM prakruti_purchase_order WHERE prakruti_purchase_order.id= %s AND prakruti_purchase_order.pr_no = %s) AS a WHERE a.pr_no = b.requisition_no",((temp.id),(temp.pr_no)))
                else:
                    cr.execute("UPDATE prakruti_purchase_requistion_analysis AS b SET state = 'partial_confirm' FROM(SELECT prakruti_purchase_order.id,prakruti_purchase_order.pr_no FROM prakruti_purchase_order WHERE prakruti_purchase_order.id= %s AND prakruti_purchase_order.pr_no = %s) AS a WHERE a.pr_no = b.request_no",((temp.id),(temp.pr_no)))
                    cr.execute("UPDATE prakruti_purchase_requisition_approve AS b SET state = 'partial_confirm' FROM(SELECT prakruti_purchase_order.id,prakruti_purchase_order.pr_no FROM prakruti_purchase_order WHERE prakruti_purchase_order.id= %s AND prakruti_purchase_order.pr_no = %s) AS a WHERE a.pr_no = b.requisition_no",((temp.id),(temp.pr_no)))
                    cr.execute("UPDATE prakruti_purchase_requisition AS b SET state = 'partial_confirm' FROM(SELECT prakruti_purchase_order.id,prakruti_purchase_order.pr_no FROM prakruti_purchase_order WHERE prakruti_purchase_order.id= %s AND prakruti_purchase_order.pr_no = %s) AS a WHERE a.pr_no = b.requisition_no",((temp.id),(temp.pr_no)))
                    
                
            else:
                raise UserError(_('Please Enter Remarks...'))
        return {}    
    
    @api.one
    @api.multi
    def _get_auto(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        for temp in self :
            cr.execute('''select cast(extract (month from order_date) as integer) as month ,cast(extract (year from order_date) as integer) as year ,id from prakruti_purchase_order where id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
            if month_value<=3:
                year_value=year_value-1
            else:
                year_value=year_value
            next_year=year_value+1
            dispay_year=str(next_year)[-2:]
            display_present_year=str(year_value)[-2:]
            cr.execute('''select autogenerate_purchase_order(%s)''', ((temp.id),)  ) 
            result = cr.dictfetchall()
            parent_invoice_id = 0
            for value in result: parent_invoice_id = value['autogenerate_purchase_order'];
            auto_gen = int(parent_invoice_id)
            if len(str(auto_gen)) < 2:
                auto_gen = '000'+ str(auto_gen)
            elif len(str(auto_gen)) < 3:
                auto_gen = '00' + str(auto_gen)
            elif len(str(auto_gen)) == 3:
                auto_gen = '0'+str(auto_gen)
            else:
                auto_gen = str(auto_gen)
            for record in self :
                if temp.purchase_type.group_code:
                    x[record.id] ='PO\\'+ temp.purchase_type.group_code+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                else:                        
                    x[record.id] ='PO\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                cr.execute('''update prakruti_purchase_order_quotation set qo_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
                cr.execute('''update prakruti_purchase_order set po_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
        return x
    
    
    
    
                
    
   
                
    @api.depends('amount_untaxed','packing_charges','excise_duty','order_line.status','discounted_total')
    def _compute_excise_duty(self):
        for order in self:
            total_excise_duty = 0.0
            for line in order.order_line:
                if line.status == 'open':
                    order.update({                
                            'total_excise_duty': (order.discounted_total + order.packing_charges )* (order.excise_duty/100)
                            })
            
    
    
    @api.depends('order_line.discount','order_line.status')
    def _compute_discount_amount(self):
        for order in self:
            discount_amt= 0.0
            for line in order.order_line:
                if line.status == 'open':
                    discount_amt += line.discount_value
                    order.update({
                        'total_discount': discount_amt
                        })
                
    @api.depends('amount_untaxed','total_discount','order_line.discount','order_line.status')
    def _compute_discounted_total(self):
        for order in self:
            discounted_total= 0.0
            for line in order.order_line:
                if line.status == 'open':
                    order.update({
                        'discounted_total': order.amount_untaxed - order.total_discount
                        })
                
    @api.depends('order_line.tax_price','order_line.tax_value','order_line.packing_charges','order_line.total_excise_duty','order_line.excise_duty','order_line.after_discount','order_line.discount','order_line.after_discount','order_line.unit_price','order_line.quantity','amount_untaxed','total_discount','total_excise_duty','discounted_total','packing_charges','excise_duty')
    def _compute_tax_total_amount(self):
        for order in self:
            total_tax = taxed_value = 0.0
            for line in order.order_line:
                if line.status == 'open':
                    taxed_value += line.tax_value
                    order.update({
                        'total_tax': taxed_value
                        })     
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['order','confirm','order_close']:
                raise UserError(_('Can\'t Delete, Since the Order is Confirm.'))
        return super(PrakrutiPurchaseOrder, self).unlink()
    
    @api.depends('grand_total')
    def _get_total_in_words(self):
        for order in self:
            grand_total = val1 = 0.0
            val1_in_words = ""
            for line in order.order_line:
                if line.status == 'open':
                    val1 = order.grand_total
                    val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
                    order.update({                    
                        'grand_total_in_words': val1_in_words.upper()
                        })
    
    @api.onchange('any_adv_payment')
    def onchange_any_adv_payment(self):
        if self.any_adv_payment == 'no':
            self.advance_payment_type = None
    
    @api.onchange('advance_payment_type')
    def onchange_advance_payment_type(self):
        if self.advance_payment_type == 'cash':
            self.cheque_amount = 0
            self.cheque_no = 0
            self.cheque_remarks = ''
            self.draft_amount = 0
            self.draft_no = 0
            self.draft_remarks = ''
        if self.advance_payment_type == 'cheque':
            self.cash_amount = 0
            self.cash_remarks = ''
            self.draft_amount = 0
            self.draft_no = 0
            self.draft_remarks = ''
        if self.advance_payment_type == 'demand_draft':
            self.cash_amount = 0
            self.cash_remarks = ''
            self.cheque_amount = 0
            self.cheque_no = 0
            self.cheque_remarks = ''
        else:
            self.cash_amount = 0
            self.cash_remarks = ''
            self.cheque_amount = 0
            self.cheque_no = 0
            self.cheque_remarks = ''
            self.draft_amount = 0
            self.draft_no = 0
            self.draft_remarks = ''
    
    @api.onchange('frieght_charges_applied','frieght_charges')
    def onchange_freight_charges(self):
        if self.frieght_charges_applied == 'no':
            self.frieght_charges = 0.0
    
    @api.one
    @api.constrains('grand_total')
    def _check_grand_total(self):
        if self.grand_total < 0:
            raise ValidationError(
                "Please Check the Advance Payment Details\n Since Grand Total is going Negative")
    
    @api.one
    @api.constrains('packing_charges')
    def _check_packing_charges(self):
        if self.packing_charges < 0:
            raise ValidationError(
                "Packing Amount !!! Can't be Negative")  
    
    @api.one
    @api.constrains('frieght_charges')
    def _check_frieght_charges(self):
        if self.frieght_charges < 0:
            raise ValidationError(
                "Freight Amount !!! Can't be Negative") 
    
    @api.one
    @api.constrains('additional_charges')
    def _check_additional_charges(self):
        if self.additional_charges < 0:
            raise ValidationError(
                "Additional Amount !!! Can't be Negative") 
    
    @api.one
    @api.constrains('draft_amount')
    def _check_draft_amount(self):
        if self.draft_amount < 0:
            raise ValidationError(
                "Draft Amount !!! Can't be Negative") 
    
    @api.one
    @api.constrains('cash_amount')
    def _check_cash_amount(self):
        if self.cash_amount < 0:
            raise ValidationError(
                "Cash Amount !!! Can't be Negative") 
    
    @api.one
    @api.constrains('cheque_amount')
    def _check_cheque_amount(self):
        if self.cheque_amount < 0:
            raise ValidationError(
                "Check Amount !!! Can't be Negative") 
    
    
    @api.model
    def _default_company(self):
        return self.env['res.company']._company_default_get('res.partner') 
    
    _defaults = {
        'po_no':'New',
        'pr_no':'Direct Order',
        'qa_no':'Direct Order',
        'qo_no':'Direct Order',
        'req_no':'Direct Order',
        'prepared_by': lambda s, cr, uid, c:uid,
        'company_address': _default_company
        }
    
    @api.one
    @api.multi 
    def confirm_to_logistics(self):        
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            cr.execute("select unit_price from prakruti_purchase_line where purchase_line_id=%s",((temp.id),))
            for line in cr.dictfetchall():
                unit_price=line['unit_price']
            if temp.revise_flag == 0: 
                if unit_price !=0:
                    logistics_entry = self.pool.get('prakruti.logistics_po_tracking').create(cr,uid, {
                        'cash_amount':temp.cash_amount,
                        'cash_remarks':temp.cash_remarks,
                        'cheque_amount':temp.cheque_amount,
                        'cheque_no':temp.cheque_no,
                        'cheque_remarks':temp.cheque_remarks,
                        'draft_amount':temp.draft_amount,
                        'draft_no':temp.draft_no,
                        'draft_remarks':temp.draft_remarks,
                        'advance_payment_type':temp.advance_payment_type,
                        'any_adv_payment':temp.any_adv_payment,
                        'po_no':temp.po_no,
                        'qa_no':temp.qa_no,
                        'pr_no':temp.pr_no,
                        'qo_no':temp.qo_no,
                        'req_no':temp.req_no,
                        'vendor_reference':temp.vendor_reference,
                        'payment':temp.payment,
                        'destination':temp.destination,
                        'other_reference':temp.other_reference,
                        'maintanence_manager':temp.maintanence_manager.id,
                        'purchase_manager':temp.purchase_manager.id,
                        'stores_incharge':temp.stores_incharge.id,
                        'terms_of_delivery':temp.terms_of_delivery,
                        'vendor_id': temp.vendor_id.id,
                        'state':'confirm',
                        'remarks':temp.remarks,
                        'request_date':temp.request_date,
                        'order_date':temp.order_date,                        
                        'amount_untaxed':temp.amount_untaxed,
                        'total_discount':temp.total_discount,
                        'total_tax':temp.total_tax,
                        'dispatch_through':temp.dispatch_through,
                        'excise_id':temp.excise_id.id,
                        'excise_duty':temp.excise_duty,
                        'total_excise_duty':temp.total_excise_duty,
                        'company_address':temp.company_address.id,
                        'purchase_type':temp.purchase_type.id,
                        #GST Entry
                        'no_of_product':temp.no_of_product,
                        'amount_taxed':temp.amount_taxed,
                        'total_cgst':temp.total_cgst,
                        'total_sgst':temp.total_sgst,
                        'total_igst':temp.total_igst,
                        'total_gst':temp.total_gst,
                        'insurance_charges':temp.insurance_charges,
                        'frieght_charges_applied':temp.frieght_charges_applied,
                        'frieght_charges':temp.frieght_charges,
                        'packing_charges':temp.packing_charges,
                        'additional_charges':temp.additional_charges,
                        'grand_total':temp.grand_total
                        })
                    cr.execute("SELECT product_id,balance_qty,description,uom_id,quantity,extra_packing,scheduled_date,unit_price,vendor_id,discount,tax_price,tax_id,subtotal,prakruti_purchase_line.remarks,prakruti_purchase_line.id,no_of_packings,pack_per_qty,hsn_code,discount_id,discount_rate,discount_value,taxable_value,total,cgst_id,cgst_rate,cgst_value,sgst_id,sgst_rate,sgst_value,igst_id,igst_rate,igst_value,taxable_value_after_adding_other,no_of_product,packing_charges,frieght_charges,additional_charges,insurance_charges FROM prakruti_purchase_line WHERE purchase_line_id = CAST(%s as integer) AND status ='open' ",((temp.id),))
                    for item in cr.dictfetchall():
                        grid_down = self.pool.get('prakruti.purchase_line_in_logistics').create(cr,uid, {
                            'product_id':item['product_id'],
                            'description':item['description'],
                            'quantity':item['balance_qty'],
                            'uom_id':item['uom_id'],
                            'scheduled_date':item['scheduled_date'],
                            'unit_price':item['unit_price'],
                            'discount':item['discount'],
                            'tax_price':item['tax_price'],
                            'tax_id':item['tax_id'],
                            'subtotal':item['subtotal'],
                            'vendor_id':item['vendor_id'],
                            'remarks':item['remarks'],
                            'no_of_packings':item['no_of_packings'],
                            'pack_per_qty':item['pack_per_qty'],
                            'extra_packing':item['extra_packing'],
                            'purchase_line_common_id':item['id'],
                            #GST ENTRY
                            'hsn_code': item['hsn_code'],
                            'discount_id':item['discount_id'],
                            'discount_rate':item['discount_rate'],
                            'discount_value':item['discount_value'],
                            'taxable_value': item['taxable_value'],
                            'total':item['total'],
                            'cgst_id':item['cgst_id'],
                            'cgst_rate':item['cgst_rate'],
                            'cgst_value': item['cgst_value'],
                            'sgst_id':item['sgst_id'],
                            'sgst_rate':item['sgst_rate'],
                            'sgst_value': item['sgst_value'],
                            'igst_id':item['igst_id'],
                            'igst_rate':item['igst_rate'],
                            'igst_value': item['igst_value'],
                            'taxable_value_after_adding_other':item['taxable_value_after_adding_other'],
                            'no_of_product':item['no_of_product'],
                            'packing_charges':item['packing_charges'],
                            'frieght_charges':item['frieght_charges'],
                            'additional_charges':item['additional_charges'],
                            'insurance_charges':item['insurance_charges'],
                            #GST ENTRY
                            'logistics_line_id':logistics_entry
                            })
                    cr.execute("UPDATE  prakruti_purchase_order SET state = 'confirm' WHERE prakruti_purchase_order.id = cast(%s as integer)", ((temp.id),))
                    cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'confirm' WHERE prakruti_purchase_requisition.requisition_no = %s ", ((temp.pr_no),))
                    cr.execute("UPDATE  prakruti_price_request SET state = 'confirm' WHERE prakruti_price_request.request_no = %s AND prakruti_price_request.inquiry_no = %s", ((temp.pr_no),(temp.req_no)))
                    cr.execute("UPDATE  prakruti_purchase_order_quotation SET state = 'confirm' WHERE prakruti_purchase_order_quotation.pr_no = %s AND prakruti_purchase_order_quotation.qo_no = %s", ((temp.pr_no),(temp.qo_no),))
                    cr.execute("UPDATE  prakruti_purchase_order_quotation_analysis SET state = 'confirm' WHERE prakruti_purchase_order_quotation_analysis.pr_no = %s AND prakruti_purchase_order_quotation_analysis.qa_no = %s", ((temp.pr_no),(temp.qa_no)))
                    cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'confirm' WHERE prakruti_purchase_requisition_approve.requisition_no = %s",((temp.pr_no),))
                    template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Purcahse Order')],context=context)[0]
                    email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
                else:
                    raise UserError(_('Please Enter Unit Price')) 
                cr.execute("SELECT count(prakruti_purchase_requistion_analysis_line.id) AS no_of_approved_line FROM prakruti_purchase_requistion_analysis_line INNER JOIN prakruti_purchase_requistion_analysis ON prakruti_purchase_requistion_analysis_line.requistion_line_id = prakruti_purchase_requistion_analysis.id INNER JOIN prakruti_purchase_order ON prakruti_purchase_order.pr_no = prakruti_purchase_requistion_analysis.request_no WHERE prakruti_purchase_requistion_analysis_line.status= 'approved' AND prakruti_purchase_requistion_analysis.request_no = %s AND prakruti_purchase_order.id = %s",((temp.pr_no),(temp.id),))
                for line in cr.dictfetchall():
                    no_of_approved_line=line['no_of_approved_line']
                cr.execute("SELECT count(prakruti_purchase_requistion_analysis_line.id) AS no_of_line FROM prakruti_purchase_requistion_analysis_line INNER JOIN prakruti_purchase_requistion_analysis ON prakruti_purchase_requistion_analysis_line.requistion_line_id = prakruti_purchase_requistion_analysis.id INNER JOIN prakruti_purchase_order ON prakruti_purchase_order.pr_no = prakruti_purchase_requistion_analysis.request_no WHERE prakruti_purchase_requistion_analysis.request_no = %s AND prakruti_purchase_order.id = %s",((temp.pr_no),(temp.id),))
                for line in cr.dictfetchall():
                    no_of_line=line['no_of_line']
                if no_of_approved_line == no_of_line:
                    cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'confirm' WHERE prakruti_purchase_requistion_analysis.request_no = %s ", ((temp.pr_no),))
                else:
                    cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'partial_confirm' WHERE prakruti_purchase_requistion_analysis.request_no = %s ", ((temp.pr_no),))                   
            if temp.revise_flag > 0:
                if temp.revise_comments: 
                    if unit_price !=0:  
                        logistics_entry = self.pool.get('prakruti.logistics_po_tracking').create(cr,uid, {
                            'cash_amount':temp.cash_amount,
                            'cash_remarks':temp.cash_remarks,
                            'cheque_amount':temp.cheque_amount,
                            'cheque_no':temp.cheque_no,
                            'cheque_remarks':temp.cheque_remarks,
                            'draft_amount':temp.draft_amount,
                            'draft_no':temp.draft_no,
                            'draft_remarks':temp.draft_remarks,
                            'advance_payment_type':temp.advance_payment_type,
                            'any_adv_payment':temp.any_adv_payment,
                            'po_no':temp.po_no,
                            'qa_no':temp.qa_no,
                            'pr_no':temp.pr_no,
                            'qo_no':temp.qo_no,
                            'req_no':temp.req_no,
                            'vendor_reference':temp.vendor_reference,
                            'payment':temp.payment,
                            'destination':temp.destination,
                            'other_reference':temp.other_reference,
                            'maintanence_manager':temp.maintanence_manager.id,
                            'purchase_manager':temp.purchase_manager.id,
                            'stores_incharge':temp.stores_incharge.id,
                            'terms_of_delivery':temp.terms_of_delivery,
                            'vendor_id': temp.vendor_id.id,
                            'state':'confirm',
                            'remarks':temp.remarks,
                            'request_date':temp.request_date,
                            'order_date':temp.order_date,                        
                            'amount_untaxed':temp.amount_untaxed,
                            'additional_charges':temp.additional_charges,
                            'grand_total':temp.grand_total,
                            'frieght_charges_applied':temp.frieght_charges_applied,
                            'frieght_charges':temp.frieght_charges,
                            'packing_charges':temp.packing_charges,
                            'total_discount':temp.total_discount,
                            'total_tax':temp.total_tax,
                            'dispatch_through':temp.dispatch_through,
                            'excise_id':temp.excise_id.id,
                            'excise_duty':temp.excise_duty,
                            'total_excise_duty':temp.total_excise_duty,
                            'company_address':temp.company_address.id,
                            'purchase_type':temp.purchase_type.id,
                            #GST Entry
                            'no_of_product':temp.no_of_product,
                            'amount_taxed':temp.amount_taxed,
                            'total_cgst':temp.total_cgst,
                            'total_sgst':temp.total_sgst,
                            'total_igst':temp.total_igst,
                            'total_gst':temp.total_gst,
                            'insurance_charges':temp.insurance_charges,
                            'frieght_charges_applied':temp.frieght_charges_applied,
                            'frieght_charges':temp.frieght_charges,
                            'packing_charges':temp.packing_charges,
                            'additional_charges':temp.additional_charges,
                            'grand_total':temp.grand_total
                            })
                        cr.execute("SELECT product_id,balance_qty,description,uom_id,quantity,extra_packing,scheduled_date,unit_price,vendor_id,discount,tax_price,tax_id,subtotal,prakruti_purchase_line.remarks,prakruti_purchase_line.id,no_of_packings,pack_per_qty,hsn_code,discount_id,discount_rate,discount_value,taxable_value,total,cgst_id,cgst_rate,cgst_value,sgst_id,sgst_rate,sgst_value,igst_id,igst_rate,igst_value,taxable_value_after_adding_other,no_of_product,packing_charges,frieght_charges,additional_charges,insurance_charges FROM prakruti_purchase_line WHERE purchase_line_id = CAST(%s as integer) AND status ='open' ",((temp.id),))
                        for item in cr.dictfetchall():
                            grid_down = self.pool.get('prakruti.purchase_line_in_logistics').create(cr,uid, {
                                'product_id':item['product_id'],
                                'description':item['description'],
                                'quantity':item['balance_qty'],
                                'uom_id':item['uom_id'],
                                'scheduled_date':item['scheduled_date'],
                                'unit_price':item['unit_price'],
                                'discount':item['discount'],
                                'tax_price':item['tax_price'],
                                'tax_id':item['tax_id'],
                                'subtotal':item['subtotal'],
                                'vendor_id':item['vendor_id'],
                                'remarks':item['remarks'],
                                'no_of_packings':item['no_of_packings'],
                                'pack_per_qty':item['pack_per_qty'],
                                'extra_packing':item['extra_packing'],
                                'purchase_line_common_id':item['id'],
                                #GST ENTRY
                                'hsn_code': item['hsn_code'],
                                'discount_id':item['discount_id'],
                                'discount_rate':item['discount_rate'],
                                'discount_value':item['discount_value'],
                                'taxable_value': item['taxable_value'],
                                'total':item['total'],
                                'cgst_id':item['cgst_id'],
                                'cgst_rate':item['cgst_rate'],
                                'cgst_value': item['cgst_value'],
                                'sgst_id':item['sgst_id'],
                                'sgst_rate':item['sgst_rate'],
                                'sgst_value': item['sgst_value'],
                                'igst_id':item['igst_id'],
                                'igst_rate':item['igst_rate'],
                                'igst_value': item['igst_value'],
                                'taxable_value_after_adding_other':item['taxable_value_after_adding_other'],
                                'no_of_product':item['no_of_product'],
                                'packing_charges':item['packing_charges'],
                                'frieght_charges':item['frieght_charges'],
                                'additional_charges':item['additional_charges'],
                                'insurance_charges':item['insurance_charges'],
                                #GST ENTRY
                                'logistics_line_id':logistics_entry
                                })
                        cr.execute("UPDATE  prakruti_purchase_order SET state = 'confirm' WHERE prakruti_purchase_order.id = cast(%s as integer)", ((temp.id),))
                        cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'confirm' WHERE prakruti_purchase_requisition.requisition_no = %s ", ((temp.pr_no),))
                        cr.execute("UPDATE  prakruti_price_request SET state = 'confirm' WHERE prakruti_price_request.request_no = %s AND prakruti_price_request.inquiry_no = %s", ((temp.pr_no),(temp.req_no)))
                        cr.execute("UPDATE  prakruti_purchase_order_quotation SET state = 'confirm' WHERE prakruti_purchase_order_quotation.pr_no = %s AND prakruti_purchase_order_quotation.qo_no = %s", ((temp.pr_no),(temp.qo_no),))
                        cr.execute("UPDATE  prakruti_purchase_order_quotation_analysis SET state = 'confirm' WHERE prakruti_purchase_order_quotation_analysis.pr_no = %s AND prakruti_purchase_order_quotation_analysis.qa_no = %s", ((temp.pr_no),(temp.qa_no)))
                        cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'confirm' WHERE prakruti_purchase_requisition_approve.requisition_no = %s",((temp.pr_no),))
                        template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Purcahse Order')],context=context)[0]
                        email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True) 
                    else:
                        raise UserError(_('Please Enter Unit Price')) 
                    cr.execute("SELECT count(prakruti_purchase_requistion_analysis_line.id) AS no_of_approved_line FROM prakruti_purchase_requistion_analysis_line INNER JOIN prakruti_purchase_requistion_analysis ON prakruti_purchase_requistion_analysis_line.requistion_line_id = prakruti_purchase_requistion_analysis.id INNER JOIN prakruti_purchase_order ON prakruti_purchase_order.pr_no = prakruti_purchase_requistion_analysis.request_no WHERE prakruti_purchase_requistion_analysis_line.status= 'approved' AND prakruti_purchase_requistion_analysis.request_no = %s AND prakruti_purchase_order.id = %s",((temp.pr_no),(temp.id),))
                    for line in cr.dictfetchall():
                        no_of_approved_line=line['no_of_approved_line']
                    cr.execute("SELECT count(prakruti_purchase_requistion_analysis_line.id) AS no_of_line FROM prakruti_purchase_requistion_analysis_line INNER JOIN prakruti_purchase_requistion_analysis ON prakruti_purchase_requistion_analysis_line.requistion_line_id = prakruti_purchase_requistion_analysis.id INNER JOIN prakruti_purchase_order ON prakruti_purchase_order.pr_no = prakruti_purchase_requistion_analysis.request_no WHERE prakruti_purchase_requistion_analysis.request_no = %s AND prakruti_purchase_order.id = %s",((temp.pr_no),(temp.id),))
                    for line in cr.dictfetchall():
                        no_of_line=line['no_of_line']
                    if no_of_approved_line == no_of_line:
                        cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'confirm' WHERE prakruti_purchase_requistion_analysis.request_no = %s ", ((temp.pr_no),))
                    else:
                        cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'partial_confirm' WHERE prakruti_purchase_requistion_analysis.request_no = %s ", ((temp.pr_no),))                    
                else:
                    raise UserError(_('Please Enter Revise Comments'))                              
        return {}
    
    @api.one
    @api.multi
    def calculate_total(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute(''' SELECT update_purchase_order_gst_calculation(%s)''',((temp.id),)) 
        return {} 
 

class PrakrutiPurchaseLine(models.Model):
    _name = 'prakruti.purchase_line'
    _table = 'prakruti_purchase_line'
    _order = 'id desc'
    
    purchase_line_id = fields.Many2one('prakruti.purchase_order', ondelete='cascade')
    product_id = fields.Many2one('product.product',string='Product Name',readonly=1)    
    description = fields.Text(string='Description')
    p_type = fields.Selection([('extraction','Extraction'),('formulation','Formulation'),('packing','Packing Material')], string= 'Product Type' , readonly=1)
    scheduled_date =fields.Date(string='Due On')
    unit_price = fields.Float(string='Unit price' ,digits=(6,3))
    uom_id = fields.Many2one('product.uom',string='UOM',readonly=1)
    pr_common_id = fields.Integer('PR SCREEN COMMON ID') 
    currency_id = fields.Many2one(related='purchase_line_id.currency_id', store=1, string='Currency', readonly=1)
    prakruti_stock_id = fields.Integer('SCREEN COMMON ID')
    remarks=fields.Text('Remarks')
    vendor_id = fields.Many2one('res.partner',string="Vendor Name")
    status = fields.Selection([
        ('open', 'Open'),
        ('wait', 'Wait'),
        ('close','Close')],default= 'open', string= 'Status')
    balance_qty = fields.Float(string="Balance Qty" ,digits=(6,3))
    no_of_packings= fields.Float(string= "No. of Packings",default=0 ,digits=(6,3))
    pack_per_qty= fields.Float(string= "Packing Per. Qty.",default=0 ,digits=(6,3))
    extra_packing= fields.Float(string= "(+)Extra Packing",default=0 ,digits=(6,3))
    quantity = fields.Float(string='Quantity Packed',digits=(6,3))
    # Previous Code  (Not in use)
    tax_type = fields.Selection([('cst','CST'),('tin','TIN'),('tax','Tax'),('vat','VAT')], string="Tax", default= 'tax')
    tax_id = fields.Many2one('account.other.tax', string='Taxes', domain=['|', ('active', '=', 0), ('active', '=', 1)])
    tax_price = fields.Float(related='tax_id.per_amount',string='Taxes', store=1,readonly=1 ,digits=(6,3))
    tax_value = fields.Float(string='Tax Value',digits=(6,3),readonly=1)
    discount = fields.Float(string='Discount' ,digits=(6,3),default=0)
    after_discount = fields.Float(string='After Discount' ,digits=(6,3),default=0)
    excise_duty = fields.Float(related='purchase_line_id.excise_duty',string='Excise Duty', store=1)
    total_excise_duty = fields.Float(string='Excise Duty Per Product',readonly=1)
    #GST REQUIREMENT
    hsn_code = fields.Char(string='HSN/SAC',readonly=1)
    discount_id = fields.Many2one('account.other.tax',string= 'Discount(%)',domain=[('select_type', '=', 'discount')])
    discount_rate = fields.Float(related='discount_id.per_amount',string= 'Discount(%)',default=0,store=1)
    discount_value = fields.Float(string= 'Discount Amount',digits=(6,3),readonly=1) 
    taxable_value = fields.Float(string= 'Taxable Value',digits=(6,3),readonly=1)
    total= fields.Float(string='Total',digits=(6,3),readonly=1)
    cgst_id = fields.Many2one('account.other.tax',string= 'CGST Rate',domain=[('select_type', '=', 'cgst')])
    cgst_rate = fields.Float(related='cgst_id.per_amount',string= 'CGST Rate',default=0,store=1)
    cgst_value = fields.Float(string= 'CGST Amount',digits=(6,3),readonly=1)
    sgst_id = fields.Many2one('account.other.tax',string= 'SGST Rate',domain=[('select_type', '=', 'sgst')])
    sgst_rate = fields.Float(related='sgst_id.per_amount',string= 'SGST Rate',default=0,store=1)
    sgst_value = fields.Float(string= 'SGST Amount',digits=(6,3),readonly=1) 
    igst_id = fields.Many2one('account.other.tax',string= 'IGST Rate',domain=[('select_type', '=', 'igst')])
    igst_rate = fields.Float(related='igst_id.per_amount',string= 'IGST Rate',default=0,store=1)
    igst_value = fields.Float(string= 'IGST Amount',digits=(6,3),readonly=1) 
    taxable_value_after_adding_other= fields.Float(string='Taxable Value After Adding Other Charges',digits=(6,3),readonly=1)
    packing_charges = fields.Float(related='purchase_line_id.packing_charges',string='Packing Charges',store=1)
    frieght_charges = fields.Float(related='purchase_line_id.frieght_charges',string='Frieght Charges',store=1)
    additional_charges = fields.Float(related='purchase_line_id.additional_charges',string='Additional Charges',store=1)
    no_of_product = fields.Integer(related='purchase_line_id.no_of_product',string= "No of Products",store=1)
    subtotal = fields.Float(string= 'Sub Total',digits=(6,3),readonly=1)
    insurance_charges = fields.Float(related='purchase_line_id.insurance_charges',string='Insurance Charges',store=1)
    
    
    
    ## Total calculation
    #@api.depends('quantity', 'unit_price')
    #def _compute_price_total(self):
        #for order in self:
            #total = 0.0            
            #order.update({                
                #'total': order.quantity * order.unit_price 
            #})
    
    ## Discount calculation
    #@api.depends('quantity','unit_price','discount_rate')
    #def _compute_line_discount(self):
        #for order in self:
            #discount_value = 0.0
            #order.update({
                    #'discount_value': ((order.quantity * order.unit_price)*(order.discount_rate/100))
                    #})
    
    ## Taxable Value calculation
    #@api.depends('quantity','unit_price','discount_rate')
    #def _compute_taxable_value(self):
        #for order in self:
            #taxable_value = 0.0            
            #order.update({                
                #'taxable_value': ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100))) 
            #})
     
    ## Taxable Value After Adding Others
    #@api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate')
    #def _compute_taxable_value_after_adding_others(self):
        #for order in self:
            #taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            #other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges + order.insurance_charges)/ order.no_of_product
            #order.update({                
                #'taxable_value_after_adding_other': taxable_value + other_charges
            #})
            
    ## CGST value calculation
    #@api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate')
    #def _compute_cgst_value(self):
        #for order in self:
            #taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            #other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges + order.insurance_charges)/ order.no_of_product
            #cgst_rate = order.cgst_rate
            #cgst_value = (taxable_value + other_charges) * cgst_rate/100
            #order.update({                
                #'cgst_value': cgst_value
            #})
            
    ## SGST value calculation
    #@api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate')
    #def _compute_sgst_value(self):
        #for order in self:
            #taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            #other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges + order.insurance_charges)/ order.no_of_product
            #sgst_rate = order.sgst_rate
            #sgst_value = (taxable_value + other_charges) * sgst_rate/100
            #order.update({                
                #'sgst_value': sgst_value
            #})
            
    ## IGST value calculation
    #@api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate')
    #def _compute_igst_value(self):
        #for order in self:
            #taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            #other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges + order.insurance_charges)/ order.no_of_product
            #igst_rate = order.igst_rate
            #igst_value = (taxable_value + other_charges) * igst_rate/100
            #order.update({                
                #'igst_value': igst_value
            #})
            
    ## Subtotal calculation
    #@api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate')
    #def _compute_subtotal(self):
        #for order in self:
            #taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            #other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges +  order.insurance_charges)/ order.no_of_product
            #taxable_value_after_adding_other = taxable_value + other_charges
            #cgst_rate = order.cgst_rate
            #cgst_value = (taxable_value + other_charges) * cgst_rate/100
            #sgst_rate = order.sgst_rate
            #sgst_value = (taxable_value + other_charges) * sgst_rate/100
            #igst_rate = order.igst_rate
            #igst_value = (taxable_value + other_charges) * igst_rate/100
            #order.update({                
                #'subtotal': taxable_value_after_adding_other + cgst_value + sgst_value + igst_value
            #})
    
    
    
    @api.one
    @api.constrains('discount')
    def _check_discount(self):
        if self.discount < 0 or self.discount > 100:
            raise ValidationError(
                "Discount !!! Can't be Negative OR exceeds more than 100%") 
    
    @api.one
    @api.constrains('unit_price')
    def _check_unit_price(self):
        if self.unit_price <= 0 :
            raise ValidationError(
                "Unit Price !!! Can't be Negative or 0")  
    
    @api.one
    @api.constrains('no_of_packings')
    def _check_no_of_packings(self):
        if self.no_of_packings < 0 :
            raise ValidationError(
                "No of Packing !!! Can't be Negative")  
    
    @api.one
    @api.constrains('pack_per_qty')
    def _check_pack_per_qty(self):
        if self.pack_per_qty < 0 :
            raise ValidationError(
                "Packing Per Qty !!! Can't be Negative") 
    
    @api.one
    @api.constrains('extra_packing')
    def _check_extra_packing(self):
        if self.extra_packing < 0 :
            raise ValidationError(
                "Extra Packing Qty !!! Can't be Negative") 
    
    @api.one
    @api.constrains('quantity')
    def _check_quantity(self):
        if self.quantity <= 0 :
            raise ValidationError(
                "Qty !!! Can't be Negative")
    
    def onchange_product(self, cr, uid, ids, product_id, context=None):
        cr.execute('SELECT  product_uom.id AS uom_id,product_product.default_code as description,product_template.list_purchase_price AS unit_price, product_template.p_type AS p_type  FROM product_uom INNER JOIN product_template ON  product_uom.id=product_template.uom_id  INNER JOIN product_product ON product_product.product_tmpl_id =product_template.id WHERE  product_template.id = cast(%s as integer)', ((product_id),))
        for values in cr.dictfetchall():
            uom_id = values['uom_id']
            unit_price = values['unit_price']
            p_type = values['p_type']
            return {'value' :{ 'uom_id': uom_id,'unit_price': unit_price,'p_type': p_type }}
        
    def _check_qty(self, cr, uid, ids):
         lines = self.browse(cr, uid, ids)
         for line in lines:
             if line.quantity <= 0:
                 return False
         return True
     
    _constraints = [
         (_check_qty, 'Order quantity cannot be negative or zero !', ['quantity']),
    ]