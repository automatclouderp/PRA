# -*- coding: utf-8 -*-
from openerp import models, fields, api,_
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
import re
import logging

class PrakrutiPurchaseOrderQuotationAnalysis(models.Model):
    _name =  'prakruti.purchase_order_quotation_analysis'
    _table = 'prakruti_purchase_order_quotation_analysis'
    _description = ' Quotation fields similar Purchase order'
    _rec_name = 'qa_no'
    _order="id desc"
    
    @api.one
    @api.multi
    def _get_auto(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        for temp in self :
            cr.execute('''select cast(extract (month from order_date) as integer) as month ,cast(extract (year from order_date) as integer) as year ,id from prakruti_purchase_order_quotation_analysis where id=%s''',((temp.id),))            
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
            if month_value<=3:
                year_value=year_value-1
            else:
                year_value=year_value
            next_year=year_value+1
            dispay_year=str(next_year)[-2:]
            display_present_year=str(year_value)[-2:]
            cr.execute('''select autogenerate_purchase_quotation_analysis(%s)''', ((temp.id),)  ) 
            result = cr.dictfetchall()
            parent_invoice_id = 0
            for value in result: parent_invoice_id = value['autogenerate_purchase_quotation_analysis'];
            auto_gen = int(parent_invoice_id)
            if len(str(auto_gen)) < 2:
                auto_gen = '000'+ str(auto_gen)
            elif len(str(auto_gen)) < 3:
                auto_gen = '00' + str(auto_gen)
            elif len(str(auto_gen)) == 3:
                auto_gen = '0'+str(auto_gen)
            else:
                auto_gen = str(auto_gen)
            for record in self :
                print '--------------------------------4------------------------------------------',record.purchase_type.id
                if temp.purchase_type.group_code:
                    x[record.id] ='PQA\\'+ temp.purchase_type.group_code+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                else:                        
                    x[record.id] ='PQA\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                cr.execute('''update prakruti_purchase_order_quotation_analysis set qa_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
        return x
    
    # Previous Code  (Not in use)
    excise_id = fields.Many2one('account.other.tax', string='Excise Duty', domain=['|', ('active', '=', False), ('active', '=', True)])
    excise_duty = fields.Float(related='excise_id.per_amount',string= 'Excise Duty(%)',store=True ,digits=(6,3))
    total_excise_duty = fields.Float(string= 'Total Excise Duty',compute= '_compute_excise_duty' ,digits=(6,3))
    total_tax = fields.Float(string="Total Tax" , compute='_compute_tax_total_amount', store=True ,digits=(6,3))
    auto_no = fields.Integer('Auto')
    req_no_control_id = fields.Integer('Auto Generating id',default= 0)
    quotation_no= fields.Char(string='Quotation No',compute= '_get_auto', readonly=True)
    qa_no = fields.Char(string='Analysis No', readonly=True)
    qo_no = fields.Char(string='Quotation No', readonly=True)
    pr_no = fields.Char(string='Requisition No', readonly=True)
    inq_no = fields.Char(string='Inquiry No', readonly=True)
    vendor_id = fields.Many2one('res.partner',string='Vendor/Supplier')
    vendor_reference = fields.Char(string='Vendor/Supplier Reference')
    other_reference = fields.Char(string='Other Reference')
    requisition_date = fields.Date(string='Requisition Date')
    order_date = fields.Date(string='Quotation Date', required=True, default= fields.Date.today)
    destination = fields.Char(string='Destination')
    company_address = fields.Many2one('res.company',string='Company Address')
    delivery_address = fields.Many2one('res.company',string='Dispatch To')
    payment = fields.Char(string='Mode/Terms of Payments')
    terms_of_delivery = fields.Text(string='Terms of Delivery')
    order_line = fields.One2many('prakruti.purchase_quotation_analysis_line','purchase_line_id',string='Purchase Order Line')
    amount_untaxed= fields.Float(string='Untaxed Amount',compute= '_compute_untaxed_amount',store=True ,digits=(6,3)) 
    total_discount = fields.Float(string="Total Discount" , compute='_compute_discount_amount', store=True ,digits=(6,3))
    dispatch_through = fields.Char(string='Dispatch Through')
    prepared_by = fields.Many2one('res.users','Prepared By',readonly=True)    
    purchase_manager = fields.Many2one('res.users',string="Purchase Manager",readonly=True)
    maintanence_manager = fields.Many2one('res.users',string="Maintanence Manager",readonly=True)
    stores_incharge = fields.Many2one('res.users',string="Stores Incharge")
    remarks=fields.Text('Remarks')
    purchase_type = fields.Many2one('product.group',string= 'Purchase Type')
    state = fields.Selection([
		('requisition', 'Requisition'),
		('request','Request'),
		('quotation','Quotation'),
                ('analysis','Quotation Analysis'),
                ('order','Order'),
                ('confirm','Order Confirm'),
                ('reject','Rejected'),
                ('short_close','Short Close')],default= 'analysis', string= 'Status')
    quotation_status = fields.Selection([
                ('hold', 'Hold'),
		('accepted','Accepted')], default= 'hold', string= 'Quotation Status')
    pr_common_id = fields.Integer('PR SCREEN COMMON ID')
    pr_request_common_id = fields.Integer('Price Request SCREEN COMMON ID')
    currency_id = fields.Many2one('res.currency', 'Currency')
    discounted_total = fields.Float(string= 'Discounted Total',compute= '_compute_discounted_total',store= True ,digits=(6,3)) 
    product_id = fields.Many2one('product.product', related='order_line.product_id', string='Product Name')
    revised_status = fields.Selection([('revised','Revised')],string= 'Revised Status')
    #GST ENTRY
    no_of_product = fields.Integer(string= "No of Products",compute='_total_no_of_product')
    amount_taxed= fields.Float(string='Taxed Amount',compute= '_compute_taxed_amount' ,digits=(6,3))    
    total_cgst= fields.Float(string='Total CGST',compute= '_compute_total_cgst' ,digits=(6,3))
    total_sgst= fields.Float(string='Total SGST',compute= '_compute_total_sgst' ,digits=(6,3))
    total_igst= fields.Float(string='Total IGST',compute= '_compute_total_igst' ,digits=(6,3))
    total_gst= fields.Float(string='Total GST',compute= '_compute_total_gst' ,digits=(6,3))
    insurance_charges = fields.Float(string="Insurance Charges" ,digits=(6,3))
    frieght_charges_applied = fields.Selection([('yes','Yes'),('no','No')], string="Freight Charge Applied", default='no')
    frieght_charges = fields.Float(string="Frieght Charges" ,digits=(6,3))
    additional_charges = fields.Float(string='Additional Charges' ,digits=(6,3))
    packing_charges = fields.Float(string='Packing & Forwarding' ,digits=(6,3))
    grand_total= fields.Float(string='Grand Total',compute= '_compute_grand_total' ,digits=(6,3))
                
    @api.depends('order_line.taxable_value_after_adding_other')
    def _compute_taxed_amount(self):
        for order in self:
            amount_taxed = 0.0
            for line in order.order_line:
                amount_taxed += line.taxable_value_after_adding_other
                order.update({
                    'amount_taxed': amount_taxed
                    })
    
    @api.depends('order_line.cgst_value')
    def _compute_total_cgst(self):
        for order in self:
            cgst_value = 0.0
            for line in order.order_line:
                cgst_value += line.cgst_value
                order.update({
                    'total_cgst': cgst_value
                    })
                
    @api.depends('order_line.sgst_value')
    def _compute_total_sgst(self):
        for order in self:
            sgst_value = 0.0
            for line in order.order_line:
                sgst_value += line.sgst_value
                order.update({
                    'total_sgst': sgst_value
                    })
                
                
    @api.depends('order_line.igst_value')
    def _compute_total_igst(self):
        for order in self:
            igst_value = 0.0
            for line in order.order_line:
                igst_value += line.igst_value
                order.update({
                    'total_igst': igst_value
                    })
    
    @api.depends('order_line.cgst_value','order_line.sgst_value','order_line.igst_value')
    def _compute_total_gst(self):
        for order in self:
            total_gst = 0.0
            cgst_value = 0.0
            sgst_value = 0.0
            igst_value = 0.0
            for line in order.order_line:
                cgst_value += line.cgst_value
                sgst_value += line.sgst_value
                igst_value += line.igst_value
                total_gst = cgst_value + sgst_value + igst_value
                order.update({
                    'total_gst': total_gst
                    })
                
    @api.depends('order_line.subtotal')
    def _compute_grand_total(self):
        for order in self:
            grand_total = 0.0
            for line in order.order_line:
                grand_total += line.subtotal
                order.update({
                    'grand_total': grand_total
                    })
    
    
    @api.depends('order_line.quantity','order_line.unit_price')
    def _total_no_of_product(self):
        for order in self:
            total_no_of_product = 0
            for line in order.order_line:
                total_no_of_product += line.quantity
                order.update({
                    'no_of_product': total_no_of_product
                    })
    
    
    @api.depends('amount_untaxed','packing_charges','excise_duty')
    def _compute_excise_duty(self):
        for order in self:
            total_excise_duty = 0.0
            order.update({                
                    'total_excise_duty': (order.discounted_total + order.packing_charges )* (order.excise_duty/100)
                    })
            
    
    
    @api.depends('order_line.discount')
    def _compute_discount_amount(self):
        for order in self:
            discount_amt= 0.0
            for line in order.order_line:
                discount_amt += line.discount_value
                order.update({
                    'total_discount': discount_amt
                    })
                
    @api.depends('amount_untaxed','total_discount','order_line.discount')
    def _compute_discounted_total(self):
        for order in self:
            discounted_total= 0.0
            order.update({
                'discounted_total': order.amount_untaxed - order.total_discount
                })
                
    @api.depends('order_line.tax_price','order_line.tax_value','order_line.packing_charges','order_line.total_excise_duty','order_line.excise_duty','order_line.after_discount')
    def _compute_tax_total_amount(self):
        for order in self:
            total_tax = taxed_value = 0.0
            for line in order.order_line:
                taxed_value += line.tax_value
                order.update({
                    'total_tax': taxed_value
                    })            
                
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['order','confirm']:
                raise UserError(_('Can\'t Delete, Since the Analysis went for further Process.'))
        return super(PrakrutiPurchaseOrderQuotationAnalysis, self).unlink()
    
    @api.onchange('frieght_charges_applied','frieght_charges')
    def onchange_freight_charges(self):
        if self.frieght_charges_applied == 'no':
            self.frieght_charges = 0.0
    
    @api.model
    def _default_company(self):
        return self.env['res.company']._company_default_get('res.partner')
    
    _defaults = {
        'qa_no':'New',
        'qo_no':'Direct Analysis',
        'pr_no':'Direct Analysis',
        'inq_no':'Direct Analysis',
        'prepared_by': lambda s, cr, uid, c:uid,
        'company_address': _default_company,
        'delivery_address': _default_company,
        }

    @api.one
    @api.multi 
    def confirm_to_order(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        scheduled_date = ''
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            cr.execute("select scheduled_date from prakruti_purchase_quotation_analysis_line where purchase_line_id = %s",((temp.id),))
            for line in cr.dictfetchall():
                scheduled_date = line['scheduled_date']
            if scheduled_date < temp.order_date:
                if temp.remarks:
                    cr.execute('''select vendor_id from prakruti_purchase_order_quotation where inq_no = %s  ''', ((temp.inq_no),))
                    for vendor in cr.dictfetchall():
                        vendor=vendor['vendor_id']
                        if(temp.vendor_id.id == vendor ):
                            print 'accepted ----------records'
                            cr.execute("UPDATE prakruti_purchase_order_quotation as ppq set quotation_status='hold' WHERE vendor_id not in (SELECT ppqa.vendor_id as inq_no FROM prakruti_purchase_order_quotation_analysis  as ppqa WHERE ppqa.vendor_id =%s  AND ppqa.inq_no =%s) AND ppq.inq_no =%s ", ((temp.vendor_id.id),(temp.inq_no),(temp.inq_no),))
                            purchase_order = self.pool.get('prakruti.purchase_order').create(cr,uid, {
                                'po_no':'From Quotation Analysis',
                                'purchase_type':temp.purchase_type.id,
                                'qa_no':temp.qa_no,
                                'pr_no':temp.pr_no,
                                'qo_no':temp.qo_no,
                                'req_no':temp.inq_no,
                                'vendor_reference':temp.vendor_reference,
                                'payment':temp.payment,
                                'destination':temp.destination,
                                'other_reference':temp.other_reference,
                                'maintanence_manager':temp.maintanence_manager.id,
                                'purchase_manager':temp.purchase_manager.id,
                                'stores_incharge':temp.stores_incharge.id,
                                'terms_of_delivery':temp.terms_of_delivery,
                                'vendor_id': temp.vendor_id.id,
                                'state':'order',
                                'remarks':temp.remarks,
                                'amount_untaxed':temp.amount_untaxed,
                                'total_discount':temp.total_discount,
                                'total_tax':temp.total_tax,
                                'dispatch_through':temp.dispatch_through,
                                'excise_id':temp.excise_id.id,
                                'excise_duty':temp.excise_duty,
                                'total_excise_duty':temp.total_excise_duty,
                                'request_date':temp.requisition_date,
                                'delivery_address':temp.delivery_address.id,
                                #GST Entry
                                'no_of_product':temp.no_of_product,
                                'amount_taxed':temp.amount_taxed,
                                'total_cgst':temp.total_cgst,
                                'total_sgst':temp.total_sgst,
                                'total_igst':temp.total_igst,
                                'total_gst':temp.total_gst,
                                'insurance_charges':temp.insurance_charges,
                                'frieght_charges_applied':temp.frieght_charges_applied,
                                'frieght_charges':temp.frieght_charges,
                                'packing_charges':temp.packing_charges,
                                'additional_charges':temp.additional_charges,
                                'grand_total':temp.grand_total
                                })
                            for item in temp.order_line:
                                grid_values = self.pool.get('prakruti.purchase_line').create(cr,uid, {
                                'product_id': item.product_id.id,
                                'description': item.description,
                                'quantity': item.quantity,
                                'balance_qty': item.quantity,
                                'uom_id': item.uom_id.id,
                                'scheduled_date': item.scheduled_date,                   
                                'unit_price': item.unit_price,
                                'discount': item.discount,
                                'tax_price': item.tax_price,
                                'tax_id': item.tax_id.id,
                                #GST ENTRY
                                'hsn_code': item.hsn_code,
                                'discount_id':item.discount_id.id,
                                'discount_rate':item.discount_rate,
                                'discount_value':item.discount_value,
                                'taxable_value': item.taxable_value,
                                'total':item.total,
                                'cgst_id':item.cgst_id.id,
                                'cgst_rate':item.cgst_rate,
                                'cgst_value': item.cgst_value,
                                'sgst_id':item.sgst_id.id,
                                'sgst_rate':item.sgst_rate,
                                'sgst_value': item.sgst_value,
                                'igst_id':item.igst_id.id,
                                'igst_rate':item.igst_rate,
                                'igst_value': item.igst_value,
                                'taxable_value_after_adding_other':item.taxable_value_after_adding_other,
                                'subtotal': item.subtotal,
                                'no_of_product':item.no_of_product,
                                'packing_charges':item.packing_charges,
                                'frieght_charges':item.frieght_charges,
                                'additional_charges':item.additional_charges,
                                'insurance_charges':item.insurance_charges,
                                #GST ENTRY
                                'purchase_line_id': purchase_order
                                })
                            cr.execute("UPDATE  prakruti_purchase_order_quotation_analysis SET state = 'order' WHERE prakruti_purchase_order_quotation_analysis.id = cast(%s as integer)", ((temp.id),))
                            cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'order' WHERE prakruti_purchase_requisition.requisition_no = %s ", ((temp.pr_no),))
                            cr.execute("UPDATE  prakruti_price_request SET state = 'order' WHERE prakruti_price_request.request_no = %s AND prakruti_price_request.inquiry_no= %s ", ((temp.pr_no),(temp.inq_no),))
                            cr.execute("UPDATE  prakruti_purchase_order_quotation SET state = 'order' WHERE prakruti_purchase_order_quotation.pr_no = %s AND prakruti_purchase_order_quotation.qo_no = %s ", ((temp.pr_no),(temp.qo_no),))
                            cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'order' WHERE prakruti_purchase_requistion_analysis.request_no = %s ", ((temp.pr_no),))
                            cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'order' WHERE prakruti_purchase_requisition_approve.requisition_no = %s",((temp.pr_no),))
                else:
                    raise UserError(_('Please enter remarks\n Since Your Scheduled Date is Over'))
            else:
                cr.execute('''select vendor_id from prakruti_purchase_order_quotation where inq_no = %s  ''', ((temp.inq_no),))
                for vendor in cr.dictfetchall():
                    vendor=vendor['vendor_id']
                    if(temp.vendor_id.id == vendor ):
                        print 'accepted ----------records'
                        cr.execute("UPDATE prakruti_purchase_order_quotation as ppq set quotation_status='hold' WHERE vendor_id not in (SELECT ppqa.vendor_id as inq_no FROM prakruti_purchase_order_quotation_analysis  as ppqa WHERE ppqa.vendor_id =%s  AND ppqa.inq_no =%s) AND ppq.inq_no =%s ", ((temp.vendor_id.id),(temp.inq_no),(temp.inq_no),))
                        purchase_order = self.pool.get('prakruti.purchase_order').create(cr,uid, {
                            'po_no':'From Quotation Analysis',
                            'purchase_type':temp.purchase_type.id,
                            'qa_no':temp.qa_no,
                            'pr_no':temp.pr_no,
                            'qo_no':temp.qo_no,
                            'req_no':temp.inq_no,
                            'vendor_reference':temp.vendor_reference,
                            'payment':temp.payment,
                            'destination':temp.destination,
                            'other_reference':temp.other_reference,
                            'maintanence_manager':temp.maintanence_manager.id,
                            'purchase_manager':temp.purchase_manager.id,
                            'stores_incharge':temp.stores_incharge.id,
                            'terms_of_delivery':temp.terms_of_delivery,
                            'vendor_id': temp.vendor_id.id,
                            'state':'order',
                            'remarks':temp.remarks,
                            'amount_untaxed':temp.amount_untaxed,
                            'total_discount':temp.total_discount,
                            'total_tax':temp.total_tax,
                            'dispatch_through':temp.dispatch_through,
                            'excise_id':temp.excise_id.id,
                            'excise_duty':temp.excise_duty,
                            'total_excise_duty':temp.total_excise_duty,
                            'request_date':temp.requisition_date,
                            'delivery_address':temp.delivery_address.id,
                            #GST Entry
                            'no_of_product':temp.no_of_product,
                            'amount_taxed':temp.amount_taxed,
                            'total_cgst':temp.total_cgst,
                            'total_sgst':temp.total_sgst,
                            'total_igst':temp.total_igst,
                            'total_gst':temp.total_gst,
                            'insurance_charges':temp.insurance_charges,
                            'frieght_charges_applied':temp.frieght_charges_applied,
                            'frieght_charges':temp.frieght_charges,
                            'packing_charges':temp.packing_charges,
                            'additional_charges':temp.additional_charges,
                            'grand_total':temp.grand_total
                            })
                        for item in temp.order_line:
                            grid_values = self.pool.get('prakruti.purchase_line').create(cr,uid, {
                            'product_id': item.product_id.id,
                            'description': item.description,
                            'quantity': item.quantity,
                            'balance_qty': item.quantity,
                            'uom_id': item.uom_id.id,
                            'scheduled_date': item.scheduled_date,                   
                            'unit_price': item.unit_price,
                            'discount': item.discount,
                            'tax_price': item.tax_price,
                            'tax_id': item.tax_id.id,
                            #GST ENTRY
                            'hsn_code': item.hsn_code,
                            'discount_id':item.discount_id.id,
                            'discount_rate':item.discount_rate,
                            'discount_value':item.discount_value,
                            'taxable_value': item.taxable_value,
                            'total':item.total,
                            'cgst_id':item.cgst_id.id,
                            'cgst_rate':item.cgst_rate,
                            'cgst_value': item.cgst_value,
                            'sgst_id':item.sgst_id.id,
                            'sgst_rate':item.sgst_rate,
                            'sgst_value': item.sgst_value,
                            'igst_id':item.igst_id.id,
                            'igst_rate':item.igst_rate,
                            'igst_value': item.igst_value,
                            'taxable_value_after_adding_other':item.taxable_value_after_adding_other,
                            'subtotal': item.subtotal,
                            'no_of_product':item.no_of_product,
                            'packing_charges':item.packing_charges,
                            'frieght_charges':item.frieght_charges,
                            'additional_charges':item.additional_charges,
                            'insurance_charges':item.insurance_charges,
                            #GST ENTRY
                            'purchase_line_id': purchase_order
                            })
                        cr.execute("UPDATE  prakruti_purchase_order_quotation_analysis SET state = 'order' WHERE prakruti_purchase_order_quotation_analysis.id = cast(%s as integer)", ((temp.id),))
                        cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'order' WHERE prakruti_purchase_requisition.requisition_no = %s ", ((temp.pr_no),))
                        cr.execute("UPDATE  prakruti_price_request SET state = 'order' WHERE prakruti_price_request.request_no = %s AND prakruti_price_request.inquiry_no= %s ", ((temp.pr_no),(temp.inq_no),))
                        cr.execute("UPDATE  prakruti_purchase_order_quotation SET state = 'order' WHERE prakruti_purchase_order_quotation.pr_no = %s AND prakruti_purchase_order_quotation.qo_no = %s ", ((temp.pr_no),(temp.qo_no),))
                        cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'order' WHERE prakruti_purchase_requistion_analysis.request_no = %s ", ((temp.pr_no),))
                        cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'order' WHERE prakruti_purchase_requisition_approve.requisition_no = %s",((temp.pr_no),))
        return {}
    
    @api.one
    @api.multi 
    def action_calculate(self):        
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute('''SELECT update_purchase_quotation_analysis_calculation(%s)''',((temp.id),))
        return {} 
    
class PrakrutiPurchaseQuatationAnalysisLine(models.Model):
    _name = 'prakruti.purchase_quotation_analysis_line'
    _table = 'prakruti_purchase_quotation_analysis_line'  
    
    purchase_line_id = fields.Many2one('prakruti.purchase_order_quotation_analysis', ondelete='cascade')
    product_id = fields.Many2one('product.product',string='Product Name', required= True)
    description = fields.Text(string='Description')
    scheduled_date =fields.Date(string='Scheduled Date', required= True, default= fields.Date.today)
    quantity = fields.Float(string='Qty. Req', required= True ,digits=(6,3))
    unit_price = fields.Float(string='Unit price' ,digits=(6,3))
    uom_id = fields.Many2one('product.uom',string='UOM', required= True)    
    currency_id = fields.Many2one(related='purchase_line_id.currency_id', store=True, string='Currency', readonly=True)    
    # Previous Code  (Not in use)
    tax_type = fields.Selection([('cst','CST'),('tin','TIN'),('tax','Tax'),('vat','VAT')], string="Tax", default= 'tax')
    tax_id = fields.Many2one('account.other.tax', string='Taxes', domain=['|', ('active', '=', False), ('active', '=', True)])
    tax_price = fields.Float(related='tax_id.per_amount',string='Taxes', store=True,readonly=True ,digits=(6,3))
    tax_value = fields.Float(string='Tax Value',digits=(6,3),readonly=1)
    discount = fields.Float(string='Discount' ,digits=(6,3),default=0)
    after_discount = fields.Float(string='After Discount' ,digits=(6,3),default=0)
    excise_duty = fields.Float(related='purchase_line_id.excise_duty',string='Excise Duty', store=True)
    total_excise_duty = fields.Float(string='Excise Duty Per Product',readonly=1)
    
   
    #GST REQUIREMENT
    hsn_code = fields.Char(string='HSN/SAC',readonly=1)
    discount_id = fields.Many2one('account.other.tax', string='Discount', domain=['|', ('active', '=', False), ('active', '=', True)])
    discount_rate = fields.Float(related='discount_id.per_amount',string='Discount Rate' ,digits=(6,3),default=0)
    discount_value = fields.Float(string= 'Discount Amount',compute= '_compute_line_discount' ,digits=(6,3)) 
    taxable_value = fields.Float(string= 'Taxable Value',digits=(6,3),compute='_compute_taxable_value')
    total= fields.Float(string='Total',compute= '_compute_price_total',digits=(6,3))
    
    
    cgst_id = fields.Many2one('account.other.tax', string='CGST Rate', domain=['|', ('active', '=', False), ('active', '=', True)])
    cgst_rate = fields.Float(string='CGST Rate' ,digits=(6,3),default=0)
    cgst_value = fields.Float(string= 'CGST Amount',compute= '_compute_cgst_value' ,digits=(6,3))
    
    sgst_id = fields.Many2one('account.other.tax', string='SGST Rate', domain=['|', ('active', '=', False), ('active', '=', True)])
    sgst_rate = fields.Float(string='SGST Rate' ,digits=(6,3),default=0)
    sgst_value = fields.Float(string= 'SGST Amount',compute= '_compute_sgst_value' ,digits=(6,3)) 
    
    igst_id = fields.Many2one('account.other.tax', string='IGST Rate', domain=['|', ('active', '=', False), ('active', '=', True)])
    igst_rate = fields.Float(string='IGST Rate' ,digits=(6,3),default=0)
    igst_value = fields.Float(string= 'IGST Amount',compute= '_compute_igst_value' ,digits=(6,3)) 
    taxable_value_after_adding_other= fields.Float(string='Taxable Value After Adding Other Charges',compute= '_compute_taxable_value_after_adding_others' ,digits=(6,3))
    
    
    packing_charges = fields.Float(related='purchase_line_id.packing_charges',string='Packing Charges')
    frieght_charges = fields.Float(related='purchase_line_id.frieght_charges',string='Frieght Charges')
    additional_charges = fields.Float(related='purchase_line_id.additional_charges',string='Additional Charges')
    no_of_product = fields.Integer(string= "No of Products",compute = '_total_no_of_product')
    subtotal = fields.Float(string= 'Sub Total',compute= '_compute_subtotal' ,digits=(6,3))
    insurance_charges = fields.Float(related='purchase_line_id.insurance_charges',string='Insurance Charges')
    
    
    
    # Total calculation
    @api.depends('quantity', 'unit_price')
    def _compute_price_total(self):
        for order in self:
            total = 0.0            
            order.update({                
                'total': order.quantity * order.unit_price 
            })
    
    # Discount calculation
    @api.depends('quantity','unit_price','discount_rate')
    def _compute_line_discount(self):
        for order in self:
            discount_value = 0.0
            order.update({
                    'discount_value': ((order.quantity * order.unit_price)*(order.discount_rate/100))
                    })
    
    # Taxable Value calculation
    @api.depends('quantity','unit_price','discount_rate')
    def _compute_taxable_value(self):
        for order in self:
            taxable_value = 0.0            
            order.update({                
                'taxable_value': ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100))) 
            })
    
    # Total No of Product
    @api.depends('quantity')
    def _total_no_of_product(self):
        for order in self:
            total_no_of_product = 0
            total_no_of_product += order.quantity
            order.update({
                'no_of_product': total_no_of_product
                })
     
    # Taxable Value After Adding Others
    @api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate')
    def _compute_taxable_value_after_adding_others(self):
        for order in self:
            taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges + order.insurance_charges)/ order.no_of_product
            order.update({                
                'taxable_value_after_adding_other': taxable_value + other_charges
            })
            
    # CGST value calculation
    @api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate')
    def _compute_cgst_value(self):
        for order in self:
            taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges + order.insurance_charges)/ order.no_of_product
            cgst_rate = order.cgst_rate
            cgst_value = (taxable_value + other_charges) * cgst_rate/100
            order.update({                
                'cgst_value': cgst_value
            })
            
    # SGST value calculation
    @api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate')
    def _compute_sgst_value(self):
        for order in self:
            taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges + order.insurance_charges)/ order.no_of_product
            sgst_rate = order.sgst_rate
            sgst_value = (taxable_value + other_charges) * sgst_rate/100
            order.update({                
                'sgst_value': sgst_value
            })
            
    # IGST value calculation
    @api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate')
    def _compute_igst_value(self):
        for order in self:
            taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges + order.insurance_charges)/ order.no_of_product
            igst_rate = order.igst_rate
            igst_value = (taxable_value + other_charges) * igst_rate/100
            order.update({                
                'igst_value': igst_value
            })
            
    # Subtotal calculation
    @api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate')
    def _compute_subtotal(self):
        for order in self:
            taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges +  order.insurance_charges)/ order.no_of_product
            taxable_value_after_adding_other = taxable_value + other_charges
            cgst_rate = order.cgst_rate
            cgst_value = (taxable_value + other_charges) * cgst_rate/100
            sgst_rate = order.sgst_rate
            sgst_value = (taxable_value + other_charges) * sgst_rate/100
            igst_rate = order.igst_rate
            igst_value = (taxable_value + other_charges) * igst_rate/100
            order.update({                
                'subtotal': taxable_value_after_adding_other + cgst_value + sgst_value + igst_value
            })
            
    
    # Validations start
    
    def _check_unit_price(self, cr, uid, ids):
         lines = self.browse(cr, uid, ids)
         for line in lines:
             if line.unit_price <= 0:
                 return False
         return True
    
    def _check_qty(self, cr, uid, ids):
         lines = self.browse(cr, uid, ids)
         for line in lines:
             if line.quantity <= 0:
                 return False
         return True
     
     
    def _check_discount(self, cr, uid, ids, context=None):
        obj = self.browse(cr, uid, ids[0], context=context)
        if (obj.discount < 0.0 or obj.discount > 100):
            return False
        return True
     
    _constraints = [
         (_check_qty, 'Order quantity cannot be negative or zero !', ['quantity']),
         (_check_unit_price, 'Unit Price cannot be negative or zero !', ['unit_price']),
         (_check_discount, 'Discount cannot be negative or zero or greater than 100!', ['discount'])
    ]
    
    # End
    
    def onchange_product(self, cr, uid, ids, product_id, context=None):
        cr.execute('SELECT  product_uom.id AS uom_id,product_product.default_code as description,product_template.list_purchase_price AS unit_price  FROM product_uom INNER JOIN product_template ON  product_uom.id=product_template.uom_id  INNER JOIN product_product ON product_product.product_tmpl_id =product_template.id WHERE  product_template.id = cast(%s as integer)', ((product_id),))
        for values in cr.dictfetchall():
            uom_id = values['uom_id']
            unit_price = values['unit_price']
            return {'value' :{ 'uom_id': uom_id,'unit_price': unit_price }}
    
    