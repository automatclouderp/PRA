# -*- coding: utf-8 -*-

from openerp import models, fields, api,_
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
import re
import logging
from openerp.exceptions import ValidationError
from openerp.tools import amount_to_text
from openerp.tools.amount_to_text import amount_to_text_in 
from openerp.tools.amount_to_text import amount_to_text_in_without_word_rupees
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp import tools
from datetime import timedelta
from openerp.osv import osv,fields
from openerp import models, fields, api, _
import sys, os, urllib2, urlparse
from datetime import date, timedelta
from lxml import etree
import cgi
import lxml.html
import lxml.html.clean as clean
import openerp.pooler as pooler
import random
import socket
import threading


class PrakrutiPurchaseOrderQuotation(models.Model):
    _name =  'prakruti.purchase_order_quotation'
    _table = 'prakruti_purchase_order_quotation'
    _description = ' Quotation fields similar Purchase order'
    _rec_name = 'qo_no'
    _order="id desc"
    
    @api.one
    @api.multi
    def _get_auto(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        for temp in self :
            cr.execute('''select cast(extract (month from order_date) as integer) as month ,cast(extract (year from order_date) as integer) as year ,id from prakruti_purchase_order_quotation where id=%s''',((temp.id),))            
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
            if month_value<=3:
                year_value=year_value-1
            else:
                year_value=year_value
            next_year=year_value+1
            dispay_year=str(next_year)[-2:]
            display_present_year=str(year_value)[-2:]
            cr.execute('''select autogenerate_purchase_quotation(%s)''', ((temp.id),)  ) 
            result = cr.dictfetchall()
            parent_invoice_id = 0
            for value in result: parent_invoice_id = value['autogenerate_purchase_quotation'];
            auto_gen = int(parent_invoice_id)
            if len(str(auto_gen)) < 2:
                auto_gen = '000'+ str(auto_gen)
            elif len(str(auto_gen)) < 3:
                auto_gen = '00' + str(auto_gen)
            elif len(str(auto_gen)) == 3:
                auto_gen = '0'+str(auto_gen)
            else:
                auto_gen = str(auto_gen)
            for record in self :
                print '--------------------------------4------------------------------------------',record.purchase_type.id
                if temp.purchase_type.group_code:
                    x[record.id] ='PQO\\'+ temp.purchase_type.group_code+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                else:                        
                    x[record.id] ='PQO\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                cr.execute('''update prakruti_purchase_order_quotation set qo_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
        return x
                
    auto_no = fields.Integer('Auto')
    req_no_control_id = fields.Integer('Auto Generating id',default= 0)
    quotation_no= fields.Char(string='Quotation No',compute= '_get_auto', readonly=True)
    qo_no = fields.Char(string='Quotation No', readonly=True)
    pr_no = fields.Char(string='Requisition No', readonly=True)
    inq_no = fields.Char(string='Inquiry No', readonly=True)
    logo = fields.Binary(related='company_address.logo')
    vendor_id = fields.Many2one('res.partner',string='Vendor/Supplier')
    vendor_reference = fields.Char(string='Vendor/Supplier Reference')
    other_reference = fields.Char(string='Other Reference')
    order_date = fields.Date(string='Quotation Date', required=True,default= fields.Date.today)
    destination = fields.Char(string='Destination')
    company_address = fields.Many2one('res.company',string='Company Address')
    delivery_address = fields.Many2one('res.company',string='Dispatch To',readonly=True)
    payment = fields.Char(string='Mode/Terms of Payments')
    terms_of_delivery = fields.Text(string='Terms of Delivery')
    order_line = fields.One2many('prakruti.purchase_quotation_line','purchase_line_id',string='Purchase Order Line')
    request_date = fields.Date(string = "Requisition Date", default= fields.Date.today)
    amount_untaxed= fields.Float(string='Untaxed Amount',compute= '_compute_untaxed_amount',store=True ,digits=(6,3)) 
    
    
    total_discount = fields.Float(string="Total Discount" , compute='_compute_discount_amount', store=True ,digits=(6,3))
    dispatch_through = fields.Char(string='Dispatch Through')
    prepared_by = fields.Many2one('res.users','Prepared By',readonly=True)    
    purchase_manager = fields.Many2one('res.users',string="Purchase Manager",required=True)
    maintanence_manager = fields.Many2one('res.users',string="Maintanence Manager",required=True)
    stores_incharge = fields.Many2one('res.users',string="Stores Incharge")
    remarks=fields.Text('Remarks')
    purchase_type = fields.Many2one('product.group',string= 'Purchase Type')
    state = fields.Selection([
		('requisition', 'Requisition'),
		('request','Request'),
		('quotation','Quotation'),
                ('analysis','Quotation Analysis'),
                ('order','Order'),
                ('confirm','Order Confirm'),
                ('reject','Rejected'),
                ('short_close','Short Close')],default= 'quotation', string= 'Status')
    quotation_status = fields.Selection([
                ('hold', 'Hold'),
		('accepted','Accepted')], default= 'hold', string= 'Quotation Status')
    grand_total_in_words= fields.Text(compute= '_get_total_in_words' ,method=True, store=False,string='Total in words')
    pr_common_id = fields.Integer('PR SCREEN COMMON ID')
    pr_request_common_id = fields.Integer('Price Request SCREEN COMMON ID')
    currency_id = fields.Many2one('res.currency', 'Currency')
    
    discounted_total = fields.Float(string= 'Discounted Total',compute= '_compute_discounted_total',store= True ,digits=(6,3)) 
    product_id = fields.Many2one('product.product', related='order_line.product_id', string='Product Name')
    revised_status = fields.Selection([('revised','Revised')],string= 'Revised Status')# Previous Code  (Not in use)
    excise_id = fields.Many2one('account.other.tax', string='Excise Duty', domain=['|', ('active', '=', False), ('active', '=', True)])
    excise_duty = fields.Float(related='excise_id.per_amount',string= 'Excise Duty(%)',store=True,readonly=True ,digits=(6,3))
    total_excise_duty = fields.Float(string= 'Total Excise Duty',compute= '_compute_excise_duty' ,digits=(6,3))
    total_tax = fields.Float(string="Total Tax" , compute='_compute_tax_total_amount', store=True ,digits=(6,3)) 
    
    
    
    #GST ENTRY
    no_of_product = fields.Integer(string= "No of Products",compute='_total_no_of_product')
    amount_taxed= fields.Float(string='Taxed Amount',compute= '_compute_taxed_amount' ,digits=(6,3))    
    total_cgst= fields.Float(string='Total CGST',compute= '_compute_total_cgst' ,digits=(6,3))
    total_sgst= fields.Float(string='Total SGST',compute= '_compute_total_sgst' ,digits=(6,3))
    total_igst= fields.Float(string='Total IGST',compute= '_compute_total_igst' ,digits=(6,3))
    total_gst= fields.Float(string='Total GST',compute= '_compute_total_gst' ,digits=(6,3))
    insurance_charges = fields.Float(string="Insurance Charges" ,digits=(6,3))
    frieght_charges_applied = fields.Selection([('yes','Yes'),('no','No')], string="Freight Charge Applied", default='no')
    frieght_charges = fields.Float(string="Frieght Charges" ,digits=(6,3))
    additional_charges = fields.Float(string='Additional Charges' ,digits=(6,3))
    packing_charges = fields.Float(string='Packing & Forwarding' ,digits=(6,3))
    grand_total= fields.Float(string='Grand Total',compute= '_compute_grand_total' ,digits=(6,3))
                
    @api.depends('order_line.taxable_value_after_adding_other')
    def _compute_taxed_amount(self):
        for order in self:
            amount_taxed = 0.0
            for line in order.order_line:
                amount_taxed += line.taxable_value_after_adding_other
                order.update({
                    'amount_taxed': amount_taxed
                    })
    
    @api.depends('order_line.cgst_value')
    def _compute_total_cgst(self):
        for order in self:
            cgst_value = 0.0
            for line in order.order_line:
                cgst_value += line.cgst_value
                order.update({
                    'total_cgst': cgst_value
                    })
                
    @api.depends('order_line.sgst_value')
    def _compute_total_sgst(self):
        for order in self:
            sgst_value = 0.0
            for line in order.order_line:
                sgst_value += line.sgst_value
                order.update({
                    'total_sgst': sgst_value
                    })
                
                
    @api.depends('order_line.igst_value')
    def _compute_total_igst(self):
        for order in self:
            igst_value = 0.0
            for line in order.order_line:
                igst_value += line.igst_value
                order.update({
                    'total_igst': igst_value
                    })
    
    @api.depends('order_line.cgst_value','order_line.sgst_value','order_line.igst_value')
    def _compute_total_gst(self):
        for order in self:
            total_gst = 0.0
            cgst_value = 0.0
            sgst_value = 0.0
            igst_value = 0.0
            for line in order.order_line:
                cgst_value += line.cgst_value
                sgst_value += line.sgst_value
                igst_value += line.igst_value
                total_gst = cgst_value + sgst_value + igst_value
                order.update({
                    'total_gst': total_gst
                    })
    
    
    @api.depends('order_line.quantity','order_line.unit_price')
    def _total_no_of_product(self):
        for order in self:
            total_no_of_product = 0
            for line in order.order_line:
                total_no_of_product += line.quantity
                order.update({
                    'no_of_product': total_no_of_product
                    })
                
    @api.depends('order_line.subtotal','order_line.quantity', 'order_line.unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','order_line.discount_rate','order_line.cgst_rate','order_line.cgst_id','order_line.sgst_rate','order_line.sgst_id','order_line.igst_rate','order_line.igst_id','order_line.discount_id')
    def _compute_grand_total(self):
        for order in self:
            grand_total = 0.0
            for line in order.order_line:
                grand_total += line.subtotal
                order.update({
                    'grand_total': grand_total
                    })
    
    
    @api.constrains('packing_charges')
    def _check_packing_charges(self):
        for record in self:
            if record.packing_charges <0:
                raise ValidationError("Packing & Forwarding can not be negative: %s" % record.packing_charges)
    
    
    @api.constrains('additional_charges')
    def _check_additional_charges(self):
        for record in self:
            if record.additional_charges <0:
                raise ValidationError("Additional Charges can not be negative: %s " % record.additional_charges)
    
    
    
    @api.constrains('frieght_charges')
    def _check_frieght_charges(self):
        for record in self:
            if record.frieght_charges <0:
                raise ValidationError("Freight Charges can not be negative: %s " % record.frieght_charges)
    
    
    @api.depends('order_line.quantity','order_line.unit_price')
    def _compute_untaxed_amount(self):
        for order in self:
            amount_untaxed = total_untaxed_amount = 0.0
            for line in order.order_line:
                total_untaxed_amount += line.quantity * line.unit_price
                order.update({
                    'amount_untaxed': total_untaxed_amount
                    })
                
   
    
    @api.depends('order_line.discount')
    def _compute_discount_amount(self):
        for order in self:
            discount_amt= 0.0
            for line in order.order_line:
                discount_amt += line.discount_value
                order.update({
                    'total_discount': discount_amt
                    })
                
    @api.depends('amount_untaxed','total_discount','order_line.discount')
    def _compute_discounted_total(self):
        for order in self:
            discounted_total= 0.0
            order.update({
                'discounted_total': order.amount_untaxed - order.total_discount
                })
     
     
    @api.depends('amount_untaxed','packing_charges','excise_duty')
    def _compute_excise_duty(self):
        for order in self:
            total_excise_duty = 0.0
            order.update({                
                    'total_excise_duty': (order.discounted_total + order.packing_charges )* (order.excise_duty/100)
                    })
            
   
                
    @api.depends('order_line.tax_price','order_line.tax_value','order_line.packing_charges','order_line.total_excise_duty','order_line.excise_duty','order_line.after_discount')
    def _compute_tax_total_amount(self):
        for order in self:
            total_tax = taxed_value = 0.0
            for line in order.order_line:
                taxed_value += line.tax_value
                order.update({
                    'total_tax': taxed_value
                    })            
    @api.multi
    def unlink(self):
        raise UserError(_('Can\'t Delete'))
        return super(PrakrutiPurchaseOrderQuotation, self).unlink()
    
    @api.depends('order_line.quantity','order_line.unit_price','order_line.tax_price','order_line.discount','total_discount','amount_untaxed','packing_charges','additional_charges','frieght_charges')
    def _get_total_in_words(self):
        for order in self:
            frieght_charges = grand_total =val1=0.0
            val1_in_words = ""
            if order.frieght_charges_applied == 'yes':
                frieght_charges= order.frieght_charges
            else:
                frieght_charges = 0.0
            grand_total = order.discounted_total + order.packing_charges + order.total_excise_duty + order.total_tax + frieght_charges + order.additional_charges
            val1 = grand_total
            val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
            order.update({                    
                'grand_total_in_words': val1_in_words.upper()
                })
    
    @api.onchange('frieght_charges_applied','frieght_charges')
    def onchange_freight_charges(self):
        if self.frieght_charges_applied == 'no':
            self.frieght_charges = 0.0
    
    @api.model
    def _default_company(self):
        return self.env['res.company']._company_default_get('res.partner')
    
    _defaults = {
        'qo_no':'New',
        'pr_no':'Direct Quotation',
        'inq_no':'Direct Quotation',
        'prepared_by': lambda s, cr, uid, c:uid,
        'company_address': _default_company,
        'delivery_address': _default_company,
        }

    @api.one
    @api.multi 
    def confirm_to_analysis(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        template_ids=[]
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}  
            template_ids.append(temp.id)
            if (temp.quotation_status == 'hold'):
                purchase_order = self.pool.get('prakruti.purchase_order_quotation_analysis').create(cr,uid, {
                    'qa_no':'From Quotation',
                    'pr_no':temp.pr_no,
                    'purchase_type':temp.purchase_type.id,
                    'qo_no':temp.qo_no,
                    'inq_no':temp.inq_no,
                    'vendor_reference':temp.vendor_reference,
                    'payment':temp.payment,
                    'destination':temp.destination,
                    'other_reference':temp.other_reference,
                    'maintanence_manager':temp.maintanence_manager.id,
                    'purchase_manager':temp.purchase_manager.id,
                    'stores_incharge':temp.stores_incharge.id,
                    'terms_of_delivery':temp.terms_of_delivery,
                    'vendor_id': temp.vendor_id.id,
                    'amount_untaxed':temp.amount_untaxed,
                    'total_discount':temp.total_discount,
                    'total_tax':temp.total_tax,
                    'dispatch_through':temp.dispatch_through,
                    'state':'analysis',
                    'quotation_status':'accepted',
                    'remarks':temp.remarks,
                    'excise_id':temp.excise_id.id,
                    'excise_duty':temp.excise_duty,
                    'total_excise_duty':temp.total_excise_duty,
                    'requisition_date': temp.request_date,
                    #GST Entry
                    'no_of_product':temp.no_of_product,
                    'amount_taxed':temp.amount_taxed,
                    'total_cgst':temp.total_cgst,
                    'total_sgst':temp.total_sgst,
                    'total_igst':temp.total_igst,
                    'total_gst':temp.total_gst,
                    'insurance_charges':temp.insurance_charges,
                    'frieght_charges_applied':temp.frieght_charges_applied,
                    'frieght_charges':temp.frieght_charges,
                    'packing_charges':temp.packing_charges,
                    'additional_charges':temp.additional_charges,
                    'grand_total':temp.grand_total,  
                    
                    })
                for item in temp.order_line:
                    grid_values = self.pool.get('prakruti.purchase_quotation_analysis_line').create(cr,uid, {
                    'product_id': item.product_id.id,
                    'description': item.description,
                    'quantity': item.quantity,
                    'balance_qty':item.quantity,
                    'uom_id': item.uom_id.id,
                    'scheduled_date': item.scheduled_date,                   
                    'unit_price': item.unit_price,
                    'discount': item.discount,
                    'tax_price': item.tax_price,
                    'tax_id':item.tax_id.id,
                    
                    #GST ENTRY
                    'hsn_code': item.hsn_code,
                    'discount_id':item.discount_id.id,
                    'discount_rate':item.discount_rate,
                    'discount_value':item.discount_value,
                    'taxable_value': item.taxable_value,
                    'total':item.total,
                    'cgst_id':item.cgst_id.id,
                    'cgst_rate':item.cgst_rate,
                    'cgst_value': item.cgst_value,
                    'sgst_id':item.sgst_id.id,
                    'sgst_rate':item.sgst_rate,
                    'sgst_value': item.sgst_value,
                    'igst_id':item.igst_id.id,
                    'igst_rate':item.igst_rate,
                    'igst_value': item.igst_value,
                    'taxable_value_after_adding_other':item.taxable_value_after_adding_other,
                    'subtotal': item.subtotal,
                    'no_of_product':item.no_of_product,
                    'packing_charges':item.packing_charges,
                    'frieght_charges':item.frieght_charges,
                    'additional_charges':item.additional_charges,
                    'insurance_charges':item.insurance_charges,
                    #GST ENTRY
                    'purchase_line_id': purchase_order
                    })            
                cr.execute("UPDATE  prakruti_purchase_order_quotation SET state = 'analysis' WHERE prakruti_purchase_order_quotation.id = cast(%s as integer)", ((temp.id),))
                cr.execute("UPDATE  prakruti_purchase_order_quotation SET quotation_status = 'accepted' WHERE prakruti_purchase_order_quotation.id = cast(%s as integer)", ((temp.id),))
                cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'analysis' WHERE prakruti_purchase_requisition.requisition_no = %s ", ((temp.pr_no),))
                cr.execute("UPDATE  prakruti_price_request SET state = 'analysis' WHERE prakruti_price_request.request_no = %s AND prakruti_price_request.inquiry_no = %s", ((temp.pr_no),(temp.inq_no),))
                cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'analysis' WHERE prakruti_purchase_requistion_analysis.request_no = %s ", ((temp.pr_no),))
                cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'analysis' WHERE prakruti_purchase_requisition_approve.requisition_no = %s",((temp.pr_no),))
                 
                #template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Purcahse Quotation')],context=context)[0]
                #email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True) 
        return {}
    
    #@api.one
    #@api.multi 
    #def action_calculate(self):        
        #cr = self.env.cr
        #uid = self.env.uid
        #ids = self.ids
        #context = 'context'
        #for temp in self:
            #cr.execute('''SELECT update_purchase_quotation_calculation(%s)''',((temp.id),))
        #return {} 

class PrakrutiPurchaseQuatationLine(models.Model):
    _name = 'prakruti.purchase_quotation_line'
    _table = 'prakruti_purchase_quotation_line'
    
    purchase_line_id = fields.Many2one('prakruti.purchase_order_quotation', ondelete='cascade')
    product_id = fields.Many2one('product.product',string='Product Name', required= True)
    description = fields.Text(string='Description')
    scheduled_date =fields.Date(string='Scheduled Date', required= True, default= fields.Date.today)
    quantity = fields.Float(string='Qty', required= True ,digits=(6,3))
    unit_price = fields.Float(string='Unit price' ,digits=(6,3)) 
    uom_id = fields.Many2one('product.uom',string='UOM', required= True)    
    currency_id = fields.Many2one(related='purchase_line_id.currency_id',  string='Currency', readonly=True)    
    # Previous Code  (Not in use)
    tax_type = fields.Selection([('cst','CST'),('tin','TIN'),('tax','Tax'),('vat','VAT')], string="Tax", default= 'tax')
    tax_id = fields.Many2one('account.other.tax', string='Taxes', domain=['|', ('active', '=', False), ('active', '=', True)])
    tax_price = fields.Float(related='tax_id.per_amount',string='Taxes', readonly=True ,digits=(6,3))
    tax_value = fields.Float(string='Tax Value',digits=(6,3),readonly=1)
    discount = fields.Float(string='Discount' ,digits=(6,3),default=0)
    after_discount = fields.Float(string='After Discount' ,digits=(6,3),default=0)
    excise_duty = fields.Float(related='purchase_line_id.excise_duty',string='Excise Duty')
    total_excise_duty = fields.Float(string='Excise Duty Per Product',readonly=1)
    
   
    #GST REQUIREMENT
    hsn_code = fields.Char(string='HSN/SAC',readonly=1)
    discount_id = fields.Many2one('account.other.tax',string= 'Discount(%)',domain=[('select_type', '=', 'discount')])
    discount_rate = fields.Float(related='discount_id.per_amount',string= 'Discount(%)',default=0,store=1)
    discount_value = fields.Float(string= 'Discount Amount',compute= '_compute_line_discount' ,digits=(6,3)) 
    taxable_value = fields.Float(string= 'Taxable Value',digits=(6,3),compute='_compute_taxable_value')
    total= fields.Float(string='Total',compute= '_compute_price_total',digits=(6,3))
    
    
    cgst_id = fields.Many2one('account.other.tax',string= 'CGST Rate',domain=[('select_type', '=', 'cgst')])
    cgst_rate = fields.Float(related='cgst_id.per_amount',string= 'CGST Rate',default=0,store=1)
    cgst_value = fields.Float(string= 'CGST Amount',compute= '_compute_cgst_value' ,digits=(6,3))
    
    sgst_id = fields.Many2one('account.other.tax',string= 'SGST Rate',domain=[('select_type', '=', 'sgst')])
    sgst_rate = fields.Float(related='sgst_id.per_amount',string= 'SGST Rate',default=0,store=1)
    sgst_value = fields.Float(string= 'SGST Amount',compute= '_compute_sgst_value' ,digits=(6,3)) 
    
    igst_id = fields.Many2one('account.other.tax',string= 'IGST Rate',domain=[('select_type', '=', 'igst')])
    igst_rate = fields.Float(related='igst_id.per_amount',string= 'IGST Rate',default=0,store=1)
    igst_value = fields.Float(string= 'IGST Amount',compute= '_compute_igst_value' ,digits=(6,3)) 
    taxable_value_after_adding_other= fields.Float(string='Taxable Value After Adding Other Charges',compute= '_compute_taxable_value_after_adding_others' ,digits=(6,3))
    
    
    packing_charges = fields.Float(related='purchase_line_id.packing_charges',string='Packing Charges',store=1)
    frieght_charges = fields.Float(related='purchase_line_id.frieght_charges',string='Frieght Charges',store=1)
    additional_charges = fields.Float(related='purchase_line_id.additional_charges',string='Additional Charges',store=1)
    no_of_product = fields.Integer(string= "No of Products",compute = '_total_no_of_product')
    subtotal = fields.Float(string= 'Sub Total',compute= '_compute_subtotal' ,digits=(6,3))
    insurance_charges = fields.Float(related='purchase_line_id.insurance_charges',string='Insurance Charges',store=1)
    
    
    
    # Total calculation
    @api.depends('quantity', 'unit_price')
    def _compute_price_total(self):
        for order in self:
            total = 0.0            
            order.update({                
                'total': order.quantity * order.unit_price 
            })
    
    # Discount calculation
    @api.depends('quantity','unit_price','discount_rate','discount_id')
    def _compute_line_discount(self):
        for order in self:
            discount_value = 0.0
            order.update({
                    'discount_value': ((order.quantity * order.unit_price)*(order.discount_rate/100))
                    })
    
    # Taxable Value calculation
    @api.depends('quantity','unit_price','discount_rate','discount_id')
    def _compute_taxable_value(self):
        for order in self:
            taxable_value = 0.0            
            order.update({                
                'taxable_value': ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100))) 
            })
    
    # Total No of Product
    @api.depends('quantity')
    def _total_no_of_product(self):
        for order in self:
            total_no_of_product = 0
            total_no_of_product += order.quantity
            order.update({
                'no_of_product': total_no_of_product
                })
     
    # Taxable Value After Adding Others
    @api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate','discount_id')
    def _compute_taxable_value_after_adding_others(self):
        for order in self:
            taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges + order.insurance_charges)/ order.no_of_product
            order.update({                
                'taxable_value_after_adding_other': taxable_value + other_charges
            })
            
    # CGST value calculation
    @api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate','cgst_rate','cgst_id')
    def _compute_cgst_value(self):
        for order in self:
            taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges + order.insurance_charges)/ order.no_of_product
            cgst_rate = order.cgst_rate
            cgst_value = (taxable_value + other_charges) * cgst_rate/100
            order.update({                
                'cgst_value': cgst_value
            })
            
    # SGST value calculation
    @api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate','sgst_rate','sgst_id')
    def _compute_sgst_value(self):
        for order in self:
            taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges + order.insurance_charges)/ order.no_of_product
            sgst_rate = order.sgst_rate
            sgst_value = (taxable_value + other_charges) * sgst_rate/100
            order.update({                
                'sgst_value': sgst_value
            })
            
    # IGST value calculation
    @api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate','igst_rate','igst_id')
    def _compute_igst_value(self):
        for order in self:
            taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges + order.insurance_charges)/ order.no_of_product
            igst_rate = order.igst_rate
            igst_value = (taxable_value + other_charges) * igst_rate/100
            order.update({                
                'igst_value': igst_value
            })
            
    # Subtotal calculation
    @api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate','cgst_rate','cgst_id','sgst_rate','sgst_id','igst_rate','igst_id')
    def _compute_subtotal(self):
        for order in self:
            taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges +  order.insurance_charges)/ order.no_of_product
            taxable_value_after_adding_other = taxable_value + other_charges
            cgst_rate = order.cgst_rate
            cgst_value = (taxable_value + other_charges) * cgst_rate/100
            sgst_rate = order.sgst_rate
            sgst_value = (taxable_value + other_charges) * sgst_rate/100
            igst_rate = order.igst_rate
            igst_value = (taxable_value + other_charges) * igst_rate/100
            order.update({                
                'subtotal': taxable_value_after_adding_other + cgst_value + sgst_value + igst_value
            })
            
            
            
            
            
            
            
            
            
    #@api.depends('after_discount','packing_charges','no_of_product','total_excise_duty','tax_price')
    #def _compute_tax_value(self):
        #for order in self:
            #tax_value = 0.0            
            #order.update({                
                #'tax_value': (order.after_discount + order.packing_charges/order.no_of_product + order.total_excise_duty) * order.tax_price/100
            #})
    
    
    
    
            
    
            
    
    
    
    #@api.depends('quantity', 'unit_price','tax_id','tax_price','excise_duty','discount_value')
    #def _compute_excise_duty_per_product(self):
        #for order in self:
            #total_excise_duty = discount_value= 0.0            
            #order.update({                
                #'total_excise_duty': (order.after_discount + (order.packing_charges/order.no_of_product))  * order.excise_duty/100 
            #})
          
    
    
    
    # Validations start
    
    def _check_unit_price(self, cr, uid, ids):
         lines = self.browse(cr, uid, ids)
         for line in lines:
             if line.unit_price <= 0:
                 return False
         return True
    
    def _check_qty(self, cr, uid, ids):
         lines = self.browse(cr, uid, ids)
         for line in lines:
             if line.quantity <= 0:
                 return False
         return True
     
     
    def _check_discount(self, cr, uid, ids, context=None):
        obj = self.browse(cr, uid, ids[0], context=context)
        if (obj.discount < 0.0 or obj.discount > 100):
            return False
        return True
     
    _constraints = [
         (_check_qty, 'Order quantity cannot be negative or zero !', ['quantity']),
         (_check_unit_price, 'Unit Price cannot be negative or zero !', ['unit_price']),
         (_check_discount, 'Discount cannot be negative or zero or greater than 100!', ['discount'])
    ]
    
    # End
    
    def onchange_product(self, cr, uid, ids, product_id, context=None):
        cr.execute('SELECT  product_uom.id AS uom_id,product_product.default_code as description,product_template.list_purchase_price AS unit_price  FROM product_uom INNER JOIN product_template ON  product_uom.id=product_template.uom_id  INNER JOIN product_product ON product_product.product_tmpl_id =product_template.id WHERE  product_template.id = cast(%s as integer)', ((product_id),))
        for values in cr.dictfetchall():
            uom_id = values['uom_id']
            unit_price = values['unit_price']
            return {'value' :{ 'uom_id': uom_id,'unit_price': unit_price }}