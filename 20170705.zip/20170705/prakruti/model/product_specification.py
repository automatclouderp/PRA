from openerp import models, fields, api
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
import openerp.addons.decimal_precision as dp
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
import re
import logging

class ProductSpecificationNew(models.Model):
    _name = 'product.specification.main'
    _table = 'product_specification_main'
    _rec_name = 'specification_name'
    _order = 'id desc'
    
    product_id = fields.Many2one('product.product',string= "Product Name",required=True)
    specification_sale_status= fields.Boolean('Sale Ok')
    specification_purchase_status= fields.Boolean('Purchase Ok')
    specification_name= fields.Char(string= 'Specification Name', required= True)
    scientific_name= fields.Char(string= 'Scientific Name')
    lab_time= fields.Float(string= 'Lab Report in Hours' ,digits=(6,3))
    customer_name= fields.Many2one('res.partner', string= 'Customer Name')
    common_name= fields.Char(string= 'Common Name')
    plant_part_used= fields.Char(string= 'Plant Part Used')
    preparation_type= fields.Char(string='Preparation Type')
    extraction_ratio= fields.Char(string= 'Extraction Ratio')
    standardization= fields.Char(string= 'Standardization')
    excipients_used= fields.Char(string= 'Excipients Used')
    excipients_details= fields.Char(string= 'Excipients Details')
    specification_table= fields.One2many('specification.table','specification_line',string= 'No.of Specifications')
    quality_table = fields.One2many('quality.table','quality_line',string= 'Quality Records')
    specification_product_id= fields.Many2one('product.template',ondelete='cascade', string= 'Product Template ID')
    company_id= fields.Many2one('res.company',ondelete='cascade', string= 'Company ID')
    code= fields.Char(string= 'Product Code', readonly=True)
    issue_date= fields.Date(string= 'Issue Date')
    effective_date= fields.Date(string= 'Effective Date')
    review_date= fields.Date(string= 'Review Date')
    extraction_solvent= fields.Char(string= 'Extraction Solvent')
    final_extract_ratio= fields.Char(string= 'Final Extract Ratio')
    common_specification= fields.Boolean('Common Ok')       
    status = fields.Selection([('draft','Draft'),('assign','Assigned')],string= 'Status',default= 'draft',readonly=True)
    doc_no= fields.Char(string= 'Doc No')
    rev_no= fields.Char(string= 'Rev No') 
    specification_id = fields.Many2one('product.specification',related='specification_table.specification_id', string='Specification')
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.status == 'assign':
                raise UserError(_('Can\'t delete the Record which is Assigned'))
        return super(ProductSpecificationNew, self).unlink()
    
    @api.one
    @api.multi
    def assign_no(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute("UPDATE product_specification_main SET status = 'assign' WHERE id = CAST(%s AS INTEGER)",((temp.id),))
        return {}
    
    def onchange_product_id(self, cr, uid, ids, product_id, context=None):
        cr.execute('''SELECT code as product_code FROM product_template INNER JOIN product_product ON product_template.id = product_product.product_tmpl_id AND product_product.id = CAST(%s AS INTEGER)''',((product_id),))
        for values in cr.dictfetchall():
            product_code = values['product_code']
            return {
                'value':{
                    'code':product_code
                    }
                }
        
    def create(self, cr, uid, vals, context=None):
        onchangeResult = self.onchange_product_id(cr, uid, [], vals['product_id'])
        if onchangeResult.get('value') or onchangeResult['value'].get('code'):
            vals['code'] = onchangeResult['value']['code']
        return super(ProductSpecificationNew, self).create(cr, uid, vals, context=context)
    
    def write(self, cr, uid, ids, vals, context=None):
        op=super(ProductSpecificationNew, self).write(cr, uid, ids, vals, context=context)
        for record in self.browse(cr, uid, ids, context=context):
            store_type=record.product_id.id
        onchangeResult = self.onchange_product_id(cr, uid, ids, store_type)
        if onchangeResult.get('value') or onchangeResult['value'].get('code'):
            vals['code'] = onchangeResult['value']['code']
        return super(ProductSpecificationNew, self).write(cr, uid, ids, vals, context=context)
    
    @api.onchange('specification_sale_status')
    def onchange_sale_status(self):
        if self.specification_sale_status == False:
            self.customer_name = False
    
    @api.onchange('common_specification')
    def onchange_sale_status(self):
        if self.common_specification == True:
            self.specification_sale_status = False
            self.specification_purchase_status = False
            self.customer_name = False
    
    @api.model
    def _default_company(self):
        return self.env['res.company']._company_default_get('res.partner') 
    
    _defaults = {
        'company_id': _default_company
        }
    
    
    _sql_constraints = [
    ('name_uniqueness', 'unique(specification_name)','Specification Name must be Unique !')
    ]
    
    def onchange_check_code(self, cr, uid, ids, code, context=None):
        if code == False: 
            return {

                'value': {
                    'code': False
                }
            }

        if re.match("^[ A-Za-z0-9-]*$", code) != None:
            ''' to strip left and right spaces '''
            code = code.strip()
            code = code.upper()

            return {
                'value': {
                    'code': code
                }
            }

        else:
            warning_shown = {
                'title': _("Alert"),
                'message': _('Enter only numbers and alphabets'),
            }
            return {'value': {
                'code': False
            }, 'warning': warning_shown}

    def onchange_check_name(self, cr, uid, ids, specification_name, context=None):
        if specification_name == False:  
            return {

                'value': {
                    'specification_name': False
                }
            }

        if re.match("^[ A-Za-z0-9]*$", specification_name) != None:
            ''' to strip left and right spaces '''
            specification_name = specification_name.strip()
            specification_name = specification_name.upper()

            return {
                'value': {
                    'specification_name': specification_name
                }
            }

        else:
            warning_shown = {
                'title': _("Alert"),
                'message': _('Enter only numbers and alphabets'),
            }
            return {'value': {
                'specification_name': False
            }, 'warning': warning_shown}
    

class ProductSpecification(models.Model):
    _name= 'product.specification'
    
    parameter_category = fields.Char('Parameter Name', required= True)
    parameter_value = fields.Char('Parameter Value', required= True)#This will be inside square [] bracket
    parameter_name = fields.Text(string= 'Specifications')
    pcal= fields.Text(string= 'Protocols')
    
    def name_get(self, cr, uid, ids, context=None):
            if context is None:
                    context = {}
            res = []
            for record in self.browse(cr, uid, ids, context=context):
                    parameter_category = record.parameter_category
                    parameter_value = record.parameter_value
                    description = "%s [%s]" % (parameter_value, record.parameter_category)
                    res.append((record.id, description))
            return res
   
class ProductSpecificationTable(models.Model):
    _name= 'specification.table'
    specification_line= fields.Many2one('product.specification.main',ondelete='cascade', string="Specifications Line")
    specification_id= fields.Many2one('product.specification',ondelete='cascade', string="Parameters",required= True)
    specification= fields.Text(string= 'Specifications',related='specification_id.parameter_name',store=True)
    protocol= fields.Text(string= 'Protocol',related='specification_id.pcal',store=True)
    remarks= fields.Text(string= 'Remarks')
    
class ProductQualitytable(models.Model):
    _name = 'quality.table'
    quality_line= fields.Many2one('product.template',ondelete='cascade', string="Specifications Line")
    specification_id= fields.Many2one('product.specification',ondelete='cascade', string="Specifications")
    quality_parameter= fields.Many2one('product.specification',string= 'Parameters', no_create= 'True',required= True)
    perorval= fields.Float(string= '% or VALUE' ,digits=(6,3))
    minimum_value= fields.Float(string= 'STD. Min.' ,digits=(6,3))
    maximum_value= fields.Float(string= 'STD. Max.' ,digits=(6,3))
    remarks= fields.Text(string= 'Remarks')
    specification= fields.Text(string= 'Specifications',related= 'quality_parameter.parameter_name')