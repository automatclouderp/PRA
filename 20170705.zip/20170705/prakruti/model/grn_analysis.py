# -*- coding: utf-8 -*-
from openerp import models, fields, api,_
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp.exceptions import ValidationError
import re
import logging

class PrakrutiGRNAnalysis(models.Model):
    _name =  'prakruti.grn_analysis'
    _table = 'prakruti_grn_analysis'
    _rec_name = 'analysis_no'    
    _order="id desc" 
    
    order_line = fields.One2many('prakruti.grn_analysis_line','analysis_line_id')
    analysis_no= fields.Char(string='Analysis No.',default= 'New',readonly=1)
    analysis_date= fields.Date(string='Analysis Date',default= fields.Date.today,required=True)
    auto_no = fields.Integer('Auto')
    req_no_control_id = fields.Integer('Auto Generating id',default= 0)    
    analysis_number= fields.Char(string='Analysis No',compute= '_get_auto')
    category = fields.Selection([
                                ('maintanence','Non Testing Material'),
                                ('qc','Testing Material')
                                ],default= 'maintanence', string= 'Category')
    po_no= fields.Char(string= "Order Number",readonly=True)
    pr_no = fields.Char(string='Requisition No', readonly=True)
    qa_no = fields.Char(string='Analysis No', readonly=True)
    qo_no = fields.Char(string='Quotation No', readonly=True)
    req_no =fields.Char(string='Request No', readonly=True)
    vendor_id = fields.Many2one('res.partner',string='Vendor/Supplier', readonly= "True")
    logo = fields.Binary(related='company_address.logo')
    vendor_reference = fields.Char(string='Vendor/Supplier Reference', readonly= "True" )
    other_reference = fields.Char(string='Other Reference')
    request_date = fields.Date(string = "Requisition Date")
    order_date = fields.Date(string='Order Date')
    destination = fields.Char(string='Destination')
    company_address = fields.Many2one('res.company',string='Company Address', readonly= "True" )
    delivery_address = fields.Many2one('res.company',string='Dispatch To', readonly= "True" )
    payment = fields.Char(string='Mode/Terms of Payments')
    terms_of_delivery = fields.Text(string='Terms of Delivery')
    remarks=fields.Text('Remarks', readonly= "True" )
    total_discount = fields.Float(string="Total Discount" ,digits=(6,3))
    total_tax = fields.Float(string="Total Tax" ,digits=(6,3))
    grand_total= fields.Float(string='Grand Total' ,digits=(6,3))
    amount_untaxed= fields.Float(string='Untaxed Amount' ,digits=(6,3))
    additional_charges = fields.Float(string='Additional Charges' ,digits=(6,3))
    frieght_charges_applied = fields.Selection([('yes','Yes'),('no','No')], string="Freight Charge Applied", default='no')
    frieght_charges = fields.Float(string="Frieght Charges" ,digits=(6,3))
    dispatch_through = fields.Char(string='Dispatch Through', readonly= "True" )
    packing_charges = fields.Float(string='Packing & Forwarding' ,digits=(6,3))
    prepared_by = fields.Many2one('res.users','Prepared By',readonly=True)
    maintanence_manager = fields.Many2one('res.users',string="Maintanence Manager")    
    purchase_manager = fields.Many2one('res.users',string="Purchase Manager", readonly= "True" )
    purchase_type = fields.Many2one('product.group',string= 'Purchase Type')
    state = fields.Selection([('grn_analysis','GRN Analysis'),
                              ('grn','GRN'),
                              ('qc_check','QC Check'),                              
                              ('accepted','Accepted'),
                              ('rejected','Rejected'),
                              ('accepted_under_deviation','Accepted Under Deviation'),
                              ('qc_check_done','QC Check Done'),
                              ('invoice','Invoice'),
                              ('done','Done')],default= 'grn_analysis', string= 'Status')
    pr_common_id = fields.Integer('PR SCREEN COMMON ID')
    grand_total_in_words= fields.Text(string='Total in words')
    currency_id = fields.Many2one('res.currency', 'Currency')
    prakruti_stock_id = fields.Integer('SCREEN COMMON ID')
    excise_duty = fields.Float(string= 'Excise Duty(%)' ,digits=(6,3))
    total_excise_duty = fields.Float(string= 'Total Excise Duty' ,digits=(6,3))
    stores_incharge = fields.Many2one('res.users','Stores Incharge')
    grn_remarks=fields.Text('Remarks')
    gc_no=fields.Char('GC No')
    gc_date=fields.Date('GC Date')
    dc_no=fields.Char('DC No')
    dc_date=fields.Date('DC Date')
    transporter_name=fields.Text('Name of Transporter')
    transporter_payment_details=fields.Text('Transporter Payment Details')
    doc_no=fields.Char('Doc. No',default='PPPL-STR-F-001',readonly=1)
    rev_no=fields.Char('Rev. No',default='02',readonly=1)
    doc_date=fields.Date('Document Date',default= fields.Date.today,readonly=1)
    flag_rejected_count = fields.Integer('Flag', default=1)
    st_loc = fields.Many2one('stock.location', string='Stock Location')
    st_loc_remarks = fields.Text(string='Stock Location Remarks')
    flag_count_accept = fields.Integer('Accepted Line is There',default= 0)
    flag_count_reject = fields.Integer('Rejected Line is There',default= 0)
    flag_count_par_reject = fields.Integer('Partial Rejected Line is There',default= 0)
    any_adv_payment =fields.Selection([
                    ('no', 'No'),
                    ('yes','Yes')
                    ], string= 'Any Advance Payment')
    advance_payment_type =fields.Selection([
                    ('cash', 'CASH'),
                    ('cheque','CHEQUE'),
                    ('demand_draft','DEMAND DRAFT')
                    ], string= 'Done By')
    cash_amount = fields.Float(string="Amount" ,digits=(6,3))
    cash_remarks = fields.Text(string="Remarks")    
    cheque_amount = fields.Float(string="Amount" ,digits=(6,3))
    cheque_no = fields.Integer(string="Cheque No.")
    cheque_remarks = fields.Text(string="Remarks")    
    draft_amount = fields.Float(string="Amount" ,digits=(6,3))
    draft_no = fields.Integer(string="Draft No.")
    draft_remarks = fields.Text(string="Remarks") 
    product_id = fields.Many2one('product.product', related='order_line.product_id', string='Product Name') 
    
    @api.one
    @api.constrains('analysis_date')
    def _check_analysis_date(self):
        if self.analysis_date <  fields.Date.today():
            raise ValidationError(
                "Can\'t Select Back Date") 
    
    @api.one
    @api.multi
    def _get_auto(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids   
        for temp in self:
            cr.execute('''select cast(extract (month from analysis_date) as integer) as month ,cast(extract (year from analysis_date) as integer) as year ,id from prakruti_grn_analysis where id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
            if month_value<=3:
                year_value=year_value-1
            else:                
                year_value=year_value
            next_year=year_value+1
            dispay_year=str(next_year)[-2:]
            display_present_year=str(year_value)[-2:]
            cr.execute('''select autogenerate_grn_analysis(%s)''', ((temp.id),)  ) 
            result = cr.dictfetchall()
            parent_invoice_id = 0
            for value in result: parent_invoice_id = value['autogenerate_grn_analysis'];
            auto_gen = int(parent_invoice_id)
            if len(str(auto_gen)) < 2:
                auto_gen = '000'+ str(auto_gen)
            elif len(str(auto_gen)) < 3:
                auto_gen = '00' + str(auto_gen)
            elif len(str(auto_gen)) == 3:
                auto_gen = '0'+str(auto_gen)
            else:
                auto_gen = str(auto_gen)
            for record in self :
                print '--------------------------------4------------------------------------------',record.purchase_type.id
                if temp.purchase_type.group_code:
                    x[record.id] ='GRN-A\\'+ temp.purchase_type.group_code+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                else:                        
                    x[record.id] ='GRN_A\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                cr.execute('''update prakruti_grn_analysis set analysis_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
        return x
    
    @api.one
    @api.multi 
    def analysis_to_grn(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            if temp.category:
                if temp.category == 'maintanence':
                    grn_entry = self.pool.get('prakruti.grn_inspection_details').create(cr,uid, {
                        'cash_amount':temp.cash_amount,
                        'cash_remarks':temp.cash_remarks,
                        'cheque_amount':temp.cheque_amount,
                        'cheque_no':temp.cheque_no,
                        'cheque_remarks':temp.cheque_remarks,
                        'draft_amount':temp.draft_amount,
                        'draft_no':temp.draft_no,
                        'draft_remarks':temp.draft_remarks,
                        'advance_payment_type':temp.advance_payment_type,
                        'any_adv_payment':temp.any_adv_payment,
                        'po_no':temp.po_no,
                        'qa_no':temp.qa_no,
                        'pr_no':temp.pr_no,
                        'qo_no':temp.qo_no,
                        'req_no':temp.req_no,
                        'vendor_reference':temp.vendor_reference,
                        'payment':temp.payment,
                        'destination':temp.destination,
                        'other_reference':temp.other_reference,
                        'maintanence_manager':temp.maintanence_manager.id,
                        'purchase_manager':temp.purchase_manager.id,
                        'stores_incharge':temp.stores_incharge.id,
                        'terms_of_delivery':temp.terms_of_delivery,
                        'vendor_id': temp.vendor_id.id,
                        'state':'grn',
                        'remarks':temp.remarks,
                        'request_date':temp.request_date,
                        'order_date':temp.order_date,                        
                        'amount_untaxed':temp.amount_untaxed,
                        'additional_charges':temp.additional_charges,
                        'grand_total':temp.grand_total,
                        'frieght_charges_applied':temp.frieght_charges_applied,
                        'frieght_charges':temp.frieght_charges,
                        'packing_charges':temp.packing_charges,
                        'total_discount':temp.total_discount,
                        'total_tax':temp.total_tax,
                        'dispatch_through':temp.dispatch_through,
                        'excise_duty':temp.excise_duty,
                        'total_excise_duty':temp.total_excise_duty,
                        'purchase_type':temp.purchase_type.id,
                        'transporter_name':temp.transporter_name,
                        'transporter_payment_details':temp.transporter_payment_details,
                        'gc_no':temp.gc_no,
                        'gc_date':temp.gc_date,
                        'dc_date':temp.dc_date,
                        'dc_no':temp.dc_no,
                        })
                    for item in temp.order_line:
                        grid_values = self.pool.get('prakruti.grn_inspection_details_line').create(cr,uid, {
                            'product_id': item.product_id.id,
                            'description': item.description,
                            'actual_quantity': item.actual_quantity,
                            'accepted_qty': item.quantity,
                            'quantity': item.quantity,
                            'mfg_date':item.mfg_date,
                            'exp_date':item.exp_date,
                            'uom_id': item.uom_id.id,
                            'scheduled_date': item.scheduled_date,                   
                            'unit_price': item.unit_price,
                            'discount': item.discount,
                            'tax_price': item.tax_price,
                            'tax_id': item.tax_id.id,
                            'subtotal': item.subtotal,
                            'remarks':item.remarks,
                            'packing_style': item.packing_style,
                            'batch_no': item.batch_no,
                            'received_per_qty': item.received_per_qty,
                            'extra_packing':item.extra_packing,
                            'inspection_line_id': grn_entry
                            })
                    cr.execute('''UPDATE prakruti_grn_analysis SET state = 'grn' WHERE id = %s  ''', ((temp.id),))
                    cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'grn' WHERE prakruti_purchase_requisition.requisition_no = %s ", ((temp.pr_no),))
                else:
                    for item in temp.order_line:
                        grn_entry_1 = self.pool.get('prakruti.grn_inspection_details').create(cr,uid, {
                            'po_no':temp.po_no,
                            'qa_no':temp.qa_no,
                            'pr_no':temp.pr_no,
                            'qo_no':temp.qo_no,
                            'req_no':temp.req_no,
                            'vendor_reference':temp.vendor_reference,
                            'payment':temp.payment,
                            'destination':temp.destination,
                            'other_reference':temp.other_reference,
                            'maintanence_manager':temp.maintanence_manager.id,
                            'purchase_manager':temp.purchase_manager.id,
                            'stores_incharge':temp.stores_incharge.id,
                            'terms_of_delivery':temp.terms_of_delivery,
                            'vendor_id': temp.vendor_id.id,
                            'state':'grn',
                            'remarks':temp.remarks,
                            'request_date':temp.request_date,
                            'order_date':temp.order_date,                        
                            'amount_untaxed':temp.amount_untaxed,
                            'additional_charges':temp.additional_charges,
                            'grand_total':temp.grand_total,
                            'frieght_charges_applied':temp.frieght_charges_applied,
                            'frieght_charges':temp.frieght_charges,
                            'packing_charges':temp.packing_charges,
                            'total_discount':temp.total_discount,
                            'total_tax':temp.total_tax,
                            'dispatch_through':temp.dispatch_through,
                            'excise_duty':temp.excise_duty,
                            'total_excise_duty':temp.total_excise_duty,
                            'purchase_type':temp.purchase_type.id,
                            'transporter_name':temp.transporter_name,
                            'transporter_payment_details':temp.transporter_payment_details,
                            'gc_no':temp.gc_no,
                            'gc_date':temp.gc_date,
                            'dc_date':temp.dc_date,
                            'dc_no':temp.dc_no,
                            })
                        grid_values_1 = self.pool.get('prakruti.grn_inspection_details_line').create(cr,uid, {
                            'product_id': item.product_id.id,
                            'description': item.description,
                            'actual_quantity': item.actual_quantity,
                            'accepted_qty': item.quantity,
                            'quantity': item.quantity,
                            'uom_id': item.uom_id.id,
                            'scheduled_date': item.scheduled_date,                   
                            'unit_price': item.unit_price,
                            'discount': item.discount,
                            'tax_price': item.tax_price,
                            'tax_id': item.tax_id.id,
                            'subtotal': item.subtotal,
                            'remarks':item.remarks,
                            'packing_style': item.packing_style,
                            'received_per_qty': item.received_per_qty,
                            'batch_no': item.batch_no,
                            'inspection_line_id': grn_entry_1
                            })
                    cr.execute('''UPDATE prakruti_grn_analysis SET state = 'grn' WHERE id = %s  ''', ((temp.id),))
                    cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'grn' WHERE prakruti_purchase_requisition.requisition_no = %s ", ((temp.pr_no),))
            else:
                raise UserError(_('Oops...! Please Select Category'))
        return {}
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['grn','qc_check','accepted','rejected','accepted_under_deviation','done','qc_check_done','invoice']:
                raise UserError(_('Can\'t Delete record went to further process'))
        return super(PrakrutiGRNAnalysis, self).unlink()
    
    
    
    @api.onchange('any_adv_payment')
    def onchange_any_adv_payment(self):
        if self.any_adv_payment == 'no':
            self.advance_payment_type = None
    
    @api.onchange('advance_payment_type')
    def onchange_advance_payment_type(self):
        if self.advance_payment_type == 'cash':
            self.cheque_amount = 0
            self.cheque_no = 0
            self.cheque_remarks = ''
            self.draft_amount = 0
            self.draft_no = 0
            self.draft_remarks = ''
        if self.advance_payment_type == 'cheque':
            self.cash_amount = 0
            self.cash_remarks = ''
            self.draft_amount = 0
            self.draft_no = 0
            self.draft_remarks = ''
        if self.advance_payment_type == 'demand_draft':
            self.cash_amount = 0
            self.cash_remarks = ''
            self.cheque_amount = 0
            self.cheque_no = 0
            self.cheque_remarks = ''
        else:
            self.cash_amount = 0
            self.cash_remarks = ''
            self.cheque_amount = 0
            self.cheque_no = 0
            self.cheque_remarks = ''
            self.draft_amount = 0
            self.draft_no = 0
            self.draft_remarks = ''
    
    @api.model
    def _default_company(self):
        return self.env['res.company']._company_default_get('res.partner') 
    
    _defaults = {
        'stores_incharge': lambda s, cr, uid, c:uid,
        'prepared_by': lambda s, cr, uid, c:uid,
        'company_address': _default_company,
        'delivery_address': _default_company,
        }  

class PrakrutiGRNAnalysisLine(models.Model):
    _name = 'prakruti.grn_analysis_line'
    _table = 'prakruti_grn_analysis_line'
    
    analysis_line_id = fields.Many2one('prakruti.grn_analysis', ondelete='cascade')
    
    product_id = fields.Many2one('product.product',string='Product Name',required=True, readonly=1)   
    description = fields.Text(string='Description', readonly=1)
    scheduled_date =fields.Datetime(string='Due On')
    quantity = fields.Float(string='Received Quantity',store=True ,digits=(6,3))
    actual_quantity = fields.Float(string='Quantity', readonly=1 ,digits=(6,3))
    unit_price = fields.Float(string='Unit price' ,digits=(6,3))
    uom_id = fields.Many2one('product.uom',string='UOM',required=True, readonly=1)
    mfg_date = fields.Date(string='Mfg. Date')
    exp_date = fields.Date(string="Expiry Date")
    discount = fields.Float(string='Discount(%)' ,digits=(6,3))
    tax_type = fields.Selection([('cst','CST'),('tin','TIN'),('tax','Tax'),('vat','VAT')], string="Tax", default= 'tax')
    tax_id = fields.Many2one('account.other.tax', string='Taxes', domain=['|', ('active', '=', False), ('active', '=', True)])
    tax_price = fields.Float(related='tax_id.per_amount',string='Taxes', store=True,readonly=True ,digits=(6,3)) 
    subtotal= fields.Float(string='Sub Total' ,digits=(6,3))
    total= fields.Float(string='Total' ,digits=(6,3))
    currency_id = fields.Many2one(related='analysis_line_id.currency_id', store=True, string='Currency', readonly=True)
    prakruti_stock_id = fields.Integer('SCREEN COMMON ID')
    remarks = fields.Text('Remarks')
    packing_style = fields.Float(string= 'Packing Style' ,digits=(6,3))
    received_per_qty = fields.Float(string= 'Received Per Qty.' ,digits=(6,3))
    extra_packing= fields.Float(string= "(+)Extra Packing",default=0 ,digits=(6,3))
    accepted_qty = fields.Float('Accepted Qty.', store=True ,digits=(6,3))
    rejected_qty = fields.Float('Rejected Qty.', readonly=True ,digits=(6,3))
    status = fields.Selection([('open','Open'),
                               ('close','Close')],string= 'Status')
    
    batch_no = fields.Char('Batch No.')
    
    _sql_constraints = [
        ('unique_batch_no','unique(batch_no)','Batch No. must be Unique !')
        ]
    
    _defaults = {
        'unit_price': 1
        }
    
    @api.onchange('packing_style','received_per_qty','extra_packing')
    def _compute_total_quantity(self):
        for order in self:
            accepted_qty = 0.0
            quantity = 0.0
            order.update({
                    'accepted_qty': ((order.packing_style * order.received_per_qty) + order.extra_packing),
                    'quantity': ((order.packing_style * order.received_per_qty) + order.extra_packing)
                    })