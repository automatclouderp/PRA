import time
import openerp
from datetime import date, datetime
from openerp import models, fields, api
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from openerp.tools.translate import _
from datetime import timedelta



class PrakrutiPurchaseRequistionAnalysis(models.Model):
    _name = 'prakruti.purchase_requistion_analysis'
    _table = 'prakruti_purchase_requistion_analysis'
    _rec_name = 'analysis_no'
    _order="id desc"
    
    request_date = fields.Datetime(string = "Requisition Date", default= fields.Date.today)
    inquiry_date = fields.Date(string = "Analysis Date", default= fields.Date.today)    
    analysis_no = fields.Char(string = "Analysis No", readonly=True)    
    request_no = fields.Char(string = "Requisition No", readonly=True)
    terms_and_conditions = fields.Text()
    prepared_by = fields.Many2one('res.users','Prepared By', readonly=True)
    approved_by = fields.Many2one('res.users','Approved By', readonly=True)
    stores_incharge = fields.Many2one('res.users',string="Stores Incharge")
    requistion_order_line = fields.One2many('prakruti.purchase_requistion_analysis_line','requistion_line_id',string="Please Enter Some Product")
    remarks = fields.Text(string="Remarks")
    on_save = fields.Char('Grid Validation', compute='_on_save')    
    purchase_type = fields.Many2one('product.group',string= 'Purchase Type')    
    state = fields.Selection([
		('requisition', 'Requisition'),
		('requisition_analysis','Requisition Analysis'),
		('partial_analysis','Requisition Partial Analysis'),
		('partial_confirm','Requisition Partial Confirmed'),
		('request','Request'),
		('quotation','Quotation'),
                ('analysis','Quotation Analysis'),
                ('order','Order'),
                ('rejected','Rejected'),
                ('partial_confirm','Partial Confirm'),
                ('confirm','Order Confirm')],default= 'requisition', string= 'Status')   
    quotation_status = fields.Selection([
                ('hold', 'Hold'),
		('accepted','Accepted')]) 
    inq_no = fields.Char('Price Request Number', compute='_get_auto', readonly=True)
    auto_no = fields.Integer('Auto')
    req_no_control_id = fields.Integer('Auto Generating id',default= 0)    
    validate_flag = fields.Integer('CHECK FLAG',default= 0)
    to_name = fields.Many2one('res.users',string="To") 
    product_id = fields.Many2one('product.product', related='requistion_order_line.product_id', string='Product Name')
    approved_date = fields.Datetime(string = "Approve Date")
    revised_status = fields.Selection([('revised','Revised')],string= 'Revised Status')
    
    @api.one
    @api.multi
    def _get_auto(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids   
        for temp in self:
            cr.execute('''select cast(extract (month from inquiry_date) as integer) as month ,cast(extract (year from inquiry_date) as integer) as year ,id from prakruti_purchase_requistion_analysis where id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
            if month_value<=3:
                year_value=year_value-1
            else:                
                year_value=year_value
            next_year=year_value+1
            dispay_year=str(next_year)[-2:]
            display_present_year=str(year_value)[-2:]
            cr.execute('''select autogenerate_purchase_requisition_analysis(%s)''', ((temp.id),)  ) 
            result = cr.dictfetchall()
            parent_invoice_id = 0
            for value in result: parent_invoice_id = value['autogenerate_purchase_requisition_analysis'];
            auto_gen = int(parent_invoice_id)
            if len(str(auto_gen)) < 2:
                auto_gen = '000'+ str(auto_gen)
            elif len(str(auto_gen)) < 3:
                auto_gen = '00' + str(auto_gen)
            elif len(str(auto_gen)) == 3:
                auto_gen = '0'+str(auto_gen)
            else:
                auto_gen = str(auto_gen)
            for record in self :
                if temp.purchase_type.group_code:
                    x[record.id] ='PRA\\'+ temp.purchase_type.group_code+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                else:                        
                    x[record.id] ='PRA\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                cr.execute('''update prakruti_purchase_requistion_analysis set analysis_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
        return x   
    
    @api.one
    @api.multi
    def _on_save(self):
        pr_no = {}
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        for temp in self:
            cr.execute('''select count(id) as grid_id  from prakruti_price_request_line where request_line_id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                grid_id=int(item['grid_id'])
                
            cr.execute('''select count(id) as ven_id  from prakruti_vendor_list_line where vendor_line_id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                ven_id=int(item['ven_id'])                
                if (grid_id <=0  & ven_id <=0 ) :
                    raise UserError(_('Please Enter atleast 1 Material to Create Request')) 
            return pr_no  
    
    
    _defaults = {
        'analysis_no':'New',
        'request_no':'Direct Request',
        'prepared_by': lambda s, cr, uid, c:uid,
        'approved_by': lambda s, cr, uid, c:uid        
        }
    
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['request','quotation','analysis','order','rejected','confirm']:
                raise UserError(_('Can\'t Delete'))
        return super(PrakrutiPurchaseRequistionAnalysis, self).unlink()
    
    
 
    @api.one
    @api.multi
    def action_price_request(self): 
        vendor = 0
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            cr.execute(''' SELECT count(id) as status_line FROM prakruti_purchase_requistion_analysis_line WHERE (status = 'approved' OR status = 'rejected' OR status = 'hold') AND requistion_line_id = %s''',((temp.id),))
            for no_of_line in cr.dictfetchall():
                status_line = int(no_of_line['status_line'])
            if status_line == len(temp.requistion_order_line):
                if temp.state == 'requisition_analysis':
                    cr.execute('''select DISTINCT vendor_id from prakruti_purchase_requistion_analysis_line where requistion_line_id = %s and status='approved' and send_status = 0 ''', ((temp.id),))
                    for vendor in cr.dictfetchall():
                        vendor=vendor['vendor_id']
                        print '----------------------------------------------------------VENDOR NAMES ARE---------------------------------------------------------',vendor
                        
                        price_request = self.pool.get('prakruti.price_request').create(cr,uid, {
                            'inquiry_no': 'From Requisition Analysis',
                            'request_date':temp.request_date,
                            'purchase_type':temp.purchase_type.id,
                            'state': 'request',
                            'request_no':temp.request_no,
                            'remarks':temp.remarks,
                            'terms_and_conditions':temp.terms_and_conditions,
                            'purchase_manager':temp.prepared_by.id,
                            'stores_incharge':temp.stores_incharge.id,
                            'maintanence_manager':temp.prepared_by.id
                            })
                        vendor_grid = self.pool.get('prakruti.vendor_list_line').create(cr,uid, {
                            'vendor_id':vendor,
                            'vendor_line_id': price_request
                        })                    
                        for item in temp.requistion_order_line:
                            if (item.status == 'approved' and item.send_status==0 and vendor == item.vendor_id.id):
                                print '-----VENDOR ID IS-----',vendor
                                print '-----VENDOR NAME IS-----',item.vendor_id.name
                                print '-----PRODUCT ID IS-----',item.product_id.id
                                print '-----PRODUCT NAME IS-----',item.product_id.name_template
                                grid_values = self.pool.get('prakruti.price_request_line').create(cr,uid, {
                                    'product_id': item.product_id.id,
                                    'description': item.description,
                                    'quantity_req': item.quantity_req,
                                    'uom_id': item.uom_id.id,
                                    'required_date': item.required_date,
                                    'remarks': item.remarks,
                                    'last_price':item.last_price,
                                    'last_purchase_date':item.last_purchase_date,
                                    'last_purchase_vendor_id':item.last_purchase_vendor_id,
                                    'hsn_code':item.hsn_code,
                                    'request_line_id': price_request
                                    })
                    #When some are kept in hold
                    cr.execute("select count(id) as hold_line  from prakruti_purchase_requistion_analysis_line where requistion_line_id=%s AND status = 'hold' ",((temp.id),))
                    for line in cr.dictfetchall():
                        hold_line=line['hold_line'] 
                    if hold_line:                                            
                        cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'partial_analysis' WHERE prakruti_purchase_requistion_analysis.id = cast(%s as integer)",((temp.id),))
                        cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'partial_analysis' WHERE prakruti_purchase_requisition.requisition_no = %s",((temp.request_no),))
                        cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'partial_analysis' WHERE prakruti_purchase_requisition_approve.requisition_no = %s",((temp.request_no),))                                            
                        cr.execute("UPDATE  prakruti_purchase_requistion_analysis_line SET send_status = 1 WHERE requistion_line_id = cast(%s as integer) and status = 'approved'",((temp.id),))
                    else:                                            
                        cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'request' WHERE prakruti_purchase_requistion_analysis.id = cast(%s as integer)",((temp.id),))
                        cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'request' WHERE prakruti_purchase_requisition.requisition_no = %s",((temp.request_no),))
                        cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'request' WHERE prakruti_purchase_requisition_approve.requisition_no = %s",((temp.request_no),))
                    #When All are Rejected
                    cr.execute("select count(id) as no_of_rejectedline  from prakruti_purchase_requistion_analysis_line where requistion_line_id=%s AND status = 'rejected' ",((temp.id),))
                    for line in cr.dictfetchall():
                        no_of_rejectedline=line['no_of_rejectedline'] 
                    cr.execute("select count(id) as total_line  from prakruti_purchase_requistion_analysis_line where requistion_line_id=%s  ",((temp.id),))
                    for line in cr.dictfetchall():
                        total_line=line['total_line']
                    if total_line == no_of_rejectedline:                                            
                        cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'rejected' WHERE prakruti_purchase_requistion_analysis.id = cast(%s as integer)",((temp.id),))
                        cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'rejected' WHERE prakruti_purchase_requisition.requisition_no = %s",((temp.request_no),))
                        cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'rejected' WHERE prakruti_purchase_requisition_approve.requisition_no = %s",((temp.request_no),))
                elif temp.state == 'partial_analysis' or temp.state == 'partial_confirm':
                    cr.execute('''select DISTINCT vendor_id from prakruti_purchase_requistion_analysis_line where requistion_line_id = %s and status='approved' and send_status = 0 ''', ((temp.id),))
                    for vendor in cr.dictfetchall():
                        vendor=vendor['vendor_id']
                        print '----------------------------------------------------------VENDOR NAMES ARE---------------------------------------------------------',vendor
                        
                        price_request = self.pool.get('prakruti.price_request').create(cr,uid, {
                            'inquiry_no': 'From Requisition Analysis',
                            'request_date':temp.request_date,
                            'purchase_type':temp.purchase_type.id,
                            'state': 'request',
                            'request_no':temp.request_no,
                            'remarks':temp.remarks,
                            'terms_and_conditions':temp.terms_and_conditions,
                            'purchase_manager':temp.prepared_by.id,
                            'stores_incharge':temp.stores_incharge.id,
                            'maintanence_manager':temp.prepared_by.id
                            })
                        vendor_grid = self.pool.get('prakruti.vendor_list_line').create(cr,uid, {
                            'vendor_id':vendor,
                            'vendor_line_id': price_request
                        })                    
                        for item in temp.requistion_order_line:
                            if (item.status == 'approved' and item.send_status==0 and vendor == item.vendor_id.id):
                                print '-----VENDOR ID IS-----',vendor
                                print '-----VENDOR NAME IS-----',item.vendor_id.name
                                print '-----PRODUCT ID IS-----',item.product_id.id
                                print '-----PRODUCT NAME IS-----',item.product_id.name_template
                                grid_values = self.pool.get('prakruti.price_request_line').create(cr,uid, {
                                    'product_id': item.product_id.id,
                                    'description': item.description,
                                    'quantity_req': item.quantity_req,
                                    'uom_id': item.uom_id.id,
                                    'required_date': item.required_date,
                                    'remarks': item.remarks,
                                    'last_price':item.last_price,
                                    'last_purchase_date':item.last_purchase_date,
                                    'last_purchase_vendor_id':item.last_purchase_vendor_id,
                                    'hsn_code':item.hsn_code,
                                    'request_line_id': price_request
                                    })
                    #When some are kept in hold
                    cr.execute("select count(id) as hold_line  from prakruti_purchase_requistion_analysis_line where requistion_line_id=%s AND status = 'hold' ",((temp.id),))
                    for line in cr.dictfetchall():
                        hold_line=line['hold_line'] 
                    if hold_line:                                            
                        cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'partial_analysis' WHERE prakruti_purchase_requistion_analysis.id = cast(%s as integer)",((temp.id),))
                        cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'partial_analysis' WHERE prakruti_purchase_requisition.requisition_no = %s",((temp.request_no),))
                        cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'partial_analysis' WHERE prakruti_purchase_requisition_approve.requisition_no = %s",((temp.request_no),))                                            
                        cr.execute("UPDATE  prakruti_purchase_requistion_analysis_line SET send_status = 1 WHERE requistion_line_id = cast(%s as integer) and status = 'approved'",((temp.id),))
                    else:                                            
                        cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'request' WHERE prakruti_purchase_requistion_analysis.id = cast(%s as integer)",((temp.id),))
                        cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'request' WHERE prakruti_purchase_requisition.requisition_no = %s",((temp.request_no),))
                        cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'request' WHERE prakruti_purchase_requisition_approve.requisition_no = %s",((temp.request_no),))
            else:
                raise UserError(_('Please Select Status For The Products'))
            template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Purchase Analysis')],context=context)[0]
            email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True) 
        return {}
    
    @api.one
    @api.multi
    def req_analysis_to_order(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            cr.execute(''' SELECT count(id) as status_line FROM prakruti_purchase_requistion_analysis_line WHERE (status = 'approved' OR status = 'rejected' OR status = 'hold') AND requistion_line_id = %s''',((temp.id),))
            for no_of_line in cr.dictfetchall():
                status_line = int(no_of_line['status_line'])
            if status_line == len(temp.requistion_order_line):
                if temp.state == 'requisition_analysis':
                    cr.execute('''select DISTINCT vendor_id from prakruti_purchase_requistion_analysis_line where requistion_line_id = %s and status='approved' and send_status = 0 ''', ((temp.id),))
                    for vendor in cr.dictfetchall():
                        vendor=vendor['vendor_id']
                        print '----------------------------------------------------------VENDOR NAMES ARE---------------------------------------------------------',vendor
                        
                        purchase_order = self.pool.get('prakruti.purchase_order').create(cr,uid, {
                            'pr_no':temp.request_no,
                            'po_no':'From Requisition Analysis',
                            'qa_no':'From Requisition Analysis',
                            'qo_no':'From Requisition Analysis',
                            'req_no':'From Requisition Analysis',
                            'request_date':temp.request_date,
                            'purchase_type':temp.purchase_type.id,
                            'state': 'order',
                            'vendor_id':vendor,
                            'purchase_manager':temp.prepared_by.id,
                            'stores_incharge':temp.stores_incharge.id,
                            'maintanence_manager':temp.prepared_by.id,
                            'remarks':temp.remarks,
                            })
                        for item in temp.requistion_order_line:
                            if (item.status == 'approved' and item.send_status==0 and vendor == item.vendor_id.id) :
                                print '-----VENDOR ID IS-----',vendor
                                print '-----VENDOR NAME IS-----',item.vendor_id.name
                                print '-----PRODUCTS ID IS-----',item.product_id.id
                                print '-----PRODUCTS NAME IS-----',item.product_id.name_template
                                grid_values = self.pool.get('prakruti.purchase_line').create(cr,uid, {
                                    'product_id': item.product_id.id,
                                    'description': item.description,
                                    'quantity': item.quantity_req,
                                    'balance_qty': item.quantity_req,
                                    'uom_id': item.uom_id.id,
                                    'scheduled_date':item.required_date,
                                    'remarks': item.remarks,
                                    'hsn_code':item.hsn_code,
                                    'purchase_line_id': purchase_order
                                    })
                    #When some are kept in hold
                    cr.execute("select count(id) as hold_line  from prakruti_purchase_requistion_analysis_line where requistion_line_id=%s AND status = 'hold' ",((temp.id),))
                    for line in cr.dictfetchall():
                        hold_line=line['hold_line'] 
                    if hold_line:                                            
                        cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'partial_analysis' WHERE prakruti_purchase_requistion_analysis.id = cast(%s as integer)",((temp.id),))
                        cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'partial_analysis' WHERE prakruti_purchase_requisition.requisition_no = %s",((temp.request_no),))
                        cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'partial_analysis' WHERE prakruti_purchase_requisition_approve.requisition_no = %s",((temp.request_no),))                                            
                        cr.execute("UPDATE  prakruti_purchase_requistion_analysis_line SET send_status = 1 WHERE requistion_line_id = cast(%s as integer) and status = 'approved'",((temp.id),))
                    else:                                            
                        cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'order' WHERE prakruti_purchase_requistion_analysis.id = cast(%s as integer)",((temp.id),))
                        cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'order' WHERE prakruti_purchase_requisition.requisition_no = %s",((temp.request_no),))
                        cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'order' WHERE prakruti_purchase_requisition_approve.requisition_no = %s",((temp.request_no),))
                    #When All are Rejected
                    cr.execute("select count(id) as no_of_rejectedline  from prakruti_purchase_requistion_analysis_line where requistion_line_id=%s AND status = 'rejected' ",((temp.id),))
                    for line in cr.dictfetchall():
                        no_of_rejectedline=line['no_of_rejectedline'] 
                    cr.execute("select count(id) as total_line  from prakruti_purchase_requistion_analysis_line where requistion_line_id=%s  ",((temp.id),))
                    for line in cr.dictfetchall():
                        total_line=line['total_line']
                    if total_line == no_of_rejectedline:                                            
                        cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'rejected' WHERE prakruti_purchase_requistion_analysis.id = cast(%s as integer)",((temp.id),))
                        cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'rejected' WHERE prakruti_purchase_requisition.requisition_no = %s",((temp.request_no),))
                        cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'rejected' WHERE prakruti_purchase_requisition_approve.requisition_no = %s",((temp.request_no),))
                elif temp.state == 'partial_analysis' or temp.state == 'partial_confirm':
                    cr.execute('''select DISTINCT vendor_id from prakruti_purchase_requistion_analysis_line where requistion_line_id = %s and status='approved' and send_status = 0 ''', ((temp.id),))
                    for vendor in cr.dictfetchall():
                        vendor=vendor['vendor_id']
                        print '----------------------------------------------------------VENDOR NAMES ARE---------------------------------------------------------',vendor
                        
                        purchase_order = self.pool.get('prakruti.purchase_order').create(cr,uid, {
                            'pr_no':temp.request_no,
                            'po_no':'From Requisition Analysis',
                            'qa_no':'From Requisition Analysis',
                            'qo_no':'From Requisition Analysis',
                            'req_no':'From Requisition Analysis',
                            'request_date':temp.request_date,
                            'purchase_type':temp.purchase_type.id,
                            'state': 'order',
                            'vendor_id':vendor,
                            'purchase_manager':temp.prepared_by.id,
                            'stores_incharge':temp.stores_incharge.id,
                            'maintanence_manager':temp.prepared_by.id,
                            'remarks':temp.remarks,
                            })
                        for item in temp.requistion_order_line:
                            if (item.status == 'approved' and item.send_status==0 and vendor == item.vendor_id.id) :
                                print '-----PRODUCTS FOR THIS PATICULAR VENDOR-----',vendor
                                print '-----VENDOR NAME IS-----',item.vendor_id.name
                                print '-----PRODUCTS ID IS-----',item.product_id.id
                                print '-----PRODUCTS NAME IS-----',item.product_id.name_template
                                grid_values = self.pool.get('prakruti.purchase_line').create(cr,uid, {
                                    'product_id': item.product_id.id,
                                    'description': item.description,
                                    'quantity': item.quantity_req,
                                    'balance_qty': item.quantity_req,
                                    'uom_id': item.uom_id.id,
                                    'scheduled_date':item.required_date,
                                    'remarks': item.remarks,
                                    'hsn_code':item.hsn_code,
                                    'purchase_line_id': purchase_order
                                    })
                    #When some are kept in hold
                    cr.execute("select count(id) as hold_line  from prakruti_purchase_requistion_analysis_line where requistion_line_id=%s AND status = 'hold' ",((temp.id),))
                    for line in cr.dictfetchall():
                        hold_line=line['hold_line'] 
                    if hold_line:                                            
                        cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'partial_analysis' WHERE prakruti_purchase_requistion_analysis.id = cast(%s as integer)",((temp.id),))
                        cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'partial_analysis' WHERE prakruti_purchase_requisition.requisition_no = %s",((temp.request_no),))
                        cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'partial_analysis' WHERE prakruti_purchase_requisition_approve.requisition_no = %s",((temp.request_no),))                                            
                        cr.execute("UPDATE  prakruti_purchase_requistion_analysis_line SET send_status = 1 WHERE requistion_line_id = cast(%s as integer) and status = 'approved'",((temp.id),))
                    else:                                            
                        cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'order' WHERE prakruti_purchase_requistion_analysis.id = cast(%s as integer)",((temp.id),))
                        cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'order' WHERE prakruti_purchase_requisition.requisition_no = %s",((temp.request_no),))
                        cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'order' WHERE prakruti_purchase_requisition_approve.requisition_no = %s",((temp.request_no),))
            else:
                raise UserError(_('Please Select Status For The Products'))  
            template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Purchase Analysis Order')],context=context)[0]
            email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)          
        return {}   
    
    
    @api.one
    @api.multi
    def validate_total_qty(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            for line in temp.requistion_order_line:
                cr.execute("SELECT SUM(prakruti_purchase_requisition_line.quantity_req) as requested_qty FROM public.prakruti_purchase_requisition, public.prakruti_purchase_requisition_line, public.prakruti_purchase_requistion_analysis WHERE prakruti_purchase_requisition.id = prakruti_purchase_requisition_line.order_id AND prakruti_purchase_requisition.requisition_no = prakruti_purchase_requistion_analysis.request_no AND prakruti_purchase_requisition_line.product_id = CAST(%s AS INTEGER) AND prakruti_purchase_requistion_analysis.id = CAST(%s AS INTEGER)", ((line.product_id.id),(temp.id),))
                for item in cr.dictfetchall():
                    requested_qty = item['requested_qty']
                cr.execute("SELECT SUM(prakruti_purchase_requistion_analysis_line.quantity_req) as analysis_qty FROM public.prakruti_purchase_requistion_analysis, public.prakruti_purchase_requistion_analysis_line, prakruti_purchase_requisition WHERE prakruti_purchase_requistion_analysis.id = prakruti_purchase_requistion_analysis_line.requistion_line_id AND prakruti_purchase_requistion_analysis.request_no = prakruti_purchase_requisition.requisition_no AND prakruti_purchase_requistion_analysis_line.product_id = CAST(%s AS INTEGER) AND prakruti_purchase_requistion_analysis.id = CAST(%s AS INTEGER)", ((line.product_id.id),(temp.id),))
                for item in cr.dictfetchall():
                    analysis_qty = item['analysis_qty']
                print '-------------------------------product_name----------------------------------------------',line.product_id.id
                print '-------------------------------product_name----------------------------------------------',line.product_id.name_template
                print '-------------------------------analysis_qty----------------------------------------------',analysis_qty
                print '-------------------------------requested_qty----------------------------------------------',requested_qty
                if analysis_qty != requested_qty:
                    raise UserError(_('Your Entered Quantity is %s for the Product [ %s ] which is not equal to the Requested Qty i.e. %s') %(analysis_qty,line.product_id.name_template,requested_qty))                                    
                cr.execute("UPDATE prakruti_purchase_requistion_analysis SET validate_flag = 1 WHERE prakruti_purchase_requistion_analysis.id = CAST(%s AS INTEGER)", ((temp.id),))
        return {}   
    
class PurchaseRequisitionAnalysisLine(models.Model):
    _name = 'prakruti.purchase_requistion_analysis_line'
    _table = 'prakruti_purchase_requistion_analysis_line'
    
    requistion_line_id = fields.Many2one('prakruti.purchase_requistion_analysis', ondelete='cascade')
    product_id = fields.Many2one('product.product',string="Product Name", required=True)
    description = fields.Text(string = "Description")
    quantity_req = fields.Float(string = "Qty. Req", required=True ,digits=(6,3))
    uom_id = fields.Many2one('product.uom',string="UOM",required= True)
    required_date = fields.Date(string="Req. Date")
    remarks = fields.Text(string="Remarks")
    vendor_id = fields.Many2one('res.partner',string="Vendor Name")
    requisition_grid_id = fields.Integer(string= 'Requisition Grid ID')
    status= fields.Selection([
		('approved','Approved'),
		('hold','Hold'),
		('rejected', 'Rejected')],default='approved')   
    send_status = fields.Integer(default= 0, string= 'Send Status',readonly=1)    
    request_no = fields.Char(string = "Requisition No", readonly=True)
    last_price = fields.Float(string = "Last Purchase Price", readonly=True,digits=(6,3))
    last_purchase_vendor_id= fields.Many2one('res.partner',string="Last Purchase Vendor Name",readonly=True)
    last_purchase_date= fields.Date(string="Last Purchase Date",store=True,readonly=True)
    hsn_code = fields.Char(string='HSN/SAC')
    
    def onchange_product(self, cr, uid, ids, product_id, context=None):
        qty_aval = 0.0
        line1 = 0
        line2 = ''
        line3 = 0
        line4 = False
        line5 = False
        uom_name = ''
        line8 = ''
        hsn_code = ''
        cr.execute('SELECT product_uom.id AS uom_id, product_uom.name AS uom_name, product_template.name AS description,product_template.hsn_code AS hsn_code FROM product_uom INNER JOIN product_template ON product_uom.id=product_template.uom_id INNER JOIN product_product ON product_template.id=product_product.product_tmpl_id WHERE product_product.id = cast(%s as integer)', ((product_id),))
        for line in cr.dictfetchall():
            line1 = line['uom_id']
            line2 = line['description']
            line8 = line['hsn_code']
        print 'UOM ID',line1
        print 'PRODUCT NAME',line2
        cr.execute('''  SELECT ppl.unit_price AS last_price,ppo.vendor_id AS last_purchase_vendor_name, order_date AS purchase_date FROM prakruti_purchase_order AS ppo INNER JOIN prakruti_purchase_line AS ppl ON ppo.id = ppl.purchase_line_id WHERE ppl.product_id = CAST(%s as integer) and ppo.state = 'order_close' order by ppo.id DESC LIMIT 1''', ((product_id),))
        for line in cr.dictfetchall():
            line3 = line['last_price']
            line4 = line['purchase_date']
            line5 = line['last_purchase_vendor_name']
        print 'UOM ID',line1
        print 'LAST PRICE',line3
        print 'PRODUCT NAME',line2
        print 'VENDOR  NAME',line5
        print 'LAST PURCHASE DATE',line4
        return {'value' :{'uom_id':line1,
                          'description':line2,
                          'last_price':line3,
                          'last_purchase_vendor_id':line5,
                          'last_purchase_date':line4, 
                          'hsn_code':line8 or ''
                          }}

    def _check_qty(self, cr, uid, ids):
         lines = self.browse(cr, uid, ids)
         for line in lines:
             if line.quantity_req <= 0:
                 return False
         return True
     
    _constraints = [
         (_check_qty, 'Order quantity cannot be negative or zero !', ['quantity_req']),
    ]
        
    def create(self, cr, uid, vals, context=None):
        onchangeResult = self.onchange_product(cr, uid, [], vals['product_id'])
        if onchangeResult.get('value') or onchangeResult['value'].get('last_price'):
            vals['last_price'] = onchangeResult['value']['last_price']
        return super(PurchaseRequisitionAnalysisLine, self).create(cr, uid, vals, context=context)
    
    def write(self, cr, uid, ids, vals, context=None):
        op=super(PurchaseRequisitionAnalysisLine, self).write(cr, uid, ids, vals, context=context)
        for record in self.browse(cr, uid, ids, context=context):
            store_type=record.product_id.id
        onchangeResult = self.onchange_product(cr, uid, ids, store_type)
        if onchangeResult.get('value') or onchangeResult['value'].get('last_price'):
            vals['last_price'] = onchangeResult['value']['last_price']
        return super(PurchaseRequisitionAnalysisLine, self).write(cr, uid, ids, vals, context=context)