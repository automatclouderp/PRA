import openerp
from datetime import date, datetime
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from datetime import timedelta
from openerp.osv import osv,fields
from openerp import models, fields, api, _
from openerp.tools.translate import _
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
from lxml import etree
import cgi
import logging
import lxml.html
import lxml.html.clean as clean
import openerp.pooler as pooler
import random
import re
import socket
import threading
import time
from operator import itemgetter


class PurchaseRequisitionFromStoresApprove(models.Model):
    _name = 'prakruti.purchase_requisition_approve'
    _table = 'prakruti_purchase_requisition_approve'
    _description = 'Purchase Requisition Approval'
    _rec_name = 'requisition_no'
    _order="id desc"  
        
    requisition_date = fields.Datetime(string = "Requisition Date")
    requisition_no = fields.Char(string = "Requisition No", readonly=True)
    remarks = fields.Text(string="Remarks")
    prepared_by = fields.Many2one('res.users','Requisition By',readonly=True)
    plant_manager = fields.Many2one('res.users',string="Plant Manager",readonly=True)
    stores_incharge = fields.Many2one('res.users',string="Stores Incharge",readonly=True)
    purchase_manager = fields.Many2one('res.users',string="Purchase Manager",readonly=True)
    to_name = fields.Many2one('res.users',string="Name", readonly= True)
    state = fields.Selection([
		('requisition', 'Requisition'),
		('approve', 'Requisition Approval'),
		('partially_approved', 'Requisition Partially Approval'),
		('partial_confirm','Requisition Partial Confirmed'),
		('requisition_analysis','Requisition Analysis'),
		('partial_analysis','Requisition Partial Analysis'),
		('request','Request'),
		('quotation','Quotation'),
                ('analysis','Quotation Analysis'),
                ('order','Order'),
                ('rejected','Rejected'),
                ('confirm','Order Confirm')],default= 'requisition', string= 'Status')
    requisition_line = fields.One2many('prakruti.purchase_requisition_approve_line','order_id',string='Order Lines')
    purchase_type = fields.Many2one('product.group',string= 'Purchase Type')
    approved_date = fields.Datetime(string = "Approve Date")
    approved_by = fields.Many2one('res.users','Approved By')
    product_id = fields.Many2one(related='requisition_line.product_id', string="Product Name")
    revised_status = fields.Selection([('revised','Revised')],string= 'Revised Status')

    @api.one
    @api.constrains('approved_date')
    def _check_approved_date(self):
        if self.approved_date < fields.Date.today():
            raise openerp.exceptions.ValidationError(
                "Can't Select Back Date!")
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['request','quotation','analysis','order','rejected','confirm','approve']:
                raise UserError(_('Can\'t Delete'))
        return super(PurchaseRequisitionFromStoresApprove, self).unlink()
    
    _defaults = {
        'approved_date':lambda *a: time.strftime('%Y-%m-%d'),
        'approved_by': lambda s, cr, uid, c:uid
        }
    
    @api.multi
    def onchange_state(self, state_id):
        if state_id:
            state = self.env['res.country.state'].browse(state_id)
            return {'value': {'country_id': state.country_id.id}}
        return {'value': {}}
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['requisition_analysis','request','quotation','analysis','order','rejected','confirm']:
                raise UserError(_('Can\'t Delete...'))
        return super(PurchaseRequisitionFromStoresApprove, self).unlink() 
    
    @api.one
    @api.multi 
    def action_reject(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            if temp.remarks:
                cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'rejected' WHERE prakruti_purchase_requisition_approve.id = %s",((temp.id),))
                cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'rejected' WHERE prakruti_purchase_requisition.requisition_no = %s",((temp.requisition_no),))
            else:
                raise UserError(_('Please Enter Remarks...'))
        return {}
    
    @api.one
    @api.multi
    def action_approve_analysis(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {} 
            cr.execute("SELECT count(id) as approve_line from prakruti_purchase_requisition_approve_line where (status='approve' or status='partial_approve' or status='reject') and order_id = %s", ((temp.id),))
            for line in cr.dictfetchall():
                approve_line=line['approve_line']
            if approve_line:
                req_analysis = self.pool.get('prakruti.purchase_requistion_analysis').create(cr,uid, {
                    'inquiry_no': 'From Requisition',
                    'request_date':temp.requisition_date,
                    'purchase_type':temp.purchase_type.id,
                    'state': 'requisition_analysis',
                    'request_no':temp.requisition_no,
                    'remarks':temp.remarks,
                    'purchase_manager':temp.prepared_by.id,
                    'stores_incharge':temp.stores_incharge.id,
                    'maintanence_manager':temp.prepared_by.id,
                    'approved_by':temp.approved_by.id,
                    'approved_date':temp.approved_date,
                    'to_name':temp.to_name.id,
                    })
                cr.execute("SELECT product_id,description,quantity,uom_id,required_date,remarks,last_price,last_purchase_date,last_purchase_vendor_id,hsn_code from prakruti_purchase_requisition_approve_line where order_id = %s and  (status='approve' or status='partial_approve')", ((temp.id),))
                for item in cr.dictfetchall():
                    product_id=item['product_id']
                    description=item['description']
                    quantity=item['quantity']
                    uom_id=item['uom_id']
                    required_date=item['required_date']
                    remarks=item['remarks']
                    last_price=item['last_price']
                    last_purchase_date=item['last_purchase_date']
                    last_purchase_vendor_id=item['last_purchase_vendor_id']
                    hsn_code=item['hsn_code']
                    grid_values = self.pool.get('prakruti.purchase_requistion_analysis_line').create(cr,uid, {
                        'product_id': product_id,
                        'description': description,
                        'quantity_req': quantity,
                        'uom_id': uom_id,
                        'required_date': required_date,
                        'remarks': remarks,
                        'last_price': last_price,
                        'last_purchase_date': last_purchase_date,
                        'last_purchase_vendor_id': last_purchase_vendor_id,
                        'hsn_code':hsn_code,
                        'requistion_line_id': req_analysis
                        })
            else:
                raise UserError(_('Please Select Status For The Products'))
            cr.execute("SELECT quantity,quantity_req from prakruti_purchase_requisition_approve_line where order_id = %s and  (status='approve' or status='partial_approve')", ((temp.id),))
            for line in cr.dictfetchall():
                quantity=line['quantity']
                quantity_req=line['quantity_req']
            if quantity_req == quantity:
                cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'requisition_analysis' WHERE prakruti_purchase_requistion_analysis.id = cast(%s as integer)",((temp.id),))
                cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'requisition_analysis' WHERE prakruti_purchase_requisition_approve.id = cast(%s as integer)",((temp.id),))
                cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'requisition_analysis' WHERE prakruti_purchase_requisition.requisition_no = %s",((temp.requisition_no),))
            else:
                cr.execute("UPDATE  prakruti_purchase_requistion_analysis SET state = 'partially_approved' WHERE prakruti_purchase_requistion_analysis.id = cast(%s as integer)",((temp.id),))
                cr.execute("UPDATE  prakruti_purchase_requisition_approve SET state = 'partially_approved' WHERE prakruti_purchase_requisition_approve.id = cast(%s as integer)",((temp.id),))
                cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'partially_approved' WHERE prakruti_purchase_requisition.requisition_no = %s",((temp.requisition_no),))
            
            template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Purchase Approve')],context=context)[0]
            email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
        return {}
    
    def _check_the_grid(self, cr, uid, ids, context=None, * args):
        for line_id in self.browse(cr, uid, ids, context=context):
            if len(line_id.requisition_line) == 0:
                return False
        return True
    
    
    _constraints = [
         (_check_the_grid, 'Sorry !!!, Please enter some products to procced further, Thank You !', ['requisition_line']),
    ]
    
    def send_mail_quotation(self, cr, uid, ids, context=None):
        for temp in self.browse(cr, uid, ids, context={}):
            template_id = self.pool.get('email.template').search(cr,uid,[('name','=','PR - Send by Email')],context=context)[0]
            email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
        return True
    
class PurchaseRequisitionLineApprove(models.Model):
    _name = 'prakruti.purchase_requisition_approve_line'
    _table = 'prakruti_purchase_requisition_approve_line'
    
    product_id = fields.Many2one('product.product' , string="Product Name", required=True)
    description = fields.Text(string = "Description ")
    quantity_req = fields.Float(string = "Qty. Req", required=True ,digits=(6,3) )
    quantity = fields.Float(string = "Quantity Approved", required=True ,digits=(6,3))
    suggested_packing_size = fields.Float(string="Suggested Packing Size",digits=(6,3))
    required_date = fields.Date(string="Required Date")
    current_date = fields.Date(string="Current Date")
    remarks = fields.Text(string="Remarks")
    uom_id = fields.Many2one('product.uom',string="UOM",required=True)    
    stock_on_pr_date_ref = fields.Float(string="Available Stock",store=True,readonly=True ,digits=(6,3))
    last_purchase_date= fields.Date(string="Last Purchase Date",store=True,readonly=True)
    order_id = fields.Many2one('prakruti.purchase_requisition_approve', string='Order Reference', index=True, ondelete='cascade')
    specification_id = fields.Many2one('product.specification.main', string = "Specification")
    status = fields.Selection([
                ('approve','Approved'),
                ('partial_approve','PartiallyApproved'),
                ('reject','Reject')],default= 'approve', string= 'Status')
    last_purchase_vendor_id= fields.Many2one('res.partner',string="Last Purchase Vendor Name",readonly=True) 
    last_price = fields.Float(string = "Last Purchase Price", readonly=True ,digits=(6,3))
    hsn_code = fields.Char(string='HSN/SAC')
    
    _defaults = {
        'required_date':lambda *a: time.strftime('%Y-%m-%d'),
        'current_date':lambda *a: time.strftime('%Y-%m-%d')
        }

    @api.one
    @api.constrains('quantity')
    def _check_quantity(self):
        if (self.quantity > self.quantity_req) or self.quantity <= 0:
            raise openerp.exceptions.ValidationError(
                "Please Check Qty") 

    @api.one
    @api.constrains('required_date')
    def _check_required_date(self):
        if self.required_date < fields.Date.today():
            raise openerp.exceptions.ValidationError(
                "Can't Select Back Date!") 
    
    _sql_constraints=[
        
        ('unique_product_id','unique(product_id, order_id)', 'Item(s) should be Unique')
        ]
    
    def onchange_product(self, cr, uid, ids, product_id, context=None):
        qty_aval = 0.0
        line1 = 0
        line2 = ''
        line3 = 0
        line4 = False
        uom_name = ''
        line8 = ''
        hsn_code = ''
        cr.execute('SELECT product_uom.id AS uom_id, product_uom.name AS uom_name, product_template.name AS description,product_template.hsn_code AS hsn_code FROM product_uom INNER JOIN product_template ON product_uom.id=product_template.uom_id INNER JOIN product_product ON product_template.id=product_product.product_tmpl_id WHERE product_product.id = cast(%s as integer)', ((product_id),))
        for line in cr.dictfetchall():
            line1 = line['uom_id']
            line2 = line['description']
            line8 = line['hsn_code']
        cr.execute('''SELECT qty_aval FROM (SELECT uom, product_id, name, qty_in, qty_out, qty_in - qty_out as qty_aval FROM ( SELECT uom,product_id, name, sum(qty_out) as qty_out, sum(qty_in) as qty_in FROM ( SELECT product_uom.name as uom,stock_move.product_id, product_product.name_template as name, picking_id, case when move_dest_id > 0 then product_qty else 0 end as qty_out, case when move_dest_id > 0 then 0 else product_qty end as qty_in FROM product_uom INNER JOIN product_template ON product_uom.id = product_template.uom_id INNER JOIN product_product ON product_product.product_tmpl_id = product_template.id INNER JOIN stock_move ON stock_move.product_id = product_product.id WHERE location_dest_id = 12  AND stock_move.state = 'done' AND product_product.id = CAST(%s as integer)) as a group by product_id, name, uom ) as a ) AS b ORDER BY product_id''', ((product_id),))
        for line in cr.dictfetchall():
            line3 = line['qty_aval']
        cr.execute('''  SELECT ppl.unit_price AS last_price,ppo.vendor_id AS last_purchase_vendor_name, order_date AS purchase_date FROM prakruti_purchase_order AS ppo INNER JOIN prakruti_purchase_line AS ppl ON ppo.id = ppl.purchase_line_id WHERE ppl.product_id = CAST(%s as integer) and ppo.state = 'order_close' order by ppo.id DESC LIMIT 1''', ((product_id),))
        for line in cr.dictfetchall():
            line6 = line['last_price']
            line4 = line['purchase_date']
            line5 = line['last_purchase_vendor_name']
        print 'UOM ID',line1
        print 'AVAILABLE STOCK',line3
        print 'PRODUCT NAME',line2
        return {'value' :{'uom_id':line1,
                          'description':line2,
                          'stock_on_pr_date_ref': line3 or 0.0,
                          'last_purchase_date': line4,
                          'last_price': line6,
                          'last_purchase_vendor_id': line5, 
                          'hsn_code':line8 or ''
                          }}