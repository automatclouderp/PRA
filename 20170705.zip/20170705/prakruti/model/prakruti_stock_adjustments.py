from openerp import models, fields, api
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
import openerp.addons.decimal_precision as dp
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
import re
import logging
from datetime import timedelta

class PrakrutiStockAdjustments(models.Model):
    _name= 'prakruti.stock_adjustments'
    _table= 'prakruti_stock_adjustments'
    _description= 'Prakruti Stock Adjustments'
    _rec_name= 'adjustment_name'
    _order="id desc"

    adjustment_name = fields.Char(string= 'Name',required= True)
    location_dest_id = fields.Many2one('stock.location',string= 'Location',readonly=1)
    entered_date = fields.Datetime(string= 'Date')
    adjustment_line = fields.One2many('prakruti.stock_adjustments_line','adjustment_id',string= 'Adjustment Line')
    product_line = fields.One2many('prakruti.all_product_line','main_id',string= 'All Product Line')
    status = fields.Selection([('wait','Waiting'),('done','Done')],string= 'Status')
    product_id = fields.Many2one('product.product', related='adjustment_line.product_id', string='Product Name')
    list_flag = fields.Integer(string= 'List Flag',default=0)
    
    _defaults = {
        'location_dest_id' : 12,
        'entered_date': datetime.now(),
        'status': 'wait'
        } 
    
    @api.one
    @api.multi
    def action_done(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        gf = 0
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {} 
            cr.execute("""SELECT update_stock_adjustments(%s)""",((temp.id),))
            cr.execute("UPDATE  prakruti_stock_adjustments SET status = 'done' WHERE prakruti_stock_adjustments.id = cast(%s as integer)",((temp.id),))
            #template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Stock Adjustments')],context=context)[0]
            #email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
        return {} 
    
    @api.one
    @api.multi
    def list_all_products(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        item_id = 0
        item_code = ' '
        item_uom_id = 0
        main_id = 0
        for temp in self:
            cr.execute('''INSERT INTO prakruti_all_product_line (item_id,item_code,item_uom_id,main_id,name_template)
SELECT item_id,item_code,item_uom_id,main_id,name_template FROM
(
SELECT 
	product_product.id AS item_id,
	product_template.code AS item_code,
	product_uom.id AS item_uom_id,
	product_template.name AS name_template 
FROM 
	product_product JOIN 
	product_template ON 
	product_product.product_tmpl_id = product_template.id JOIN 
	product_uom ON 
	product_template.uom_id = product_uom.id               
   ) AS a CROSS JOIN
   (
   SELECT id AS main_id FROM prakruti_stock_adjustments WHERE prakruti_stock_adjustments.id = %s
   ) AS b ORDER BY a.name_template''', ((temp.id),))
            cr.execute("UPDATE prakruti_all_product_line SET item_quantity= qty_aval FROM ( SELECT product_id,name,(sum(qty_in) - sum(qty_out)) as qty_aval,id FROM ( SELECT stock_move.product_id,product_template.name, case when move_dest_id > 0 then product_qty else 0 end as qty_out, case when move_dest_id > 0 then 0 else product_qty end as qty_in,main_id,prakruti_all_product_line.id FROM product_template INNER JOIN product_product  ON product_product.product_tmpl_id = product_template.id INNER JOIN stock_move ON stock_move.product_id = product_product.id INNER JOIN prakruti_all_product_line ON prakruti_all_product_line.item_id = stock_move.product_id WHERE prakruti_all_product_line.main_id = %s and location_dest_id = 12  AND stock_move.state = 'done')as a GROUP BY product_id,id,name ORDER BY name) as b WHERE b.id = prakruti_all_product_line.id",((temp.id),))
            cr.execute("UPDATE  prakruti_stock_adjustments SET list_flag = 1 WHERE prakruti_stock_adjustments.id = cast(%s as integer)",((temp.id),))
        return {} 
    
    @api.one
    @api.multi
    def delete_all_products(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute("DELETE FROM prakruti_all_product_line WHERE main_id=%s",((temp.id),))
            cr.execute("UPDATE  prakruti_stock_adjustments SET list_flag = 0 WHERE prakruti_stock_adjustments.id = cast(%s as integer)",((temp.id),))
        return {}
    
    def _check_the_grid(self, cr, uid, ids, context=None, * args):
        for line_id in self.browse(cr, uid, ids, context=context):
            if len(line_id.adjustment_line) == 0:
                return False
        return True
    
    
    #_constraints = [
         #(_check_the_grid, 'Sorry !!!, Please enter some products to procced further, Thank You !', ['adjustment_line']),
    #]

class PrakrutiStockAdjustmentsLine(models.Model):
    _name= 'prakruti.stock_adjustments_line'
    _table= 'prakruti_stock_adjustments_line'
    _description= 'Prakruti Stock Adjustments Line'
    _order="id desc"
    
    adjustment_id = fields.Many2one('prakruti.stock_adjustments',string = 'Adjustment ID',readonly=1)
    product_id = fields.Many2one('product.product',string = 'Product Name',required=1)
    description = fields.Text(string = 'Description',readonly=1)
    uom_id = fields.Many2one('product.uom',string = 'UOM',readonly=1)
    stock_qty = fields.Float(string = 'Theoretical Quantity',readonly=1)
    real_qty = fields.Float(string = 'Real Quantity')
    
    _sql_constraints=[
        
        ('unique_product','unique(product_id,adjustment_id)', 'Item(s) must be Unique')
        ]
    
    def onchange_product(self, cr, uid, ids, product_id, context=None):
        qty_aval = 0.0
        line1 = 0
        line2 = ''
        line3 = 0
        cr.execute('SELECT product_uom.id AS uom_id, product_uom.name AS uom_name, product_template.name AS description,product_template.group_ref AS group_ref FROM product_uom INNER JOIN product_template ON product_uom.id=product_template.uom_id INNER JOIN product_product ON product_template.id=product_product.product_tmpl_id WHERE product_product.id = cast(%s as integer)', ((product_id),))
        for line in cr.dictfetchall():
            line1 = line['uom_id']
            line2 = line['description']
        cr.execute('''SELECT qty_aval FROM (SELECT uom, product_id, name, qty_in, qty_out, qty_in - qty_out as qty_aval FROM ( SELECT uom,product_id, name, sum(qty_out) as qty_out, sum(qty_in) as qty_in FROM ( SELECT product_uom.name as uom,stock_move.product_id, product_product.name_template as name, picking_id, case when move_dest_id > 0 then product_qty else 0 end as qty_out, case when move_dest_id > 0 then 0 else product_qty end as qty_in FROM product_uom INNER JOIN product_template ON product_uom.id = product_template.uom_id INNER JOIN product_product ON product_product.product_tmpl_id = product_template.id INNER JOIN stock_move ON stock_move.product_id = product_product.id WHERE location_dest_id = 12  AND stock_move.state = 'done' AND product_product.id = CAST(%s as integer)) as a group by product_id, name, uom ) as a ) AS b ORDER BY product_id''', ((product_id),))
        for line in cr.dictfetchall():
            line3 = line['qty_aval']
        print 'UOM ID',line1
        print 'PRODUCT NAME',line2
        print 'AVAILABLE STOCK',line3
        return {'value' :{'uom_id':line1,
                          'description':line2,
                          'stock_qty': line3 or 0.0
                          }}
        
    def create(self, cr, uid, vals, context=None):
        onchangeResult = self.onchange_product(cr, uid, [], vals['product_id'])
        if onchangeResult.get('value') or onchangeResult['value'].get('stock_qty','description','uom_id'):
            vals['stock_qty'] = onchangeResult['value']['stock_qty']
            vals['description'] = onchangeResult['value']['description']
            vals['uom_id'] = onchangeResult['value']['uom_id']
        return super(PrakrutiStockAdjustmentsLine, self).create(cr, uid, vals, context=context)
    
    def write(self, cr, uid, ids, vals, context=None):
        op=super(PrakrutiStockAdjustmentsLine, self).write(cr, uid, ids, vals, context=context)
        for record in self.browse(cr, uid, ids, context=context):
            store_type=record.product_id.id
        onchangeResult = self.onchange_product(cr, uid, ids, store_type)
        if onchangeResult.get('value') or onchangeResult['value'].get('stock_qty','description','uom_id'):
            vals['stock_qty'] = onchangeResult['value']['stock_qty']
            vals['description'] = onchangeResult['value']['description']
            vals['uom_id'] = onchangeResult['value']['uom_id']
        return super(PrakrutiStockAdjustmentsLine, self).write(cr, uid, ids, vals, context=context)

class PrakrutiAllProductLine(models.Model):
    _name= 'prakruti.all_product_line'
    _table= 'prakruti_all_product_line'
    _description= 'Prakruti All Product Line'
    
    main_id = fields.Many2one('prakruti.stock_adjustments',string = 'Main ID',readonly=1)
    
    item_id = fields.Many2one('product.product',string = 'Item Name')
    name_template = fields.Text(string = 'Name',readonly=1)
    item_code = fields.Text(string = 'Item Code',readonly=1)
    item_uom_id = fields.Many2one('product.uom',string = 'UOM',readonly=1)
    item_quantity = fields.Float(string = 'Stock',readonly=1)