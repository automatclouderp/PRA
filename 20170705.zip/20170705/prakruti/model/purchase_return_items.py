import time
import openerp
from datetime import date, datetime
from openerp import models, fields, api
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from openerp.tools.translate import _
from datetime import timedelta

##################################################################################################

class PrakrutiReturnItems(models.Model):
    _name = 'prakruti.return_items'
    _table= 'prakruti_return_items'
    _description = 'Managing Purchase Returned Items'
    _order = 'id desc'
    _rec_name = 'mrn_no'
    
    purchase_return_id = fields.Many2one('prakruti.purchase_invoice',string = 'Invoice No.')
    flag_display_list = fields.Integer(string="Product List Displayed",default=0)
    flag_delete_list = fields.Integer(string="Product List Deleted",default=0)
    mrn_no=fields.Char('MRN No')
    pr_no = fields.Char(string="Requisition No")
    coming_from = fields.Selection([('grn','GRN'),('purchase_invoice','Purchase Invoice')],default='purchase_invoice',string="Coming From")
    pr_date= fields.Date(string="Requisition Date")    
    po_no = fields.Char(string='Order No')
    order_date= fields.Date(string="Order Date")
    vendor_id = fields.Many2one('res.partner',string="Vendor Name")
    return_date= fields.Date(string="Return Date",default=fields.Date.today)
    state = fields.Selection([('mrn','MRN'),  
                              ('invoice','From Invoice'),
                              ('debit_note','Debit Note')
                              ],default= 'invoice', string= 'Status')    
    return_line = fields.One2many('prakruti.return_items_line','return_line_id',string='Purchase Order Line')
    return_id = fields.Many2one('prakruti.return_items_line')
    auto_no = fields.Integer('Auto')
    req_no_control_id = fields.Integer('Auto Generating id',default= 0)    
    material_reject_note_no= fields.Char(string='MRN No',compute='_get_auto_mrn_no', readonly=True)
    mrn_date=fields.Date('MRN Date',default= fields.Date.today)
    request_date = fields.Date(string = "Requisition Date")
    order_date = fields.Date(string='Order Date')    
    stores_incharge = fields.Many2one('res.users','Stores Incharge')
    dispatch_asst = fields.Many2one('res.users','Dispatch Assistant')
    doc_no=fields.Char('Doc. No',default='PPPL-STR-F-002')
    rev_no=fields.Char('Rev. No',default='02')
    doc_date=fields.Date('Document Date',default= fields.Date.today)
    company_address = fields.Many2one('res.company',string='Company Address')
    tin_vat = fields.Char(related='company_address.tin',string= 'Company TIN No')
    reason_for_rejection = fields.Text('Reason for Rejection')
    time_of_removal = fields.Float('Time of Removal',digits=(6,3))
    transporter_name=fields.Text('Name of Transporter')
    party_vat_no = fields.Char(related='vendor_id.vat_no', string="Party VAT No")
    party_cst_no = fields.Char(related='vendor_id.cst_no', string="Party CST No")
    gc_no =fields.Char('GC No')
    gc_date=fields.Date('GC Date')
    grn_no = fields.Char('GRN No')
    invoice_no = fields.Char('Invoice No')
    grn_date=fields.Date('GRN Date')
    invoice_date=fields.Date('Invoice Date')
    purchase_manager = fields.Many2one('res.users',string="Purchase Manager", readonly= "True" )
    dispatch_through = fields.Char(string='Dispatch Through', readonly= "True" )
    total= fields.Float(string='Total',compute= '_compute_total',store=True ,digits=(6,3)) 
    product_id = fields.Many2one('product.product', related='return_line.product_id', string='Product Name')
    
    def onchange_purchase_return_id(self, cr, uid, ids, purchase_return_id, context=None):
        process_type = self.pool.get('prakruti.purchase_invoice').browse(cr, uid, purchase_return_id, context=context)
        result = {
            'vendor_id': process_type.vendor_id.id,
            'po_no':process_type.po_no,
            'order_date':process_type.order_date
                }
        return {'value': result}    
    
    @api.onchange('coming_from')
    def onchange_return_type(self):
        if self.coming_from == 'purchase_invoice':
            self.grn_no = False
            self.grn_date = False
            self.invoice_date = False
            self.invoice_no = False
            self.company_address = False
            self.vendor_id = False
        else:
            self.grn_no = False
            self.grn_date = False
            self.invoice_date = False
            self.invoice_no = False
            self.order_date = False
            self.company_address = False
    
    @api.one
    @api.multi
    def action_list_products(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute('''SELECT product_id,description,uom_id,(actual_quantity - quantity) as return_qty,unit_price FROM prakruti_purchase_invoice INNER JOIN prakruti_purchase_invoice_line ON prakruti_purchase_invoice.id=prakruti_purchase_invoice_line.invoice_line_id WHERE prakruti_purchase_invoice_line.invoice_line_id =CAST(%s as integer) AND quantity < actual_quantity''',((temp.purchase_return_id.id),))
            for item in cr.dictfetchall():
                product_id=item['product_id']
                description=item['description']
                uom_id=item['uom_id']
                return_qty=item['return_qty']
                unit_price =item['unit_price']
                grid_down = self.pool.get('prakruti.return_items_line').create(cr,uid, {
                    'product_id':product_id,
                    'description':description,
                    'uom_id':uom_id,
                    'return_qty':return_qty,
                    'unit_price':unit_price,
                    'return_line_id':temp.id,
                        })
                cr.execute("UPDATE prakruti_return_items SET flag_display_list = 1 WHERE prakruti_return_items.id = cast(%s as integer)",((temp.id),))
                cr.execute("UPDATE prakruti_return_items SET flag_delete_list = 0 WHERE prakruti_return_items.id = cast(%s as integer)",((temp.id),))
            return {}
   
    @api.one
    @api.multi
    def action_delete_products(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute("DELETE FROM prakruti_return_items_line WHERE prakruti_return_items_line.return_line_id = (%s)", ((temp.id),))
            cr.execute("UPDATE prakruti_return_items SET flag_delete_list = 1 WHERE prakruti_return_items.id = cast(%s as integer)",((temp.id),))
            cr.execute("UPDATE prakruti_return_items SET flag_display_list = 0 WHERE prakruti_return_items.id = cast(%s as integer)",((temp.id),))
        return {} 
    
    @api.model
    def _default_company(self):
        return self.env['res.company']._company_default_get('res.partner') 
    
    _defaults = {
        'mrn_no':'New',
        'company_address': _default_company
        }
    
    @api.one
    @api.multi
    def _get_auto_mrn_no(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        display_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        print 'abcdefgh---------1'
        for temp in self :
            print 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-------2'
            cr.execute('''select cast(extract (month from mrn_date) as integer) as month ,cast(extract (year from mrn_date) as integer) as year ,id from prakruti_return_items where id=%s''',((temp.id),))
            
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
            if month_value<=3:
                year_value=year_value-1
            else:
                
                year_value=year_value
            next_year=year_value+1
            display_year=str(next_year)[-2:]
            display_present_year=str(year_value)[-2:]
            
            cr.execute('''select autogenerate_mrn_no(%s)''', ((temp.id),)  ) 
            result = cr.dictfetchall()
            parent_invoice_id = 0
            print 'temp.idtemp.idtemp.idtemp.idtemp.idtemp.id----------1',temp.id
            for value in result: parent_invoice_id = value['autogenerate_mrn_no'];
            auto_gen = int(parent_invoice_id)
            if len(str(auto_gen)) < 2:
                auto_gen = '000'+ str(auto_gen)
            elif len(str(auto_gen)) < 3:
                auto_gen = '00' + str(auto_gen)
            elif len(str(auto_gen)) == 3:
                auto_gen = '0'+str(auto_gen)
            else:
                auto_gen = str(auto_gen)
            for record in self :
                #if temp.purchase_type.group_code:
                    #x[record.id] ='MRN\\'+ temp.purchase_type.group_code+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(display_year)
                #else:                        
                x[record.id] ='MRN\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(display_year)
                print 'x[record.id]x[record.id]x[record.id]x[record.id]---------122',x[record.id]
            cr.execute('''update prakruti_return_items set mrn_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
        return x
    
    @api.multi
    def unlink(self):
        for order in self:
            if order.state in ['debit_note']:
                raise UserError(_('Can\'t Delete '))
        return super(PrakrutiReturnItems, self).unlink()
    
    @api.one
    @api.multi 
    def to_debit_note(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {} 
            if len(temp.return_line) > 0:
                dn_entry = self.pool.get('prakruti.debit.note').create(cr,uid, {
                    'po_no':temp.po_no,
                    'purchase_return_id':temp.purchase_return_id.id,
                    'vendor_id':temp.vendor_id.id,
                    'order_date':temp.order_date,
                    'purchase_manager':temp.purchase_manager.id,
                    'stores_incharge':temp.stores_incharge.id,
                    })
                for line in temp.return_line:
                    grid_values = self.pool.get('prakruti.debit.note.line').create(cr,uid, {
                        'product_id': line.product_id.id,
                        'return_qty': line.return_qty,
                        'uom_id': line.uom_id.id, 
                        'unit_price': line.unit_price,
                        'line_id': dn_entry
                        })
            else:
                raise UserError(_('Please Enter Some Products'))
            cr.execute("UPDATE prakruti_return_items SET state = 'debit_note' WHERE id = %s",((temp.id),))
        return {}
        
    @api.depends('return_line.return_qty','return_line.unit_price')
    def _compute_total(self):
        for order in self:
            total_amount = total = 0.0
            for line in order.return_line:
                total_amount += line.return_qty * line.unit_price
                total = total_amount
                print '-------------------TOTAL----------------------',total_amount
                order.update({
                    'total': total_amount
                    })
    
class PrakrutiReturnItemsLine(models.Model):
    _name="prakruti.return_items_line"
    _table= 'prakruti_return_items_line'
    
    return_line_id = fields.Many2one('prakruti.return_items', ondelete='cascade')
    
    product_id= fields.Many2one('product.product', string="Product Name", readonly= True)
    description = fields.Char(string="Description", readonly= True)
    uom_id = fields.Many2one('product.uom', string="UOM", readonly= True)
    remarks= fields.Char(string="Remarks")
    status= fields.Selection([('reject','Reject'),('accept','Accept'),('par_accept','Partially Accepted')],string="Status", readonly= True)
    return_qty= fields.Float(string="Return Qty",readonly= True ,digits=(6,3))
    scheduled_date=fields.Date(string="Scheduled Date",default= fields.Date.today)
    no_of_packing =  fields.Float(string="No of Packing" ,digits=(6,3))
    packing_size = fields.Float(string="Packing Size" ,digits=(6,3))
    unit_price = fields.Float(string='Unit price' ,digits=(6,3))
    total = fields.Float('Total' ,digits=(6,3))
    
    
      
    def _check_return_qty(self, cr, uid, ids):
        lines = self.browse(cr, uid, ids)
        for line in lines:
            if line.return_qty < 0:
                return False
        return True
     
    _constraints = [
         (_check_return_qty, 'Return Quantity cannot be less than Zero or equal to Zero !', ['return_qty'])
    ]