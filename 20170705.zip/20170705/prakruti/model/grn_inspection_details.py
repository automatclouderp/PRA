# -*- coding: utf-8 -*-
from openerp import models, fields, api,_
from openerp.tools import amount_to_text
from openerp.tools.amount_to_text import amount_to_text_in 
from openerp.tools.amount_to_text import amount_to_text_in_without_word_rupees 
import openerp
from datetime import date, datetime
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from datetime import timedelta
from openerp.osv import osv,fields
from openerp import models, fields, api, _
from openerp.tools.translate import _
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
from lxml import etree
import cgi
import logging
import lxml.html
import lxml.html.clean as clean
import openerp.pooler as pooler
import random
import re
import socket
import threading
import time
from openerp.tools import image_resize_image_big

class PrakrutiGRNInspectionDetails(models.Model):
    _name =  'prakruti.grn_inspection_details'
    _table = 'prakruti_grn_inspection_details'
    _description = ' GRN fields much similar Purchase order'
    _rec_name = 'grn_no'    
    _order="id desc"
    
    grn_no= fields.Char(string='GRN No')
    invoice_no= fields.Char(string='Invoice No')
    po_no = fields.Char(string='Order No', readonly=True)
    pr_no = fields.Char(string='Requisition No', readonly=True)
    qa_no = fields.Char(string='Analysis No', readonly=True)
    qo_no = fields.Char(string='Quotation No', readonly=True)
    req_no =fields.Char(string='Request No', readonly=True)
    vendor_id = fields.Many2one('res.partner',string='Vendor/Supplier', readonly= "True")
    logo = fields.Binary(related='company_address.logo')
    vendor_reference = fields.Char(string='Vendor/Supplier Reference', readonly= "True" )
    other_reference = fields.Char(string='Other Reference')
    request_date = fields.Date(string = "Requisition Date")
    order_date = fields.Date(string='Order Date')
    destination = fields.Char(string='Destination')
    company_address = fields.Many2one('res.company',string='Company Address', readonly= "True" )
    delivery_address = fields.Many2one('res.company',string='Dispatch To', readonly= "True" )
    payment = fields.Char(string='Mode/Terms of Payments')
    terms_of_delivery = fields.Text(string='Terms of Delivery')
    remarks=fields.Text('Received Remarks', readonly= "True" )
    order_line = fields.One2many('prakruti.grn_inspection_details_line','inspection_line_id')
    total_discount = fields.Float(string="Total Discount" , compute='_compute_discount_amount', store=True ,digits=(6,3))
    total_tax = fields.Float(string="Total Tax" , compute='_compute_tax_total_amount', store=True ,digits=(6,3))
    grand_total= fields.Float(string='Grand Total',compute= '_compute_grand_total',store=True ,digits=(6,3))
    amount_untaxed= fields.Float(string='Untaxed Amount',compute= '_compute_untaxed_total',store=True ,digits=(6,3))
    additional_charges = fields.Float(string='Additional Charges' ,digits=(6,3))
    frieght_charges_applied = fields.Selection([('yes','Yes'),('no','No')], string="Freight Charge Applied", default='no')
    frieght_charges = fields.Float(string="Frieght Charges" ,digits=(6,3))
    dispatch_through = fields.Char(string='Dispatch Through', readonly= "True" )
    packing_charges = fields.Float(string='Packing & Forwarding' ,digits=(6,3))
    prepared_by = fields.Many2one('res.users','Prepared By',readonly=True)
    maintanence_manager = fields.Many2one('res.users',string="Maintanence Manager")    
    purchase_manager = fields.Many2one('res.users',string="Purchase Manager", readonly= "True" )
    purchase_type = fields.Many2one('product.group',string= 'Purchase Type')
    state = fields.Selection([('grn','GRN'),
                              ('qc_check','QC Check'),                              
                              ('accepted','Accepted'),
                              ('rejected','Rejected'),
                              ('accepted_under_deviation','Accepted Under Deviation'),
                              ('qc_check_done','QC Check Done'),
                              ('invoice','Invoice'),
                              ('done','Done')],default= 'grn', string= 'Status')
    pr_common_id = fields.Integer('PR SCREEN COMMON ID')
    grand_total_in_words= fields.Text(compute= '_get_total_in_words' ,method=True, store=False,string='Total in words') # The above total in words.
    currency_id = fields.Many2one('res.currency', 'Currency')
    prakruti_stock_id = fields.Integer('SCREEN COMMON ID')
    excise_duty = fields.Float(string= 'Excise Duty(%)' ,digits=(6,3))
    total_excise_duty = fields.Float(string= 'Total Excise Duty' ,digits=(6,3))
    stores_incharge = fields.Many2one('res.users','Stores Incharge')
    grn_remarks=fields.Text('Remarks')
    gc_no=fields.Char('GC No')
    gc_date=fields.Date('GC Date')
    dc_no=fields.Char('DC No')
    dc_date=fields.Date('DC Date')
    transporter_name=fields.Text('Name of Transporter')
    transporter_payment_details=fields.Text('Transporter Payment Details')
    doc_no=fields.Char('Doc. No',default='PPPL-STR-F-001',readonly=1)
    rev_no=fields.Char('Rev. No',default='02',readonly=1)
    doc_date=fields.Date('Document Date',default= fields.Date.today,readonly=1)
    #Fields For Auto Generation Serial Number for GRN and Invoice Number
    # GRN
    auto_no = fields.Integer('Auto')
    req_no_control_id = fields.Integer('Auto Generating id',default= 0)    
    good_received_note_no= fields.Char(string='GRN No',compute= '_get_auto_grn_no', readonly=True)
    grn_date=fields.Date('GRN Date',default= fields.Date.today)
    # INVOICE
    auto_no1 = fields.Integer('Auto')
    req_no_control_id1 = fields.Integer('Auto Generating id',default= 0)    
    good_invoice_no= fields.Char(string='INVOICE No',compute= '_get_auto_grn_inv_no', readonly=True)
    invoice_date=fields.Date('Invoice Date',default= fields.Date.today)
    flag_rejected_count = fields.Integer('Flag', default=1)
    st_loc = fields.Many2one('stock.location', string='Stock Location')
    st_loc_remarks = fields.Text(string='Stock Location Remarks')
    flag_count_accept = fields.Integer('Accepted Line is There',default= 0)
    flag_count_reject = fields.Integer('Rejected Line is There',default= 0)
    flag_count_par_reject = fields.Integer('Partial Rejected Line is There',default= 0)
    #Payment Terms
    any_adv_payment =fields.Selection([
                    ('no', 'No'),
                    ('yes','Yes')
                    ], string= 'Any Advance Payment')
    advance_payment_type =fields.Selection([
                    ('cash', 'CASH'),
                    ('cheque','CHEQUE'),
                    ('demand_draft','DEMAND DRAFT')
                    ], string= 'Done By')
    cash_amount = fields.Float(string="Amount" ,digits=(6,3))
    cash_remarks = fields.Text(string="Remarks")    
    cheque_amount = fields.Float(string="Amount" ,digits=(6,3))
    cheque_no = fields.Integer(string="Cheque No.")
    cheque_remarks = fields.Text(string="Remarks")    
    draft_amount = fields.Float(string="Amount" ,digits=(6,3))
    draft_no = fields.Integer(string="Draft No.")
    draft_remarks = fields.Text(string="Remarks") 
    product_id = fields.Many2one('product.product', related='order_line.product_id', string='Product Name')
    
    @api.one
    @api.multi
    def _get_auto_grn_inv_no(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        display_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        print 'abcdefgh---------1'
        for temp in self :
            print 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-------2'
            cr.execute('''select cast(extract (month from invoice_date) as integer) as month ,cast(extract (year from invoice_date) as integer) as year ,id from prakruti_grn_inspection_details where id=%s''',((temp.id),))
            
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
            if month_value<=3:
                year_value=year_value-1
            else:
                
                year_value=year_value
            next_year=year_value+1
            display_year=str(next_year)[-2:]
            display_present_year=str(year_value)[-2:]
            
            cr.execute('''select autogenerate_grn_inv_no(%s)''', ((temp.id),)  ) 
            result = cr.dictfetchall()
            parent_invoice_id = 0
            print 'temp.idtemp.idtemp.idtemp.idtemp.idtemp.id----------1',temp.id
            for value in result: parent_invoice_id = value['autogenerate_grn_inv_no'];
            auto_gen = int(parent_invoice_id)
            if len(str(auto_gen)) < 2:
                auto_gen = '000'+ str(auto_gen)
            elif len(str(auto_gen)) < 3:
                auto_gen = '00' + str(auto_gen)
            elif len(str(auto_gen)) == 3:
                auto_gen = '0'+str(auto_gen)
            else:
                auto_gen = str(auto_gen)
            for record in self :
                if temp.purchase_type.group_code:
                    x[record.id] ='GRN-INV-\\'+ temp.purchase_type.group_code+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(display_year)
                else:                        
                    x[record.id] ='GRN-INV-\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(display_year)
                print 'x[record.id]x[record.id]x[record.id]x[record.id]---------122',x[record.id]
            cr.execute('''update prakruti_grn_inspection_details set invoice_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
        return x
    
    @api.one
    @api.multi
    def _get_auto_grn_no(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        display_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        print 'abcdefgh---------1'
        for temp in self :
            print 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-------2'
            cr.execute('''select cast(extract (month from grn_date) as integer) as month ,cast(extract (year from grn_date) as integer) as year ,id from prakruti_grn_inspection_details where id=%s''',((temp.id),))
            
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
            if month_value<=3:
                year_value=year_value-1
            else:
                
                year_value=year_value
            next_year=year_value+1
            display_year=str(next_year)[-2:]
            display_present_year=str(year_value)[-2:]
            
            cr.execute('''select autogenerate_grn_no(%s)''', ((temp.id),)  ) 
            result = cr.dictfetchall()
            parent_invoice_id = 0
            print 'temp.idtemp.idtemp.idtemp.idtemp.idtemp.id----------1',temp.id
            for value in result: parent_invoice_id = value['autogenerate_grn_no'];
            auto_gen = int(parent_invoice_id)
            if len(str(auto_gen)) < 2:
                auto_gen = '000'+ str(auto_gen)
            elif len(str(auto_gen)) < 3:
                auto_gen = '00' + str(auto_gen)
            elif len(str(auto_gen)) == 3:
                auto_gen = '0'+str(auto_gen)
            else:
                auto_gen = str(auto_gen)
            for record in self :
                x[record.id] = 'GRN-'+str(auto_gen) +'/'+str(display_present_year)+'-'+str(display_year)
                print 'x[record.id]x[record.id]x[record.id]x[record.id]---------122',x[record.id]
            cr.execute('''update prakruti_grn_inspection_details set grn_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
        return x
    
    @api.multi
    def unlink(self):
        raise UserError(_('Can\'t Delete record'))
        return super(PrakrutiGRNInspectionDetails, self).unlink()
    
    @api.onchange('any_adv_payment')
    def onchange_any_adv_payment(self):
        if self.any_adv_payment == 'no':
            self.advance_payment_type = None
    
    @api.onchange('advance_payment_type')
    def onchange_advance_payment_type(self):
        if self.advance_payment_type == 'cash':
            self.cheque_amount = 0
            self.cheque_no = 0
            self.cheque_remarks = ''
            self.draft_amount = 0
            self.draft_no = 0
            self.draft_remarks = ''
        if self.advance_payment_type == 'cheque':
            self.cash_amount = 0
            self.cash_remarks = ''
            self.draft_amount = 0
            self.draft_no = 0
            self.draft_remarks = ''
        if self.advance_payment_type == 'demand_draft':
            self.cash_amount = 0
            self.cash_remarks = ''
            self.cheque_amount = 0
            self.cheque_no = 0
            self.cheque_remarks = ''
        else:
            self.cash_amount = 0
            self.cash_remarks = ''
            self.cheque_amount = 0
            self.cheque_no = 0
            self.cheque_remarks = ''
            self.draft_amount = 0
            self.draft_no = 0
            self.draft_remarks = ''
    
    
    @api.model
    def _default_company(self):
        return self.env['res.company']._company_default_get('res.partner') 
    
    _defaults = {
        'grn_no':'New',
        'invoice_no':'New',
        'prepared_by': lambda s, cr, uid, c:uid, #Currently logged in user will display automatically,
        'company_address': _default_company,
        'delivery_address': _default_company,
        'stores_incharge': lambda s, cr, uid, c:uid, #Current login user will display automatically
        }
    
    @api.one
    @api.multi
    def grn_to_stock(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}  
            if temp.st_loc_remarks and temp.st_loc:
                for item in temp.order_line:
                    if item.status in ['reject']:
                        temp.flag_count_reject = 1
                    elif item.status in ['accept']:
                        temp.flag_count_accept = 1
                    elif item.status in ['par_accept']:
                        temp.flag_count_par_reject = 1
                if temp.flag_count_reject or temp.flag_count_par_reject:
                    return_po= self.pool.get('prakruti.return_items').create(cr,uid, {
                        'po_no':temp.po_no,
                        'order_date':temp.order_date,
                        'pr_no':temp.pr_no,
                        'grn_no':temp.grn_no,
                        'invoice_no':temp.invoice_no,
                        'grn_date':temp.grn_date,
                        'invoice_date':temp.invoice_date,
                        'pr_date':temp.request_date,
                        'vendor_id':temp.vendor_id.id,
                        'stores_incharge':temp.stores_incharge.id,
                        'purchase_manager':temp.purchase_manager.id,
                        'company_address':temp.company_address.id,
                        'dispatch_through':temp.dispatch_through,
                        'coming_from':'grn',
                        'state':'mrn'
                            })
                ####################################################################################################################################################
                #Update Price in Product Template
                cr.execute("UPDATE product_template AS b SET list_purchase_price = a.unit_price FROM(SELECT prakruti_grn_inspection_details_line.unit_price,prakruti_grn_inspection_details_line.product_id,prakruti_grn_inspection_details_line.inspection_line_id,product_product.product_tmpl_id,product_template.id FROM prakruti_grn_inspection_details_line INNER JOIN product_product ON prakruti_grn_inspection_details_line.product_id = product_product.id INNER JOIN product_template ON product_template.id = product_product.product_tmpl_id WHERE inspection_line_id = %s) AS a WHERE a.product_tmpl_id = b.id",((temp.id),))
                #Count No of Accepted Line
                cr.execute("SELECT count(id) as accept_line FROM prakruti_grn_inspection_details_line WHERE (status = 'accept' or status = 'par_accept') AND inspection_line_id = %s",((temp.id),))
                for act_line in cr.dictfetchall():
                    accept_line=int(act_line['accept_line'])
                if accept_line > 0 or temp.flag_count_accept or temp.flag_count_par_reject:
                    cr.execute("SELECT UpdatePurchaseStock(%s)", ((temp.id),))
                ####################################################################################################################################################
                cr.execute("SELECT count(id) as reject_line FROM prakruti_grn_inspection_details_line WHERE (status = 'reject' or status = 'par_accept') AND inspection_line_id = %s",((temp.id),))
                for line in cr.dictfetchall():
                    reject_line=int(line['reject_line'])
                if reject_line > 0 or temp.flag_count_reject or temp.flag_count_par_reject:
                    cr.execute("SELECT product_id,uom_id,description,rejected_qty,remarks,status,unit_price FROM prakruti_grn_inspection_details_line WHERE (status = 'reject' or status = 'par_accept') AND inspection_line_id = %s",((temp.id),))
                    for item in cr.dictfetchall():
                        grid_item= self.pool.get('prakruti.return_items_line').create(cr,uid, {
                            'product_id': item['product_id'],
                            'uom_id': item['uom_id'],
                            'description':item['description'],
                            'return_qty':item['rejected_qty'],
                            'remarks':item['remarks'],
                            'status': item['status'],
                            'unit_price': item['unit_price'],
                            'return_line_id': return_po
                            })
                        cr.execute("UPDATE prakruti_return_items SET state = 'rejected' WHERE prakruti_return_items.id = cast(%s as integer)", ((temp.id),))
                        cr.execute("UPDATE prakruti_grn_inspection_details SET state = 'done' WHERE prakruti_grn_inspection_details.id = cast(%s as integer)", ((temp.id),))                
                cr.execute("UPDATE prakruti_grn_inspection_details SET state = 'done' WHERE prakruti_grn_inspection_details.id = cast(%s as integer)", ((temp.id),))
                cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'done' WHERE prakruti_purchase_requisition.requisition_no = %s ", ((temp.pr_no),))
                template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Purchase GRN')],context=context)[0]
                email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True) 
            else:
                raise UserError(_('Oops...! Please Enter Stock Location and Location Remarks...'))
        return {}
        
    
    @api.one
    @api.multi 
    def grn_to_quality(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {}
            cr.execute(''' SELECT count(id) as entered_line FROM prakruti_grn_inspection_details_line WHERE COALESCE(packing_style,0) > 0 AND COALESCE(received_per_qty,0) > 0 AND inspection_line_id = %s''',((temp.id),))
            for no_of_line in cr.dictfetchall():
                entered_line = int(no_of_line['entered_line'])
            if entered_line == len(temp.order_line):
                control_entry = self.pool.get('prakruti.quality_control').create(cr,uid, {
                    'po_no':temp.po_no,
                    'qa_no':temp.qa_no,
                    'pr_no':temp.pr_no,
                    'qo_no':temp.qo_no,
                    'req_no':temp.req_no,
                    'grn_no':temp.grn_no,
                    'invoice_no':temp.invoice_no,
                    'grn_date':temp.grn_date,
                    'invoice_date':temp.invoice_date,
                    'vendor_reference':temp.vendor_reference,
                    'payment':temp.payment,
                    'destination':temp.destination,
                    'other_reference':temp.other_reference,
                    'maintanence_manager':temp.maintanence_manager.id,
                    'purchase_manager':temp.purchase_manager.id,
                    'stores_incharge':temp.stores_incharge.id,
                    'terms_of_delivery':temp.terms_of_delivery,
                    'vendor_id': temp.vendor_id.id,
                    'state':'qc',
                    'remarks':temp.remarks,
                    'request_date':temp.request_date,
                    'order_date':temp.order_date,                        
                    'amount_untaxed':temp.amount_untaxed,
                    'additional_charges':temp.additional_charges,
                    'grand_total':temp.grand_total,
                    'frieght_charges_applied':temp.frieght_charges_applied,
                    'frieght_charges':temp.frieght_charges,
                    'packing_charges':temp.packing_charges,
                    'total_discount':temp.total_discount,
                    'total_tax':temp.total_tax,
                    'dispatch_through':temp.dispatch_through,
                    'excise_duty':temp.excise_duty,
                    'total_excise_duty':temp.total_excise_duty,
                    })
                for item in temp.order_line:
                    grid_values = self.pool.get('prakruti.quality_control_line').create(cr,uid, {
                        'product_id': item.product_id.id,
                        'description': item.description,
                        'actual_quantity': item.quantity,
                        'quantity': item.quantity,
                        'uom_id': item.uom_id.id,
                        'scheduled_date': item.scheduled_date,                   
                        'unit_price': item.unit_price,
                        'discount': item.discount,
                        'tax_price': item.tax_price,
                        'tax_id': item.tax_id.id,
                        'subtotal': item.subtotal,
                        'remarks':item.remarks,
                        'batch_no':item.batch_no,
                        'control_line_id': control_entry,
                        'grn_grid_common_id':item.id
                        })
                    cr.execute('''UPDATE prakruti_grn_inspection_details SET state = 'qc_check' WHERE prakruti_grn_inspection_details.id = cast(%s as integer)''', ((temp.id),))
                    cr.execute("UPDATE  prakruti_purchase_requisition SET state = 'qc_check' WHERE prakruti_purchase_requisition.requisition_no = %s ", ((temp.pr_no),))  
                    template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Purchase GRN QC')],context=context)[0]
                    email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True)
                     
            else:
                raise UserError(_('Please Enter Packing Style & Received Per Qty'))
        return {}
    
    

class PrakrutiGRNInspectionDetailsLine(models.Model):
    _name = 'prakruti.grn_inspection_details_line'
    _table = 'prakruti_grn_inspection_details_line'
    
    inspection_line_id = fields.Many2one('prakruti.grn_inspection_details', ondelete='cascade')
    product_id = fields.Many2one('product.product',string='Product Name',required=True, readonly=1)   
    description = fields.Text(string='Description', readonly=1)
    scheduled_date =fields.Datetime(string='Due On')
    quantity = fields.Float(string='Received Quantity',store=True ,digits=(6,3))
    actual_quantity = fields.Float(string='Quantity', readonly=1 ,digits=(6,3))
    unit_price = fields.Float(string='Unit price' ,digits=(6,3))
    mfg_date = fields.Date(string='Mfg. Date')
    exp_date = fields.Date(string="Expiry Date")
    uom_id = fields.Many2one('product.uom',string='UOM',required=True, readonly=1)
    discount = fields.Float(string='Discount(%)' ,digits=(6,3))
    tax_type = fields.Selection([('cst','CST'),('tin','TIN'),('tax','Tax'),('vat','VAT')], string="Tax", default= 'tax')
    tax_id = fields.Many2one('account.other.tax', string='Taxes', domain=['|', ('active', '=', False), ('active', '=', True)])
    tax_price = fields.Float(related='tax_id.per_amount',string='Taxes', store=True,readonly=True ,digits=(6,3)) 
    subtotal= fields.Float(string='Sub Total',compute= '_compute_price_subtotal',store=True ,digits=(6,3))
    total= fields.Float(string='Total',compute= '_compute_price_total',store=True ,digits=(6,3))
    currency_id = fields.Many2one(related='inspection_line_id.currency_id', store=True, string='Currency', readonly=True)
    prakruti_stock_id = fields.Integer('SCREEN COMMON ID')
    remarks = fields.Text('Remarks')
    packing_style = fields.Integer(string= 'Packing Style')
    received_per_qty = fields.Integer(string= 'Received Per Qty.')
    accepted_qty = fields.Float('Accepted Qty.' ,digits=(6,3))
    rejected_qty = fields.Float('Rejected Qty.', readonly=True ,digits=(6,3))
    status = fields.Selection([('accept','Accept'),
                               ('reject','Reject'),
                               ('accept_under_deviation','Accepted Under Deviation'),
                               ('par_accept','Partially Accepted')],default='accept',string= 'Status',readonly= True)
    batch_no = fields.Char('Batch No.')
    extra_packing= fields.Integer(string= "(+)Extra Packing",default=0)

    _sql_constraints = [
        ('unique_batch_no','unique(batch_no)','Batch No. must be Unique !')
        ]
    
    _defaults = {
        'unit_price': 1
        }
    
    @api.onchange('packing_style','received_per_qty','extra_packing')
    def _compute_total_quantity(self):
        for order in self:
            quantity = 0.0
            order.update({
                    'quantity': ((order.packing_style * order.received_per_qty) + order.extra_packing),
                    'accepted_qty': ((order.packing_style * order.received_per_qty) + order.extra_packing)
                    })
    
    
    
    @api.depends('packing_style', 'received_per_qty')
    def _compute_received_qty(self):
        print 'automat-----------------1'
        for order in self:
            print 'automat-----------------2'
            quantity = 0.0            
            order.update({                
                'quantity': order.packing_style * order.received_per_qty 
            })
    
    @api.depends('quantity', 'unit_price')
    def _compute_price_total(self):
        print 'automat-----------------1'
        for order in self:
            print 'automat-----------------2'
            total = 0.0            
            order.update({                
                'total': order.quantity * order.unit_price 
            })
            
    @api.depends('quantity', 'unit_price')
    def _compute_price_subtotal(self):
        print 'automat-----------------1'
        for order in self:
            print 'automat-----------------2'
            subtotal = 0.0            
            order.update({                
                'subtotal': order.quantity * order.unit_price 
            })