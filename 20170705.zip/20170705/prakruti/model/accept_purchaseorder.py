import time
import openerp
from datetime import date, datetime
from openerp import models, fields, api
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from openerp.tools.translate import _
from datetime import timedelta

###########################################################################################################

class PrakrutiAcceptPO(models.Model):
    _name = 'prakruti.accept_po'
    _table = 'prakruti_accept_po'
    _description = 'Details of Accepted Purchase Order'
    _order="id desc"
    _rec_name='invoice_no'
    
    invoice_no = fields.Char(string="Invoice No",required=True,default= 'INVOICE')
    mrn_no = fields.Char(string="MRN/GRN No",required=True,default= 'GRN')
    invoice_date= fields.Date(string="Invoice Date", default= fields.Date.today,readonly=True)
    vendor_id = fields.Many2one('res.partner',string="Vendor Name")
    po_no= fields.Char(string="Order No")
    pr_no = fields.Char(string="Requisition No")
    status= fields.Char(string="Status",readonly=True)
    state = fields.Selection([
                ('confirm','Order Confirm'),
                ('accept','Accept PO')],default= 'confirm', string= 'States')
    accept_line= fields.One2many('prakruti.accept_po_line','accept_line_id',string='Purchase Order Accept Line')
    total_discount = fields.Float(string="Total Discount", compute='_compute_discount_amount' , store=True ,digits=(6,3))
    total_tax = fields.Float(string="Total Tax", compute='_compute_tax_total_amount' ,  store=True ,digits=(6,3))
    grand_total= fields.Float(string='Grand Total',compute= '_compute_grand_total',store=True ,digits=(6,3))
    amount_untaxed= fields.Float(string='Untaxed Amount',compute= '_compute_untaxed_total',store=True ,digits=(6,3))
    additional_charges = fields.Float(string='Additional Charges' ,digits=(6,3))
    frieght_charges_applied = fields.Selection([('yes','Yes'),('no','No')], string="Freight Charge Applied", default='no')
    frieght_charges = fields.Float(string="Frieght Charges" ,digits=(6,3))
    dispatch_through = fields.Char(string='Dispatch Through')
    excise_duty = fields.Float(string= 'Excise Duty(%)' ,digits=(6,3))
    total_excise_duty = fields.Float(string= 'Total Excise Duty',compute= '_compute_excise_duty' ,digits=(6,3)) 
    product_id = fields.Many2one('product.product', related='accept_line.product_id', string='Product Name')
    
    @api.one
    @api.multi
    def _get_invoice_no(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        display_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        print 'abcdefgh---------1'
        for temp in self :
            print 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-------2'
            cr.execute('''select cast(extract (month from invoice_date) as integer) as month ,cast(extract (year from invoice_date) as integer) as year ,id from prakruti_accept_po where id=%s''',((temp.id),))
            
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
            if month_value<=3:
                year_value=year_value-1
            else:
                
                year_value=year_value
            next_year=year_value+1
            display_year=str(next_year)[-2:]
            display_present_year=str(year_value)[-2:]
            
            cr.execute('''select autogenerate_accept_purchase_order(%s)''', ((temp.id),)  ) 
            result = cr.dictfetchall()
            parent_invoice_id = 0
            print 'temp.idtemp.idtemp.idtemp.idtemp.idtemp.id----------1',temp.id
            for value in result: parent_invoice_id = value['autogenerate_accept_purchase_order'];
            auto_gen = int(parent_invoice_id)
            if len(str(auto_gen)) < 2:
                auto_gen = '000'+ str(auto_gen)
            elif len(str(auto_gen)) < 3:
                auto_gen = '00' + str(auto_gen)
            elif len(str(auto_gen)) == 3:
                auto_gen = '0'+str(auto_gen)
            else:
                auto_gen = str(auto_gen)
            for record in self :
                x[record.id] = 'INV-'+str(auto_gen) +'/'+str(display_present_year)+'-'+str(display_year)
                cr.execute('''update prakruti_accept_po set invoice_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
        return x
    
    
    @api.one
    @api.multi
    def _get_grn_no(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        display_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        print 'abcdefgh---------1'
        for temp in self :
            print 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-------2'
            cr.execute('''select cast(extract (month from invoice_date) as integer) as month ,cast(extract (year from invoice_date) as integer) as year ,id from prakruti_accept_po where id=%s''',((temp.id),))
            
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
            if month_value<=3:
                year_value=year_value-1
            else:
                
                year_value=year_value
            next_year=year_value+1
            display_year=str(next_year)[-2:]
            display_present_year=str(year_value)[-2:]
            
            cr.execute('''select autogenerate_accept_purchase_order_grn(%s)''', ((temp.id),)  ) 
            result = cr.dictfetchall()
            parent_invoice_id = 0
            print 'temp.idtemp.idtemp.idtemp.idtemp.idtemp.id----------1',temp.id
            for value in result: parent_invoice_id = value['autogenerate_accept_purchase_order_grn'];
            auto_gen = int(parent_invoice_id)
            if len(str(auto_gen)) < 2:
                auto_gen = '000'+ str(auto_gen)
            elif len(str(auto_gen)) < 3:
                auto_gen = '00' + str(auto_gen)
            elif len(str(auto_gen)) == 3:
                auto_gen = '0'+str(auto_gen)
            else:
                auto_gen = str(auto_gen)
            for record in self :
                x[record.id] = 'GRN-'+str(auto_gen) +'/'+str(display_present_year)+'-'+str(display_year)
                cr.execute('''update prakruti_accept_po set mrn_no =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
        return x
    
    @api.depends('accept_line.accept_qty','accept_line.unit_price')
    def _compute_untaxed_total(self):
        for order in self:
            amount_untaxed = total= discount_cal= 0.0
            for line in order.accept_line:
                total += line.accept_qty * line.unit_price 
                amount_untaxed_cal = total
                order.update({
                    'amount_untaxed': amount_untaxed_cal
                    })
    @api.depends('amount_untaxed')
    def _compute_excise_duty(self):
        print 'I am Inside exice Calculation line 1 --I am Inside exice Calculation line 1---I am Inside exice Calculation line 1---I am Inside exice Calculation line 1---'
        for order in self:
            print 'I am Inside exice Calculation line 2 --I am Inside exice Calculation line 2---I am Inside exice Calculation line 2---I am Inside exice Calculation line 2---'
            amount_untaxed = excise_duty= amount_excise_duty  = total_excise_duty = 0.0
            amount_excise_duty += order.amount_untaxed * (order.excise_duty/100)
            order.update({                
                    'total_excise_duty': amount_excise_duty
                    })
            print 'I am Inside exice Calculation line 3 --I am Inside exice Calculation line 3---I am Inside exice Calculation line 3---I am Inside exice Calculation line 3---'
            
    @api.depends('accept_line.accept_qty','accept_line.unit_price')
    def _compute_grand_total(self):
        for order in self:
            amount_untaxed = total= discount_cal= tax_amt= amount_excise_duty= 0.0
            for line in order.accept_line:
                total += line.accept_qty * line.unit_price 
                discount_cal += (line.accept_qty * line.unit_price)*(line.discount/100)
                tax_amt += (line.accept_qty * line.unit_price)*(line.tax_price/100)
                amount_excise_duty += order.amount_untaxed * (order.excise_duty/100)
                print 'discount_caldiscount_caldiscount_cal --',discount_cal
                
                if order.frieght_charges_applied == 'yes':
                    frieght_charges= order.frieght_charges
                else:
                    frieght_charges = 0.0
                    
                amount_untaxed_cal = total - discount_cal + tax_amt + frieght_charges + order.additional_charges + amount_excise_duty
                
                order.update({
                    'grand_total': amount_untaxed_cal 
                    })
   
    
    @api.depends('accept_line.discount','amount_untaxed')
    def _compute_discount_amount(self):
        for order in self:
            amount_untaxed = total= discount_amt= 0.0
            for line in order.accept_line: 
                total += line.accept_qty * line.unit_price 
                discount_amt += (line.accept_qty * line.unit_price)*(line.discount/100)
                print 'discount_caldiscount_caldiscount_cal --',discount_amt
                
                order.update({
                    'total_discount': discount_amt
                    })
                
    @api.depends('accept_line.tax_price','amount_untaxed')
    def _compute_tax_total_amount(self):
        for order in self:
            amount_untaxed = total= tax_amt= 0.0
            for line in order.accept_line: 
                total += line.accept_qty * line.unit_price 
                tax_amt += (line.accept_qty * line.unit_price)*(line.tax_price/100)
                print 'tax_amttax_amttax_amttax_amt--',tax_amt
                
                order.update({
                    'total_tax': tax_amt
                    })
    
    @api.one
    @api.multi
    def accept_order(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:

            inspection_details = self.pool.get('prakruti.inspection_details').create(cr,uid, {
                'invoice_no':temp.invoice_no,
                'grn_no':temp.mrn_no,
                'po_no':temp.po_no,
                'pr_no':temp.pr_no,
                'vendor_id':temp.vendor_id.id,
                'status':temp.status
                })
            for item in temp.accept_line:
                grid_values = self.pool.get('prakruti.inspection_details_line').create(cr,uid, {
                   'product_id': item.product_id.id,
                   'description': item.description,
                   'actual_qty': item.accept_qty,
                   'uom_id': item.uom_id.id,
                   'inspection_line_id': inspection_details
                })
        cr.execute("UPDATE prakruti_accept_po SET state = 'accept' WHERE prakruti_accept_po.id = cast(%s as integer)", ((temp.id),))
        cr.execute("UPDATE prakruti_accept_po_line as papl SET accepted_qty = papl.accept_qty WHERE papl.accept_line_id = cast(%s as integer) AND papl.id =%s", ((temp.id),(item.id),))

        for temp in self:
            print 'Accept purchase order ------------1'
            copy_id = 0
            for line in temp.accept_line:
                print 'Accept purchase order ------------2'
                if line.requested_qty == (line.accept_qty+line.accepted_qty):
                    print 'Accept purchase order ------------3'
                    copy_id = 0
                elif (line.accept_qty > 0):
                    print 'Accept purchase order ------------4'
                    copy_id = 1
                    cr.execute('''update prakruti_accept_po set status = 'Inprogress'  where id = %s ''',((temp.id),))
                elif (line.accept_qty == 0):
                    raise UserError(_('Done its Over.'))
                else:
                    copy_id = 0
            if copy_id == 1:
                print 'Accept purchase order ------------8'
                new_invoice_name = "IN-" + str(temp.id+1) + "/" + str(temp.invoice_no)
                new_grn_name = "IN-" + str(temp.id+1) + "/" + str(temp.mrn_no)
                new_record_name = "IN-" + str(temp.id+1) + "/" + str(temp.po_no)
                state_value = "confirm"
                cr.execute(''' INSERT INTO prakruti_accept_po (invoice_no,mrn_no,po_no,invoice_date,state)
                                SELECT
                                    cast(%s as varchar) as name,
                                    cast(%s as varchar) as name,
                                    cast(%s as varchar) as name,
                                    cast(%s as date) as invoice_date,
                                    cast(%s as varchar) as state
                                FROM
                                    prakruti_accept_po as md
                                WHERE
                                    md.id = %s''', ((new_invoice_name),(new_grn_name),(new_record_name),(temp.invoice_date),(state_value),(temp.id),) )
                cr.execute('''INSERT INTO  prakruti_accept_po_line(product_id,requested_qty,accepted_qty,accept_qty,accept_line_id)

                                    SELECT
                                           product_id,requested_qty,accept_qty,(requested_qty-accept_qty),(accept_line_id+1) as accept_line_id
                                    FROM
                                        prakruti_accept_po_line as md
                                    WHERE
                                        md.accept_line_id = %s ''', ((temp.id),) )

                cr.execute('''update prakruti_accept_po set status = 'Dispatched'  where id = %s ''',((temp.id),))
                res = { 'type': 'ir.actions.client', 'tag': 'reload' }
                return res
  
    _defaults = {
            'invoice_no':'New',
            'mrn_no':'New',
            'status':'Wait',
        }
    
class PrakrutiAcceptPOLine(models.Model):
    _name = 'prakruti.accept_po_line'
    _table = 'prakruti_accept_po_line'
    
    accept_line_id = fields.Many2one('prakruti.accept_po', ondelete='cascade')
    product_id= fields.Many2one('product.product', string="Product",required=True)
    description = fields.Char(string="Description")
    uom_id = fields.Many2one('product.uom', string="UOM")
    requested_qty = fields.Float(string="Qty Requested" ,digits=(6,3))
    accepted_qty= fields.Float(string="Accepted Qty" ,digits=(6,3))
    accept_qty = fields.Float(string="Accept Qty" ,digits=(6,3))
    unit_price = fields.Float(string="Unit Price" ,digits=(6,3))
    discount= fields.Float(string="Discount%" ,digits=(6,3))
    tax_type = fields.Selection([('cst','CST'),('tin','TIN'),('tax','Tax'),('vat','VAT')], string="Tax", default= 'tax')
    tax_price= fields.Float(string="Tax%" ,digits=(6,3))
    subtotal= fields.Float(string='Sub Total',compute= '_compute_price_subtotal',store=True ,digits=(6,3))
    total= fields.Float(string='Total',compute= '_compute_price_total',store=True ,digits=(6,3))
    remarks= fields.Char(string="Remarks")
    
    @api.depends('accept_qty', 'unit_price')
    def _compute_price_total(self):
        print 'automat-----------------1'
        for order in self:
            print 'automat-----------------2'
            total = 0.0            
            order.update({                
                'total': order.accept_qty * order.unit_price 
            })
            
    @api.depends('accept_qty', 'unit_price')
    def _compute_price_subtotal(self):
        print 'automat-----------------1'
        for order in self:
            print 'automat-----------------2'
            subtotal = 0.0            
            order.update({                
                'subtotal': order.accept_qty * order.unit_price 
            })