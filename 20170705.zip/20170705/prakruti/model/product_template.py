from openerp import models, fields, api
import time
import openerp
from datetime import date
from datetime import datetime
from openerp.tools.translate import _
import openerp.addons.decimal_precision as dp
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize
from openerp.tools import image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
import re
import logging
from datetime import timedelta

class ProductGroup(models.Model):
    _name= 'product.group'
    _rec_name= 'group_name'

    group_name = fields.Char('Group Name',required= True)
    group_code = fields.Char('Group Code',required= True)

class ProductSubgroup(models.Model):
    _name= 'product.subgroup'
    _rec_name= 'subgroup_name'

    group_id = fields.Many2one('product.group')
    subgroup_name = fields.Char('Sub Group Name')
    subgroup_code = fields.Char()

class ProductClassification(models.Model):
    _name= 'product.classification'
    _rec_name= 'classification_name'

    group_id = fields.Many2one('product.group')
    subgroup_id = fields.Many2one('product.subgroup')
    classification_name = fields.Char('Classification Name')
    classification_code = fields.Char()

class ProductTemplate(models.Model):
    _inherit= 'product.template'
   
    p_type = fields.Selection([('extraction','Extraction'),('formulation','Formulation'),('packing','Packing Material'),('others','Others')],default= 'extraction')
    specification_type = fields.Selection([('product_wise','Based on Product'),('customer_wise','Based on Customer')],default= 'product_wise')    
    expire_date = fields.Char(string= 'Expire within this months')
    retest_date = fields.Char(string= 'Re-test after this months')
    packingmaterial_name= fields.One2many('packing.material.line','packing_id')
    format_number = fields.Char(string= 'Format No')
    sop_number = fields.Char(string= 'SOP No')
    list_purchase_price = fields.Float(string= 'Purchase Price', default= '1', digits_compute= dp.get_precision('Product Price') ,digits=(6,3))
    group_ref = fields.Many2one('product.group',string= "Product Group/Type of Product")
    subgroup_ref = fields.Many2one('product.subgroup', domain="[('group_id','=',group_ref)]")
    remarks= fields.Text(string= 'Remarks')
    department_name = fields.Many2one('res.partner',string= 'Department Name')
    code = fields.Char(string='Code',readonly=1)
    product_description = fields.One2many('product.description.line','product_description_id')
    specification_attachement= fields.Binary(string= 'Specification Attachment') 
    state = fields.Selection([
		('draft','Draft'),
		('approve','Approved')],default= 'draft')
    specification_line= fields.One2many('product.specification.main','specification_product_id')
    code_date = fields.Date(string='Code Date', default= fields.Date.today, required=True)
    code_no = fields.Char('Code Number', compute='_get_auto')
    auto_no = fields.Integer('Auto')
    req_no_control_id1 = fields.Integer('Auto Generating id',default= 0)
    store_qty = fields.Float(string="Store Qty",digits=(6,3),readonly=1)
    hsn_code = fields.Char(string= 'HSN/SAC')
    
    _sql_constraints = [
    ('name_uniq', 'unique(name,group_ref)','Group wise product name must be unique !')
    ]
    
    @api.one
    @api.multi
    def check_stock(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr.execute("UPDATE product_template SET store_qty= qty_aval FROM ( SELECT product_id,(sum(qty_in) - sum(qty_out)) as qty_aval,id FROM ( SELECT stock_move.product_id,case when move_dest_id > 0 then product_qty else 0 end as qty_out, case when move_dest_id > 0 then 0 else product_qty end as qty_in,product_template.id FROM product_template INNER JOIN product_product  ON product_product.product_tmpl_id = product_template.id INNER JOIN stock_move ON stock_move.product_id = product_product.id WHERE product_template.id = %s and location_dest_id = 12  AND stock_move.state = 'done')as a GROUP BY product_id,id) as b WHERE b.id = product_template.id",((temp.id),))
        return {}
   
    @api.one
    @api.multi
    def _get_auto(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        for temp in self:
            cr.execute('''select cast(extract (month from code_date) as integer) as month ,cast(extract (year from code_date) as integer) as year ,id from product_template where id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
                if month_value<=3:
                    year_value=year_value-1
                else:
                    year_value=year_value
                next_year=year_value+1
                dispay_year=str(next_year)[-2:]
                display_present_year=str(year_value)[-2:]
                        
                cr.execute('''select autogenerate_product_template(%s)''', ((temp.id),)  ) 
                result = cr.dictfetchall()
                parent_invoice_id = 0
                for value in result: parent_invoice_id = value['autogenerate_product_template'];
                auto_gen = int(parent_invoice_id)
                if len(str(auto_gen)) < 2:
                    auto_gen = '000'+ str(auto_gen)
                elif len(str(auto_gen)) < 3:
                    auto_gen = '00' + str(auto_gen)
                elif len(str(auto_gen)) == 3:
                    auto_gen = '0'+str(auto_gen)
                else:
                    auto_gen = str(auto_gen)
                for record in self :
                    if temp.group_ref.group_code:
                        x[record.id] = temp.group_ref.group_code+str(auto_gen)
                    else:                        
                        x[record.id] = 'MISC'+str(auto_gen)
                cr.execute('''update product_template set code =%s where id=%s ''', ((x[record.id]),(temp.id),)  )
            return x

    
    def onchange_check_code(self, cr, uid, ids, code, context=None):
        if code == False: 
            return {
                'value': {
                    'code': False
                }
            }
        if re.match("^[ A-Za-z0-9]*$", code) != None:
            code = code.strip()
            code = code.upper()

            return {
                'value': {
                    'code': code
                }
            }

        else:
            warning_shown = {
                'title': _("Warning"),
                'message': _('Enter only numbers and alphabets'),
            }
            return {'value': {
                'code': False
            }, 'warning': warning_shown}

  

    def onchange_check_name(self, cr, uid, ids, name, context=None):
        if name == False:
            return {
                'value': {
                    'name': False
                }
            }

        if  name != None:
            name = name.strip()
            name = name.upper()

            return {
                'value': {
                    'name': name
                }
            }

        else:
            warning_shown = {
                'title': _("Warning"),
                'message': _('Enter only numbers and alphabets'),
            }
            return {'value': {
                'name': False
            }, 'warning': warning_shown}


    @api.onchange('group_ref')
    def onchange_group_ref(self):
        if self.group_ref:
            self.subgroup_ref = False
            
    @api.multi
    def action_draft(self):
        self.state = 'draft'

    @api.multi
    def action_approve(self):
        self.state = 'approve'

    
class PackingMaterialLine(models.Model):
    _name= 'packing.material.line'
    _table= 'packing_material_line'

    remarks = fields.Text(string= 'Remarks')
    qty = fields.Float(string= 'Qty.', default= '1',digits=(6,3))
    package_name = fields.Char(string= 'Package Name',index= True)
    packing_name = fields.Many2one('product.product',string='Packing Item', ondelete='cascade', domain= "[('group_ref','=', 3)]", no_create= 'True')
    packing_id = fields.Many2one('product.template')

class ProductDescriptionLine(models.Model):
    _name= 'product.description.line'

    remarks = fields.Text(string= 'Remarks')    
    specification_name = fields.Char(string= 'Specification')
    parameter_name = fields.Char(string='Parameter')
    product_description_id = fields.Many2one('product.product')


class PrackrutiEmergencyLevel(models.Model):
    _inherit = 'stock.warehouse.orderpoint'
    emergency_min_qty = fields.Float(string= "Emergency Quantity" ,digits=(6,3))
