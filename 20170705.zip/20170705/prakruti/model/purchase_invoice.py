# -*- coding: utf-8 -*-
import openerp
from datetime import date, datetime
from openerp.tools import DEFAULT_SERVER_DATE_FORMAT, image_colorize, image_resize_image_big
from openerp.exceptions import except_orm, Warning as UserError
from openerp import tools
from datetime import timedelta
from openerp.osv import osv,fields
from openerp import models, fields, api, _
from openerp.tools.translate import _
import sys, os, urllib2, urlparse
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from email.MIMEMultipart import MIMEMultipart
import email, re
from datetime import datetime
from datetime import date, timedelta
from lxml import etree
import cgi
import logging
import lxml.html
import lxml.html.clean as clean
import openerp.pooler as pooler
import random
import re
import socket
import threading
import time
from openerp.tools import image_resize_image_big
from openerp.tools import amount_to_text
from openerp.tools.amount_to_text import amount_to_text_in 
from openerp.tools.amount_to_text import amount_to_text_in_without_word_rupees 

class PrakrutiPurchaseInvoice(models.Model):
    _name =  'prakruti.purchase_invoice'
    _table = 'prakruti_purchase_invoice'
    _description = 'Purchase Invoice Details'
    _order="id desc"
    _rec_name="purchase_invoice_no"
    
    purchase_invoice_date=fields.Date(string='Invoice Date',default= fields.Date.today,required=True)
    purchase_invoice_no = fields.Char(string='Invoice No', readonly=True,default='New')
    flag_count_display_product = fields.Integer(default=0)    
    flag_count = fields.Integer('Accepted Line is There',default= 0)
    flag_count_display_product = fields.Integer(default=0)  
    pur_inv_no = fields.Char('Purchase Invoice Number', compute='_get_auto')    
    auto_no2 = fields.Integer('Auto')
    req_no_control_id2 = fields.Integer('Auto Generating id',default= 0)    
    order_close_flag = fields.Integer('Order Is Closed',default=0,readonly=True)
    invoice_no= fields.Char(string='Invoice No')    
    po_no= fields.Char(string= "Order No.",readonly=1)
    pass_no= fields.Many2one('prakruti.gate_pass',string= "Gate Pass No.")
    pr_no = fields.Char(string='Requisition No',readonly=1)
    qa_no = fields.Char(string='Analysis No')
    qo_no = fields.Char(string='Quotation No')
    req_no =fields.Char(string='Request No')
    vendor_id = fields.Many2one('res.partner',string='Vendor/Supplier',readonly=1)    
    logo = fields.Binary(related='company_address.logo')
    vendor_reference = fields.Char(string='Vendor/Supplier Reference' ,readonly=1)
    other_reference = fields.Char(string='Other Reference')
    request_date = fields.Date(string = "Requisition Date",readonly=1)
    order_date = fields.Date(string='Order Date',readonly=1)
    destination = fields.Char(string='Destination')
    company_address = fields.Many2one('res.company',string='Company Address',readonly=1)
    delivery_address = fields.Many2one('res.company',string='Dispatch To' )
    payment = fields.Char(string='Mode/Terms of Payments')
    terms_of_delivery = fields.Text(string='Terms of Delivery')
    remarks=fields.Text(string='Remarks')
    dispatch_through = fields.Char(string='Dispatch Through',readonly=1)
    prepared_by = fields.Many2one('res.users','Prepared By')
    maintanence_manager = fields.Many2one('res.users',string="Maintanence Manager")    
    purchase_manager = fields.Many2one('res.users',string="Purchase Manager")
    purchase_type = fields.Many2one('product.group',string= 'Purchase Type',readonly=1)
    state = fields.Selection([('invoice','Invoiced'),
                              ('qc_check','QC Check'),                              
                              ('accepted','Accepted'),
                              ('rejected','Rejected'),
                              ('accepted_under_deviation','Accepted Under Deviation'),
                              ('qc_check_done','QC Check Done'),
                              ('done','Done')],default= 'invoice', string= 'Status') 
    status = fields.Selection([('draft','Draft'),
                              ('pending','Pending'),                              
                              ('close','Close')],default= 'draft', string= 'Status')    
    pr_common_id = fields.Integer('PR SCREEN COMMON ID')
    grand_total_in_words= fields.Text(string='Total in words')
    currency_id = fields.Many2one('res.currency', 'Currency')
    prakruti_stock_id = fields.Integer('SCREEN COMMON ID')
    excise_id = fields.Many2one('account.other.tax', string='Excise Duty', domain=['|', ('active', '=', False), ('active', '=', True)],readonly=1)
    excise_duty = fields.Float(related='excise_id.per_amount',string= 'Excise Duty(%)',store=True,readonly=1 ,digits=(6,3))
    stores_incharge = fields.Many2one('res.users','Stores Incharge')
    gc_no=fields.Char('GC No')
    gc_date=fields.Date('GC Date')
    dc_no=fields.Char('DC No')
    dc_date=fields.Date('DC Date')
    transporter_name=fields.Text('Name of Transporter',readonly=1)
    transporter_payment_details=fields.Text('Transporter Payment Details')
    doc_no=fields.Char('Doc. No',default='PPPL-STR-F-001',readonly=1)
    rev_no=fields.Char('Rev. No',default='02',readonly=1)
    doc_date=fields.Date('Document Date',default= fields.Date.today,readonly=1)
    invoice_line = fields.One2many('prakruti.purchase_invoice_line','invoice_line_id')
    total_discount = fields.Float(string="Total Discount" , digits=(6,3))
    total_tax = fields.Float(string="Total Tax" , digits=(6,3))
    amount_untaxed= fields.Float(string='Untaxed Amount',digits=(6,3))
    total_excise_duty = fields.Float(string= 'Total Excise Duty',digits=(6,3))
    discounted_total = fields.Float(string= 'Discounted Total',digits=(6,3))
    order_close_pending = fields.Integer('Still Pending Order',default=0,readonly=True)
    any_adv_payment =fields.Selection([
                    ('no', 'No'),
                    ('yes','Yes')
                    ], string= 'Any Advance Payment',readonly=1)
    advance_payment_type =fields.Selection([
                    ('cash', 'CASH'),
                    ('cheque','CHEQUE'),
                    ('demand_draft','DD')
                    ], string= 'Done By',readonly=1)
    cash_amount = fields.Float(string="Amount",readonly=1 ,digits=(6,3),default=0)
    cash_remarks = fields.Text(string="Remarks",readonly=1)    
    cheque_amount = fields.Float(string="Amount",readonly=1 ,digits=(6,3),default=0)
    cheque_no = fields.Integer(string="Cheque No.",readonly=1)
    cheque_remarks = fields.Text(string="Remarks",readonly=1)    
    draft_amount = fields.Float(string="Amount",readonly=1 ,digits=(6,3),default=0)
    draft_no = fields.Integer(string="Draft No.",readonly=1)
    draft_remarks = fields.Text(string="Remarks",readonly=1) 
    product_id = fields.Many2one('product.product', related='invoice_line.product_id', string='Product Name')
    
    
    
    #GST ENTRY
    no_of_product = fields.Integer(string= "No of Products")
    amount_taxed= fields.Float(string='Taxed Amount',digits=(6,3),readonly=1)    
    total_cgst= fields.Float(string='Total CGST',digits=(6,3),readonly=1)
    total_sgst= fields.Float(string='Total SGST',digits=(6,3),readonly=1)
    total_igst= fields.Float(string='Total IGST',digits=(6,3),readonly=1)
    total_gst= fields.Float(string='Total GST',digits=(6,3),readonly=1)
    insurance_charges = fields.Float(string="Insurance Charges" ,digits=(6,3))
    frieght_charges_applied = fields.Selection([('yes','Yes'),('no','No')], string="Freight Charge Applied", default='no')
    frieght_charges = fields.Float(string="Frieght Charges" ,digits=(6,3))
    additional_charges = fields.Float(string='Additional Charges' ,digits=(6,3))
    packing_charges = fields.Float(string='Packing & Forwarding' ,digits=(6,3))
    grand_total= fields.Float(string='Total',digits=(6,3),readonly=1)
    grand_total_after_payments= fields.Float(string='Grand Total',digits=(6,3),readonly=1)
                
    #@api.depends('invoice_line.taxable_value_after_adding_other')
    #def _compute_taxed_amount(self):
        #for order in self:
            #amount_taxed = 0.0
            #for line in order.invoice_line:
                #amount_taxed += line.taxable_value_after_adding_other
                #order.update({
                    #'amount_taxed': amount_taxed
                    #})
    
    #@api.depends('invoice_line.cgst_value')
    #def _compute_total_cgst(self):
        #for order in self:
            #cgst_value = 0.0
            #for line in order.invoice_line:
                #cgst_value += line.cgst_value
                #order.update({
                    #'total_cgst': cgst_value
                    #})
                
    #@api.depends('invoice_line.sgst_value')
    #def _compute_total_sgst(self):
        #for order in self:
            #sgst_value = 0.0
            #for line in order.invoice_line:
                #sgst_value += line.sgst_value
                #order.update({
                    #'total_sgst': sgst_value
                    #})
                
                
    #@api.depends('invoice_line.igst_value')
    #def _compute_total_igst(self):
        #for order in self:
            #igst_value = 0.0
            #for line in order.invoice_line:
                #igst_value += line.igst_value
                #order.update({
                    #'total_igst': igst_value
                    #})
    
    #@api.depends('invoice_line.cgst_value','invoice_line.sgst_value','invoice_line.igst_value')
    #def _compute_total_gst(self):
        #for order in self:
            #total_gst = 0.0
            #cgst_value = 0.0
            #sgst_value = 0.0
            #igst_value = 0.0
            #for line in order.invoice_line:
                #cgst_value += line.cgst_value
                #sgst_value += line.sgst_value
                #igst_value += line.igst_value
                #total_gst = cgst_value + sgst_value + igst_value
                #order.update({
                    #'total_gst': total_gst
                    #})
                
    #@api.depends('invoice_line.subtotal')
    #def _compute_grand_total(self):
        #for order in self:
            #grand_total = 0.0
            #for line in order.invoice_line:
                #grand_total += line.subtotal
                #order.update({
                    #'grand_total': grand_total
                    #})
    
    
    #@api.depends('invoice_line.quantity','invoice_line.unit_price')
    #def _total_no_of_product(self):
        #for order in self:
            #total_no_of_product = 0
            #total_no_of_product = len(order.invoice_line)
            #order.update({
                #'no_of_product': total_no_of_product
                #})
    
    @api.one
    @api.multi
    def _get_auto(self):
        x = {}
        month_value=0
        year_value=0
        next_year=0
        dispay_year=''
        display_present_year=''
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        for temp in self :
            cr.execute('''select cast(extract (month from purchase_invoice_date) as integer) as month ,cast(extract (year from purchase_invoice_date) as integer) as year ,id from prakruti_purchase_invoice where id=%s''',((temp.id),))
            for item in cr.dictfetchall():
                month_value=int(item['month'])
                year_value=int(item['year'])
            if month_value<=3:
                year_value=year_value-1
            else:
                year_value=year_value
            next_year=year_value+1
            dispay_year=str(next_year)[-2:]
            display_present_year=str(year_value)[-2:]
            cr.execute('''select autogenerate_purchase_invoice(%s)''', ((temp.id),)  ) 
            result = cr.dictfetchall()
            parent_invoice_id = 0
            for value in result: parent_invoice_id = value['autogenerate_purchase_invoice'];
            auto_gen = int(parent_invoice_id)
            if len(str(auto_gen)) < 2:
                auto_gen = '000'+ str(auto_gen)
            elif len(str(auto_gen)) < 3:
                auto_gen = '00' + str(auto_gen)
            elif len(str(auto_gen)) == 3:
                auto_gen = '0'+str(auto_gen)
            else:
                auto_gen = str(auto_gen)
            for record in self :
                if temp.purchase_type.group_code:
                    x[record.id] ='PI\\'+ temp.purchase_type.group_code+'\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                else:                        
                    x[record.id] ='PI\\'+str(auto_gen)+'\\'+str(display_present_year)+'-'+str(dispay_year)
                cr.execute('''UPDATE prakruti_purchase_invoice SET purchase_invoice_no =%s WHERE id=%s ''', ((x[record.id]),(temp.id),)  )
            return x
        
    @api.one
    @api.multi 
    def update_order(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'        
        for temp in self:
            cr = self.env.cr
            uid = self.env.uid
            ids = self.ids
            context = {} 
            for line in temp.invoice_line:
                if (line.quantity != line.actual_quantity) and line.status == 'close':
                    if line.remarks:
                        cr.execute("UPDATE prakruti_purchase_line AS b SET status = a.status FROM(SELECT invoice_line_id,purchase_line_common_id,product_id,status FROM prakruti_purchase_invoice_line WHERE invoice_line_id= %s ) AS a WHERE a.purchase_line_common_id = b.id AND a.product_id = b.product_id",((temp.id),))
                        cr.execute("SELECT count(prakruti_purchase_line.id) as c_line FROM prakruti_purchase_line INNER JOIN prakruti_purchase_order ON prakruti_purchase_order.id = prakruti_purchase_line.purchase_line_id INNER JOIN prakruti_purchase_invoice ON prakruti_purchase_order.po_no = prakruti_purchase_invoice.po_no WHERE prakruti_purchase_line.status = 'close' and prakruti_purchase_invoice.id = CAST(%s AS INTEGER)",((temp.id),))
                        for close_line in cr.dictfetchall():
                            c_line = close_line['c_line']
                        print 'CLOSE LINE',c_line
                        cr.execute("SELECT count(prakruti_purchase_line.id) as t_line FROM prakruti_purchase_line INNER JOIN prakruti_purchase_order ON prakruti_purchase_order.id = prakruti_purchase_line.purchase_line_id INNER JOIN prakruti_purchase_invoice ON prakruti_purchase_order.po_no = prakruti_purchase_invoice.po_no WHERE prakruti_purchase_invoice.id = CAST(%s AS INTEGER)",((temp.id),))
                        for total_line in cr.dictfetchall():
                            t_line = total_line['t_line']
                        print 'TOTAL LINE',t_line
                        if c_line == t_line:
                            cr.execute("UPDATE prakruti_purchase_order SET state = 'order_close' WHERE prakruti_purchase_order.po_no = %s",((temp.po_no),))
                            cr.execute("UPDATE prakruti_purchase_invoice SET order_close_flag = 1 where id = %s", ((temp.id),))
                            cr.execute("UPDATE prakruti_purchase_invoice SET status = 'close' where id = %s", ((temp.id),))
                            cr.execute("UPDATE prakruti_gate_pass SET order_close_flag = 1 WHERE prakruti_gate_pass.id = %s",((temp.pass_no.id),))
                        else:
                            cr.execute("UPDATE prakruti_purchase_order SET state = 'order' WHERE prakruti_purchase_order.po_no = %s",((temp.po_no),))
                            cr.execute("UPDATE prakruti_purchase_invoice SET order_close_pending = 1 where id = %s", ((temp.id),))
                            cr.execute("UPDATE prakruti_purchase_invoice SET status = 'pending' where id = %s", ((temp.id),))
                            cr.execute("UPDATE prakruti_gate_pass SET order_close_pending = 1 WHERE prakruti_gate_pass.id = %s",((temp.pass_no.id),))
                    else:
                        raise UserError(_('Please Enter Remarks for Manual Closing'))
                elif (line.quantity == line.actual_quantity):
                    if line.status == 'close':
                        cr.execute("UPDATE prakruti_purchase_line AS b SET status = a.status FROM(SELECT invoice_line_id,purchase_line_common_id,product_id,status FROM prakruti_purchase_invoice_line WHERE invoice_line_id= %s ) AS a WHERE a.purchase_line_common_id = b.id AND a.product_id = b.product_id",((temp.id),))
                        cr.execute("SELECT count(prakruti_purchase_line.id) as c_line FROM prakruti_purchase_line INNER JOIN prakruti_purchase_order ON prakruti_purchase_order.id = prakruti_purchase_line.purchase_line_id INNER JOIN prakruti_purchase_invoice ON prakruti_purchase_order.po_no = prakruti_purchase_invoice.po_no WHERE prakruti_purchase_line.status = 'close' and prakruti_purchase_invoice.id = CAST(%s AS INTEGER)",((temp.id),))
                        for close_line in cr.dictfetchall():
                            c_line = close_line['c_line']
                        print 'CLOSE LINE',c_line
                        cr.execute("SELECT count(prakruti_purchase_line.id) as t_line FROM prakruti_purchase_line INNER JOIN prakruti_purchase_order ON prakruti_purchase_order.id = prakruti_purchase_line.purchase_line_id INNER JOIN prakruti_purchase_invoice ON prakruti_purchase_order.po_no = prakruti_purchase_invoice.po_no WHERE prakruti_purchase_invoice.id = CAST(%s AS INTEGER)",((temp.id),))
                        for total_line in cr.dictfetchall():
                            t_line = total_line['t_line']
                        print 'TOTAL LINE',t_line
                        if c_line == t_line:
                            cr.execute("UPDATE prakruti_purchase_order SET state = 'order_close' WHERE prakruti_purchase_order.po_no = %s",((temp.po_no),))
                            cr.execute("UPDATE prakruti_purchase_invoice SET order_close_flag = 1 where id = %s", ((temp.id),))
                            cr.execute("UPDATE prakruti_purchase_invoice SET status = 'close' where id = %s", ((temp.id),))
                            cr.execute("UPDATE prakruti_gate_pass SET order_close_flag = 1 WHERE prakruti_gate_pass.id = %s",((temp.pass_no.id),))
                        else:
                            cr.execute("UPDATE prakruti_purchase_order SET state = 'order' WHERE prakruti_purchase_order.po_no = %s",((temp.po_no),))
                            cr.execute("UPDATE prakruti_purchase_invoice SET order_close_pending = 1 where id = %s", ((temp.id),))
                            cr.execute("UPDATE prakruti_purchase_invoice SET status = 'pending' where id = %s", ((temp.id),))
                            cr.execute("UPDATE prakruti_gate_pass SET order_close_pending = 1 WHERE prakruti_gate_pass.id = %s",((temp.pass_no.id),))
                    else:
                        raise UserError(_('Please Close the Status Since the Quantity is fully Received...'))
                template_id = self.pool.get('email.template').search(cr,uid,[('name','=','Purcahse Invoice')],context=context)[0]
                email_obj = self.pool.get('email.template').send_mail(cr, uid, template_id,ids[0],force_send=True) 
            
        return True
    
    def onchange_pass_no(self, cr, uid, ids, pass_no, context=None):
        process_type = self.pool.get('prakruti.gate_pass').browse(cr, uid, pass_no, context=context)
        result = {
            'po_no':process_type.po_no,
            'order_date':process_type.order_date,
            'pr_no':process_type.pr_no,
            'request_date':process_type.request_date,
            'vendor_id':process_type.vendor_id.id,
            'stores_incharge':process_type.stores_incharge.id,
            'purchase_manager':process_type.purchase_manager.id,
            'delivery_address':process_type.delivery_address.id,
            'dispatch_through':process_type.dispatch_through,
            'purchase_type':process_type.purchase_type.id,
            'excise_id':process_type.excise_id.id,
            'excise_duty':process_type.excise_duty,
            'advance_payment_type':process_type.advance_payment_type,
            'any_adv_payment':process_type.any_adv_payment,
            'cash_amount':process_type.cash_amount,
            'cash_remarks':process_type.cash_remarks,
            'cheque_amount':process_type.cheque_amount,
            'cheque_no':process_type.cheque_no,
            'cheque_remarks':process_type.cheque_remarks,
            'draft_amount':process_type.draft_amount,
            'draft_no':process_type.draft_no,
            'draft_remarks':process_type.draft_remarks,
            'transporter_name':process_type.transport_name,
            #GST Entry
            'no_of_product':process_type.no_of_product,
            'amount_taxed':process_type.amount_taxed,
            'total_cgst':process_type.total_cgst,
            'total_sgst':process_type.total_sgst,
            'total_igst':process_type.total_igst,
            'total_gst':process_type.total_gst,
            'insurance_charges':process_type.insurance_charges,
            'frieght_charges_applied':process_type.frieght_charges_applied,
            'frieght_charges':process_type.frieght_charges,
            'packing_charges':process_type.packing_charges,
            'additional_charges':process_type.additional_charges,
            'grand_total':process_type.grand_total  
            }
        return {'value': result}
        
    def create(self, cr, uid, vals, context=None):
        onchangeResult = self.onchange_pass_no(cr, uid, [], vals['pass_no'])
        if onchangeResult.get('value') or onchangeResult['value'].get('po_no','order_date','pr_no','request_date','vendor_id','stores_incharge','purchase_manager','delivery_address','dispatch_through','excise_id','excise_duty','packing_charges','frieght_charges_applied','frieght_charges','any_adv_payment','advance_payment_type','cash_amount','cash_remarks','cheque_amount','cheque_no','cheque_remarks','draft_amount','draft_no','draft_remarks','additional_charges','transporter_name','purchase_type','grand_total','total_cgst','insurance_charges','total_gst','total_igst','total_sgst','amount_taxed','no_of_product'):
            vals['po_no'] = onchangeResult['value']['po_no']
            vals['order_date'] = onchangeResult['value']['order_date']
            vals['pr_no'] = onchangeResult['value']['pr_no']
            vals['request_date'] = onchangeResult['value']['request_date']
            vals['vendor_id'] = onchangeResult['value']['vendor_id']
            vals['stores_incharge'] = onchangeResult['value']['stores_incharge']
            vals['purchase_manager'] = onchangeResult['value']['purchase_manager']
            vals['delivery_address'] = onchangeResult['value']['delivery_address']
            vals['dispatch_through'] = onchangeResult['value']['dispatch_through']
            vals['excise_id'] = onchangeResult['value']['excise_id']
            vals['excise_duty'] = onchangeResult['value']['excise_duty']
            #vals['packing_charges'] = onchangeResult['value']['packing_charges']
            #vals['frieght_charges_applied'] = onchangeResult['value']['frieght_charges_applied']
            #vals['frieght_charges'] = onchangeResult['value']['frieght_charges']
            vals['any_adv_payment'] = onchangeResult['value']['any_adv_payment']
            vals['advance_payment_type'] = onchangeResult['value']['advance_payment_type']
            vals['cash_amount'] = onchangeResult['value']['cash_amount']
            vals['cash_remarks'] = onchangeResult['value']['cash_remarks']
            vals['cheque_amount'] = onchangeResult['value']['cheque_amount']
            vals['cheque_no'] = onchangeResult['value']['cheque_no']
            vals['cheque_remarks'] = onchangeResult['value']['cheque_remarks']
            vals['draft_amount'] = onchangeResult['value']['draft_amount']
            vals['draft_no'] = onchangeResult['value']['draft_no']
            vals['draft_remarks'] = onchangeResult['value']['draft_remarks']
            #vals['additional_charges'] = onchangeResult['value']['additional_charges']
            vals['transporter_name'] = onchangeResult['value']['transporter_name']
            vals['purchase_type'] = onchangeResult['value']['purchase_type']            
            vals['grand_total'] = onchangeResult['value']['grand_total']
            vals['total_cgst'] = onchangeResult['value']['total_cgst']
            #vals['insurance_charges'] = onchangeResult['value']['insurance_charges']
            vals['total_gst'] = onchangeResult['value']['total_gst']
            vals['total_igst'] = onchangeResult['value']['total_igst']
            vals['total_sgst'] = onchangeResult['value']['total_sgst']
            vals['amount_taxed'] = onchangeResult['value']['amount_taxed']
            vals['no_of_product'] = onchangeResult['value']['no_of_product']
        return super(PrakrutiPurchaseInvoice, self).create(cr, uid, vals, context=context)
    
    def write(self, cr, uid, ids, vals, context=None):
        op=super(PrakrutiPurchaseInvoice, self).write(cr, uid, ids, vals, context=context)
        for record in self.browse(cr, uid, ids, context=context):
            store_type=record.pass_no.id
        onchangeResult = self.onchange_pass_no(cr, uid, ids, store_type)
        if onchangeResult.get('value') or onchangeResult['value'].get('po_no','order_date','pr_no','request_date','vendor_id','stores_incharge','purchase_manager','delivery_address','dispatch_through','excise_id','excise_duty','packing_charges','frieght_charges_applied','frieght_charges','any_adv_payment','advance_payment_type','cash_amount','cash_remarks','cheque_amount','cheque_no','cheque_remarks','draft_amount','draft_no','draft_remarks','additional_charges','transporter_name','purchase_type','grand_total','total_cgst','insurance_charges','total_gst','total_igst','total_sgst','amount_taxed','no_of_product'):
            vals['po_no'] = onchangeResult['value']['po_no']
            vals['order_date'] = onchangeResult['value']['order_date']
            vals['pr_no'] = onchangeResult['value']['pr_no']
            vals['request_date'] = onchangeResult['value']['request_date']
            vals['vendor_id'] = onchangeResult['value']['vendor_id']
            vals['stores_incharge'] = onchangeResult['value']['stores_incharge']
            vals['purchase_manager'] = onchangeResult['value']['purchase_manager']
            vals['delivery_address'] = onchangeResult['value']['delivery_address']
            vals['dispatch_through'] = onchangeResult['value']['dispatch_through']
            vals['excise_id'] = onchangeResult['value']['excise_id']
            vals['excise_duty'] = onchangeResult['value']['excise_duty']
            #vals['packing_charges'] = onchangeResult['value']['packing_charges']
            #vals['frieght_charges_applied'] = onchangeResult['value']['frieght_charges_applied']
            #vals['frieght_charges'] = onchangeResult['value']['frieght_charges']
            vals['any_adv_payment'] = onchangeResult['value']['any_adv_payment']
            vals['advance_payment_type'] = onchangeResult['value']['advance_payment_type']
            vals['cash_amount'] = onchangeResult['value']['cash_amount']
            vals['cash_remarks'] = onchangeResult['value']['cash_remarks']
            vals['cheque_amount'] = onchangeResult['value']['cheque_amount']
            vals['cheque_no'] = onchangeResult['value']['cheque_no']
            vals['cheque_remarks'] = onchangeResult['value']['cheque_remarks']
            vals['draft_amount'] = onchangeResult['value']['draft_amount']
            vals['draft_no'] = onchangeResult['value']['draft_no']
            vals['draft_remarks'] = onchangeResult['value']['draft_remarks']
            #vals['additional_charges'] = onchangeResult['value']['additional_charges']
            vals['transporter_name'] = onchangeResult['value']['transporter_name']
            vals['purchase_type'] = onchangeResult['value']['purchase_type']            
            vals['grand_total'] = onchangeResult['value']['grand_total']
            vals['total_cgst'] = onchangeResult['value']['total_cgst']
            #vals['insurance_charges'] = onchangeResult['value']['insurance_charges']
            vals['total_gst'] = onchangeResult['value']['total_gst']
            vals['total_igst'] = onchangeResult['value']['total_igst']
            vals['total_sgst'] = onchangeResult['value']['total_sgst']
            vals['amount_taxed'] = onchangeResult['value']['amount_taxed']
            vals['no_of_product'] = onchangeResult['value']['no_of_product']
        return super(PrakrutiPurchaseInvoice, self).write(cr, uid, ids, vals, context=context)
    
    @api.one
    @api.multi
    def action_list_products(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute("SELECT product_id,uom_id,description,recieved_qty,extra_packing,unit_price,no_of_packings,pack_per_qty,status,purchase_line_common_id,quantity,prakruti_gate_pass_line.remarks,tax_id,tax_price,discount,subtotal,main_id,hsn_code,discount_id,discount_rate,discount_value,taxable_value,total,cgst_id,cgst_rate,cgst_value,sgst_id,sgst_rate,sgst_value,igst_id,igst_rate,igst_value,taxable_value_after_adding_other,prakruti_gate_pass.no_of_product,prakruti_gate_pass.packing_charges,prakruti_gate_pass.frieght_charges,prakruti_gate_pass.additional_charges,prakruti_gate_pass.insurance_charges FROM prakruti_gate_pass INNER JOIN prakruti_gate_pass_line ON prakruti_gate_pass.id=prakruti_gate_pass_line.main_id WHERE prakruti_gate_pass_line.main_id = CAST(%s as integer)",((temp.pass_no.id),))
            for item in cr.dictfetchall():
                print 'abcdeghhhhhhhhhhhhhhh'
                product_id=item['product_id']
                description =item['description']
                uom_id=item['uom_id']
                quantity=item['quantity']
                discount=item['discount']
                recieved_qty=item['recieved_qty']
                no_of_packings=item['no_of_packings']
                pack_per_qty=item['pack_per_qty']
                unit_price=item['unit_price']
                extra_packing=item['extra_packing']
                purchase_line_common_id=item['purchase_line_common_id']
                status=item['status']
                remarks=item['remarks']
                tax_id=item['tax_id']
                tax_price=item['tax_price']
                #GST ENTRY
                hsn_code= item['hsn_code']
                discount_id=item['discount_id']
                discount_rate=item['discount_rate']
                discount_value=item['discount_value']
                taxable_value= item['taxable_value']
                total=item['total']
                cgst_id=item['cgst_id']
                cgst_rate=item['cgst_rate']
                cgst_value= item['cgst_value']
                sgst_id=item['sgst_id']
                sgst_rate=item['sgst_rate']
                sgst_value= item['sgst_value']
                igst_id=item['igst_id']
                igst_rate=item['igst_rate']
                igst_value= item['igst_value']
                taxable_value_after_adding_other=item['taxable_value_after_adding_other']
                no_of_product=item['no_of_product']
                packing_charges=item['packing_charges']
                frieght_charges=item['frieght_charges']
                additional_charges=item['additional_charges']
                insurance_charges=item['insurance_charges']
                #GST ENTRY
                grid_down = self.pool.get('prakruti.purchase_invoice_line').create(cr,uid, {
                    'product_id':product_id,
                    'description': description,
                    'uom_id': uom_id,
                    'actual_quantity':quantity,
                    'discount':discount,
                    'no_of_packings':no_of_packings,
                    'pack_per_qty':pack_per_qty,
                    'extra_packing':extra_packing,
                    'quantity':recieved_qty,
                    'status':status,                     
                    'unit_price': unit_price,
                    'remarks':remarks,
                    'tax_id': tax_id,
                    'tax_price':tax_price,
                    'purchase_line_common_id':purchase_line_common_id,
                    'invoice_line_id':temp.id,
                    #GST ENTRY
                    'hsn_code': hsn_code,
                    'discount_id':discount_id,
                    'discount_rate':discount_rate,
                    'discount_value':discount_value,
                    'taxable_value': taxable_value,
                    'total':total,
                    'cgst_id':cgst_id,
                    'cgst_rate':cgst_rate,
                    'cgst_value': cgst_value,
                    'sgst_id':sgst_id,
                    'sgst_rate':sgst_rate,
                    'sgst_value': sgst_value,
                    'igst_id':igst_id,
                    'igst_rate':igst_rate,
                    'igst_value': igst_value,
                    'taxable_value_after_adding_other':taxable_value_after_adding_other,
                    'no_of_product':no_of_product,
                    'packing_charges':packing_charges,
                    'frieght_charges':frieght_charges,
                    'additional_charges':additional_charges,
                    'insurance_charges':insurance_charges
                    #GST ENTRY
                        })
            cr.execute("UPDATE  prakruti_purchase_invoice SET flag_count_display_product = 1 WHERE prakruti_purchase_invoice.id = cast(%s as integer)",((temp.id),))
        return {}
    
    
    @api.multi
    def unlink(self):
        raise UserError(_('Can\'t Delete record went to further process'))
        return super(PrakrutiPurchaseInvoice, self).unlink()
    
    
    @api.one
    @api.multi
    def action_delete_products(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute('''DELETE FROM prakruti_purchase_invoice_line WHERE prakruti_purchase_invoice_line.invoice_line_id = (%s)''', ((temp.id),))
            cr.execute("UPDATE  prakruti_purchase_invoice SET flag_count =1 WHERE prakruti_purchase_invoice.id = cast(%s as integer)",((temp.id),))
            cr.execute("UPDATE  prakruti_purchase_invoice SET flag_count_display_product = 0 WHERE prakruti_purchase_invoice.id = cast(%s as integer)",
                                    ((temp.id),))
        return {}
    
    @api.onchange('frieght_charges_applied','frieght_charges')    
    def onchange_freight_charges(self):
        if self.frieght_charges_applied == 'no':
            self.frieght_charges = 0.0
    
    @api.model
    def _default_company(self):
        return self.env['res.company']._company_default_get('res.partner') 
    
    _defaults = {
        'company_address': _default_company
        }
    
    @api.depends('invoice_line.quantity','invoice_line.unit_price','invoice_line.status')
    def _compute_untaxed_amount(self):
        for order in self:
            amount_untaxed = total_untaxed_amount = 0.0
            for line in order.invoice_line:
                total_untaxed_amount += line.quantity * line.unit_price
                order.update({
                    'amount_untaxed': total_untaxed_amount
                    })
                
    @api.depends('amount_untaxed','packing_charges','excise_duty','invoice_line.status','discounted_total')
    def _compute_excise_duty(self):
        for order in self:
            total_excise_duty = 0.0
            order.update({                
                'total_excise_duty': (order.discounted_total + order.packing_charges )* (order.excise_duty/100)
                })
            
    #@api.depends('invoice_line.quantity','invoice_line.unit_price','invoice_line.tax_price','invoice_line.discount','total_discount','amount_untaxed','packing_charges','additional_charges','frieght_charges','cash_amount','draft_amount','cheque_amount','invoice_line.status')
    #def _compute_grand_total(self):
        #for order in self:
            #frieght_charges = grand_total =0.0
            #if order.frieght_charges_applied == 'yes':
                #frieght_charges= order.frieght_charges
            #else:
                #frieght_charges = 0.0
            #order.update({
                #'grand_total': order.discounted_total + order.packing_charges + order.total_excise_duty + order.total_tax + frieght_charges + order.additional_charges - order.cash_amount - order.cheque_amount - order.draft_amount
                    #})
    
    @api.depends('grand_total')
    def _get_total_in_words(self):
        for order in self:
            grand_total = val1 = 0.0
            val1_in_words = ""
            for line in order.invoice_line:
                val1 = order.grand_total
                val1_in_words = str(amount_to_text_in_without_word_rupees(round(val1),"Rupee"))
                order.update({
                    'grand_total_in_words': val1_in_words.upper()
                        })
    
    @api.depends('invoice_line.discount','invoice_line.status')
    def _compute_discount_amount(self):
        for order in self:
            discount_amt= 0.0
            for line in order.invoice_line:
                discount_amt += line.discount_value
                order.update({
                    'total_discount': discount_amt
                    })
                
    @api.depends('amount_untaxed','total_discount','invoice_line.discount','invoice_line.status')
    def _compute_discounted_total(self):
        for order in self:
            discounted_total= 0.00
            order.update({
                'discounted_total': order.amount_untaxed - order.total_discount
                })
            
    @api.depends('invoice_line.tax_price','packing_charges','invoice_line.discount','invoice_line.status','total_excise_duty','discounted_total')
    def _compute_tax_total_amount(self):
        for order in self:
            total_tax= common_tax_amount=0.0
            for line in order.invoice_line:
                common_tax_amount += line.tax_price
                order.update({
                    'total_tax': (order.total_excise_duty + order.discounted_total + order.packing_charges) * ((common_tax_amount/len(order.invoice_line))/100)
                    })
    
    @api.one
    @api.multi
    def calculate_total(self):
        cr = self.env.cr
        uid = self.env.uid
        ids = self.ids
        context = 'context'
        for temp in self:
            cr.execute(''' SELECT update_purchase_invoice_gst_calculation(%s)''',((temp.id),)) 
        return {} 
    
class PrakrutiPurchaseInvoiceLine(models.Model):
    _name = 'prakruti.purchase_invoice_line'
    _table = 'prakruti_purchase_invoice_line'    
    
    invoice_line_id = fields.Many2one('prakruti.purchase_invoice', ondelete='cascade')    
    product_id = fields.Many2one('product.product',string='Product',required=True, readonly=1)   
    description = fields.Text(string='Description', readonly=1)
    scheduled_date =fields.Datetime(string='Due On')
    quantity = fields.Float(string='Received Quantity',store=True ,digits=(6,3))
    actual_quantity = fields.Float(string='Quantity', readonly=1 ,digits=(6,3))
    unit_price = fields.Float(string='Unit price' ,digits=(6,3))
    uom_id = fields.Many2one('product.uom',string='UOM', readonly=1)
    discount = fields.Float(string='Discount(%)' ,digits=(6,3))    
    tax_id = fields.Many2one('account.other.tax', string='Taxes', domain=['|', ('active', '=', False), ('active', '=', True)])
    tax_price = fields.Float(related='tax_id.per_amount',string='Taxes', store=True,readonly=True ,digits=(6,3))    
    subtotal= fields.Float(string='Sub Total',compute= '_compute_price_subtotal',store=True ,digits=(6,3))
    total= fields.Float(string='Total' ,digits=(6,3))
    currency_id = fields.Many2one(related='invoice_line_id.currency_id', store=True, string='Currency', readonly=True)
    prakruti_stock_id = fields.Integer('SCREEN COMMON ID')
    remarks = fields.Text('Remarks')
    no_of_packings= fields.Float(string= "No. of Packings" ,digits=(6,3))
    pack_per_qty= fields.Float(string= "Packing Per. Qty." ,digits=(6,3))
    extra_packing= fields.Float(string= "(+)Extra Packing",default=0 ,digits=(6,3))
    accepted_qty = fields.Float('Accepted Qty.', readonly=True ,digits=(6,3))
    rejected_qty = fields.Float('Rejected Qty.', readonly=True ,digits=(6,3))
    status = fields.Selection([
        ('open','Open'),
        ('close','Close')],string= 'Status')
    batch_no = fields.Char('Batch No.')    
    discount_value = fields.Float(string= 'Discount Amount',compute= '_compute_line_discount',store=True ,digits=(6,3))
    purchase_line_common_id = fields.Integer(string="Purchase Line ID") 
    
   
    #GST REQUIREMENT
    hsn_code = fields.Char(string='HSN/SAC',readonly=1)
    discount_id = fields.Many2one('account.other.tax',string= 'Discount(%)',domain=[('select_type', '=', 'discount')])
    discount_rate = fields.Float(related='discount_id.per_amount',string= 'Discount(%)',default=0,store=1)
    discount_value = fields.Float(string= 'Discount Amount',digits=(6,3),readonly=1) 
    taxable_value = fields.Float(string= 'Taxable Value',digits=(6,3),readonly=1)
    total= fields.Float(string='Total',digits=(6,3),readonly=1)
    cgst_id = fields.Many2one('account.other.tax',string= 'CGST Rate',domain=[('select_type', '=', 'cgst')])
    cgst_rate = fields.Float(related='cgst_id.per_amount',string= 'CGST Rate',default=0,store=1)
    cgst_value = fields.Float(string= 'CGST Amount',digits=(6,3),readonly=1)
    sgst_id = fields.Many2one('account.other.tax',string= 'SGST Rate',domain=[('select_type', '=', 'sgst')])
    sgst_rate = fields.Float(related='sgst_id.per_amount',string= 'SGST Rate',default=0,store=1)
    sgst_value = fields.Float(string= 'SGST Amount',digits=(6,3),readonly=1) 
    igst_id = fields.Many2one('account.other.tax',string= 'IGST Rate',domain=[('select_type', '=', 'igst')])
    igst_rate = fields.Float(related='igst_id.per_amount',string= 'IGST Rate',default=0,store=1)
    igst_value = fields.Float(string= 'IGST Amount',digits=(6,3),readonly=1) 
    taxable_value_after_adding_other= fields.Float(string='Taxable Value After Adding Other Charges',digits=(6,3),readonly=1)
    packing_charges = fields.Float(related='invoice_line_id.packing_charges',string='Packing Charges',store=1)
    frieght_charges = fields.Float(related='invoice_line_id.frieght_charges',string='Frieght Charges',store=1)
    additional_charges = fields.Float(related='invoice_line_id.additional_charges',string='Additional Charges',store=1)
    no_of_product = fields.Integer(related='invoice_line_id.no_of_product',string= "No of Products",store=1)
    subtotal = fields.Float(string= 'Sub Total',digits=(6,3),readonly=1)
    insurance_charges = fields.Float(related='invoice_line_id.insurance_charges',string='Insurance Charges',store=1)
    
    
    
    # Total calculation
    @api.depends('quantity', 'unit_price')
    def _compute_price_total(self):
        for order in self:
            total = 0.0            
            order.update({                
                'total': order.quantity * order.unit_price 
            })
    
    # Discount calculation
    @api.depends('quantity','unit_price','discount_rate')
    def _compute_line_discount(self):
        for order in self:
            discount_value = 0.0
            order.update({
                    'discount_value': ((order.quantity * order.unit_price)*(order.discount_rate/100))
                    })
    
    # Taxable Value calculation
    @api.depends('quantity','unit_price','discount_rate')
    def _compute_taxable_value(self):
        for order in self:
            taxable_value = 0.0            
            order.update({                
                'taxable_value': ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100))) 
            })
     
    # Taxable Value After Adding Others
    @api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate')
    def _compute_taxable_value_after_adding_others(self):
        for order in self:
            taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges + order.insurance_charges)/ order.no_of_product
            order.update({                
                'taxable_value_after_adding_other': taxable_value + other_charges
            })
            
    # CGST value calculation
    @api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate')
    def _compute_cgst_value(self):
        for order in self:
            taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges + order.insurance_charges)/ order.no_of_product
            cgst_rate = order.cgst_rate
            cgst_value = (taxable_value + other_charges) * cgst_rate/100
            order.update({                
                'cgst_value': cgst_value
            })
            
    # SGST value calculation
    @api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate')
    def _compute_sgst_value(self):
        for order in self:
            taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges + order.insurance_charges)/ order.no_of_product
            sgst_rate = order.sgst_rate
            sgst_value = (taxable_value + other_charges) * sgst_rate/100
            order.update({                
                'sgst_value': sgst_value
            })
            
    # IGST value calculation
    @api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate')
    def _compute_igst_value(self):
        for order in self:
            taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges + order.insurance_charges)/ order.no_of_product
            igst_rate = order.igst_rate
            igst_value = (taxable_value + other_charges) * igst_rate/100
            order.update({                
                'igst_value': igst_value
            })
            
    # Subtotal calculation
    @api.depends('quantity', 'unit_price','packing_charges','frieght_charges','additional_charges','insurance_charges','no_of_product','discount_rate')
    def _compute_subtotal(self):
        for order in self:
            taxable_value = ((order.quantity * order.unit_price) - ((order.quantity * order.unit_price)*(order.discount_rate/100)))
            other_charges = (order.packing_charges + order.frieght_charges + order.additional_charges +  order.insurance_charges)/ order.no_of_product
            taxable_value_after_adding_other = taxable_value + other_charges
            cgst_rate = order.cgst_rate
            cgst_value = (taxable_value + other_charges) * cgst_rate/100
            sgst_rate = order.sgst_rate
            sgst_value = (taxable_value + other_charges) * sgst_rate/100
            igst_rate = order.igst_rate
            igst_value = (taxable_value + other_charges) * igst_rate/100
            order.update({                
                'subtotal': taxable_value_after_adding_other + cgst_value + sgst_value + igst_value
            }) 
    
    @api.onchange('no_of_packings','pack_per_qty','extra_packing','status')
    def _compute_total_quantity(self):
        for order in self:
            quantity = 0.0
            order.update({
                    'quantity': ((order.no_of_packings * order.pack_per_qty) + order.extra_packing)
                    })